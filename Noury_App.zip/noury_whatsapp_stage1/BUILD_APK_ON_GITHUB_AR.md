# بناء APK تجريبي للمرحلة الثامنة

1. ارفع محتويات هذا المشروع إلى مستودع GitHub الخاص بك.
2. افتح تبويب Actions.
3. اختر Build Noury Debug APK.
4. اضغط Run workflow.
5. بعد اكتمال البناء، افتح نتيجة التشغيل ونزّل Artifact باسم Noury-stage8-debug-apk.
6. فك ضغط Artifact للحصول على app-debug.apk.

هذه نسخة Debug للتجربة وليست إصدار Release موقّعًا للنشر. اختبرها على جهاز ثانٍ أولًا.
