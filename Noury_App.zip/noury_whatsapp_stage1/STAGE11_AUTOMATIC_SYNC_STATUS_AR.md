# Noury Stage 11 — Automatic sync + conflict review

## Changes in this candidate
- SQLite triggers create a durable local outbox for inserts, updates and deletes on Room tables with primary keys.
- WorkManager uses a self-rescheduling chain of one-time jobs with a five-minute initial delay between completed passes. This is used because Android WorkManager periodic requests have a 15-minute minimum interval.
- Sync requires an active network connection. Android may defer jobs due to Doze, battery restrictions, or scheduler load; five minutes is a target interval, not an exact-time guarantee.
- Login requests an immediate sync run.
- Pending outbox events are sent to `public.noury_sync_events`; successful batches are marked synced only after an HTTP success.
- The worker refreshes the Supabase session before syncing.
- Remote events are fetched by monotonically increasing server event id and applied with capture suppression to avoid echo loops.
- Remote row updates use SQLite `ON CONFLICT DO UPDATE` rather than `REPLACE`.
- Conflicts are retained locally and exposed in the new “مراجعة تعارضات المزامنة” screen reachable from the sync login page.
- For each conflict, the user can keep the local row (its outbox event remains pending) or apply the remote event. Choosing cloud marks matching local outbox entries as superseded inside the same transaction.
- Failed network operations return WorkManager retry; the outbox remains durable.

## Important limitations before production use
- This is delayed background polling, not instant push/Realtime delivery.
- The five-minute target is best effort. Android does not guarantee exact execution timing.
- Generic table replication still requires end-to-end validation for every Room entity, foreign-key ordering, composite primary keys, and unsupported column types.
- Conflict resolution must be tested on real devices, especially for foreign-key-dependent records and simultaneous edits.
- This candidate has not been built with Android Gradle or tested on two physical devices in this environment. Do not install on production devices until CI build and controlled tests pass.
- The SQL migration `supabase/11_noury_sync_events.sql` must be run once in the correct NOURY Supabase project before testing.

## Safe test plan
1. Keep the current cloud snapshot and primary phone unchanged; create local/cloud backups first.
2. Run `supabase/11_noury_sync_events.sql` once in NOURY Supabase SQL Editor if not already applied.
3. Build via GitHub Actions and verify green build.
4. Install the same APK on both phones; sign into the same Supabase user.
5. Test one new student on phone A and verify it arrives on phone B after a sync pass.
6. Test one payment and one expense in the reverse direction; verify no duplicates.
7. Test offline edit, close/reopen, restore internet and verify eventual delivery.
8. Test same-row concurrent edits; verify the conflict appears and test both resolution choices.

## Version
- versionName: 2.2.93-sync-5min-conflicts
- versionCode: 112
