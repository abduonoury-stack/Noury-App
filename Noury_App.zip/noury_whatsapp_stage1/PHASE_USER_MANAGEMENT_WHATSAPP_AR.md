# Noury — Phone + Password User Management (Corrected Stage 1)

## القرار المعتمد

هذه المرحلة تستبدل نهائيًا تصميم WhatsApp OTP السابق لتسجيل الدخول. الدخول المعتاد يكون برقم الموبايل وكلمة المرور فقط. رمز WhatsApp مسموح به في استعادة كلمة المرور فقط.

## ما تم تعديله في المصدر

- استبدال تدفق OTP العادي في `SupabaseAuth.kt` بتدفق Supabase Phone + Password.
- إضافة بوابة دخول قبل لوحة التحكم في `AppNav.kt`.
- إضافة `NouryAccessScreen.kt` وفيها الدخول، طلب التسجيل، استعادة كلمة المرور، وتغيير كلمة المرور المؤقتة.
- تحويل شاشة إدارة المستخدمين إلى مراجعة طلبات التسجيل، واختيار الدور، والقبول أو الرفض، وإدارة حالة الحساب.
- إضافة ترحيل `13_noury_phone_password_registration.sql` دون تعديل جداول الطلاب أو Room.
- إضافة Edge Functions: `registration-request`, `account-security`, `password-recovery`، وتحديث `owner-manage-users` و`owner-bootstrap`.
- إنشاء الحساب بعد اعتماد المالك فقط، مع كلمة مرور عشوائية مؤقتة وإرسالها عبر WhatsApp Business Platform الرسمي، ثم فرض تغييرها عند أول دخول.
- منع تكرار اعتماد الطلب بتحويله ذريًا من `pending` إلى `approving` قبل إنشاء الحساب.

## WhatsApp Business Platform

يستخدم الخادم Meta WhatsApp Cloud API الرسمي، ولا يتصل تطبيق Android مباشرة بمزود WhatsApp. يجب إنشاء قالبين معتمدين لدى Meta:

1. `WHATSAPP_LOGIN_TEMPLATE_NAME`: قالب يحتوي ثلاثة متغيرات في نص الرسالة: اسم الموظف، رقم الهاتف، كلمة المرور المؤقتة.
2. `WHATSAPP_RESET_TEMPLATE_NAME`: قالب يحتوي متغيرًا واحدًا لرمز الاستعادة.

اضبط Secrets على Supabase Edge Functions فقط:

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `WHATSAPP_ACCESS_TOKEN`
- `WHATSAPP_PHONE_NUMBER_ID`
- `WHATSAPP_GRAPH_API_VERSION` (إصدار Graph API مدعوم حاليًا من Meta بصيغة `vNN.N`)
- `WHATSAPP_LOGIN_TEMPLATE_NAME`
- `WHATSAPP_RESET_TEMPLATE_NAME`
- `WHATSAPP_TEMPLATE_LANGUAGE` (مثل `ar`)
- `NOURY_RECOVERY_PEPPER` (سر عشوائي طويل مستقل)
- `NOURY_OWNER_BOOTSTRAP_SECRET` (مؤقت لإنشاء المالك لأول مرة فقط)

لا تضع أيًا من مفاتيح الخادم في Android أو Git. بعد تهيئة المالك لأول مرة، احذف `NOURY_OWNER_BOOTSTRAP_SECRET` وعطّل وظيفة `owner-bootstrap`.

## ترتيب الترحيل في بيئة اختبار

1. أنشئ مشروع Supabase تجريبيًا منفصلًا.
2. خذ نسخة احتياطية من قاعدة البيانات.
3. تأكد من تطبيق `09_noury_sync_snapshots.sql` و`11_noury_sync_events.sql` ثم `12_noury_user_management.sql`.
4. راجع ربط المؤسسة القديمة ومعرّف `legacy_owner_id` قبل تطبيق أي ترحيل.
5. طبّق `13_noury_phone_password_registration.sql` في الاختبار فقط.
6. اضبط Secrets وقوالب WhatsApp المعتمدة.
7. انشر Edge Functions من مجلد `supabase/functions`.
8. أنشئ المالك لأول مرة عبر `owner-bootstrap`، أو استخدم استعادة كلمة المرور عبر WhatsApp إذا كان ملف المالك موجودًا بالفعل. ثم احذف سر التهيئة وعطّل الوظيفة.
9. اختبر الطلب والرفض والاعتماد وتغيير كلمة المرور والاستعادة وإيقاف الحساب قبل ربط أي بيانات تشغيلية.

## ضوابط الأمان

- طلب التسجيل لا ينشئ `auth.users` ولا يختار الدور.
- Edge Function تتحقق من جلسة المالك ودوره النشط قبل مراجعة الطلبات.
- كلمة المرور المؤقتة لا تحفظ في قاعدة البيانات ولا تسجل في logs؛ تخزن Supabase Auth كلمة المرور وفق نظامه الآمن.
- رمز الاستعادة يحفظ كـ hash مع انتهاء صلاحية 10 دقائق وحد أقصى 5 محاولات و3 طلبات في الساعة لكل رقم.
- إيقاف الحساب يحدّث `is_active=false` ويحدّث `sessions_revoked_at` ويضع حظر Auth. دالة RLS تتحقق من حالة الحساب ووقت إصدار JWT؛ يجب اختبار سلوك ذلك فعليًا على مشروع Supabase.
- RLS يحمي بيانات Supabase فقط. يجب استكمال صلاحيات الشاشات والعمليات المحلية في Room قبل تسليم التطبيق لكل الأدوار.

## حدود الاختبار الحالية

لم يتم تشغيل Android Build أو Unit Tests أو Instrumented Tests في بيئة إعداد هذه الحزمة؛ ملف Gradle Wrapper JAR وسكربت `gradlew` غير موجودين، ولا يوجد Gradle مثبت محليًا. كما لم يتم اختبار إرسال WhatsApp حقيقي لعدم توفر أسرار Meta والقوالب المعتمدة. لا تعتبر هذه الحزمة إصدار إنتاج قبل استكمال هذه الاختبارات.
