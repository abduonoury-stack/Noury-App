# Noury — Android Academy Management App

## Current correction stage: 2.2.94 Phone + Password
- Normal sign-in uses Egyptian phone number + password. No WhatsApp OTP is used for ordinary login.
- New users submit a pending registration request; only the owner can approve/reject and assign a role.
- Approved accounts receive a temporary password through the official Meta WhatsApp Business Platform template and must change it after first sign-in.
- WhatsApp verification codes are used only for password recovery.
- See `PHASE_USER_MANAGEMENT_WHATSAPP_AR.md` for deployment prerequisites, secrets, migration order, and current test limitations.

# Little Dreams Academy — Android Student & Finance App

## Version 2.2.56 — Refund Lifecycle and Payroll Reversals
- Approved student exit settlements now create linked refund credits; historical settlement refunds are migrated into the unified credit/transaction ledger without double-counting cash outflows.
- Manual refunds can be created from an original non-cancelled receipt with a required reason and document reference, approved by the single owner.
- Payroll entries distinguish an unpaid-entry void from reversal of a payment that actually left cash/bank.
- Actual employee repayments are recorded as account inflows; unreturned balances remain employee receivables and never inflate cash/bank balances.
- Current source baseline before comprehensive upgrade: app 2.2.84 / versionCode 103, Room database version 26, full backup version 13. See COMPREHENSIVE_UPGRADE_STATUS_AR.md for the active upgrade status.
- No APK was built in this preparation environment. Run GitHub Actions before installing this source on operational data. See `UPDATE_2.2.56_FINANCIAL_CYCLES_AR.md` and `RELEASE_MANIFEST_2.2.56_AR.md`.


## 2.2.36 – Settings Centralization
- Period and subscription price management is now accessible only from System Settings.
- Backup and restore is now accessible only from System Settings; removed its dashboard shortcut.
- No database schema or financial behavior changes.


## 2.2.38 – Global Academy Name
- Academy Profile is now the single source of truth for the academy name across all screens, dashboard, receipts, reports, printouts and parent WhatsApp messages.
- Subscription receipt screen displays the centrally managed name instead of allowing a separate local name.
- Restoring a backup refreshes the global academy name immediately.

## الإصدار 2.2.39 – أيام عمل الأكاديمية
- إعداد مركزي لأيام عمل الأكاديمية من الإعدادات، ينعكس على تقاويم حضور وغياب الطلاب والموظفين وتقارير الغياب وخصم غياب الموظفين.
- الإعداد الافتراضي الأحد إلى الخميس، ويمكن تخصيص أي أيام من الأسبوع.

## 2.2.42 – A5 Payment Receipt
- Redesigned monthly subscription receipt as a clean A5 portrait PDF using the academy's purple/peach identity.
- Added guardian, student, class, subscription month, receipt number/date, due/paid/remaining amounts, amount-in-words line, notes, and signature/stamp areas.
- No database schema or collection workflow changes.

## 2.2.47 – Expense Reconciliation
- Unified month filtering for expenses using monthKey, with legacy spentAt fallback.
- Unified committed, paid, and remaining expense totals across dashboard, monthly reports, and expense management.
- Clamped negative and overpaid legacy values consistently at calculation time without mutating stored records.
- Added unit tests for month filtering and invalid legacy payment values.


## الإصدار 2.2.48
تم توحيد مصدر المرتبات مع المصروفات بحيث تكون شؤون العاملين المرجع الأساسي، مع حماية بند المزامنة ومنع التكرار. التفاصيل في `UPDATE_2.2.48_PAYROLL_EXPENSE_SOURCE_OF_TRUTH_AR.md`.

## الإصدار 2.2.49
تم توحيد تعريف صافي الحركة النقدية بين لوحة التحكم والتقرير الشهري، بحيث يعتمد على جميع الإيصالات السارية مطروحًا منها المصروفات المدفوعة. ويظل تحصيل الاشتراكات مؤشرًا منفصلًا عن إجمالي المقبوضات. التفاصيل في `UPDATE_2.2.49_FINANCIAL_RECONCILIATION_AR.md`.

## 2.2.50 — Cash Lifecycle Audit
- Added a read-only audit across refund credits/transactions, student exit settlement events, payroll payment ledgers, employee loans, and HR-synced salary expenses.
- Added financial report visibility for audit issues, including possible duplicate refunds for manual review.
- No Room schema migration and no automatic mutation of historical financial records.
- General refund recording remains disabled; refund outflows are not automatically deducted from net cash until legacy overlap is reconciled.

## 2.2.51 — Cash Movement Ledger
- Added a read-only monthly cash-movement projection across valid receipts, paid expenses, refunds, active payroll payments, and employee loans.
- Shows source references, confirmed inflows/outflows, net period movement, and excluded records requiring review.
- Excludes HR_SYNC salary summary rows and flags legacy manual salary expense rows to prevent salary double counting.
- Potential duplicate refund pairs remain visible but are excluded from totals pending review.
- No database schema migration; this is not an opening-balance-backed cash account balance.
- See `UPDATE_2.2.51_CASH_LEDGER_AR.md` for calculation rules and limitations.

## 2.2.52 — Cash Control
- أضيف رصيد افتتاحي موثق وسجل تاريخي لاعتمادات الرصيد، مع سجل مستقل للجرد الفعلي ومقارنة الفعلي بالرصيد المتوقع.
- تمت ترقية قاعدة البيانات إلى Room 18 والنسخ الاحتياطي إلى الإصدار 9 دون تعديل السجلات المالية السابقة.
- راجع `UPDATE_2.2.52_CASH_CONTROL_AR.md` لمعرفة حدود التواريخ التقديرية للمدفوعات القديمة.


## الإصدار 2.2.58 — الإعفاء الكامل من الاشتراك
يسمح بالإعفاء الكامل للطالب في شهر محدد دون إنشاء حركة نقدية، ويظهر السبب وحالة التسوية في كشف الحساب وإشعار PDF. راجع `UPDATE_2.2.58_FULL_TUITION_EXEMPTION_AR.md`.
