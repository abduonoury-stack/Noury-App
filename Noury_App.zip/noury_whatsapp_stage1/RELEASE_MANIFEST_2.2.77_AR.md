# Noury App 2.2.77 — Release Manifest

- Version Name: 2.2.77
- Version Code: 96
- Base: 2.2.76
- Main change: Reports hub and independent report sections.
- Database schema: unchanged.
- Data migration: none.
- Financial transaction logic: unchanged.
- APK build status: not built in this environment; run CI before installation.
