# Release Manifest — Noury App 2.2.76

- Version Code: 95
- Version Name: 2.2.76
- Base: 2.2.75 UI Review
- Main change: first-run academy profile setup and shared academy identity state.
- Data safety: no Room schema changes; existing receipt_profile preferences retained; existing customized installations bypass onboarding.
- Build status: source prepared; Gradle build not run in this environment.
