-- Noury teacher registration requests (safe, independent migration)
-- Does NOT alter noury_sync_snapshots, owner_id, or any sync RLS policy.
create table if not exists public.noury_registration_requests (
  id uuid primary key default gen_random_uuid(),
  phone text not null,
  display_name text not null,
  requested_role text not null default 'teacher' check (requested_role = 'teacher'),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  organization_id uuid references public.noury_organizations(id) on delete cascade,
  reviewed_by uuid references auth.users(id) on delete set null,
  reviewed_at timestamptz,
  created_user_id uuid references auth.users(id) on delete set null,
  rejection_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists noury_registration_requests_status_created_idx
  on public.noury_registration_requests(status, created_at desc);
create unique index if not exists noury_registration_requests_one_pending_phone_idx
  on public.noury_registration_requests(phone) where status = 'pending';
alter table public.noury_registration_requests enable row level security;
revoke all on public.noury_registration_requests from anon, authenticated;
-- All access is through Edge Function using service_role; no client-side table access.
grant select, insert, update, delete on public.noury_registration_requests to service_role;
