-- Noury Stage 9: immutable cloud snapshots for the first, primary-device transfer.
-- Run this script in Supabase SQL Editor while signed in as project owner.
-- Each authenticated user can only insert/read their own snapshots.

create table if not exists public.noury_sync_snapshots (
    id uuid primary key default gen_random_uuid(),
    owner_id uuid not null references auth.users(id) on delete cascade,
    device_id text not null,
    app_version text not null,
    backup_version integer not null,
    row_count integer not null check (row_count >= 0),
    checksum text not null,
    payload jsonb not null,
    created_at timestamptz not null default now()
);

create index if not exists noury_sync_snapshots_owner_created_idx
    on public.noury_sync_snapshots (owner_id, created_at desc);

alter table public.noury_sync_snapshots enable row level security;

drop policy if exists "noury snapshots insert own" on public.noury_sync_snapshots;
create policy "noury snapshots insert own"
    on public.noury_sync_snapshots for insert to authenticated
    with check (auth.uid() = owner_id);

drop policy if exists "noury snapshots select own" on public.noury_sync_snapshots;
create policy "noury snapshots select own"
    on public.noury_sync_snapshots for select to authenticated
    using (auth.uid() = owner_id);

grant insert, select on public.noury_sync_snapshots to authenticated;
