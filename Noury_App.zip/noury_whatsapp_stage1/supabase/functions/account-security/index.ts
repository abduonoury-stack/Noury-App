import { createClient } from "npm:@supabase/supabase-js@2";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return reply({ error: "Method not allowed" }, 405);
  const url = Deno.env.get("SUPABASE_URL"), service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"), anon = Deno.env.get("SUPABASE_ANON_KEY");
  const authorization = req.headers.get("Authorization") ?? "";
  if (!url || !service || !anon || !authorization.startsWith("Bearer ")) return reply({ error: "Unauthorized" }, 401);
  const admin = createClient(url, service, { auth: { persistSession: false } });
  const caller = createClient(url, anon, { global: { headers: { Authorization: authorization } }, auth: { persistSession: false } });
  try {
    const { data, error } = await caller.auth.getUser();
    if (error || !data.user?.phone) return reply({ error: "Unauthorized" }, 401);
    const body = await req.json();
    const currentPassword = String(body.current_password ?? ""), newPassword = String(body.new_password ?? "");
    if (newPassword.length < 10 || !currentPassword || currentPassword === newPassword) return reply({ error: "كلمة المرور الجديدة يجب أن تختلف عن المؤقتة وألا تقل عن 10 أحرف." }, 400);
    const verifier = createClient(url, anon, { auth: { persistSession: false } });
    const { data: verified, error: verifyError } = await verifier.auth.signInWithPassword({ phone: data.user.phone, password: currentPassword });
    if (verifyError || verified.user?.id !== data.user.id) return reply({ error: "كلمة المرور الحالية غير صحيحة." }, 401);
    const { data: profile, error: profileError } = await admin.from("noury_user_profiles").select("is_active,must_change_password").eq("user_id", data.user.id).maybeSingle();
    if (profileError) throw profileError;
    if (!profile?.is_active || !profile.must_change_password) return reply({ error: "لا يوجد تغيير إجباري معلق لهذا الحساب." }, 403);
    const { error: passwordError } = await admin.auth.admin.updateUserById(data.user.id, { password: newPassword });
    if (passwordError) throw passwordError;
    const { error: clearError } = await admin.from("noury_user_profiles").update({ must_change_password: false, updated_at: new Date().toISOString() }).eq("user_id", data.user.id);
    if (clearError) throw clearError;
    return reply({ ok: true });
  } catch (error) { return reply({ error: error instanceof Error ? error.message : "Password update failed" }, 400); }
});
function reply(body: unknown, status = 200) { return new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } }); }
