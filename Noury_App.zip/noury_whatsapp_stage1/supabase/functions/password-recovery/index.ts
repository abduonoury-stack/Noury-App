import { createClient } from "npm:@supabase/supabase-js@2";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return reply({ error: "Method not allowed" }, 405);
  const url = Deno.env.get("SUPABASE_URL"), service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !service) return reply({ error: "Server configuration missing" }, 500);
  const admin = createClient(url, service, { auth: { persistSession: false } });
  try {
    const body = await req.json();
    const action = String(body.action ?? "request");
    const phone = normalizeEgyptianPhone(String(body.phone ?? ""));
    if (action === "request") {
      const since = new Date(Date.now() - 60 * 60 * 1000).toISOString();
      const { count } = await admin.from("noury_password_reset_challenges").select("id", { count: "exact", head: true }).eq("phone", phone).gte("created_at", since);
      if ((count ?? 0) >= 3) return reply({ error: "تجاوزت عدد محاولات الاستعادة. حاول لاحقًا." }, 429);
      const { data: profile } = await admin.from("noury_user_profiles").select("user_id,is_active").eq("phone", phone).maybeSingle();
      // Same outward response whether the phone exists or not.
      if (profile?.is_active) {
        const code = randomDigits(6);
        const pepper = Deno.env.get("NOURY_RECOVERY_PEPPER");
        if (!pepper) return reply({ error: "خدمة الاستعادة غير مهيأة" }, 503);
        const hash = await sha256(`${phone}:${code}:${pepper}`);
        await admin.from("noury_password_reset_challenges").update({ used_at: new Date().toISOString() }).eq("phone", phone).is("used_at", null);
        const { error } = await admin.from("noury_password_reset_challenges").insert({ phone, code_hash: hash, expires_at: new Date(Date.now() + 10 * 60 * 1000).toISOString() });
        if (error) throw error;
        await sendWhatsAppTemplate(phone, Deno.env.get("WHATSAPP_RESET_TEMPLATE_NAME") ?? "", [code]);
      }
      return reply({ ok: true, message: "إذا كان الرقم مسجلًا ونشطًا، فسيصلك رمز استعادة على واتساب." });
    }
    if (action === "reset") {
      const code = String(body.code ?? "").trim();
      const password = String(body.new_password ?? "");
      if (!/^\d{6}$/.test(code) || password.length < 10) return reply({ error: "أدخل الرمز الصحيح وكلمة مرور لا تقل عن 10 أحرف." }, 400);
      const { data: challenge, error } = await admin.from("noury_password_reset_challenges").select("id,code_hash,expires_at,attempts")
        .eq("phone", phone).is("used_at", null).order("created_at", { ascending: false }).limit(1).maybeSingle();
      if (error) throw error;
      if (!challenge || new Date(challenge.expires_at).getTime() < Date.now() || challenge.attempts >= 5) return reply({ error: "رمز الاستعادة غير صالح أو انتهت صلاحيته." }, 400);
      const pepper = Deno.env.get("NOURY_RECOVERY_PEPPER");
      if (!pepper) return reply({ error: "خدمة الاستعادة غير مهيأة" }, 503);
      const candidate = await sha256(`${phone}:${code}:${pepper}`);
      if (candidate !== challenge.code_hash) {
        await admin.from("noury_password_reset_challenges").update({ attempts: challenge.attempts + 1 }).eq("id", challenge.id);
        return reply({ error: "رمز الاستعادة غير صحيح." }, 400);
      }
      const { data: profile } = await admin.from("noury_user_profiles").select("user_id,is_active").eq("phone", phone).maybeSingle();
      if (!profile?.is_active) return reply({ error: "الحساب غير نشط." }, 403);
      const { error: updateError } = await admin.auth.admin.updateUserById(profile.user_id, { password });
      if (updateError) throw updateError;
      await admin.from("noury_user_profiles").update({ must_change_password: false, sessions_revoked_at: new Date().toISOString(), updated_at: new Date().toISOString() }).eq("user_id", profile.user_id);
      await admin.from("noury_password_reset_challenges").update({ used_at: new Date().toISOString() }).eq("id", challenge.id);
      return reply({ ok: true, message: "تم تغيير كلمة المرور. سجل الدخول بكلمة المرور الجديدة." });
    }
    return reply({ error: "Unsupported action" }, 400);
  } catch (error) { return reply({ error: error instanceof Error ? error.message : "Recovery failed" }, 400); }
});

async function sendWhatsAppTemplate(phone: string, template: string, values: string[]) {
  const token = Deno.env.get("WHATSAPP_ACCESS_TOKEN"), id = Deno.env.get("WHATSAPP_PHONE_NUMBER_ID"), version = Deno.env.get("WHATSAPP_GRAPH_API_VERSION");
  if (!token || !id || !version || !/^v\d+\.\d+$/.test(version) || !template) throw new Error("WhatsApp Cloud API secrets/template are not configured");
  const response = await fetch(`https://graph.facebook.com/${version}/${id}/messages`, {
    method: "POST", headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({ messaging_product: "whatsapp", to: phone.replace(/\D/g, ""), type: "template", template: { name: template, language: { code: Deno.env.get("WHATSAPP_TEMPLATE_LANGUAGE") ?? "ar" }, components: [{ type: "body", parameters: values.map(text => ({ type: "text", text })) }] } }),
  });
  if (!response.ok) throw new Error(`WhatsApp delivery request failed (${response.status})`);
}
function randomDigits(length: number) { const bytes = new Uint8Array(length); crypto.getRandomValues(bytes); return Array.from(bytes, b => String(b % 10)).join(""); }
async function sha256(value: string) { const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)); return Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, "0")).join(""); }
function normalizeEgyptianPhone(value: string) { const d = value.replace(/\D/g, ""); const p = d.startsWith("0020") ? `+${d.slice(2)}` : d.startsWith("20") ? `+${d}` : d.startsWith("0") ? `+20${d.slice(1)}` : `+20${d}`; if (!/^\+201[0125]\d{8}$/.test(p)) throw new Error("Invalid Egyptian mobile number"); return p; }
function reply(body: unknown, status = 200) { return new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } }); }
