import { createClient } from "npm:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-noury-bootstrap-secret",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return reply({ error: "Method not allowed" }, 405);

  const expected = Deno.env.get("NOURY_OWNER_BOOTSTRAP_SECRET") ?? "";
  const supplied = req.headers.get("x-noury-bootstrap-secret") ?? "";
  if (!expected || !supplied || !constantTimeEqual(expected, supplied)) {
    return reply({ error: "Unauthorized" }, 401);
  }

  const url = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !serviceKey) return reply({ error: "Server configuration missing" }, 500);

  try {
    const body = await req.json();
    const phone = normalizeEgyptianPhone(String(body.phone ?? ""));
    if (phone !== "+201273288127") {
      return reply({ error: "Bootstrap phone does not match the configured owner phone" }, 400);
    }

    const password = String(body.initial_password ?? "");
    if (password.length < 8) {
      return reply({ error: "كلمة المرور يجب ألا تقل عن 8 أحرف" }, 400);
    }

    const displayName = String(body.display_name ?? "مالك Noury").trim().slice(0, 80);
    if (!displayName) return reply({ error: "display_name is required" }, 400);

    // Email/password is used internally by Supabase. This address is not a mailbox.
    // Keep the same mapping in the Android app and disable email confirmation.
    const syntheticEmail = syntheticEmailForPhone(phone);
    const admin = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });

    const { data, error } = await admin.auth.admin.createUser({
      email: syntheticEmail,
      password,
      email_confirm: true,
      user_metadata: { display_name: displayName, phone },
      app_metadata: { noury_role: "owner" },
    });

    if (error) {
      const message = error.message.toLowerCase();
      if (message.includes("already") || message.includes("registered") || message.includes("exists")) {
        return reply({ error: "حساب المالك موجود بالفعل. جرّب تسجيل الدخول بدل إنشاء حساب جديد." }, 409);
      }
      console.error("Owner bootstrap failed:", error.message);
      return reply({ error: "تعذر إنشاء حساب المالك في Supabase" }, 400);
    }

    if (!data.user) return reply({ error: "Supabase لم يُرجع مستخدمًا بعد الإنشاء" }, 500);

    return reply({
      ok: true,
      message: "Owner Auth account created. Disable/delete this bootstrap function and remove its secret now.",
      user_id: data.user.id,
      login_email: syntheticEmail,
    }, 200);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Invalid request";
    return reply({ error: message }, 400);
  }
});

function syntheticEmailForPhone(phone: string): string {
  return `${phone.replace(/\D/g, "")}@users.noury.app`;
}

function normalizeEgyptianPhone(value: string): string {
  const digits = value.replace(/\D/g, "");
  const phone = digits.startsWith("0020") ? `+${digits.slice(2)}`
    : digits.startsWith("20") ? `+${digits}`
    : digits.startsWith("0") ? `+20${digits.slice(1)}`
    : `+20${digits}`;
  if (!/^\+201[0125]\d{8}$/.test(phone)) throw new Error("أدخل رقم موبايل مصري صحيحًا");
  return phone;
}

function constantTimeEqual(a: string, b: string): boolean {
  const encoder = new TextEncoder();
  const aa = encoder.encode(a);
  const bb = encoder.encode(b);
  let diff = aa.length ^ bb.length;
  const length = Math.max(aa.length, bb.length);
  for (let i = 0; i < length; i++) diff |= (aa[i] ?? 0) ^ (bb[i] ?? 0);
  return diff === 0;
}

function reply(body: unknown, status: number) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, "Content-Type": "application/json" },
  });
}
