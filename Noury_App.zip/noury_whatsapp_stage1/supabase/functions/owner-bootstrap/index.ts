import { createClient } from "npm:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return reply({ error: "Method not allowed" }, 405);

  const expected = Deno.env.get("NOURY_OWNER_BOOTSTRAP_SECRET");
  const supplied = req.headers.get("x-noury-bootstrap-secret");
  if (!expected || !supplied || supplied !== expected) return reply({ error: "Unauthorized" }, 401);

  const url = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !serviceKey) return reply({ error: "Server configuration missing" }, 500);

  const admin = createClient(url, serviceKey, { auth: { persistSession: false } });
  try {
    const { data: existingOwner, error: ownerCheckError } = await admin
      .from("noury_user_profiles").select("user_id").eq("role", "owner").maybeSingle();
    if (ownerCheckError) throw ownerCheckError;
    if (existingOwner) return reply({ error: "Owner already initialized" }, 409);

    const body = await req.json();
    const phone = normalizeEgyptianPhone(String(body.phone ?? ""));
    const displayName = String(body.display_name ?? "مالك Noury").trim().slice(0, 80);
    const initialPassword = String(body.initial_password ?? "");
    if (initialPassword.length < 8) return reply({ error: "initial_password must contain at least 8 characters" }, 400);
    if (phone !== "+201273288127") return reply({ error: "Bootstrap phone does not match the configured owner phone" }, 400);
    const legacyOwnerId = String(body.legacy_owner_id ?? "").trim();
    if (!displayName) return reply({ error: "display_name is required" }, 400);

    let organizationId: string;
    if (legacyOwnerId) {
      if (!/^[0-9a-f-]{36}$/i.test(legacyOwnerId)) return reply({ error: "Invalid legacy_owner_id" }, 400);
      const { data: legacyOrg, error: legacyError } = await admin.from("noury_organizations")
        .select("id").eq("id", legacyOwnerId).maybeSingle();
      if (legacyError) throw legacyError;
      if (!legacyOrg) return reply({ error: "Legacy organization not found; do not guess this ID" }, 404);
      organizationId = legacyOrg.id;
    } else {
      const { data: org, error: orgError } = await admin.from("noury_organizations")
        .insert({ name: "Noury Organization" }).select("id").single();
      if (orgError) throw orgError;
      organizationId = org.id;
    }

    const { data: created, error: createError } = await admin.auth.admin.createUser({
      phone,
      password: initialPassword,
      phone_confirm: true,
      user_metadata: { display_name: displayName, noury_role: "owner" },
    });
    if (createError) throw createError;
    if (!created.user) throw new Error("Auth user creation returned no user");

    const { error: profileError } = await admin.from("noury_user_profiles").insert({
      user_id: created.user.id,
      organization_id: organizationId,
      phone,
      display_name: displayName,
      role: "owner",
      is_active: true,
    });
    if (profileError) {
      await admin.auth.admin.deleteUser(created.user.id);
      throw profileError;
    }
    const { error: organizationUpdateError } = await admin.from("noury_organizations")
      .update({ owner_user_id: created.user.id }).eq("id", organizationId);
    if (organizationUpdateError) throw organizationUpdateError;
    await admin.from("noury_user_audit_log").insert({
      target_user_id: created.user.id,
      action: "owner_bootstrapped",
      details: { phone, organization_id: organizationId, linked_legacy_org: Boolean(legacyOwnerId) },
    });
    return reply({ ok: true, message: "Owner created. Remove the bootstrap secret and disable this function now." }, 200);
  } catch (error) {
    return reply({ error: error instanceof Error ? error.message : "Bootstrap failed" }, 400);
  }
});

function normalizeEgyptianPhone(value: string): string {
  const digits = value.replace(/\D/g, "");
  const phone = digits.startsWith("0020") ? `+${digits.slice(2)}`
    : digits.startsWith("20") ? `+${digits}`
    : digits.startsWith("0") ? `+20${digits.slice(1)}`
    : `+20${digits}`;
  if (!/^\+201[0125]\d{8}$/.test(phone)) throw new Error("Invalid Egyptian mobile number");
  return phone;
}

function reply(body: unknown, status: number) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, "Content-Type": "application/json" },
  });
}
