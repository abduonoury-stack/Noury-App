import { createClient } from "npm:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return reply({ error: "Method not allowed" }, 405);

  const expected = Deno.env.get("NOURY_OWNER_BOOTSTRAP_SECRET");
  const supplied = req.headers.get("x-noury-bootstrap-secret");
  if (!expected || !supplied || supplied !== expected) return reply({ error: "Unauthorized" }, 401);

  const url = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !serviceKey) return reply({ error: "Server configuration missing" }, 500);

  const admin = createClient(url, serviceKey, { auth: { persistSession: false } });
  try {
    const { data: existingOwner, error: ownerCheckError } = await admin
      .from("noury_user_profiles").select("user_id").eq("role", "owner").maybeSingle();
    if (ownerCheckError) throw ownerCheckError;
    if (existingOwner) return reply({ error: "Owner already initialized" }, 409);

    const body = await req.json();
    const phone = normalizeEgyptianPhone(String(body.phone ?? ""));
    const displayName = String(body.display_name ?? "مالك Noury").trim().slice(0, 80);
    const legacyOwnerId = String(body.legacy_owner_id ?? "").trim();
    if (!displayName) return reply({ error: "display_name is required" }, 400);

    let organizationId: string;
    if (legacyOwnerId) {
      if (!/^[0-9a-f-]{36}$/i.test(legacyOwnerId)) return reply({ error: "Invalid legacy_owner_id" }, 400);
      const { data: legacyOrg, error: legacyError } = await admin.from("noury_organizations")
        .select("id").eq("id", legacyOwnerId).maybeSingle();
      if (legacyError) throw legacyError;
      if (!legacyOrg) return reply({ error: "Legacy organization not found; do not guess this ID" }, 404);
      organizationId = legacyOrg.id;
    } else {
      const { data: org, error: orgError } = await admin.from("noury_organizations")
        .insert({ name: "Noury Organization" }).select("id").single();
      if (orgError) throw orgError;
      organizationId = org.id;
    }

    const temporaryPassword = generateTemporaryPassword();
    const { data: created, error: createError } = await admin.auth.admin.createUser({
      phone,
      phone_confirm: true,
      password: temporaryPassword,
      user_metadata: { display_name: displayName, noury_role: "owner", must_change_password: true },
    });
    if (createError) throw createError;
    if (!created.user) throw new Error("Auth user creation returned no user");

    const { error: profileError } = await admin.from("noury_user_profiles").insert({
      user_id: created.user.id,
      organization_id: organizationId,
      phone,
      display_name: displayName,
      role: "owner",
      is_active: true,
      must_change_password: true,
    });
    if (profileError) {
      await admin.auth.admin.deleteUser(created.user.id);
      throw profileError;
    }
    const { error: organizationUpdateError } = await admin.from("noury_organizations")
      .update({ owner_user_id: created.user.id }).eq("id", organizationId);
    if (organizationUpdateError) {
      await admin.from("noury_user_profiles").delete().eq("user_id", created.user.id);
      await admin.auth.admin.deleteUser(created.user.id);
      throw organizationUpdateError;
    }
    try {
      await sendWhatsAppTemplate(phone, Deno.env.get("WHATSAPP_LOGIN_TEMPLATE_NAME") ?? "", [displayName, phone, temporaryPassword]);
    } catch (deliveryError) {
      await admin.from("noury_user_profiles").delete().eq("user_id", created.user.id);
      await admin.auth.admin.deleteUser(created.user.id);
      await admin.from("noury_organizations").update({ owner_user_id: null }).eq("id", organizationId);
      throw deliveryError;
    }
    await admin.from("noury_user_audit_log").insert({
      target_user_id: created.user.id,
      action: "owner_bootstrapped",
      details: { phone, organization_id: organizationId, linked_legacy_org: Boolean(legacyOwnerId) },
    });
    return reply({ ok: true, message: "Owner created. Remove the bootstrap secret and disable this function now." }, 200);
  } catch (error) {
    return reply({ error: error instanceof Error ? error.message : "Bootstrap failed" }, 400);
  }
});

function generateTemporaryPassword() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%";
  const bytes = new Uint8Array(24); crypto.getRandomValues(bytes);
  return Array.from(bytes, value => alphabet[value % alphabet.length]).join("");
}

async function sendWhatsAppTemplate(phone: string, template: string, values: string[]) {
  const token = Deno.env.get("WHATSAPP_ACCESS_TOKEN"), id = Deno.env.get("WHATSAPP_PHONE_NUMBER_ID"), version = Deno.env.get("WHATSAPP_GRAPH_API_VERSION");
  if (!token || !id || !version || !/^v\d+\.\d+$/.test(version) || !template) throw new Error("WhatsApp Cloud API secrets/template are not configured");
  const response = await fetch(`https://graph.facebook.com/${version}/${id}/messages`, {
    method: "POST", headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({ messaging_product: "whatsapp", to: phone.replace(/\D/g, ""), type: "template", template: {
      name: template, language: { code: Deno.env.get("WHATSAPP_TEMPLATE_LANGUAGE") ?? "ar" },
      components: [{ type: "body", parameters: values.map(text => ({ type: "text", text })) }],
    } }),
  });
  if (!response.ok) throw new Error(`WhatsApp delivery request failed (${response.status})`);
}

function normalizeEgyptianPhone(value: string): string {
  const digits = value.replace(/\D/g, "");
  const phone = digits.startsWith("0020") ? `+${digits.slice(2)}`
    : digits.startsWith("20") ? `+${digits}`
    : digits.startsWith("0") ? `+20${digits.slice(1)}`
    : `+20${digits}`;
  if (!/^\+201[0125]\d{8}$/.test(phone)) throw new Error("Invalid Egyptian mobile number");
  return phone;
}

function reply(body: unknown, status: number) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, "Content-Type": "application/json" },
  });
}
