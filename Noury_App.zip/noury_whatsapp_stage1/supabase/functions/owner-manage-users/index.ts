import { createClient } from "npm:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return reply({ error: "Method not allowed" }, 405);

  const url = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !serviceKey) return reply({ error: "Server configuration missing" }, 500);
  const authorization = req.headers.get("Authorization") ?? "";
  if (!authorization.startsWith("Bearer ")) return reply({ error: "Unauthorized" }, 401);

  const admin = createClient(url, serviceKey, { auth: { persistSession: false } });
  const callerClient = createClient(url, Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
    global: { headers: { Authorization: authorization } },
    auth: { persistSession: false },
  });
  try {
    const { data: userData, error: userError } = await callerClient.auth.getUser();
    if (userError || !userData.user) return reply({ error: "Unauthorized" }, 401);
    const callerId = userData.user.id;
    const { data: callerProfile, error: profileError } = await admin
      .from("noury_user_profiles").select("role,is_active,organization_id").eq("user_id", callerId).maybeSingle();
    if (profileError) throw profileError;
    if (!callerProfile || callerProfile.role !== "owner" || callerProfile.is_active !== true) {
      return reply({ error: "Owner permission required" }, 403);
    }

    const body = await req.json();
    const action = String(body.action ?? "");

    if (action === "list") {
      const { data, error } = await admin.from("noury_user_profiles")
        .select("user_id,phone,display_name,role,is_active,created_at,updated_at")
        .eq("organization_id", callerProfile.organization_id)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return reply({ users: data ?? [] }, 200);
    }

    if (action === "create") {
      return reply({ error: "Direct account creation is disabled. Use the pending registration approval workflow." }, 410);
    }

    if (action === "set_active") {
      const targetId = String(body.user_id ?? "");
      const active = body.is_active === true;
      if (!targetId || targetId === callerId) return reply({ error: "Invalid target account" }, 400);
      const { data: target, error: targetError } = await admin.from("noury_user_profiles")
        .select("role").eq("user_id", targetId).eq("organization_id", callerProfile.organization_id).maybeSingle();
      if (targetError) throw targetError;
      if (!target || target.role === "owner") return reply({ error: "Target account not found or protected" }, 404);
      const { error } = await admin.from("noury_user_profiles")
        .update({ is_active: active, updated_at: new Date().toISOString() })
        .eq("user_id", targetId).eq("organization_id", callerProfile.organization_id);
      if (error) throw error;
      const { error: banError } = await admin.auth.admin.updateUserById(targetId, {
        ban_duration: active ? "none" : "876000h",
      });
      if (banError) throw banError;
      await audit(admin, callerId, targetId, active ? "staff_activated" : "staff_deactivated", {});
      return reply({ ok: true }, 200);
    }

    if (action === "set_role") {
      const targetId = String(body.user_id ?? "");
      const role = String(body.role ?? "");
      if (!targetId || targetId === callerId) return reply({ error: "Invalid target account" }, 400);
      if (!["admin", "accountant", "teacher"].includes(role)) return reply({ error: "Invalid staff role" }, 400);
      const { data: target, error: targetError } = await admin.from("noury_user_profiles")
        .select("role").eq("user_id", targetId).eq("organization_id", callerProfile.organization_id).maybeSingle();
      if (targetError) throw targetError;
      if (!target || target.role === "owner") return reply({ error: "Target account not found or protected" }, 404);
      const { error } = await admin.from("noury_user_profiles")
        .update({ role, updated_at: new Date().toISOString() })
        .eq("user_id", targetId).eq("organization_id", callerProfile.organization_id);
      if (error) throw error;
      await audit(admin, callerId, targetId, "staff_role_changed", { role });
      return reply({ ok: true }, 200);
    }

    return reply({ error: "Unsupported action" }, 400);
  } catch (error) {
    return reply({ error: error instanceof Error ? error.message : "Request failed" }, 400);
  }
});

async function audit(client: any, actor: string, target: string, action: string, details: Record<string, unknown>) {
  const { error } = await client.from("noury_user_audit_log").insert({
    actor_user_id: actor, target_user_id: target, action, details,
  });
  if (error) throw error;
}

function normalizeEgyptianPhone(value: string): string {
  const digits = value.replace(/\D/g, "");
  const phone = digits.startsWith("0020") ? `+${digits.slice(2)}`
    : digits.startsWith("20") ? `+${digits}`
    : digits.startsWith("0") ? `+20${digits.slice(1)}`
    : `+20${digits}`;
  if (!/^\+201[0125]\d{8}$/.test(phone)) throw new Error("Invalid Egyptian mobile number");
  return phone;
}

function reply(body: unknown, status: number) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, "Content-Type": "application/json" },
  });
}
