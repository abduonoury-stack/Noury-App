import { createClient } from "npm:@supabase/supabase-js@2";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return reply({ error: "Method not allowed" }, 405);
  const url = Deno.env.get("SUPABASE_URL"), serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !serviceKey) return reply({ error: "Server configuration missing" }, 500);
  const admin = createClient(url, serviceKey, { auth: { persistSession: false } });
  try {
    const body = await req.json();
    const action = String(body.action ?? "");
    // Public teacher request: no password is accepted or stored here.
    if (action === "request_teacher") {
      const phone = normalizeEgyptianPhone(String(body.phone ?? ""));
      const displayName = String(body.display_name ?? "").trim().slice(0, 80);
      if (displayName.length < 2) return reply({ error: "اكتب اسم المدرس بشكل صحيح" }, 400);
      const { data: existing } = await admin.from("noury_user_profiles").select("user_id").eq("phone", phone).maybeSingle();
      if (existing) return reply({ error: "هذا الرقم لديه حساب بالفعل. تواصل مع المالك." }, 409);
      const { data: pending } = await admin.from("noury_registration_requests").select("id").eq("phone", phone).eq("status", "pending").maybeSingle();
      if (pending) return reply({ ok: true, message: "يوجد طلب تسجيل قيد المراجعة بالفعل." }, 200);
      const { error } = await admin.from("noury_registration_requests").insert({ phone, display_name: displayName, requested_role: "teacher" });
      if (error) throw error;
      return reply({ ok: true, message: "تم إرسال طلب إنشاء حساب المدرس. ينتظر موافقة المالك." }, 200);
    }
    const authorization = req.headers.get("Authorization") ?? "";
    if (!authorization.startsWith("Bearer ")) return reply({ error: "Unauthorized" }, 401);
    const callerClient = createClient(url, Deno.env.get("SUPABASE_ANON_KEY") ?? "", { global: { headers: { Authorization: authorization } }, auth: { persistSession: false } });
    const { data: userData, error: userError } = await callerClient.auth.getUser();
    if (userError || !userData.user) return reply({ error: "Unauthorized" }, 401);
    const callerId = userData.user.id;
    const { data: callerProfile, error: profileError } = await admin.from("noury_user_profiles").select("role,is_active,organization_id").eq("user_id", callerId).maybeSingle();
    if (profileError) throw profileError;
    if (!callerProfile || callerProfile.role !== "owner" || callerProfile.is_active !== true) return reply({ error: "Owner permission required" }, 403);
    if (action === "list") {
      const { data, error } = await admin.from("noury_user_profiles").select("user_id,phone,display_name,role,is_active,created_at,updated_at").eq("organization_id", callerProfile.organization_id).order("created_at", { ascending: true });
      if (error) throw error;
      return reply({ users: data ?? [] }, 200);
    }
    if (action === "list_pending") {
      const { data, error } = await admin.from("noury_registration_requests").select("id,phone,display_name,status,created_at").eq("status", "pending").order("created_at", { ascending: true });
      if (error) throw error;
      return reply({ requests: data ?? [] }, 200);
    }
    if (action === "approve_teacher") {
      const requestId = String(body.request_id ?? ""), password = String(body.initial_password ?? "");
      if (!/^[0-9a-f-]{36}$/i.test(requestId)) return reply({ error: "طلب التسجيل غير صحيح" }, 400);
      if (password.length < 8) return reply({ error: "كلمة المرور الأولية يجب ألا تقل عن 8 أحرف" }, 400);
      const { data: registration, error: requestError } = await admin.from("noury_registration_requests").select("*").eq("id", requestId).eq("status", "pending").maybeSingle();
      if (requestError) throw requestError;
      if (!registration) return reply({ error: "الطلب غير موجود أو تمت مراجعته مسبقًا" }, 404);
      const email = syntheticEmailForPhone(registration.phone);
      const { data: created, error: createError } = await admin.auth.admin.createUser({ email, password, email_confirm: true, user_metadata: { display_name: registration.display_name, noury_role: "teacher", phone: registration.phone } });
      if (createError) throw createError;
      if (!created.user) throw new Error("Auth user creation returned no user");
      const { error: profileInsertError } = await admin.from("noury_user_profiles").insert({ user_id: created.user.id, organization_id: callerProfile.organization_id, phone: registration.phone, display_name: registration.display_name, role: "teacher", is_active: true, created_by: callerId });
      if (profileInsertError) { await admin.auth.admin.deleteUser(created.user.id); throw profileInsertError; }
      const { error: updateError } = await admin.from("noury_registration_requests").update({ status: "approved", organization_id: callerProfile.organization_id, reviewed_by: callerId, reviewed_at: new Date().toISOString(), created_user_id: created.user.id, updated_at: new Date().toISOString() }).eq("id", requestId).eq("status", "pending");
      if (updateError) { await admin.from("noury_user_profiles").delete().eq("user_id", created.user.id); await admin.auth.admin.deleteUser(created.user.id); throw updateError; }
      await audit(admin, callerId, created.user.id, "teacher_account_approved", { request_id: requestId, phone: registration.phone });
      return reply({ ok: true, user_id: created.user.id, phone: registration.phone, login_email: email, message: "تم إنشاء حساب المدرس وتفعيله" }, 200);
    }
    if (action === "reject_teacher") {
      const requestId = String(body.request_id ?? "");
      const { error } = await admin.from("noury_registration_requests").update({ status: "rejected", reviewed_by: callerId, reviewed_at: new Date().toISOString(), rejection_reason: String(body.reason ?? "").slice(0, 250), updated_at: new Date().toISOString() }).eq("id", requestId).eq("status", "pending");
      if (error) throw error;
      await audit(admin, callerId, callerId, "teacher_registration_rejected", { request_id: requestId });
      return reply({ ok: true }, 200);
    }
    if (action === "set_active") {
      const targetId = String(body.user_id ?? ""), active = body.is_active === true;
      if (!targetId || targetId === callerId) return reply({ error: "Invalid target account" }, 400);
      const { data: target, error: targetError } = await admin.from("noury_user_profiles").select("role").eq("user_id", targetId).eq("organization_id", callerProfile.organization_id).maybeSingle();
      if (targetError) throw targetError;
      if (!target || target.role === "owner") return reply({ error: "Target account not found or protected" }, 404);
      const { error } = await admin.from("noury_user_profiles").update({ is_active: active, updated_at: new Date().toISOString() }).eq("user_id", targetId).eq("organization_id", callerProfile.organization_id);
      if (error) throw error;
      const { error: banError } = await admin.auth.admin.updateUserById(targetId, { ban_duration: active ? "none" : "876000h" });
      if (banError) throw banError;
      await audit(admin, callerId, targetId, active ? "staff_activated" : "staff_deactivated", {});
      return reply({ ok: true }, 200);
    }
    if (action === "set_role") {
      const targetId = String(body.user_id ?? ""), role = String(body.role ?? "");
      if (!targetId || targetId === callerId || !["admin", "accountant", "teacher"].includes(role)) return reply({ error: "Invalid target or role" }, 400);
      const { data: target, error: targetError } = await admin.from("noury_user_profiles").select("role").eq("user_id", targetId).eq("organization_id", callerProfile.organization_id).maybeSingle();
      if (targetError) throw targetError;
      if (!target || target.role === "owner") return reply({ error: "Target account not found or protected" }, 404);
      const { error } = await admin.from("noury_user_profiles").update({ role, updated_at: new Date().toISOString() }).eq("user_id", targetId).eq("organization_id", callerProfile.organization_id);
      if (error) throw error;
      await audit(admin, callerId, targetId, "staff_role_changed", { role });
      return reply({ ok: true }, 200);
    }
    return reply({ error: "Unsupported action" }, 400);
  } catch (error) { return reply({ error: error instanceof Error ? error.message : "Request failed" }, 400); }
});
async function audit(client: any, actor: string, target: string, action: string, details: Record<string, unknown>) {
  const { error } = await client.from("noury_user_audit_log").insert({ actor_user_id: actor, target_user_id: target, action, details });
  if (error) throw error;
}
function normalizeEgyptianPhone(value: string): string {
  const digits = value.replace(/\D/g, "");
  const phone = digits.startsWith("0020") ? `+${digits.slice(2)}` : digits.startsWith("20") ? `+${digits}` : digits.startsWith("0") ? `+20${digits.slice(1)}` : `+20${digits}`;
  if (!/^\+201[0125]\d{8}$/.test(phone)) throw new Error("أدخل رقم موبايل مصري صحيحًا");
  return phone;
}
function syntheticEmailForPhone(phone: string): string { return `${phone.replace(/\D/g, "")}@users.noury.invalid`; }
function reply(body: unknown, status = 200) { return new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } }); }
