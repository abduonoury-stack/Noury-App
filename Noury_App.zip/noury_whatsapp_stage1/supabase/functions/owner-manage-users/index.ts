import { createClient } from "npm:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return reply({ error: "Method not allowed" }, 405);
  const url = Deno.env.get("SUPABASE_URL"), serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"), anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  const authorization = req.headers.get("Authorization") ?? "";
  if (!url || !serviceKey || !anonKey || !authorization.startsWith("Bearer ")) return reply({ error: "Unauthorized" }, 401);

  const admin = createClient(url, serviceKey, { auth: { persistSession: false } });
  const callerClient = createClient(url, anonKey, { global: { headers: { Authorization: authorization } }, auth: { persistSession: false } });
  try {
    const { data: userData, error: userError } = await callerClient.auth.getUser();
    if (userError || !userData.user) return reply({ error: "Unauthorized" }, 401);
    const callerId = userData.user.id;
    const { data: callerProfile, error: profileError } = await admin.from("noury_user_profiles")
      .select("role,is_active,organization_id").eq("user_id", callerId).maybeSingle();
    if (profileError) throw profileError;
    if (!callerProfile || callerProfile.role !== "owner" || callerProfile.is_active !== true) return reply({ error: "Owner permission required" }, 403);

    const body = await req.json();
    const action = String(body.action ?? "");

    if (action === "list") {
      const { data, error } = await admin.from("noury_user_profiles")
        .select("user_id,phone,display_name,role,is_active,must_change_password,created_at,updated_at")
        .eq("organization_id", callerProfile.organization_id).order("created_at", { ascending: true });
      if (error) throw error;
      return reply({ users: data ?? [] });
    }

    if (action === "list_requests") {
      const { data, error } = await admin.from("noury_registration_requests")
        .select("id,full_name,phone,job_title,address,extra_data,status,created_at")
        .in("status", ["pending", "approving"]).order("created_at", { ascending: true });
      if (error) throw error;
      return reply({ requests: data ?? [] });
    }

    if (action === "approve_request") {
      const requestId = String(body.request_id ?? "");
      const role = String(body.role ?? "");
      if (!isUuid(requestId) || !["admin", "accountant", "teacher"].includes(role)) return reply({ error: "Invalid request or role" }, 400);
      const { data: claimed, error: claimError } = await admin.from("noury_registration_requests")
        .update({ status: "approving", reviewed_by: callerId, updated_at: new Date().toISOString() })
        .eq("id", requestId).eq("status", "pending")
        .select("id,full_name,phone,job_title,address").maybeSingle();
      if (claimError) throw claimError;
      if (!claimed) return reply({ error: "الطلب تمت معالجته بالفعل أو لم يعد متاحًا." }, 409);

      let createdUserId: string | null = null;
      let whatsappSent = false;
      try {
        const temporaryPassword = generateTemporaryPassword();
        const { data: created, error: createError } = await admin.auth.admin.createUser({
          phone: claimed.phone, phone_confirm: true, password: temporaryPassword,
          user_metadata: { display_name: claimed.full_name, noury_role: role, must_change_password: true },
        });
        if (createError) throw createError;
        if (!created.user) throw new Error("Auth user creation returned no user");
        createdUserId = created.user.id;
        const { error: profileInsertError } = await admin.from("noury_user_profiles").insert({
          user_id: created.user.id, organization_id: callerProfile.organization_id,
          phone: claimed.phone, display_name: claimed.full_name, job_title: claimed.job_title,
          address: claimed.address, role, is_active: true, must_change_password: true, created_by: callerId,
        });
        if (profileInsertError) throw profileInsertError;

        await sendWhatsAppTemplate(claimed.phone, Deno.env.get("WHATSAPP_LOGIN_TEMPLATE_NAME") ?? "", [
          claimed.full_name, claimed.phone, temporaryPassword,
        ]);
        whatsappSent = true;

        const { error: finishError } = await admin.from("noury_registration_requests").update({
          status: "approved", reviewed_by: callerId, reviewed_at: new Date().toISOString(),
          approved_user_id: created.user.id, updated_at: new Date().toISOString(),
        }).eq("id", requestId).eq("status", "approving");
        if (finishError) {
          // Account and WhatsApp message already exist. Keep the request claimed to prevent duplicate credentials.
          throw new Error("تم إنشاء الحساب وإرسال بياناته، لكن تعذر إغلاق الطلب آليًا. لا تعاود الموافقة؛ راجع سجل الطلب.");
        }
        await audit(admin, callerId, created.user.id, "registration_approved", { request_id: requestId, role, phone: claimed.phone });
        return reply({ ok: true, user_id: created.user.id, message: "تم اعتماد الطلب وإنشاء الحساب وإرسال بيانات الدخول المؤقتة عبر واتساب." });
      } catch (error) {
        // If no WhatsApp credential was delivered, remove the partial account so the owner can safely retry.
        if (createdUserId && !whatsappSent) {
          const { data: currentRequest } = await admin.from("noury_registration_requests").select("status,approved_user_id").eq("id", requestId).maybeSingle();
          if (currentRequest?.status === "approving" && !currentRequest.approved_user_id) {
            await admin.from("noury_user_profiles").delete().eq("user_id", createdUserId);
            await admin.auth.admin.deleteUser(createdUserId);
            await admin.from("noury_registration_requests").update({ status: "pending", reviewed_by: null, updated_at: new Date().toISOString() }).eq("id", requestId).eq("status", "approving");
          }
        } else if (!createdUserId) {
          await admin.from("noury_registration_requests").update({ status: "pending", reviewed_by: null, updated_at: new Date().toISOString() }).eq("id", requestId).eq("status", "approving");
        }
        throw error;
      }
    }

    if (action === "reject_request") {
      const requestId = String(body.request_id ?? "");
      if (!isUuid(requestId)) return reply({ error: "Invalid request ID" }, 400);
      const { data, error } = await admin.from("noury_registration_requests").update({
        status: "rejected", reviewed_by: callerId, reviewed_at: new Date().toISOString(), updated_at: new Date().toISOString(),
      }).eq("id", requestId).eq("status", "pending").select("id").maybeSingle();
      if (error) throw error;
      if (!data) return reply({ error: "الطلب تمت معالجته بالفعل أو غير موجود." }, 409);
      await audit(admin, callerId, null, "registration_rejected", { request_id: requestId });
      return reply({ ok: true });
    }

    if (action === "set_active") {
      const targetId = String(body.user_id ?? ""), active = body.is_active === true;
      if (!isUuid(targetId) || targetId === callerId) return reply({ error: "Invalid target account" }, 400);
      const { data: target, error: targetError } = await admin.from("noury_user_profiles").select("role")
        .eq("user_id", targetId).eq("organization_id", callerProfile.organization_id).maybeSingle();
      if (targetError) throw targetError;
      if (!target || target.role === "owner") return reply({ error: "Target account not found or protected" }, 404);
      if (!active) {
        // Disable the profile first so RLS rejects an already-issued access token immediately.
        const { error: profileDisableError } = await admin.from("noury_user_profiles").update({ is_active: false, sessions_revoked_at: new Date().toISOString(), updated_at: new Date().toISOString() })
          .eq("user_id", targetId).eq("organization_id", callerProfile.organization_id);
        if (profileDisableError) throw profileDisableError;
        const { error: banError } = await admin.auth.admin.updateUserById(targetId, { ban_duration: "876000h" });
        if (banError) throw banError;
      } else {
        const { error: unbanError } = await admin.auth.admin.updateUserById(targetId, { ban_duration: "none" });
        if (unbanError) throw unbanError;
        const { error: profileEnableError } = await admin.from("noury_user_profiles").update({ is_active: true, updated_at: new Date().toISOString() })
          .eq("user_id", targetId).eq("organization_id", callerProfile.organization_id);
        if (profileEnableError) throw profileEnableError;
      }
      await audit(admin, callerId, targetId, active ? "staff_activated" : "staff_deactivated", {});
      return reply({ ok: true });
    }

    if (action === "set_role") {
      const targetId = String(body.user_id ?? ""), role = String(body.role ?? "");
      if (!isUuid(targetId) || targetId === callerId || !["admin", "accountant", "teacher"].includes(role)) return reply({ error: "Invalid target or role" }, 400);
      const { data: target, error: targetError } = await admin.from("noury_user_profiles").select("role")
        .eq("user_id", targetId).eq("organization_id", callerProfile.organization_id).maybeSingle();
      if (targetError) throw targetError;
      if (!target || target.role === "owner") return reply({ error: "Target account not found or protected" }, 404);
      const { error } = await admin.from("noury_user_profiles").update({ role, updated_at: new Date().toISOString() })
        .eq("user_id", targetId).eq("organization_id", callerProfile.organization_id);
      if (error) throw error;
      await audit(admin, callerId, targetId, "staff_role_changed", { role });
      return reply({ ok: true });
    }

    return reply({ error: "Unsupported action" }, 400);
  } catch (error) {
    return reply({ error: error instanceof Error ? error.message : "Request failed" }, 400);
  }
});

async function sendWhatsAppTemplate(phone: string, template: string, values: string[]) {
  const token = Deno.env.get("WHATSAPP_ACCESS_TOKEN"), id = Deno.env.get("WHATSAPP_PHONE_NUMBER_ID"), version = Deno.env.get("WHATSAPP_GRAPH_API_VERSION");
  if (!token || !id || !version || !/^v\d+\.\d+$/.test(version) || !template) throw new Error("WhatsApp Cloud API secrets/template are not configured");
  const response = await fetch(`https://graph.facebook.com/${version}/${id}/messages`, {
    method: "POST", headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({ messaging_product: "whatsapp", to: phone.replace(/\D/g, ""), type: "template", template: {
      name: template, language: { code: Deno.env.get("WHATSAPP_TEMPLATE_LANGUAGE") ?? "ar" },
      components: [{ type: "body", parameters: values.map(text => ({ type: "text", text })) }],
    } }),
  });
  if (!response.ok) throw new Error(`WhatsApp delivery request failed (${response.status})`);
}
function generateTemporaryPassword() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%";
  const bytes = new Uint8Array(24); crypto.getRandomValues(bytes);
  return Array.from(bytes, value => alphabet[value % alphabet.length]).join("");
}
function isUuid(value: string) { return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value); }
async function audit(client: any, actor: string, target: string | null, action: string, details: Record<string, unknown>) {
  const { error } = await client.from("noury_user_audit_log").insert({ actor_user_id: actor, target_user_id: target, action, details });
  if (error) throw error;
}
function reply(body: unknown, status = 200) { return new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } }); }
