import { createClient } from "npm:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return reply({ error: "Method not allowed" }, 405);
  const url = Deno.env.get("SUPABASE_URL");
  const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !key) return reply({ error: "Server configuration missing" }, 500);
  try {
    const body = await req.json();
    const fullName = clean(body.full_name, 120);
    const phone = normalizeEgyptianPhone(String(body.phone ?? ""));
    const jobTitle = clean(body.job_title, 100);
    const address = clean(body.address, 300);
    const extra = typeof body.extra_data === "object" && body.extra_data ? body.extra_data : {};
    if (fullName.length < 2 || jobTitle.length < 2 || address.length < 3) {
      return reply({ error: "أكمل الاسم والوظيفة والعنوان بصورة صحيحة." }, 400);
    }
    const admin = createClient(url, key, { auth: { persistSession: false } });
    const { data: existing } = await admin.from("noury_user_profiles").select("user_id")
      .eq("phone", phone).maybeSingle();
    if (existing) return reply({ ok: true, message: "إذا كانت البيانات مستوفاة، سيظهر الطلب لدى المالك للمراجعة." }, 200);
    const since = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const { count } = await admin.from("noury_registration_requests").select("id", { count: "exact", head: true })
      .eq("phone", phone).gte("created_at", since);
    if ((count ?? 0) >= 3) return reply({ error: "تم استلام طلبات متعددة لهذا الرقم. حاول بعد ساعة." }, 429);
    const { error } = await admin.from("noury_registration_requests").insert({
      full_name: fullName, phone, job_title: jobTitle, address, extra_data: extra, status: "pending",
    });
    if (error?.code === "23505") return reply({ ok: true, message: "يوجد طلب قيد المراجعة لهذا الرقم بالفعل." }, 200);
    if (error) throw error;
    return reply({ ok: true, message: "تم إرسال طلب التسجيل بنجاح. لن يتم إنشاء حساب قبل موافقة المالك." }, 200);
  } catch (error) {
    return reply({ error: error instanceof Error ? error.message : "تعذر إرسال الطلب" }, 400);
  }
});

function clean(value: unknown, max: number): string {
  return String(value ?? "").trim().replace(/\s+/g, " ").slice(0, max);
}
function normalizeEgyptianPhone(value: string): string {
  const digits = value.replace(/\D/g, "");
  const phone = digits.startsWith("0020") ? `+${digits.slice(2)}` : digits.startsWith("20") ? `+${digits}` : digits.startsWith("0") ? `+20${digits.slice(1)}` : `+20${digits}`;
  if (!/^\+201[0125]\d{8}$/.test(phone)) throw new Error("أدخل رقم موبايل مصري صحيحًا");
  return phone;
}
function reply(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
}
