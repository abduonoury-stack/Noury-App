-- Noury Stage 11 foundation: append-only change feed for automatic sync.
-- Run only in the NOURY Supabase project. This does NOT modify existing snapshots.

create table if not exists public.noury_sync_events (
    id bigint generated always as identity primary key,
    owner_id uuid not null references auth.users(id) on delete cascade,
    device_id text not null,
    event_id uuid not null,
    entity_type text not null,
    entity_key text not null,
    operation text not null check (operation in ('upsert','delete')),
    payload jsonb,
    base_revision bigint not null default 0,
    created_at timestamptz not null default now(),
    unique (owner_id, event_id),
    check ((operation = 'delete') or payload is not null)
);

create index if not exists noury_sync_events_owner_id_idx
    on public.noury_sync_events(owner_id, id);
create index if not exists noury_sync_events_owner_entity_idx
    on public.noury_sync_events(owner_id, entity_type, entity_key, id);

alter table public.noury_sync_events enable row level security;

drop policy if exists "noury events insert own" on public.noury_sync_events;
create policy "noury events insert own"
    on public.noury_sync_events for insert to authenticated
    with check (auth.uid() = owner_id);

drop policy if exists "noury events select own" on public.noury_sync_events;
create policy "noury events select own"
    on public.noury_sync_events for select to authenticated
    using (auth.uid() = owner_id);

grant insert, select on public.noury_sync_events to authenticated;
grant usage, select on sequence public.noury_sync_events_id_seq to authenticated;

-- Enable Postgres Changes so connected devices can be notified about new events.
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'noury_sync_events'
  ) then
    alter publication supabase_realtime add table public.noury_sync_events;
  end if;
end $$;
