-- Noury User Management v1
-- Apply only to a dedicated Noury Supabase project after taking a database backup.

create table if not exists public.noury_organizations (
    id uuid primary key default gen_random_uuid(),
    name text not null default 'Noury Organization',
    owner_user_id uuid references auth.users(id) on delete restrict,
    created_at timestamptz not null default now()
);

create table if not exists public.noury_user_profiles (
    user_id uuid primary key references auth.users(id) on delete cascade,
    organization_id uuid not null references public.noury_organizations(id) on delete restrict,
    phone text not null unique,
    display_name text not null,
    role text not null check (role in ('owner', 'admin', 'accountant', 'teacher')),
    is_active boolean not null default true,
    created_by uuid references auth.users(id) on delete set null,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

-- This application has exactly one owner account.
create unique index if not exists noury_single_owner_idx
    on public.noury_user_profiles ((role)) where role = 'owner';

-- Preserve existing cloud data by creating a legacy organization for every former owner_id.
-- A one-time owner bootstrap can later attach the new owner login to the selected legacy org.
alter table public.noury_sync_snapshots add column if not exists organization_id uuid;
alter table public.noury_sync_events add column if not exists organization_id uuid;

insert into public.noury_organizations (id, name, owner_user_id)
select u.id, 'Noury Organization', u.id from auth.users u
on conflict (id) do nothing;

insert into public.noury_organizations (id, name, owner_user_id)
select distinct legacy.owner_id, 'Noury Organization', legacy.owner_id
from (
    select owner_id from public.noury_sync_snapshots
    union
    select owner_id from public.noury_sync_events
) legacy
on conflict (id) do nothing;

update public.noury_sync_snapshots set organization_id = owner_id where organization_id is null;
update public.noury_sync_events set organization_id = owner_id where organization_id is null;

alter table public.noury_sync_snapshots alter column organization_id set not null;
alter table public.noury_sync_events alter column organization_id set not null;

do $$ begin
    if not exists (select 1 from pg_constraint where conname = 'noury_sync_snapshots_org_fk') then
        alter table public.noury_sync_snapshots add constraint noury_sync_snapshots_org_fk
            foreign key (organization_id) references public.noury_organizations(id) on delete cascade;
    end if;
    if not exists (select 1 from pg_constraint where conname = 'noury_sync_events_org_fk') then
        alter table public.noury_sync_events add constraint noury_sync_events_org_fk
            foreign key (organization_id) references public.noury_organizations(id) on delete cascade;
    end if;
end $$;

create index if not exists noury_sync_snapshots_org_created_idx
    on public.noury_sync_snapshots (organization_id, created_at desc);
create index if not exists noury_sync_events_org_id_idx
    on public.noury_sync_events (organization_id, id);

create table if not exists public.noury_user_audit_log (
    id bigint generated always as identity primary key,
    actor_user_id uuid references auth.users(id) on delete set null,
    target_user_id uuid references auth.users(id) on delete set null,
    action text not null,
    details jsonb not null default '{}'::jsonb,
    created_at timestamptz not null default now()
);

create index if not exists noury_user_audit_log_created_idx
    on public.noury_user_audit_log (created_at desc);

create or replace function public.noury_current_organization_id()
returns uuid
language sql
stable
security definer
set search_path = ''
as $$
    select p.organization_id from public.noury_user_profiles p
    where p.user_id = auth.uid() and p.is_active = true
    limit 1;
$$;

create or replace function public.noury_is_active_user()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
    select exists (
        select 1 from public.noury_user_profiles p
        where p.user_id = auth.uid() and p.is_active = true
    );
$$;

create or replace function public.noury_is_owner()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
    select exists (
        select 1 from public.noury_user_profiles p
        where p.user_id = auth.uid() and p.is_active = true and p.role = 'owner'
    );
$$;

alter table public.noury_user_profiles enable row level security;
alter table public.noury_user_audit_log enable row level security;

drop policy if exists "noury profile read self or owner" on public.noury_user_profiles;
create policy "noury profile read self or owner"
    on public.noury_user_profiles for select to authenticated
    using (user_id = auth.uid() or (public.noury_is_owner() and organization_id = public.noury_current_organization_id()));

-- No direct client writes. Owner operations go through the Edge Function using service_role.
revoke insert, update, delete on public.noury_user_profiles from anon, authenticated;
grant select on public.noury_user_profiles to authenticated;
revoke all on public.noury_organizations from anon, authenticated;

drop policy if exists "noury audit owner read" on public.noury_user_audit_log;
create policy "noury audit owner read"
    on public.noury_user_audit_log for select to authenticated
    using (public.noury_is_owner());
revoke insert, update, delete on public.noury_user_audit_log from anon, authenticated;
grant select on public.noury_user_audit_log to authenticated;

-- Existing cloud sync tables must reject inactive accounts as well as enforce owner_id.
drop policy if exists "noury snapshots insert own" on public.noury_sync_snapshots;
create policy "noury snapshots insert own"
    on public.noury_sync_snapshots for insert to authenticated
    with check (auth.uid() = owner_id and public.noury_is_active_user()
        and organization_id = public.noury_current_organization_id());

drop policy if exists "noury snapshots select own" on public.noury_sync_snapshots;
create policy "noury snapshots select own"
    on public.noury_sync_snapshots for select to authenticated
    using (public.noury_is_active_user()
        and organization_id = public.noury_current_organization_id());

drop policy if exists "noury events insert own" on public.noury_sync_events;
create policy "noury events insert own"
    on public.noury_sync_events for insert to authenticated
    with check (auth.uid() = owner_id and public.noury_is_active_user()
        and organization_id = public.noury_current_organization_id());

drop policy if exists "noury events select own" on public.noury_sync_events;
create policy "noury events select own"
    on public.noury_sync_events for select to authenticated
    using (public.noury_is_active_user()
        and organization_id = public.noury_current_organization_id());

-- Do not grant authenticated users access to any service-role operations.
