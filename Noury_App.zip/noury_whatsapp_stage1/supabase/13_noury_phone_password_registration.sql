-- Noury Phone + Password registration workflow.
-- Apply only after backup and after 12_noury_user_management.sql in a TEST project.

alter table public.noury_user_profiles
  add column if not exists job_title text,
  add column if not exists address text,
  add column if not exists must_change_password boolean not null default false;

create table if not exists public.noury_registration_requests (
  id uuid primary key default gen_random_uuid(),
  full_name text not null check (char_length(trim(full_name)) between 2 and 120),
  phone text not null,
  job_title text not null check (char_length(trim(job_title)) between 2 and 100),
  address text not null check (char_length(trim(address)) between 3 and 300),
  extra_data jsonb not null default '{}'::jsonb,
  status text not null default 'pending'
    check (status in ('pending','approving','approved','rejected')),
  reviewed_by uuid references auth.users(id) on delete set null,
  reviewed_at timestamptz,
  approved_user_id uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists noury_registration_requests_status_created_idx
  on public.noury_registration_requests(status, created_at desc);
create unique index if not exists noury_registration_requests_open_phone_idx
  on public.noury_registration_requests(phone)
  where status in ('pending','approving');

create table if not exists public.noury_password_reset_challenges (
  id uuid primary key default gen_random_uuid(),
  phone text not null,
  code_hash text not null,
  expires_at timestamptz not null,
  attempts integer not null default 0 check (attempts between 0 and 5),
  used_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists noury_password_reset_phone_created_idx
  on public.noury_password_reset_challenges(phone, created_at desc);

alter table public.noury_registration_requests enable row level security;
alter table public.noury_password_reset_challenges enable row level security;
revoke all on public.noury_registration_requests from anon, authenticated;
revoke all on public.noury_password_reset_challenges from anon, authenticated;

-- Requests and reset challenges are written/read only by trusted Edge Functions using service_role.
-- No client-side policy is intentionally created.

-- Stage-1 users were created through OTP and may not have a password yet.
-- Force them through the verified WhatsApp recovery flow before ordinary password login.
update public.noury_user_profiles set must_change_password = true where is_active = true;

alter table public.noury_user_profiles
  add column if not exists sessions_revoked_at timestamptz;

-- Reject previously issued access JWTs after a security disable/reset event.
create or replace function public.noury_is_active_user()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
    select exists (
        select 1 from public.noury_user_profiles p
        where p.user_id = auth.uid()
          and p.is_active = true
          and (p.sessions_revoked_at is null
               or to_timestamp(coalesce((auth.jwt() ->> 'iat')::bigint, 0)) > p.sessions_revoked_at)
    );
$$;
