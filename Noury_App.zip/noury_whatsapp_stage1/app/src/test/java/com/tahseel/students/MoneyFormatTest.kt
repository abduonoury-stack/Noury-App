package com.tahseel.students

import com.tahseel.students.util.Money
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MoneyFormatTest {
    @Test fun positiveAmountsKeepTwoDecimals() {
        assertEquals("0.05", Money.plain(5L))
        assertEquals("1,234.50 ج.م", Money.format(123_450L))
    }

    @Test fun negativeAmountsAreNotMalformed() {
        assertEquals("-1.50", Money.plain(-150L))
        assertEquals("-0.05", Money.plain(-5L))
        assertEquals("-1,000.01 ج.م", Money.format(-100_001L))
    }

    @Test fun parsingIsExactWithoutFloatingPointRounding() {
        assertEquals(1_010L, Money.parse("10.10"))
        assertEquals(1_000_000L, Money.parse("١٠٬٠٠٠"))
        assertNull(Money.parse("10.123"))
        assertNull(Money.parse("0"))
        assertNull(Money.parse("-5"))
    }
}
