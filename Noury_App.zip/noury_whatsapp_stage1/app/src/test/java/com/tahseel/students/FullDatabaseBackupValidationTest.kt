package com.tahseel.students

import com.tahseel.students.util.FullDatabaseBackup
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.MessageDigest

class FullDatabaseBackupValidationTest {
    private fun checksum(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    private fun canonical(value: Any?): String = when (value) {
        null, JSONObject.NULL -> "null"
        is JSONObject -> value.keys().asSequence().toList().sorted().joinToString(prefix = "{", postfix = "}") { JSONObject.quote(it) + ":" + canonical(value.get(it)) }
        is JSONArray -> (0 until value.length()).joinToString(prefix = "[", postfix = "]") { canonical(value.get(it)) }
        is String -> JSONObject.quote(value)
        is Number, is Boolean -> value.toString()
        else -> JSONObject.quote(value.toString())
    }

    /** يبني نسخة من القائمة الفعلية للجداول، فلا تنكسر الاختبارات عند إضافة جدول جديد. */
    private fun backup(rowCount: Int, version: Int = FullDatabaseBackup.VERSION, omit: Set<String> = emptySet(), extra: (JSONObject) -> Unit = {}): String {
        val tables = JSONObject()
        FullDatabaseBackup.tables.filterNot { it in omit }.forEach { tables.put(it, JSONArray()) }
        tables.put("cash_accounts", JSONArray().put(JSONObject().put("id", "cash").put("name", "الخزينة النقدية").put("type", "cash").put("isActive", true).put("createdAt", 0L)))
        val root = JSONObject().put("app", FullDatabaseBackup.APP).put("version", version)
            .put("exportedAt", 123L).put("receiptProfile", JSONObject()).put("tables", tables).put("rowCount", rowCount)
        extra(root)
        root.put("checksum", checksum(canonical(root)))
        return root.toString()
    }

    @Test fun accepts_complete_empty_backup() {
        assertEquals(1, FullDatabaseBackup.rowCount(FullDatabaseBackup.validate(backup(1))))
    }

    @Test fun rejects_row_count_mismatch_even_when_checksum_is_valid() {
        val error = runCatching { FullDatabaseBackup.validate(backup(2)) }.exceptionOrNull()
        assertTrue(error?.message?.contains("عدد السجلات") == true)
    }

    @Test fun accepts_backup_after_json_object_keys_are_reordered() {
        val original = JSONObject(backup(1))
        val reordered = JSONObject()
        original.keys().asSequence().toList().sortedDescending().forEach { key -> reordered.put(key, original.get(key)) }
        assertEquals(1, FullDatabaseBackup.rowCount(FullDatabaseBackup.validate(reordered.toString())))
    }

    @Test fun rejects_missing_required_table() {
        val root = JSONObject(backup(0))
        root.getJSONObject("tables").remove("employees")
        root.remove("checksum")
        root.put("checksum", checksum(canonical(root)))
        val error = runCatching { FullDatabaseBackup.validate(root.toString()) }.exceptionOrNull()
        assertTrue(error != null)
    }

    @Test fun backup_tables_include_expense_month_locks() {
        assertTrue("expense_month_locks" in FullDatabaseBackup.tables)
    }

    @Test fun accepts_older_v13_backup_without_expense_month_locks() {
        val v13 = backup(1, version = 13, omit = setOf("expense_month_locks"))
        assertEquals(1, FullDatabaseBackup.rowCount(FullDatabaseBackup.validate(v13)))
    }

    @Test fun rejects_current_version_backup_missing_expense_month_locks() {
        val bad = backup(1, omit = setOf("expense_month_locks"))
        assertTrue(runCatching { FullDatabaseBackup.validate(bad) }.exceptionOrNull() != null)
    }

    @Test fun embedded_photos_are_covered_by_checksum_and_not_counted_as_rows() {
        val withPhotos = backup(1) { it.put("photos", JSONObject().put("student_1.jpg", "AAAA")).put("photosSkipped", 0) }
        val checked = FullDatabaseBackup.validate(withPhotos)
        assertEquals(1, FullDatabaseBackup.rowCount(checked))
        assertEquals(1, FullDatabaseBackup.photoCount(checked))
        // أي تعديل في الصور بعد الحفظ يجب أن يُكشف.
        val tampered = JSONObject(withPhotos); tampered.getJSONObject("photos").put("student_1.jpg", "BBBB")
        assertTrue(runCatching { FullDatabaseBackup.validate(tampered.toString()) }.exceptionOrNull() != null)
    }

    @Test fun row_count_matching_ignores_tables_missing_from_older_reference() {
        val current = JSONObject(backup(1)); val old = backup(1, version = 13, omit = setOf("expense_month_locks"))
        current.getJSONObject("tables").put("expense_month_locks", JSONArray().put(JSONObject().put("monthKey", "2026-01")))
        assertEquals(1, FullDatabaseBackup.rowCountMatching(current.toString(), old))
    }
}
