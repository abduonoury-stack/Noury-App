package com.tahseel.students

import com.tahseel.students.data.StudentGender
import org.junit.Assert.assertEquals
import org.junit.Test

class StudentGenderCompatibilityTest {
    @Test fun normalizes_supported_values() {
        assertEquals("boy", StudentGender.normalize("boy"))
        assertEquals("girl", StudentGender.normalize("girl"))
        assertEquals("boy", StudentGender.normalize("ذكر"))
        assertEquals("girl", StudentGender.normalize("بنت"))
        assertEquals("girl", StudentGender.normalize("FEMALE"))
    }

    @Test fun safely_defaults_legacy_missing_or_blank_values() {
        assertEquals("boy", StudentGender.normalize(null))
        assertEquals("boy", StudentGender.normalize(""))
        assertEquals("boy", StudentGender.normalize("   "))
        assertEquals("boy", StudentGender.normalize("unknown-value"))
    }
}
