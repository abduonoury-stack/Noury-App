package com.tahseel.students.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.tahseel.students.App
import com.tahseel.students.util.AcademyProfileStore
import com.tahseel.students.vm.*

@Composable
fun AppNav(app: App) {
    val nav = rememberNavController()
    val context = LocalContext.current
    val startDestination = remember { if (AcademyProfileStore.isSetupComplete(context)) "dashboard" else "academy-setup" }
    val repo = app.repo
    val back: () -> Unit = { nav.popBackStack() }

    NavHost(navController = nav, startDestination = startDestination) {
        composable("academy-setup") {
            AcademySetupScreen(onComplete = {
                nav.navigate("dashboard") {
                    popUpTo("academy-setup") { inclusive = true }
                    launchSingleTop = true
                }
            })
        }
        composable("dashboard") {
            DashboardScreen(
                vm = viewModel<DashboardViewModel>(factory = vmFactory { DashboardViewModel(repo, app.db.studentDao(), app.db.financeDao(), app.db.expenseDao(), app.db.periodDao()) }),
                onAdd = { nav.navigate("add") },
                onReports = { nav.navigate("reports") },
                onStudents = { nav.navigate("students") },
                onSubscription = { nav.navigate("subscription") },
                onCollectionStatus = { nav.navigate("collection-status") },
                onHr = { nav.navigate("hr") }, onAddStudent = { nav.navigate("add-student") },
                onHub = { nav.navigate("hub/$it") }, onStudentProfile = { nav.navigate("student-profile/$it") }
            )
        }
        composable("hub/{section}", arguments = listOf(navArgument("section") { type = NavType.StringType })) { entry ->
            val section = entry.arguments?.getString("section") ?: "students"
            ModuleHubScreen(section = section, onBack = back) { destination -> nav.navigate(destination) }
        }
        composable("student-exit") {
            StudentExitScreen(viewModel<StudentExitViewModel>(factory = vmFactory { StudentExitViewModel(app.db.studentDao(), app.db.financeDao(), app.db.cashAccountDao()) }), back) { nav.navigate("student-profile/$it") }
        }
        composable("hr") {
            HrScreen(viewModel<HrViewModel>(factory = vmFactory { HrViewModel(app.db.hrDao(), app.db.expenseDao(), app.db) }), back)
        }
        composable("expenses") {
            AccountingScreen(app.db.accountingDao(), back) { nav.navigate("finance-payroll") }
        }
        composable("finance-payroll") {
            FinancePayrollScreen(app.db.hrDao(), back)
        }
        composable("attendance") {
            AttendanceScreen(viewModel<AttendanceViewModel>(factory = vmFactory { AttendanceViewModel(app.db.attendanceDao(), app.db.classroomDao(), app.db.studentDao(), app.db.financeDao()) }), back) { nav.navigate("student-profile/$it") }
        }
        composable("classrooms") {
            ClassroomsScreen(viewModel<ClassroomsViewModel>(factory = vmFactory { ClassroomsViewModel(app.db.classroomDao(), app.db.studentDao(), app.db.attendanceDao()) }), back) { nav.navigate("student-profile/$it") }
        }
        composable("birthdays") {
            BirthdaysScreen(app.db.studentDao(), back) { nav.navigate("student-profile/$it") }
        }
        composable("students") {
            StudentsScreen(
                viewModel<StudentsViewModel>(factory = vmFactory { StudentsViewModel(app.db.studentDao(), app.db.classroomDao(), app.db.periodDao()) }),
                back, onProfile = { nav.navigate("student-profile/$it") },
                onFinance = { nav.navigate("student-finance/$it") }
            )
        }
        composable("add-student") {
            StudentsScreen(
                viewModel<StudentsViewModel>(factory = vmFactory { StudentsViewModel(app.db.studentDao(), app.db.classroomDao(), app.db.periodDao()) }),
                back, onProfile = { nav.navigate("student-profile/$it") },
                onFinance = { nav.navigate("student-finance/$it") }, openAddInitially = true
            )
        }
        composable("student-profile/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
            val id = e.arguments?.getLong("id") ?: 0L
            StudentProfileScreen(id, app.db.studentDao(), app.db.dao(), app.db.financeDao(), app.db.feeDao(), app.db.attendanceDao(), back, onFinance = { nav.navigate("student-finance/$id") })
        }
        composable("student-finance/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
            val id = e.arguments?.getLong("id") ?: 0L
            StudentFinanceScreen(id, app.db.studentDao(), app.db.financeDao(), app.db.dao(), app.db.periodDao(), back, onAddPayment = { nav.navigate("add") }, onProfile = { nav.navigate("student-profile/$id") })
        }
        composable("collection-status") {
            CollectionStatusScreen(
                viewModel<CollectionStatusViewModel>(factory = vmFactory { CollectionStatusViewModel(app.db.studentDao(), app.db.financeDao(), app.db.periodDao()) }),
                back
            ) { nav.navigate("student-profile/$it") }
        }
        composable("periods") {
            PeriodManagementScreen(app.db.periodDao(), back)
        }
        composable("subscription") {
            SubscriptionScreen(
                viewModel<SubscriptionViewModel>(factory = vmFactory { SubscriptionViewModel(app.db.studentDao(), app.subscriptionRepo, app.db.cashAccountDao()) }),
                back
            )
        }
        composable("add") {
            PaymentFormScreen(
                vm = viewModel<PaymentFormViewModel>(factory = vmFactory { PaymentFormViewModel(repo, app.db.studentDao(), app.db.cashAccountDao(), null) }),
                title = "تسجيل دفعة جديدة", buttonText = "حفظ عملية الدفع", onBack = back, onDone = back
            )
        }
        composable("edit/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
            val id = e.arguments?.getLong("id") ?: 0L
            PaymentFormScreen(
                vm = viewModel<PaymentFormViewModel>(factory = vmFactory { PaymentFormViewModel(repo, app.db.studentDao(), app.db.cashAccountDao(), id) }),
                title = "تعديل عملية دفع", buttonText = "حفظ التعديلات", onBack = back, onDone = back
            )
        }
        composable("ledger") {
            LedgerScreen(viewModel<LedgerViewModel>(factory = vmFactory { LedgerViewModel(repo) }), back, onOpen = { nav.navigate("details/$it") }, onStudentProfile = { nav.navigate("student-profile/$it") })
        }
        composable("details/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
            val id = e.arguments?.getLong("id") ?: 0L
            DetailsScreen(viewModel<DetailsViewModel>(factory = vmFactory { DetailsViewModel(repo, id) }), back, onEdit = { nav.navigate("edit/$it") }, onStudentProfile = { nav.navigate("student-profile/$it") })
        }
        composable("search") {
            SearchScreen(viewModel<SearchViewModel>(factory = vmFactory { SearchViewModel(app.db.studentDao()) }), back) { nav.navigate("student-profile/$it") }
        }
        composable("reports") {
            ReportsScreen(viewModel<ReportsViewModel>(factory = vmFactory { ReportsViewModel(repo, app.db.studentDao(), app.db.financeDao(), app.db.expenseDao(), app.db.periodDao(), app.db.hrDao(), app.db.cashControlDao(), app.db.cashAccountDao(), app.db.cashTransferDao()) }), back, onOpen = { nav.navigate("details/$it") }, onStudentProfile = { nav.navigate("student-profile/$it") })
        }
        composable("cash-accounts") {
            CashAccountsScreen(app.db.cashAccountDao(), app.db.cashTransferDao(), back)
        }
        composable("refunds") {
            RefundScreen(viewModel<RefundViewModel>(factory = vmFactory { RefundViewModel(app.db.financeDao(), app.db.studentDao(), app.refundRepo, app.db.cashAccountDao(), app.db.dao()) }), back)
        }
        composable("backup") {
            BackupScreen(viewModel<BackupViewModel>(factory = vmFactory { BackupViewModel(repo, app.db, app) }), back)
        }
        composable("academy-profile") {
            AcademyProfileScreen(onBack = back)
        }
        composable("sync-login") {
            SupabaseLoginScreen(onBack = back, onConflicts = { nav.navigate("sync-conflicts") })
        }
        composable("user-management") {
            NouryUserManagementScreen(onBack = back)
        }
        composable("sync-conflicts") {
            SyncConflictScreen(onBack = back)
        }
        composable("system-settings") {
            SystemSettingsScreen(
                settingsDao = app.db.financeDao(),
                onBack = back,
                onAcademyProfile = { nav.navigate("academy-profile") },
                onManagePeriods = { nav.navigate("periods") },
                onBackup = { nav.navigate("backup") },
                onCashAccounts = { nav.navigate("cash-accounts") },
                onSync = { nav.navigate("sync-login") },
                onUsers = { nav.navigate("user-management") }
            )
        }
    }
}
