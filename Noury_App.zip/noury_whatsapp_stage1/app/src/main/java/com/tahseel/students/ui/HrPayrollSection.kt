package com.tahseel.students.ui

import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tahseel.students.data.Employee
import com.tahseel.students.data.EmployeeAttendance
import com.tahseel.students.data.EmployeePayroll
import com.tahseel.students.data.EmployeePayrollPayment
import com.tahseel.students.data.EmployeePayrollReversal
import com.tahseel.students.data.EmployeePayrollRecoveryTransaction
import com.tahseel.students.data.CashAccount
import com.tahseel.students.util.Money
import java.util.Locale
import java.time.DayOfWeek
import java.time.LocalDate

@Composable
fun HrPayrollSection(
    employees: List<Employee>, payroll: List<EmployeePayroll>, payments: List<EmployeePayrollPayment>, reversals: List<EmployeePayrollReversal>, recoveries: List<EmployeePayrollRecoveryTransaction>, monthlyAttendance: List<EmployeeAttendance>, workdays: Set<DayOfWeek>, message: String, cashAccounts: List<CashAccount>,
    onGenerate: () -> Unit,
    onRecordPayment: (EmployeePayroll, Long, String, String, String, String) -> Unit,
    onVoidOrCorrect: (EmployeePayrollPayment, Long?, String, String, String, String) -> Unit,
    onReversePaid: (EmployeePayrollPayment, Long, String?, String, String) -> Unit,
    onRecordRecovery: (Long, Long, String, String) -> Unit
) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StatCard("إجمالي المستحق", Money.format(payroll.sumOf { it.netPiasters }), Modifier.weight(1f))
        StatCard("المدفوع", Money.format(payroll.sumOf { it.paidPiasters }), Modifier.weight(1f))
    }
    StatCard("المتبقي", Money.format(payroll.sumOf { (it.netPiasters - it.paidPiasters).coerceAtLeast(0) }), Modifier.fillMaxWidth())
    Button(onClick = onGenerate, modifier = Modifier.fillMaxWidth(), enabled = employees.any { it.status == "active" }) { Text("إنشاء / إعادة حساب كشف مرتبات الشهر") }
    if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
    Text("يُنشأ الكشف مرة واحدة لكل موظف وشهر. تُضاف المكافآت والجزاءات والسلف المسجلة لهذا الشهر تلقائيًا. بند المرتبات في المصروفات يُحدّث تلقائيًا إذا كان غير مستخدم يدويًا، ولا يستبدل قيمة رواتب أدخلتها بنفسك.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    payroll.forEach { item ->
        var showPaymentDialog by remember(item.id) { mutableStateOf(false) }
        var paymentToCorrect by remember(item.id) { mutableStateOf<EmployeePayrollPayment?>(null) }
        var paymentToReverse by remember(item.id) { mutableStateOf<EmployeePayrollPayment?>(null) }
        var reversalToRecover by remember(item.id) { mutableStateOf<EmployeePayrollReversal?>(null) }
        val itemPayments = payments.filter { it.payrollId == item.id }
        val employee = employees.firstOrNull { it.id == item.employeeId }
        val absentDays = monthlyAttendance.count { it.employeeId == item.employeeId && it.status == "absent" && runCatching { LocalDate.parse(it.workDate).dayOfWeek in workdays }.getOrDefault(false) }
        val absenceValue = (item.basePiasters * absentDays / 30L).coerceAtMost(item.basePiasters)
        val otherDeductions = (item.deductionsPiasters - absenceValue).coerceAtLeast(0)
        Card { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(employee?.fullName ?: "موظف", style = MaterialTheme.typography.titleSmall)
            Text("أساسي ${Money.format(item.basePiasters)} • بدلات ${Money.format(item.allowancesPiasters)} • مكافآت ${Money.format(item.bonusesPiasters)}")
            Text("خصم الغياب: $absentDays يوم • ${Money.format(absenceValue)}")
            Text("جزاءات وخصومات أخرى ${Money.format(otherDeductions)} • سلفة ${Money.format(item.loanDeductionPiasters)}")
            Text("الصافي: ${Money.format(item.netPiasters)}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium)
            Text("المدفوع: ${Money.format(item.paidPiasters)} • المتبقي: ${Money.format((item.netPiasters-item.paidPiasters).coerceAtLeast(0))}")
            Text("سجل دفعات المرتب", style = MaterialTheme.typography.titleSmall)
            if (itemPayments.isEmpty()) Text("لا توجد دفعات مسجلة لهذا الكشف.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            itemPayments.forEach { payment ->
                Column(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("${payment.paymentDate} • ${payment.paymentMethod} • ${Money.format(payment.amountPiasters)}${if (payment.note.isNotBlank()) " • ${payment.note}" else ""}", style = MaterialTheme.typography.bodySmall)
                    if (payment.status == "active") {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("سارية", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                            Spacer(Modifier.weight(1f))
                            TextButton(onClick = { paymentToCorrect = payment }) { Text("إلغاء إدخال غير مصروف") }
                            TextButton(onClick = { paymentToReverse = payment }) { Text("عكس صرف فعلي") }
                        }
                    } else {
                        Text("${if (payment.status == "reversed") "معكوسة بعد صرف فعلي" else "ملغاة قبل الصرف"} • السبب: ${payment.voidReason}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        payment.voidedAt?.let { Text("تاريخ الإلغاء: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(java.util.Date(it))}", style = MaterialTheme.typography.labelSmall) }
                        payment.correctedByPaymentId?.let { Text("تم استبدالها بالدفعة رقم $it", style = MaterialTheme.typography.labelSmall) }
                        payment.correctionOfPaymentId?.let { Text("حركة تصحيح للدفعة رقم $it", style = MaterialTheme.typography.labelSmall) }
                    }
                }
                Divider()
            }
            val itemReversals = reversals.filter { reversal -> itemPayments.any { it.id == reversal.originalPaymentId } }
            itemReversals.forEach { reversal ->
                val recovered = recoveries.filter { it.reversalId == reversal.id }.sumOf { it.amountPiasters }
                val outstanding = (reversal.amountPiasters - recovered).coerceAtLeast(0L)
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("مديونية عكس مرتب #${reversal.id}", style = MaterialTheme.typography.titleSmall)
                        Text("قيمة العكس: ${Money.format(reversal.amountPiasters)} • تم تحصيل: ${Money.format(recovered)} • متبقي: ${Money.format(outstanding)}")
                        if (outstanding > 0L) TextButton(onClick = { reversalToRecover = reversal }) { Text("تسجيل تحصيل فعلي من الموظف") }
                    }
                }
            }
            Button(onClick = { showPaymentDialog = true }, enabled = item.netPiasters > item.paidPiasters, modifier = Modifier.fillMaxWidth()) { Text("تسجيل دفعة مرتب جديدة") }
            if (showPaymentDialog) PayrollPaymentDialog(
                remaining = (item.netPiasters - item.paidPiasters).coerceAtLeast(0L),
                close = { showPaymentDialog = false },
                save = { amount, date, method, note, accountId -> onRecordPayment(item, amount, date, method, note, accountId); showPaymentDialog = false },
                accounts = cashAccounts
            )
            paymentToCorrect?.let { selected ->
                VoidPayrollPaymentDialog(
                    payment = selected,
                    maxReplacement = (item.netPiasters - item.paidPiasters + selected.amountPiasters).coerceAtLeast(0L),
                    close = { paymentToCorrect = null },
                    save = { amount, date, method, note, reason ->
                        onVoidOrCorrect(selected, amount, date, method, note, reason)
                        paymentToCorrect = null
                    }
                )
            }
            paymentToReverse?.let { selected ->
                ReversePaidPayrollDialog(
                    payment = selected,
                    accounts = cashAccounts,
                    close = { paymentToReverse = null },
                    save = { returned, account, reason, note ->
                        onReversePaid(selected, returned, account, reason, note)
                        paymentToReverse = null
                    }
                )
            }
            reversalToRecover?.let { selected ->
                val collected = recoveries.filter { it.reversalId == selected.id }.sumOf { it.amountPiasters }
                PayrollRecoveryDialog(
                    reversal = selected, remaining = (selected.amountPiasters - collected).coerceAtLeast(0L),
                    accounts = cashAccounts, close = { reversalToRecover = null },
                    save = { amount, account, note -> onRecordRecovery(selected.id, amount, account, note); reversalToRecover = null }
                )
            }
        } }
    }
}


@Composable
private fun PayrollPaymentDialog(
    remaining: Long,
    close: () -> Unit,
    save: (Long, String, String, String, String) -> Unit,
    accounts: List<CashAccount>
) {
    var amount by remember { mutableStateOf(String.format(Locale.US, "%.2f", remaining / 100.0)) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var method by remember { mutableStateOf("نقدي") }
    var note by remember { mutableStateOf("") }
    var accountId by remember { mutableStateOf("cash") }
    val parsed = Money.parseNonNegative(amount)
    AlertDialog(
        onDismissRequest = close,
        title = { Text("تسجيل دفعة مرتب") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("المتبقي: ${Money.format(remaining)}", color = MaterialTheme.colorScheme.primary)
                OutlinedTextField(amount, { amount = it.filter { c -> c.isDigit() || c == '.' || c == ',' } }, label = { Text("مبلغ الدفعة بالجنيه") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(date, { date = it }, label = { Text("تاريخ الصرف YYYY-MM-DD") }, singleLine = true)
                CashAccountDropdown(accounts = accounts, selectedId = accountId, onSelected = { accountId = it }, label = "حساب الصرف")
                Text("تفصيل طريقة الدفع")
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    listOf("نقدي", "تحويل بنكي", "محفظة إلكترونية", "شيك", "أخرى").forEach { value ->
                        FilterChip(selected = method == value, onClick = { method = value }, label = { Text(value) })
                    }
                }
                OutlinedTextField(note, { note = it }, label = { Text("ملاحظات / رقم مرجعي (اختياري)") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(
                enabled = parsed != null && parsed > 0 && parsed <= remaining && runCatching { LocalDate.parse(date) }.isSuccess,
                onClick = { parsed?.let { save(it, date, method, note, accountId) } }
            ) { Text("حفظ الدفعة") }
        },
        dismissButton = { TextButton(onClick = close) { Text("إلغاء") } }
    )
}


@Composable
private fun VoidPayrollPaymentDialog(
    payment: EmployeePayrollPayment,
    maxReplacement: Long,
    close: () -> Unit,
    save: (Long?, String, String, String, String) -> Unit
) {
    var amount by remember(payment.id) { mutableStateOf("") }
    var date by remember(payment.id) { mutableStateOf(payment.paymentDate) }
    var method by remember(payment.id) { mutableStateOf(payment.paymentMethod) }
    var note by remember(payment.id) { mutableStateOf(payment.note) }
    var reason by remember(payment.id) { mutableStateOf("") }
    val parsed = if (amount.isBlank()) null else Money.parseNonNegative(amount)
    val validAmount = amount.isBlank() || (parsed != null && parsed > 0 && parsed <= maxReplacement)
    val validDate = amount.isBlank() || runCatching { LocalDate.parse(date) }.isSuccess
    AlertDialog(
        onDismissRequest = close,
        title = { Text("إلغاء / تصحيح دفعة مرتب") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الحركة الأصلية: ${payment.paymentDate} • ${Money.format(payment.amountPiasters)} • ${payment.paymentMethod}")
                Text("استخدم هذا المسار فقط إذا لم يخرج أي مال فعليًا من الخزينة أو البنك. إذا كان المرتب قد صُرف، استخدم (عكس صرف فعلي) حتى لا تختفي حركة النقد.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                Text("أقصى مبلغ تصحيح: ${Money.format(maxReplacement)}", color = MaterialTheme.colorScheme.primary)
                OutlinedTextField(amount, { amount = it.filter { c -> c.isDigit() || c == '.' || c == ',' } }, label = { Text("مبلغ الدفعة الصحيحة بالجنيه (اختياري)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                if (amount.isNotBlank()) {
                    OutlinedTextField(date, { date = it }, label = { Text("تاريخ الصرف YYYY-MM-DD") }, singleLine = true)
                    Text("طريقة الدفع")
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        listOf("نقدي", "تحويل بنكي", "محفظة إلكترونية", "شيك", "أخرى").forEach { value ->
                            FilterChip(selected = method == value, onClick = { method = value }, label = { Text(value) })
                        }
                    }
                    OutlinedTextField(note, { note = it }, label = { Text("ملاحظات / رقم مرجعي") }, singleLine = true)
                }
                OutlinedTextField(reason, { reason = it }, label = { Text("سبب الإلغاء أو التصحيح (إلزامي)") }, minLines = 2)
            }
        },
        confirmButton = {
            TextButton(
                enabled = reason.isNotBlank() && validAmount && validDate,
                onClick = { save(parsed, date, method, note, reason) }
            ) { Text(if (amount.isBlank()) "تأكيد الإلغاء" else "إلغاء الأصل وتسجيل التصحيح") }
        },
        dismissButton = { TextButton(onClick = close) { Text("رجوع") } }
    )
}


@Composable
private fun ReversePaidPayrollDialog(
    payment: EmployeePayrollPayment,
    accounts: List<CashAccount>,
    close: () -> Unit,
    save: (Long, String?, String, String) -> Unit
) {
    var returned by remember(payment.id) { mutableStateOf("0.00") }
    var accountId by remember(payment.id) { mutableStateOf(payment.accountId ?: "cash") }
    var reason by remember(payment.id) { mutableStateOf("") }
    var note by remember(payment.id) { mutableStateOf("") }
    val amount = Money.parseNonNegative(returned)
    val valid = amount != null && amount in 0L..payment.amountPiasters &&
        (amount == 0L || accounts.any { it.id == accountId && it.isActive }) && reason.isNotBlank()
    AlertDialog(
        onDismissRequest = close,
        title = { Text("عكس دفعة مرتب صُرفت فعليًا") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("قيمة الدفعة الأصلية: ${Money.format(payment.amountPiasters)}")
                Text("أدخل ما عاد فعليًا من الموظف. الفرق سيظل مديونية ولا يدخل رصيد الخزينة.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(returned, { returned = it.filter { c -> c.isDigit() || c == '.' || c == ',' } }, label = { Text("المبلغ المسترد فعليًا بالجنيه") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                if ((amount ?: 0L) > 0L) CashAccountDropdown(accounts = accounts, selectedId = accountId, onSelected = { accountId = it }, label = "الحساب الذي استقبل المبلغ")
                Text("المديونية المتبقية: ${Money.format(payment.amountPiasters - (amount ?: 0L))}", color = MaterialTheme.colorScheme.error)
                OutlinedTextField(reason, { reason = it }, label = { Text("سبب عكس المرتب (إلزامي)") }, minLines = 2)
                OutlinedTextField(note, { note = it }, label = { Text("ملاحظات / مرجع (اختياري)") })
            }
        },
        confirmButton = { TextButton(enabled = valid, onClick = { amount?.let { save(it, if (it > 0L) accountId else null, reason.trim(), note.trim()) } }) { Text("تأكيد العكس") } },
        dismissButton = { TextButton(onClick = close) { Text("رجوع") } }
    )
}


@Composable
private fun PayrollRecoveryDialog(
    reversal: EmployeePayrollReversal,
    remaining: Long,
    accounts: List<CashAccount>,
    close: () -> Unit,
    save: (Long, String, String) -> Unit
) {
    var amountText by remember(reversal.id) { mutableStateOf(Money.plain(remaining)) }
    var accountId by remember(reversal.id) { mutableStateOf("cash") }
    var note by remember(reversal.id) { mutableStateOf("") }
    val amount = Money.parseNonNegative(amountText)
    AlertDialog(
        onDismissRequest = close,
        title = { Text("تحصيل مديونية مرتب") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("المديونية المتبقية: ${Money.format(remaining)}")
                OutlinedTextField(amountText, { amountText = it.filter { c -> c.isDigit() || c == '.' || c == ',' } }, label = { Text("المبلغ المستلم فعليًا بالجنيه") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                CashAccountDropdown(accounts = accounts, selectedId = accountId, onSelected = { accountId = it }, label = "الحساب الذي استقبل المبلغ")
                OutlinedTextField(note, { note = it }, label = { Text("ملاحظات / مرجع") })
            }
        },
        confirmButton = { TextButton(enabled = amount != null && amount > 0L && amount <= remaining && accounts.any { it.id == accountId && it.isActive }, onClick = { amount?.let { save(it, accountId, note.trim()) } }) { Text("تسجيل التحصيل") } },
        dismissButton = { TextButton(onClick = close) { Text("رجوع") } }
    )
}
