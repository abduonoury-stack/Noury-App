package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.tahseel.students.BuildConfig
import com.tahseel.students.sync.SupabaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

private enum class AccessMode { LOGIN, REGISTER, RECOVERY, CHANGE_PASSWORD }

@Composable
fun NouryAccessScreen(onAuthenticated: () -> Unit) {
    val context = LocalContext.current
    val auth = remember(context) { SupabaseAuth(context) }
    val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf(AccessMode.LOGIN) }
    var phone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var temporaryPassword by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var jobTitle by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var recoveryCode by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf(false) }

    fun showMessage(value: String, isError: Boolean = false) { message = value; error = isError }
    fun callPublicFunction(function: String, payload: JSONObject, token: String? = null): JSONObject {
        val requestBuilder = Request.Builder()
            .url("${BuildConfig.SUPABASE_URL}/functions/v1/$function")
            .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
        if (!token.isNullOrBlank()) requestBuilder.header("Authorization", "Bearer $token")
        OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
            .newCall(requestBuilder.build()).execute().use { response ->
                val body = response.body?.string().orEmpty()
                val json = runCatching { JSONObject(body) }.getOrElse { JSONObject() }
                if (!response.isSuccessful) throw IOException(json.optString("error").ifBlank { "تعذر تنفيذ العملية (HTTP ${response.code})" })
                return json
            }
    }

    LaunchedEffect(Unit) {
        val existing = auth.validateStoredSession()
        if (existing != null) {
            if (existing.mustChangePassword) {
                auth.signOut()
                showMessage("لأسباب أمنية، أعد تسجيل الدخول بكلمة المرور المؤقتة لتعيين كلمة مرورك الجديدة.", true)
            } else onAuthenticated()
        }
    }

    AppScaffold(
        title = when (mode) {
            AccessMode.LOGIN -> "تسجيل الدخول إلى Noury"
            AccessMode.REGISTER -> "طلب إنشاء حساب جديد"
            AccessMode.RECOVERY -> "استعادة كلمة المرور"
            AccessMode.CHANGE_PASSWORD -> "تغيير كلمة المرور المؤقتة"
        },
        onBack = if (mode == AccessMode.LOGIN) null else ({ mode = AccessMode.LOGIN; message = null })
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp)
        ) {
            Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(44.dp))
            when (mode) {
                AccessMode.LOGIN -> {
                    Text("أدخل رقم الموبايل وكلمة المرور المعتمدين من مالك البرنامج.", style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(phone, { phone = it.filter { c -> c.isDigit() || c == '+' || c == ' ' } }, label = { Text("رقم الموبايل") }, placeholder = { Text("01XXXXXXXXX") }, modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !busy)
                    OutlinedTextField(password, { password = it }, label = { Text("كلمة المرور") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !busy)
                    Button(onClick = {
                        busy = true; message = null
                        scope.launch {
                            try {
                                val result = auth.signInWithPassword(phone, password)
                                if (result.mustChangePassword) {
                                    temporaryPassword = password
                                    password = ""
                                    mode = AccessMode.CHANGE_PASSWORD
                                } else {
                                    password = ""
                                    com.tahseel.students.sync.AutomaticSyncScheduler.requestNow(context)
                                    onAuthenticated()
                                }
                            } catch (e: Exception) { showMessage(e.message ?: "تعذر تسجيل الدخول", true) }
                            finally { busy = false }
                        }
                    }, enabled = !busy && phone.isNotBlank() && password.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                        if (busy) CircularProgressIndicator(Modifier.size(19.dp), strokeWidth = 2.dp) else Text("تسجيل الدخول")
                    }
                    TextButton(onClick = { mode = AccessMode.REGISTER; message = null }, enabled = !busy) { Text("إنشاء حساب جديد لأول مرة") }
                    TextButton(onClick = { mode = AccessMode.RECOVERY; message = null }, enabled = !busy) { Text("نسيت كلمة المرور؟") }
                }
                AccessMode.REGISTER -> {
                    Text("إرسال الطلب لا ينشئ حساب دخول. سيظهر للمالك للمراجعة والقبول أو الرفض.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedTextField(fullName, { fullName = it }, label = { Text("الاسم بالكامل") }, modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !busy)
                    OutlinedTextField(phone, { phone = it.filter { c -> c.isDigit() || c == '+' || c == ' ' } }, label = { Text("رقم الموبايل المرتبط بواتساب") }, placeholder = { Text("01XXXXXXXXX") }, modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !busy)
                    OutlinedTextField(jobTitle, { jobTitle = it }, label = { Text("الوظيفة") }, modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !busy)
                    OutlinedTextField(address, { address = it }, label = { Text("العنوان") }, modifier = Modifier.fillMaxWidth(), minLines = 2, enabled = !busy)
                    Button(onClick = {
                        busy = true; message = null
                        scope.launch {
                            try {
                                val payload = JSONObject().put("full_name", fullName).put("phone", auth.normalizeEgyptianPhone(phone))
                                    .put("job_title", jobTitle).put("address", address)
                                val result = withContext(Dispatchers.IO) { callPublicFunction("registration-request", payload) }
                                showMessage(result.optString("message", "تم إرسال طلبك للمراجعة."))
                                fullName = ""; phone = ""; jobTitle = ""; address = ""
                                mode = AccessMode.LOGIN
                            } catch (e: Exception) { showMessage(e.message ?: "تعذر إرسال الطلب", true) }
                            finally { busy = false }
                        }
                    }, enabled = !busy && fullName.isNotBlank() && phone.isNotBlank() && jobTitle.isNotBlank() && address.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                        if (busy) CircularProgressIndicator(Modifier.size(19.dp), strokeWidth = 2.dp) else Text("إرسال طلب التسجيل")
                    }
                }
                AccessMode.RECOVERY -> {
                    Text("سيتم إرسال رمز استعادة إلى واتساب للتحقق من ملكية الرقم. هذا الرمز للاستعادة فقط، وليس لتسجيل الدخول المعتاد.", style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(phone, { phone = it.filter { c -> c.isDigit() || c == '+' || c == ' ' } }, label = { Text("رقم الموبايل") }, modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !busy)
                    OutlinedTextField(recoveryCode, { recoveryCode = it.filter(Char::isDigit).take(6) }, label = { Text("رمز الاستعادة") }, modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !busy)
                    OutlinedTextField(newPassword, { newPassword = it }, label = { Text("كلمة المرور الجديدة") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !busy)
                    OutlinedTextField(confirmPassword, { confirmPassword = it }, label = { Text("تأكيد كلمة المرور الجديدة") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !busy)
                    OutlinedButton(onClick = {
                        busy = true; message = null
                        scope.launch {
                            try {
                                withContext(Dispatchers.IO) { callPublicFunction("password-recovery", JSONObject().put("action", "request").put("phone", auth.normalizeEgyptianPhone(phone))) }
                                showMessage("إذا كان الرقم مسجلًا ونشطًا، فسيصلك رمز الاستعادة على واتساب.")
                            } catch (e: Exception) { showMessage(e.message ?: "تعذر طلب الرمز", true) }
                            finally { busy = false }
                        }
                    }, enabled = !busy && phone.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("إرسال رمز الاستعادة إلى واتساب") }
                    Button(onClick = {
                        busy = true; message = null
                        scope.launch {
                            try {
                                require(newPassword == confirmPassword) { "كلمتا المرور غير متطابقتين" }
                                withContext(Dispatchers.IO) {
                                    callPublicFunction("password-recovery", JSONObject().put("action", "reset")
                                        .put("phone", auth.normalizeEgyptianPhone(phone)).put("code", recoveryCode).put("new_password", newPassword))
                                }
                                phone = ""; recoveryCode = ""; newPassword = ""; confirmPassword = ""; mode = AccessMode.LOGIN
                                showMessage("تم تغيير كلمة المرور. يمكنك تسجيل الدخول الآن.")
                            } catch (e: Exception) { showMessage(e.message ?: "تعذر تغيير كلمة المرور", true) }
                            finally { busy = false }
                        }
                    }, enabled = !busy && recoveryCode.length == 6 && newPassword.length >= 10 && confirmPassword.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("تأكيد الرمز وتغيير كلمة المرور") }
                }
                AccessMode.CHANGE_PASSWORD -> {
                    Text("هذه كلمة مرور مؤقتة. يجب تعيين كلمة مرور جديدة قبل استخدام التطبيق.", style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(newPassword, { newPassword = it }, label = { Text("كلمة المرور الجديدة") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !busy)
                    OutlinedTextField(confirmPassword, { confirmPassword = it }, label = { Text("تأكيد كلمة المرور") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !busy)
                    Button(onClick = {
                        busy = true; message = null
                        scope.launch {
                            try {
                                require(newPassword == confirmPassword) { "كلمتا المرور غير متطابقتين" }
                                auth.changePassword(temporaryPassword, newPassword)
                                newPassword = ""; confirmPassword = ""; temporaryPassword = ""
                                com.tahseel.students.sync.AutomaticSyncScheduler.requestNow(context)
                                onAuthenticated()
                            } catch (e: Exception) { showMessage(e.message ?: "تعذر تغيير كلمة المرور", true) }
                            finally { busy = false }
                        }
                    }, enabled = !busy && newPassword.length >= 10 && confirmPassword.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                        if (busy) CircularProgressIndicator(Modifier.size(19.dp), strokeWidth = 2.dp) else Text("حفظ كلمة المرور والمتابعة")
                    }
                    TextButton(onClick = {
                        scope.launch { auth.signOut(); temporaryPassword = ""; mode = AccessMode.LOGIN; showMessage("تم تسجيل الخروج") }
                    }, enabled = !busy) { Text("تسجيل الخروج") }
                }
            }
            message?.let { Text(it, color = if (error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary) }
            Text("الدخول العادي برقم الموبايل وكلمة المرور فقط. لا يتم إرسال OTP عند تسجيل الدخول.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
