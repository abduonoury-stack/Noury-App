package com.tahseel.students.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** ملف الطالب. تحفظ التواريخ كـ epoch millis، والحقول الاختيارية فارغة عند عدم توفرها. */
@Entity(tableName = "students", indices = [Index("fullName"), Index("status"), Index(value = ["cloudId"], unique = true)])
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** Stable cross-device identifier; never expose the full Student entity to teachers. */
    @ColumnInfo(defaultValue = "''") val cloudId: String = java.util.UUID.randomUUID().toString(),
    val fullName: String,
    val birthDate: Long? = null,
    val enrollmentDate: Long,
    val className: String = "",
    /** كود الفترة: 15 = صباحية (8 ص–1 م)، 16 = مسائية (10 ص–3 م)، و17 للتوافق مع السجلات القديمة. */
    val attendanceEndHour: Int = 15,
    /** الفترة المرتبط بها الطالب؛ null للسجلات التاريخية غير المعينة. */
    val periodId: Long? = null,
    /** سعر خاص للطالب بالقروش، إن وُجد. */
    val monthlyFeeOverridePiasters: Long? = null,
    /** مبلغ الشهر الأول الجزئي عند الالتحاق بمنتصف الشهر، بالقروش. */
    val firstMonthAmountPiasters: Long? = null,
    val motherName: String = "",
    val motherWhatsapp: String = "",
    val fatherName: String = "",
    val fatherPhone: String = "",
    val address: String = "",
    val photoUri: String? = null,
    /** النوع لاختيار الصورة الافتراضية المناسبة عند عدم رفع صورة شخصية. */
    val gender: String = "boy",
    val status: String = "active",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)


/** Canonical student gender values used by avatars and legacy backup restore. */
object StudentGender {
    fun normalize(raw: String?): String {
        val value = raw?.trim()?.lowercase(java.util.Locale.ROOT).orEmpty()
        return when (value) {
            "girl", "female", "f", "أنثى", "انثى", "بنت", "طالبة" -> "girl"
            "boy", "male", "m", "ذكر", "ولد", "طالب", "" -> "boy"
            else -> "boy"
        }
    }
}
