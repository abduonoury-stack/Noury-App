package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.tahseel.students.sync.SupabaseAuth
import kotlinx.coroutines.launch

@Composable
fun OwnerLoginScreen(onLoggedIn: () -> Unit, onTeacherRequest: () -> Unit) {
    val context = LocalContext.current
    val auth = remember(context) { SupabaseAuth(context) }
    val scope = rememberCoroutineScope()
    var phone by remember { mutableStateOf("01273288127") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    AppScaffold("تسجيل الدخول إلى Noury", {}) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("مرحبًا بك في Noury", style = MaterialTheme.typography.headlineSmall)
            Text("سجّل الدخول برقم الموبايل وكلمة المرور. لن يُطلب كود OTP عند تسجيل الدخول.", style = MaterialTheme.typography.bodyMedium)
            OutlinedTextField(value = phone, onValueChange = { phone = it.filter { c -> c.isDigit() || c == '+' }.take(16) }, label = { Text("رقم الموبايل") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = !busy)
            OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("كلمة المرور") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = !busy)
            Button(onClick = {
                busy = true; error = null
                scope.launch {
                    try {
                        auth.signInWithPassword(phone, password)
                        onLoggedIn()
                    } catch (e: Exception) { error = e.message ?: "تعذر تسجيل الدخول" }
                    finally { busy = false }
                }
            }, enabled = !busy && phone.isNotBlank() && password.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                if (busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Text("تسجيل الدخول")
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            OutlinedButton(onClick = onTeacherRequest, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("طلب إنشاء حساب مدرس") }
            Text("يتم تحديد صلاحياتك تلقائيًا حسب الدور الذي اعتمده المالك.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
