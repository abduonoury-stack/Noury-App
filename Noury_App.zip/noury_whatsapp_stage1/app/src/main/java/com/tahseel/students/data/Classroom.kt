package com.tahseel.students.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "classrooms", indices = [Index(value = ["name"], unique = true), Index(value = ["cloudId"], unique = true)])
data class Classroom(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** Stable cross-device identifier used for teacher class assignment. */
    @ColumnInfo(defaultValue = "''") val cloudId: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val level: String = "",
    val teacherName: String = "",
    val capacity: Int = 20,
    val createdAt: Long = System.currentTimeMillis()
)
