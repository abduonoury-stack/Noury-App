package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.TextStyle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.vm.FormEvent
import com.tahseel.students.vm.PaymentFormViewModel
import kotlinx.coroutines.launch

@Composable
fun PaymentFormScreen(vm: PaymentFormViewModel, title: String, buttonText: String, onBack: () -> Unit, onDone: () -> Unit) {
    val s by vm.state.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current

    LaunchedEffect(Unit) {
        vm.events.collect { e ->
            when (e) {
                is FormEvent.Message -> { focus.clearFocus(); scope.launch { snack.showSnackbar(e.text) } }
                FormEvent.Done -> onDone()
            }
        }
    }

    AppScaffold(title = title, onBack = onBack, snackbarHost = { SnackbarHost(snack) }) { pad ->
        when {
            s.loading -> Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            s.notFound -> Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { Text("العملية غير موجودة") }
            else -> Column(
                Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                val textStyle = TextStyle(fontSize = 18.sp)
                PremiumCard {
                    Text("بيانات عملية التحصيل", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                    value = s.motherPhone, onValueChange = vm::onMotherPhone,
                    label = { Text("كود الطالب (رقم موبايل الأم)") },
                    supportingText = { Text(s.phoneHint ?: "اكتب الرقم لاسترجاع اسم الطالب وبياناته تلقائيًا") },
                    singleLine = true, textStyle = textStyle, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = { focus.moveFocus(FocusDirection.Down) })
                )
                OutlinedTextField(
                    value = s.name, onValueChange = vm::onName, label = { Text("اسم الطالب") },
                    isError = s.nameErr != null, supportingText = { s.nameErr?.let { Text(it) } },
                    singleLine = true, textStyle = textStyle, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = { focus.moveFocus(FocusDirection.Down) })
                )
                OutlinedTextField(
                    value = s.receipt, onValueChange = vm::onReceipt, label = { Text("رقم الإيصال") },
                    isError = s.receiptErr != null, supportingText = { s.receiptErr?.let { Text(it) } },
                    singleLine = true, textStyle = textStyle, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = { focus.moveFocus(FocusDirection.Down) })
                )
                if (!s.isEditing) {
                    CashAccountDropdown(accounts = s.accounts, selectedId = s.accountId, onSelected = vm::onAccount, label = "حساب استلام المبلغ")
                } else {
                    Text("حساب الحركة الأصلية: ${s.accounts.firstOrNull { it.id == s.accountId }?.name ?: if (s.accountId.isBlank()) "غير محدد تاريخيًا" else "غير متاح"} • لن يتغير عند تعديل بيانات الإيصال", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                OutlinedTextField(
                    value = s.amount, onValueChange = vm::onAmount, label = { Text("مبلغ الدفع (جنيه)") },
                    isError = s.amountErr != null, supportingText = { s.amountErr?.let { Text(it) } },
                    singleLine = true, textStyle = textStyle, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { focus.clearFocus(); vm.save() })
                )
                }
                BigButton(buttonText, Icons.Default.Check, onClick = { focus.clearFocus(); vm.save() }, enabled = !s.saving)
            }
        }
    }
}
