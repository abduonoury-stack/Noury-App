package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import com.tahseel.students.data.FinanceDao
import com.tahseel.students.util.WorkdaySettings
import com.tahseel.students.sync.SupabaseAuth

@Composable
fun SystemSettingsScreen(settingsDao: FinanceDao, onBack: () -> Unit, onAcademyProfile: () -> Unit, onManagePeriods: () -> Unit, onBackup: () -> Unit, onCashAccounts: () -> Unit, onSync: () -> Unit, onUsers: () -> Unit) {
    val context = LocalContext.current
    val isOwner = remember(context) { SupabaseAuth(context).currentRole() == "owner" }
    val scope = rememberCoroutineScope()
    var workdays by remember { mutableStateOf(WorkdaySettings.defaultDays) }
    LaunchedEffect(settingsDao) { workdays = WorkdaySettings.load(settingsDao) }
    AppScaffold("إعدادات وإدارة النظام", onBack) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 22.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("مركز التحكم", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
                    Text("كل إعدادات الأكاديمية وبياناتها وأدوات الحماية في مكان واحد", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .9f))
                    Text("إدارة منظمة • بيانات أكثر أمانًا", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .78f))
                }
            }
            SectionTitle("بيانات الأكاديمية")
            SystemActionCard("اسم الأكاديمية والبيانات العامة", "تعديل الاسم الرئيسي الذي يظهر في جميع الشاشات والإيصالات والتقارير وكشوف الطباعة", Icons.Default.Badge, onAcademyProfile)
            SectionTitle("أيام عمل الأكاديمية")
            Card(shape = MaterialTheme.shapes.large, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("حدد أيام العمل الرسمية. سيتم تطبيقها على تقويم حضور وغياب الطلاب والموظفين، وتقارير الغياب واحتساب خصم الغياب.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val labels = listOf(
                        DayOfWeek.SATURDAY to "السبت", DayOfWeek.SUNDAY to "الأحد", DayOfWeek.MONDAY to "الاثنين",
                        DayOfWeek.TUESDAY to "الثلاثاء", DayOfWeek.WEDNESDAY to "الأربعاء", DayOfWeek.THURSDAY to "الخميس", DayOfWeek.FRIDAY to "الجمعة"
                    )
                    labels.forEach { (day, label) ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(label, style = MaterialTheme.typography.titleSmall)
                            Checkbox(checked = day in workdays, onCheckedChange = { checked ->
                                workdays = if (checked) workdays + day else workdays - day
                            })
                        }
                    }
                    Text("أيام العمل المحددة: ${workdays.size} من 7", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    Button(onClick = {
                        if (workdays.isEmpty()) Toast.makeText(context, "اختر يوم عمل واحدًا على الأقل", Toast.LENGTH_LONG).show()
                        else scope.launch {
                            WorkdaySettings.save(settingsDao, workdays)
                            Toast.makeText(context, "تم حفظ أيام عمل الأكاديمية وتطبيقها على كشوف الطلاب والموظفين", Toast.LENGTH_LONG).show()
                        }
                    }, modifier = Modifier.fillMaxWidth(), enabled = workdays.isNotEmpty()) { Text("حفظ أيام العمل") }
                }
            }
            SectionTitle("المزامنة بين الأجهزة")
            SystemActionCard("ربط الجهاز بحساب المزامنة", "تسجيل الدخول واختبار الاتصال بخدمة Supabase. لا يتم نقل البيانات في هذه المرحلة.", Icons.Default.CloudSync, onSync)
            SectionTitle("إدارة النظام")
            if (isOwner) {
                SystemActionCard("إدارة المستخدمين والصلاحيات", "إضافة حسابات الموظفين وتحديد أدوارهم وإيقاف الحسابات. متاحة لمالك البرنامج فقط.", Icons.Default.Security, onUsers)
            }
            SystemActionCard("إدارة حسابات النقدية والبنوك", "إضافة الحسابات أو تعطيلها وتسجيل التحويلات الداخلية بين النقدية والبنوك والمحافظ. الجرد ومراجعة الحركة من التقارير.", Icons.Default.Security, onCashAccounts)
            SystemActionCard("الفترات الدراسية وأسعار الاشتراك", "إضافة فترات الأطفال وتعديل مواعيدها وأسعار الاشتراكات وتواريخ سريان الأسعار", Icons.Default.Schedule, onManagePeriods)
            SystemActionCard("النسخ الاحتياطي والاستعادة", "إنشاء نسخة احتياطية من بيانات الأكاديمية أو استعادة نسخة سابقة", Icons.Default.Backup, onBackup)
            Card(shape = MaterialTheme.shapes.large, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("تنبيه لحماية البيانات", fontWeight = FontWeight.Bold)
                        Text("احتفظ بنسخة احتياطية خارج الهاتف بشكل دوري. لا تستعد نسخة قديمة إلا بعد التأكد من تاريخها، لأن الاستعادة تستبدل البيانات الحالية.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            Card(shape = MaterialTheme.shapes.large) {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("حول الإعدادات", fontWeight = FontWeight.Bold)
                        Text("اسم الأكاديمية الذي تعدله من الشاشة المخصصة هو الاسم الموحد في جميع أجزاء البرنامج والمستندات ورسائل أولياء الأمور. تعديل الاسم لا يغيّر أسعار الاشتراك أو السجلات المالية السابقة.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun SystemActionCard(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(onClick = onClick, shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .5f)), elevation = CardDefaults.cardElevation(1.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 17.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.size(50.dp)) {
                Box(contentAlignment = Alignment.Center) { Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(23.dp)) }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronLeft, contentDescription = "فتح", tint = MaterialTheme.colorScheme.primary)
        }
    }
}
