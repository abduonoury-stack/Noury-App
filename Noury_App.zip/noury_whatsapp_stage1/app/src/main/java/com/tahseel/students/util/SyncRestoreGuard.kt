package com.tahseel.students.util

import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock

/**
 * Mutual exclusion between a backup/cloud restore and a background sync pass.
 * A restore rewrites every table; a sync pass running at the same time could push
 * half-restored state or apply remote events on top of it.
 */
object SyncRestoreGuard {
    private val lock = ReentrantLock()

    /** Runs [block] only when no sync pass is in progress; waits up to [timeoutSeconds]. */
    fun <T> exclusive(timeoutSeconds: Long = 90, block: () -> T): T {
        check(lock.tryLock(timeoutSeconds, TimeUnit.SECONDS)) {
            "المزامنة التلقائية تعمل الآن؛ لم تبدأ الاستعادة حفاظًا على البيانات. أعد المحاولة بعد لحظات."
        }
        try { return block() } finally { lock.unlock() }
    }

    /** Runs a sync pass, or returns null (skipped) when a restore currently holds the guard. */
    fun <T> trySyncPass(block: () -> T): T? {
        if (!lock.tryLock()) return null
        try { return block() } finally { lock.unlock() }
    }
}
