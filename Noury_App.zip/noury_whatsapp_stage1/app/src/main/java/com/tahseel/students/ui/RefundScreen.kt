package com.tahseel.students.ui

import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.util.Money
import com.tahseel.students.vm.RefundViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RefundScreen(vm: RefundViewModel, onBack: () -> Unit) {
    val credits by vm.credits.collectAsStateWithLifecycle()
    val students by vm.students.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val allCredits by vm.allCredits.collectAsStateWithLifecycle()
    val accounts by vm.accounts.collectAsStateWithLifecycle()
    val payments by vm.payments.collectAsStateWithLifecycle()
    var manualPaymentId by remember { mutableStateOf<Long?>(null) }
    var manualExpanded by remember { mutableStateOf(false) }
    var manualAmount by remember { mutableStateOf("") }
    var manualReason by remember { mutableStateOf("") }
    var manualDocument by remember { mutableStateOf("") }
    var selectedId by remember { mutableStateOf<Long?>(null) }
    var expanded by remember { mutableStateOf(false) }
    var amount by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("cash") }
    var accountId by remember { mutableStateOf("cash") }
    var note by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val selected = credits.firstOrNull { it.id == selectedId }
    val manualCandidates = payments.filter { payment -> !payment.isCancelled && allCredits.none { it.paymentId == payment.id } }
    val manualSelected = manualCandidates.firstOrNull { it.id == manualPaymentId }
    val dateFmt = remember { SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar")) }

    AppScaffold(title = "المبالغ الزائدة والاسترداد", onBack = onBack) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("إنشاء رصيد استرداد يدوي", style = MaterialTheme.typography.titleLarge)
            Text("يُربط الرصيد بإيصال تحصيل عام غير مرتبط باشتراك شهري. السبب ورقم المستند إلزاميان، والاعتماد يتم منك مباشرة. إنشاء الرصيد لا يخصم من الخزينة أو البنك.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (manualCandidates.isEmpty()) Text("لا توجد إيصالات تحصيل عامة مؤهلة لإنشاء رصيد استرداد يدوي.", color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.bodySmall)
            ExposedDropdownMenuBox(expanded = manualExpanded, onExpandedChange = { manualExpanded = !manualExpanded }) {
                OutlinedTextField(
                    value = manualSelected?.let { "${it.receiptNo} • ${it.studentName} • ${Money.format(it.amountPiasters)}" }.orEmpty(),
                    onValueChange = {}, readOnly = true, label = { Text("إيصال التحصيل الأصلي") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(manualExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = manualExpanded, onDismissRequest = { manualExpanded = false }) {
                    manualCandidates.forEach { payment ->
                        DropdownMenuItem(text = { Text("${payment.receiptNo} • ${payment.studentName} • ${Money.format(payment.amountPiasters)}") }, onClick = { manualPaymentId = payment.id; manualExpanded = false; manualAmount = "" })
                    }
                }
            }
            OutlinedTextField(manualAmount, { manualAmount = it.filter { c -> c.isDigit() || c == '.' || c == ',' } }, label = { Text("قيمة الاسترداد بالجنيه") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            OutlinedTextField(manualReason, { manualReason = it }, label = { Text("سبب الاسترداد (إلزامي)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            OutlinedTextField(manualDocument, { manualDocument = it }, label = { Text("رقم المستند / المرجع (إلزامي)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Button(onClick = {
                val id = manualPaymentId
                if (id == null) message = "اختر إيصال التحصيل الأصلي أولًا" else {
                    busy = true
                    vm.createManualCredit(id, manualAmount, manualReason, manualDocument) { result ->
                        message = result; busy = false
                        if (result.startsWith("تم إنشاء")) { manualPaymentId = null; manualAmount = ""; manualReason = ""; manualDocument = "" }
                    }
                }
            }, enabled = !busy && manualPaymentId != null && manualAmount.isNotBlank() && manualReason.isNotBlank() && manualDocument.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("اعتماد وإنشاء رصيد الاسترداد") }
            HorizontalDivider()
            Text("صرف الأرصدة المعتمدة", style = MaterialTheme.typography.titleLarge)
            Text("اختر رصيدًا قابلًا للاسترداد، ثم سجّل المبلغ الذي تم رده فعليًا لولي الأمر.")
            if (credits.isEmpty()) Text("لا توجد أرصدة متبقية قابلة للاسترداد.", color = MaterialTheme.colorScheme.secondary)
            else {
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(
                        value = selected?.let { c -> "${students.firstOrNull { it.id == c.studentId }?.fullName ?: "طالب"} • متبقي ${Money.format(c.remainingAmountPiasters)}" }.orEmpty(),
                        onValueChange = {}, readOnly = true, label = { Text("رصيد الاسترداد / الطفل") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        credits.forEach { credit ->
                            DropdownMenuItem(
                                text = { Text("${students.firstOrNull { it.id == credit.studentId }?.fullName ?: "طالب"} — ${Money.format(credit.remainingAmountPiasters)}") },
                                onClick = { selectedId = credit.id; amount = ""; expanded = false }
                            )
                        }
                    }
                }
                selected?.let {
                    Text("الرصيد الأصلي: ${Money.format(it.originalAmountPiasters)}  |  المتبقي: ${Money.format(it.remainingAmountPiasters)}")
                    if (it.reason.isNotBlank()) Text("السبب: ${it.reason}", style = MaterialTheme.typography.bodySmall)
                    if (it.documentReference.isNotBlank()) Text("المستند: ${it.documentReference}", style = MaterialTheme.typography.bodySmall)
                }
                OutlinedTextField(value = amount, onValueChange = { amount = it.filter(Char::isDigit) }, label = { Text("المبلغ الذي تم رده بالجنيه") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                CashAccountDropdown(accounts = accounts, selectedId = accountId, onSelected = { accountId = it }, label = "حساب الصرف")
                Text("طريقة الرد / المرجع")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = method == "cash", onClick = { method = "cash" }, label = { Text("نقدًا") })
                    FilterChip(selected = method == "transfer", onClick = { method = "transfer" }, label = { Text("تحويل") })
                }
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("ملاحظات (اختياري)") }, modifier = Modifier.fillMaxWidth())
                BigButton("تأكيد رد المبلغ وتحديث الرصيد", Icons.Default.AccountBalanceWallet, onClick = {
                    val id = selectedId
                    if (id == null) message = "اختر رصيد الاسترداد أولًا" else {
                        busy = true
                        vm.refund(id, amount, method, note, accountId) { message = it; busy = false; if (it.startsWith("تم تسجيل")) { amount = ""; note = "" } }
                    }
                }, enabled = !busy)
            }
            HorizontalDivider()
            Text("سجل عمليات الاسترداد", style = MaterialTheme.typography.titleLarge)
            if (history.isEmpty()) Text("لا توجد عمليات استرداد مسجلة بعد.")
            history.forEach { tx ->
                val credit = allCredits.firstOrNull { it.id == tx.refundCreditId }
                val studentName = students.firstOrNull { it.id == credit?.studentId }?.fullName ?: "رقم رصيد ${tx.refundCreditId}"
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(studentName, style = MaterialTheme.typography.titleMedium)
                        Text("${Money.format(tx.amountPiasters)} • ${when (tx.method) { "transfer" -> "تحويل"; "exit_settlement" -> "صرف من تسوية انسحاب"; else -> "نقدًا" }}")
                        Text(dateFmt.format(Date(tx.refundedAt)), style = MaterialTheme.typography.bodySmall)
                        if (tx.note.isNotBlank()) Text(tx.note, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
    message?.let { msg -> AlertDialog(onDismissRequest = { message = null }, confirmButton = { TextButton(onClick = { message = null }) { Text("حسنًا") } }, text = { Text(msg) }) }
}
