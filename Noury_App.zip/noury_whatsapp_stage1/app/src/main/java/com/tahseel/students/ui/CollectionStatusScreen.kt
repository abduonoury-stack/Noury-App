package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.util.AcademyProfileStore
import com.tahseel.students.util.Money
import com.tahseel.students.vm.CollectionStatusViewModel
import com.tahseel.students.vm.CollectionStudentRow
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.net.URLEncoder
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun CollectionStatusScreen(vm: CollectionStatusViewModel, onBack: () -> Unit, onProfile: (Long) -> Unit) {
    val summary by vm.summary.collectAsStateWithLifecycle()
    val rows by vm.visibleRows.collectAsStateWithLifecycle()
    val month by vm.period.collectAsStateWithLifecycle()
    val query by vm.search.collectAsStateWithLifecycle()
    val filter by vm.filter.collectAsStateWithLifecycle()
    val monthLabel = month.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale("ar")))

    AppScaffold("متابعة التحصيل", onBack) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize().padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        IconButton(onClick = vm::previousMonth) { Icon(Icons.Default.ChevronRight, contentDescription = "الشهر السابق") }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("شهر التحصيل", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
                            Text(monthLabel, style = MaterialTheme.typography.titleLarge)
                        }
                        IconButton(onClick = vm::nextMonth) { Icon(Icons.Default.ChevronLeft, contentDescription = "الشهر التالي") }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard("الطلاب المنتظمون", summary.rows.size.toString(), Modifier.weight(1f))
                    StatCard("تم السداد", summary.paidCount.toString(), Modifier.weight(1f))
                    StatCard("لم يسددوا", summary.unpaidCount.toString(), Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard("إجمالي المستحق", Money.format(summary.dueTotal), Modifier.weight(1f))
                    StatCard("المحصل", Money.format(summary.collectedTotal), Modifier.weight(1f))
                }
            }
            item { StatCard("المتبقي للتحصيل", Money.format(summary.remainingTotal), Modifier.fillMaxWidth(), big = true) }
            item {
                OutlinedTextField(
                    value = query, onValueChange = { vm.search.value = it },
                    label = { Text("ابحث باسم الطالب أو رقم واتساب الأم") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = filter == "all", onClick = { vm.selectFilter("all") }, label = { Text("الكل") })
                    FilterChip(selected = filter == "paid", onClick = { vm.selectFilter("paid") }, label = { Text("سدد") })
                    FilterChip(selected = filter == "unpaid", onClick = { vm.selectFilter("unpaid") }, label = { Text("لم يسدد") })
                }
            }
            if (rows.isEmpty()) {
                item { Text("لا توجد أسماء مطابقة لهذا الاختيار", modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.secondary) }
            } else {
                items(rows, key = { it.student.id }) { row -> CollectionStudentCard(row, monthLabel, onProfile = { onProfile(row.student.id) }) }
            }
            item {
                Text(
                    "الحالة تعتمد على سجل تحصيل الاشتراك الشهري المسجل لهذا الشهر. الطالب المنقطع لا يظهر ضمن المستحقين، والدفعات الملغاة لا تُحتسب.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun CollectionStudentCard(row: CollectionStudentRow, monthLabel: String, onProfile: () -> Unit) {
    val paid = row.isPaid
    val context = LocalContext.current
    fun sendWhatsAppReminder() {
        val rawPhone = row.student.motherWhatsapp.trim()
        val digits = rawPhone.filter { it.isDigit() }
        val internationalPhone = when {
            rawPhone.startsWith("+") -> digits
            digits.startsWith("00") -> digits.drop(2)
            digits.startsWith("0") -> "20${digits.drop(1)}"
            digits.startsWith("20") -> digits
            else -> digits
        }
        if (internationalPhone.length < 10) {
            Toast.makeText(context, "رقم واتساب الأم غير مسجل أو غير صحيح", Toast.LENGTH_LONG).show()
            return
        }
        val message = "ولي الأمر الكريم 🌷\nنذكّركم بسداد اشتراك الطالب/ة ${row.student.fullName} عن شهر $monthLabel.\nالمبلغ المتبقي: ${Money.format(row.remainingPiasters)}.\nنشكركم على تعاونكم وثقتكم في ${AcademyProfileStore.getName(context)}."
        val encodedMessage = URLEncoder.encode(message, "UTF-8")
        val chatUri = Uri.parse("https://wa.me/$internationalPhone?text=$encodedMessage")

        // Prefer WhatsApp Business, then regular WhatsApp, then the system default handler.
        val preferredPackages = listOf("com.whatsapp.w4b", "com.whatsapp")
        var opened = false
        for (packageName in preferredPackages) {
            try {
                context.startActivity(Intent(Intent.ACTION_VIEW, chatUri).apply {
                    setPackage(packageName)
                })
                opened = true
                break
            } catch (_: ActivityNotFoundException) {
                // Try the next supported WhatsApp app.
            }
        }
        if (!opened) {
            try {
                context.startActivity(Intent(Intent.ACTION_VIEW, chatUri))
                opened = true
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(context, "واتساب الأعمال أو واتساب غير مثبت، ولم يمكن فتح الرابط", Toast.LENGTH_LONG).show()
            }
        }
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                StudentAvatar(row.student.photoUri, 46.dp, row.student.id, row.student.gender)
                Text(row.student.fullName, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f).clickable(onClick = onProfile), color = MaterialTheme.colorScheme.primary)
                Surface(
                    color = if (paid) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer,
                    shape = MaterialTheme.shapes.large
                ) {
                    Text(
                        if (paid) "تم السداد" else "لم يسدد",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        color = if (paid) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
            if (row.student.motherWhatsapp.isNotBlank()) {
                Text("موبايل الأم: ${row.student.motherWhatsapp}", style = MaterialTheme.typography.bodySmall)
            }
            Text("المطلوب: ${Money.format(row.duePiasters)}")
            if (row.payment != null) Text("المدفوع: ${Money.format(row.paidPiasters)}")
            if (!paid) Text("المتبقي: ${Money.format(row.remainingPiasters)}", color = MaterialTheme.colorScheme.error)
            Text("${if (row.student.attendanceEndHour == 15) "صباحية 8 ص – 1 م" else "مسائية 10 ص – 3 م"} • ${row.student.className}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
            if (!paid) {
                Button(
                    onClick = ::sendWhatsAppReminder,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Send, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("إرسال تذكير واتساب")
                }
            }
        }
    }
}
