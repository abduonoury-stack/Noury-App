package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.tahseel.students.sync.SupabaseAuth
import com.tahseel.students.sync.SupabaseSnapshotSync
import com.tahseel.students.data.AppDatabase
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.text.font.FontWeight
import com.tahseel.students.util.FullDatabaseBackup
import java.io.File

@Composable
fun SupabaseLoginScreen(onBack: () -> Unit, onConflicts: () -> Unit) {
    val context = LocalContext.current
    val auth = remember(context) { SupabaseAuth(context) }
    val snapshotSync = remember(context) { SupabaseSnapshotSync(context, auth) }
    val database = remember(context) { AppDatabase.create(context) }
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var loggedIn by remember { mutableStateOf(auth.hasSession() && auth.currentOrganizationId() != null) }
    var cloudSnapshot by remember { mutableStateOf<SupabaseSnapshotSync.DownloadResult?>(null) }
    var confirmRestore by remember { mutableStateOf(false) }
    AppScaffold("ربط ومزامنة الأجهزة", onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Icon(Icons.Default.CloudSync, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp))
            Text("تسجيل الدخول إلى حساب المزامنة", style = MaterialTheme.typography.titleLarge)
            Text("المزامنة: السحابة هي المصدر الرئيسي. عند الاستعادة سيتم استبدال جميع بيانات التطبيق المحلية ببيانات النسخة السحابية، مع حفظ نسخة أمان محلية أولًا.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (loggedIn) {
                Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("تم تسجيل الدخول على هذا الجهاز", style = MaterialTheme.typography.titleMedium)
                    Text("رقم الحساب: ${auth.currentPhone().orEmpty()}")
                    Text("نوع الحساب: ${auth.currentRole().orEmpty()}")
                    Text("معرّف الحساب: ${auth.currentUserId().orEmpty()}")
                    Text("معرّف هذا الجهاز: ${snapshotSync.deviceId()}", style = MaterialTheme.typography.bodySmall)
                    Text("استخدم زر الرفع على الجهاز الأول فقط. على الجهاز الثاني استخدم فحص النسخة ثم الاستعادة.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedButton(onClick = onConflicts, modifier = Modifier.fillMaxWidth()) {
                        Text("مراجعة تعارضات المزامنة")
                    }
                    Button(onClick = {
                        busy = true; message = null
                        scope.launch {
                            try {
                                val result = snapshotSync.uploadPrimarySnapshot(database.openHelper.writableDatabase, com.tahseel.students.util.AcademyProfileStore.exportJson(context))
                                message = "تم رفع النسخة السحابية بنجاح. عدد السجلات: ${result.rowCount}. معرّف النسخة: ${result.snapshotId}"
                            } catch (e: Exception) {
                                message = e.message ?: "تعذر رفع النسخة السحابية"
                            } finally { busy = false }
                        }
                    }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                        if (busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Text("رفع النسخة الأولية إلى السحابة")
                    }
                    OutlinedButton(onClick = {
                        busy = true; message = null; cloudSnapshot = null
                        scope.launch {
                            try {
                                val result = snapshotSync.downloadLatestSnapshot()
                                cloudSnapshot = result
                                message = "تم العثور على نسخة سليمة. عدد السجلات: ${result.rowCount}. معرّف النسخة: ${result.snapshotId}"
                            } catch (e: Exception) { message = e.message ?: "تعذر فحص النسخة" }
                            finally { busy = false }
                        }
                    }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                        Text("فحص النسخة السحابية")
                    }
                    cloudSnapshot?.let { snap ->
                        Text("النسخة الجاهزة للاستعادة: ${snap.rowCount} سجل", fontWeight = FontWeight.Bold)
                        Button(onClick = { confirmRestore = true }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("استعادة بيانات الموبايل الأول على هذا الجهاز") }
                    }
                    Button(onClick = {
                        busy = true
                        scope.launch {
                            try { auth.signOut(); loggedIn = false; cloudSnapshot = null; message = "تم تسجيل الخروج من هذا الجهاز" }
                            catch (e: Exception) { message = e.message ?: "تعذر تسجيل الخروج" }
                            finally { busy = false }
                        }
                    }, enabled = !busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors()) { Text("تسجيل الخروج") }
                } }
            } else {
                Text("تسجيل الدخول برقم الموبايل", style = MaterialTheme.typography.titleMedium)
                Text("سجّل الدخول من شاشة Noury الرئيسية باستخدام رقم الموبايل وكلمة المرور. لا يتم إرسال OTP لتسجيل الدخول.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            message?.let { Text(it, color = if (loggedIn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
            Text("لا تضع مفتاح service_role داخل التطبيق. لا تضغط زر الرفع على الجهاز الثاني.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    if (confirmRestore && cloudSnapshot != null) {
        AlertDialog(
            onDismissRequest = { confirmRestore = false },
            title = { Text("تأكيد استعادة النسخة") },
            text = { Text("تحذير: سيتم استبدال جميع بيانات Noury الموجودة على هذا الجهاز (بما فيها الإعدادات والسجلات الافتراضية والبيانات الحالية) ببيانات النسخة السحابية وعددها ${cloudSnapshot!!.rowCount} سجل. سيتم حفظ نسخة أمان محلية من الحالة الحالية أولًا. لن تتغير النسخة السحابية أو بيانات الأجهزة الأخرى. هل تؤكد الاستبدال الكامل؟") },
            confirmButton = { TextButton(onClick = {
                confirmRestore = false
                val snap = cloudSnapshot ?: return@TextButton
                busy = true; message = null
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) {
                            val db = database.openHelper.writableDatabase
                            val localJson = FullDatabaseBackup.export(db, System.currentTimeMillis())
                            // Full replacement is intentional: the authenticated cloud snapshot
                            // is the source of truth for this account. Never block because the
                            // target device contains defaults or older local records. Keep a
                            // validated local safety export before the transactional restore.
                            FullDatabaseBackup.validate(localJson)
                            val dir = File(context.filesDir, "pre_restore_backups").apply { mkdirs() }
                            val safety = File(dir, "pre-restore-${System.currentTimeMillis()}.json")
                            safety.writeText(localJson, Charsets.UTF_8)
                            FullDatabaseBackup.validate(safety.readText(Charsets.UTF_8))
                            FullDatabaseBackup.restore(db, snap.payload)
                            // إعدادات الأكاديمية محفوظة داخل النسخة؛ تُستعاد مع البيانات إن وُجدت.
                            org.json.JSONObject(snap.payload).optJSONObject("receiptProfile")?.takeIf { it.length() > 0 }?.let { p ->
                                com.tahseel.students.util.AcademyProfileStore.save(context, p.optString("name", com.tahseel.students.util.AcademyProfileStore.DEFAULT_NAME), p.optString("address", ""), p.optString("phone", ""))
                            }
                            val verified = FullDatabaseBackup.export(db, System.currentTimeMillis())
                            val restoredCount = FullDatabaseBackup.rowCountMatching(FullDatabaseBackup.validate(verified), snap.payload)
                            check(restoredCount == snap.rowCount) { "تمت الاستعادة لكن فشل تحقق العدد: المتوقع ${snap.rowCount} والفعلي $restoredCount. احتفظ بنسخة الأمان ولا تستخدم التطبيق حتى المراجعة." }
                        }
                        val missingPhotos = withContext(Dispatchers.IO) { FullDatabaseBackup.missingPhotoCount(database.openHelper.writableDatabase) }
                        message = "تمت الاستعادة والتحقق بنجاح: ${snap.rowCount} سجل. النسخة السحابية الأصلية لم تتغير." +
                            if (missingPhotos > 0) " تنبيه: $missingPhotos طالبًا لا تتوفر صورهم على هذا الجهاز (النسخة السحابية لا تتضمن الصور)؛ تظهر لهم الصورة الافتراضية ولم يُعدَّل أي سجل." else ""
                    } catch (e: Exception) { message = e.message ?: "فشلت الاستعادة" }
                    finally { busy = false }
                }
            }) { Text("تأكيد الاستعادة") } },
            dismissButton = { TextButton(onClick = { confirmRestore = false }) { Text("إلغاء") } }
        )
    }
}
