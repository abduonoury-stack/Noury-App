package com.tahseel.students.sync

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/**
 * WorkManager self-rescheduling chain. Android periodic work has a 15-minute
 * minimum, so a delayed one-time chain targets five minutes instead.
 */
object AutomaticSyncScheduler {
    private const val UNIQUE_CHAIN = "noury-automatic-sync-chain"

    private fun constraints() = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()

    fun start(context: Context) {
        val request = OneTimeWorkRequestBuilder<AutomaticSyncWorker>()
            .setConstraints(constraints())
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            UNIQUE_CHAIN, ExistingWorkPolicy.KEEP, request
        )
    }

    /** Called by the worker after a successful pass to append the next five-minute pass. */
    fun scheduleNext(context: Context) {
        val request = OneTimeWorkRequestBuilder<AutomaticSyncWorker>()
            .setInitialDelay(5, TimeUnit.MINUTES)
            .setConstraints(constraints())
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            UNIQUE_CHAIN, ExistingWorkPolicy.APPEND_OR_REPLACE, request
        )
    }

    /** Login/manual refresh requests a run immediately and keeps the chain alive. */
    fun requestNow(context: Context) {
        val request = OneTimeWorkRequestBuilder<AutomaticSyncWorker>()
            .setConstraints(constraints())
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            UNIQUE_CHAIN, ExistingWorkPolicy.REPLACE, request
        )
    }
}
