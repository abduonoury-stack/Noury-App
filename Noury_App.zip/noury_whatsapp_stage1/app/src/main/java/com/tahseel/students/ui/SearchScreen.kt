package com.tahseel.students.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.data.Student
import com.tahseel.students.util.AcademyProfileStore
import com.tahseel.students.vm.SearchViewModel
import java.net.URLEncoder
import java.time.Instant
import java.time.LocalDate
import java.time.Period
import java.time.ZoneId

@Composable
fun SearchScreen(vm: SearchViewModel, onBack: () -> Unit, onOpen: (Long) -> Unit) {
    val q by vm.query.collectAsStateWithLifecycle()
    val results by vm.results.collectAsStateWithLifecycle()
    AppScaffold("البحث عن طالب", onBack) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = q, onValueChange = { vm.query.value = it }, singleLine = true,
                label = { Text("اسم الطالب أو رقم واتساب الأم") }, leadingIcon = { Icon(Icons.Default.Search, null) },
                modifier = Modifier.fillMaxWidth()
            )
            Text("البحث يشمل جميع ملفات الطلاب، سواء تم السداد أم لا", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (q.isBlank()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("اكتب اسم الطالب أو رقم واتساب الأم") }
            } else if (results.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("لا توجد نتائج") }
            } else {
                Text("عدد النتائج: ${results.size}", style = MaterialTheme.typography.titleSmall)
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(results, key = { it.id }) { student ->
                        Card(Modifier.fillMaxWidth().clickable { onOpen(student.id) }, shape = MaterialTheme.shapes.medium) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                StudentAvatar(student.photoUri, 50.dp, student.id, student.gender)
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(student.fullName, style = MaterialTheme.typography.titleMedium)
                                    Text("العمر: ${searchAge(student.birthDate)} • الفصل: ${student.className.ifBlank { "غير موزع" }}", style = MaterialTheme.typography.bodySmall)
                                    Text(if (student.status == "active") "منتظم" else "منقطع", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                }
                                Text("عرض البيانات", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun searchAge(birthDate: Long?): String {
    if (birthDate == null) return "غير مسجل"
    val birth = Instant.ofEpochMilli(birthDate).atZone(ZoneId.systemDefault()).toLocalDate()
    val age = Period.between(birth, LocalDate.now())
    return "${age.years} سنة و${age.months} شهر"
}

@Composable
private fun SearchStudentProfileDialog(student: Student, onDismiss: () -> Unit) {
    val context = LocalContext.current
    fun openWhatsApp() {
        val raw = student.motherWhatsapp.trim()
        val digits = raw.filter { it.isDigit() }
        val phone = when {
            raw.startsWith("+") -> digits
            digits.startsWith("00") -> digits.drop(2)
            digits.startsWith("0") -> "20${digits.drop(1)}"
            digits.startsWith("20") -> digits
            else -> digits
        }
        if (phone.length < 10) {
            Toast.makeText(context, "رقم واتساب الأم غير مسجل أو غير صحيح", Toast.LENGTH_LONG).show(); return
        }
        val body = "أهلًا بحضرتك 🌷\nبخصوص الطالب/ة ${student.fullName}، نتواصل مع حضرتك من ${AcademyProfileStore.getName(context)}."
        val uri = Uri.parse("https://wa.me/$phone?text=${URLEncoder.encode(body, "UTF-8")}")
        var opened = false
        for (pkg in listOf("com.whatsapp.w4b", "com.whatsapp")) {
            try { context.startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg)); opened = true; break }
            catch (_: ActivityNotFoundException) { }
        }
        if (!opened) try { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        catch (_: ActivityNotFoundException) { Toast.makeText(context, "واتساب غير مثبت على الجهاز", Toast.LENGTH_LONG).show() }
    }
    val birth = student.birthDate?.let { Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()).toLocalDate() }
    val enrollment = Instant.ofEpochMilli(student.enrollmentDate).atZone(ZoneId.systemDefault()).toLocalDate()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("الملف الكامل للطالب") },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) { StudentAvatar(student.photoUri, 64.dp, student.id, student.gender); Text(student.fullName, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary) }
                HorizontalDivider()
                SearchProfileLine("الحالة", if (student.status == "active") "منتظم" else "منقطع")
                SearchProfileLine("الفصل", student.className.ifBlank { "غير موزع" })
                SearchProfileLine("تاريخ الميلاد", birth?.toString() ?: "غير مسجل")
                SearchProfileLine("العمر", searchAge(student.birthDate))
                SearchProfileLine("تاريخ الالتحاق", enrollment.toString())
                SearchProfileLine("ميعاد الانصراف", if (student.attendanceEndHour == 15) "صباحية 8 ص – 1 م" else "مسائية 10 ص – 3 م")
                SearchProfileLine("الاشتراك الشهري", "حسب الفترة والسعر الساري")
                SearchProfileLine("اسم الأم", student.motherName)
                SearchProfileLine("واتساب الأم", student.motherWhatsapp)
                SearchProfileLine("اسم الأب", student.fatherName)
                SearchProfileLine("هاتف الأب", student.fatherPhone)
                SearchProfileLine("العنوان", student.address)
                SearchProfileLine("ملاحظات", student.notes)
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (student.motherWhatsapp.isNotBlank()) Button(onClick = ::openWhatsApp) { Icon(Icons.Default.Send, null); Spacer(Modifier.width(6.dp)); Text("واتساب الأعمال") }
                TextButton(onClick = onDismiss) { Text("إغلاق") }
            }
        }
    )
}

@Composable
private fun SearchProfileLine(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value.ifBlank { "غير مسجل" }, style = MaterialTheme.typography.bodyMedium)
    }
}
