package com.tahseel.students.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Safe interim landing page: teacher sign-in is accepted, but no owner dashboard,
 * full database, or organization-wide sync is exposed until scoped access is ready.
 */
@Composable
fun TeacherAccessPendingScreen(onBackToLogin: () -> Unit) {
    AppScaffold("حساب المدرس", {}) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("تم تسجيل الدخول بنجاح", style = MaterialTheme.typography.headlineSmall)
            Text(
                "تم التحقق من حساب المدرس، لكن صلاحيات الفصول ومزامنة الحضور لم تُفعّل بعد. " +
                    "لن نعرض بيانات الأطفال أو بيانات المؤسسة قبل اكتمال إعداد الصلاحيات الآمنة.",
                style = MaterialTheme.typography.bodyLarge
            )
            Text(
                "يرجى تسجيل الخروج والانتظار حتى تصلك نسخة المدرس المعتمدة.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(onClick = onBackToLogin, modifier = Modifier.fillMaxWidth()) {
                Text("تسجيل الخروج والعودة")
            }
        }
    }
}
