package com.tahseel.students.sync

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.tahseel.students.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Noury phone-number + password login backed by a deterministic synthetic email.
 * The synthetic address is an internal Auth identifier only; users never need an inbox.
 */
class SupabaseAuth(context: Context) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
    private val prefs = EncryptedSharedPreferences.create(
        context,
        "noury_supabase_auth",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    data class AuthResult(val userId: String, val email: String?)

    /** Normalizes Egyptian mobile numbers to E.164 (+20XXXXXXXXXX). */
    fun normalizeEgyptianPhone(input: String): String {
        val digits = input.filter(Char::isDigit)
        val normalized = when {
            digits.startsWith("0020") -> "+" + digits.drop(2)
            digits.startsWith("20") -> "+$digits"
            digits.startsWith("0") -> "+20${digits.drop(1)}"
            else -> "+20$digits"
        }
        require(Regex("^\\+201[0125]\\d{8}$").matches(normalized)) {
            "أدخل رقم موبايل مصري صحيحًا (01XXXXXXXXX)"
        }
        return normalized
    }


    /**
     * Maps an Egyptian phone number to a stable, non-deliverable synthetic email.
     * The application-owned synthetic domain prevents accidental delivery to a real mailbox.
     * Supabase Email confirmation MUST be disabled for this authentication design.
     */
    fun syntheticEmailForPhone(rawPhone: String): String {
        val phone = normalizeEgyptianPhone(rawPhone)
        val digits = phone.filter(Char::isDigit)
        return "$digits@users.noury.app"
    }

    /** Signs in with phone + password through Supabase email/password Auth; no OTP. */
    suspend fun signInWithPassword(rawPhone: String, password: String): AuthResult = withContext(Dispatchers.IO) {
        val phone = normalizeEgyptianPhone(rawPhone)
        require(phone == "+201273288127") { "هذه المرحلة مخصصة لحساب المالك المعتمد فقط." }
        require(password.isNotBlank()) { "أدخل كلمة المرور" }
        val syntheticEmail = syntheticEmailForPhone(phone)
        val json = JSONObject().put("email", syntheticEmail).put("password", password)
        val request = Request.Builder()
            .url("${BuildConfig.SUPABASE_URL}/auth/v1/token?grant_type=password")
            .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Content-Type", "application/json")
            .post(json.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("رقم الموبايل أو كلمة المرور غير صحيحة، أو الحساب غير مفعّل.")
            val result = JSONObject(body)
            val access = result.optString("access_token")
            val refresh = result.optString("refresh_token")
            val user = result.optJSONObject("user") ?: throw IOException("استجابة تسجيل الدخول غير مكتملة")
            val userId = user.optString("id")
            if (access.isBlank() || refresh.isBlank() || userId.isBlank()) throw IOException("بيانات الجلسة غير مكتملة")
            // Phase 1 is owner-only. Do not depend on user-management tables that
            // are not present in the existing Supabase schema. The current sync
            // ownership key remains the authenticated Supabase user UUID.
            val organizationId = userId
            val role = "owner"
            prefs.edit().putString("access_token", access).putString("refresh_token", refresh)
                .putString("user_id", userId).putString("organization_id", organizationId)
                .putString("role", role).putString("phone", phone)
                .putString("email", syntheticEmail).apply()
            AuthResult(userId, syntheticEmail)
        }
    }

    /** Refresh the short-lived access token before background synchronization. */
    suspend fun refreshAccessToken(): String? = withContext(Dispatchers.IO) {
        val refresh = prefs.getString("refresh_token", null) ?: return@withContext null
        val json = JSONObject().put("refresh_token", refresh)
        val request = Request.Builder()
            .url("${BuildConfig.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token")
            .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Content-Type", "application/json")
            .post(json.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("تعذر تحديث جلسة المزامنة (HTTP ${response.code})")
            val result = JSONObject(body)
            val access = result.optString("access_token")
            val nextRefresh = result.optString("refresh_token")
            if (access.isBlank() || nextRefresh.isBlank()) throw IOException("استجابة تحديث الجلسة غير مكتملة")
            prefs.edit().putString("access_token", access).putString("refresh_token", nextRefresh).apply()
            access
        }
    }

    fun currentUserId(): String? = prefs.getString("user_id", null)
    fun currentPhone(): String? = prefs.getString("phone", null)
    fun currentOrganizationId(): String? = prefs.getString("organization_id", null)
    fun currentRole(): String? = prefs.getString("role", null)
    fun accessToken(): String? = prefs.getString("access_token", null)
    fun hasSession(): Boolean = !prefs.getString("refresh_token", null).isNullOrBlank()
    suspend fun signOut() = withContext(Dispatchers.IO) {
        val access = prefs.getString("access_token", null)
        try {
            if (!access.isNullOrBlank()) {
                val request = Request.Builder()
                    .url("${BuildConfig.SUPABASE_URL}/auth/v1/logout")
                    .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
                    .header("Authorization", "Bearer $access")
                    .post("{}".toRequestBody("application/json".toMediaType()))
                    .build()
                client.newCall(request).execute().close()
            }
        } finally {
            prefs.edit().clear().apply()
        }
    }
}
