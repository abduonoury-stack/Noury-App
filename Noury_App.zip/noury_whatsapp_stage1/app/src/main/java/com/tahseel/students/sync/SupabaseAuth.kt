package com.tahseel.students.sync

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.tahseel.students.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Phone + password authentication. WhatsApp OTP is not used for normal sign-in. */
class SupabaseAuth(context: Context) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()
    private val prefs = EncryptedSharedPreferences.create(
        context,
        "noury_supabase_auth",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    data class AuthResult(
        val userId: String,
        val phone: String,
        val organizationId: String,
        val role: String,
        val mustChangePassword: Boolean
    )

    fun normalizeEgyptianPhone(input: String): String {
        val digits = input.filter(Char::isDigit)
        val normalized = when {
            digits.startsWith("0020") -> "+" + digits.drop(2)
            digits.startsWith("20") -> "+$digits"
            digits.startsWith("0") -> "+20${digits.drop(1)}"
            else -> "+20$digits"
        }
        require(Regex("^\\+201[0125]\\d{8}$").matches(normalized)) {
            "أدخل رقم موبايل مصري صحيحًا (01XXXXXXXXX)"
        }
        return normalized
    }

    /** Standard Supabase phone + password grant; no OTP is sent. */
    suspend fun signInWithPassword(rawPhone: String, password: String): AuthResult = withContext(Dispatchers.IO) {
        val phone = normalizeEgyptianPhone(rawPhone)
        require(password.isNotBlank()) { "أدخل كلمة المرور" }
        val payload = JSONObject().put("phone", phone).put("password", password)
        val request = Request.Builder()
            .url("${BuildConfig.SUPABASE_URL}/auth/v1/token?grant_type=password")
            .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("رقم الموبايل أو كلمة المرور غير صحيحة. (HTTP ${response.code})")
            val json = JSONObject(body)
            val user = json.optJSONObject("user") ?: throw IOException("استجابة تسجيل الدخول غير مكتملة")
            val userId = user.optString("id")
            val access = json.optString("access_token")
            val refresh = json.optString("refresh_token")
            if (userId.isBlank() || access.isBlank() || refresh.isBlank()) throw IOException("بيانات الجلسة غير مكتملة")
            val result = fetchActiveProfile(userId, phone, access)
            prefs.edit()
                .putString("access_token", access)
                .putString("refresh_token", refresh)
                .putString("user_id", userId)
                .putString("organization_id", result.organizationId)
                .putString("role", result.role)
                .putString("phone", phone)
                .putBoolean("must_change_password", result.mustChangePassword)
                .apply()
            result
        }
    }

    private fun fetchActiveProfile(userId: String, phone: String, access: String): AuthResult {
        val request = Request.Builder()
            .url("${BuildConfig.SUPABASE_URL}/rest/v1/noury_user_profiles?select=organization_id,role,is_active,must_change_password&user_id=eq.$userId")
            .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Authorization", "Bearer $access")
            .header("Accept", "application/json")
            .get().build()
        val profile = client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("تعذر التحقق من صلاحيات الحساب")
            JSONArray(body).optJSONObject(0)
                ?: throw IOException("هذا الرقم غير معتمد ضمن مستخدمي Noury. يجب موافقة المالك أولًا.")
        }
        if (!profile.optBoolean("is_active", false)) throw IOException("هذا الحساب موقوف. تواصل مع مالك البرنامج.")
        val organizationId = profile.optString("organization_id")
        val role = profile.optString("role")
        if (organizationId.isBlank() || role !in setOf("owner", "admin", "accountant", "teacher")) {
            throw IOException("ملف المستخدم غير مكتمل أو صلاحياته غير صالحة")
        }
        return AuthResult(userId, phone, organizationId, role, profile.optBoolean("must_change_password", false))
    }

    /** Changes the temporary password through a server function that verifies the current password. */
    suspend fun changePassword(currentPassword: String, newPassword: String): Unit = withContext(Dispatchers.IO) {
        require(newPassword.length >= 10) { "كلمة المرور يجب ألا تقل عن 10 أحرف" }
        require(currentPassword.isNotBlank() && currentPassword != newPassword) { "أدخل كلمة المرور المؤقتة واختر كلمة مرور مختلفة" }
        val access = refreshAccessToken() ?: throw IOException("انتهت جلسة الدخول. سجّل الدخول مرة أخرى.")
        val payload = JSONObject().put("current_password", currentPassword).put("new_password", newPassword)
        val request = Request.Builder()
            .url("${BuildConfig.SUPABASE_URL}/functions/v1/account-security")
            .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Authorization", "Bearer $access")
            .header("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail = runCatching { JSONObject(body).optString("error") }.getOrNull()
                throw IOException(detail?.takeIf { it.isNotBlank() } ?: "تعذر تغيير كلمة المرور (HTTP ${response.code})")
            }
        }
        prefs.edit().putBoolean("must_change_password", false).apply()
    }

    suspend fun refreshAccessToken(): String? = withContext(Dispatchers.IO) {
        val refresh = prefs.getString("refresh_token", null) ?: return@withContext null
        val payload = JSONObject().put("refresh_token", refresh)
        val request = Request.Builder()
            .url("${BuildConfig.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token")
            .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("تعذر تحديث جلسة المزامنة (HTTP ${response.code})")
            val json = JSONObject(body)
            val access = json.optString("access_token")
            val nextRefresh = json.optString("refresh_token")
            if (access.isBlank() || nextRefresh.isBlank()) throw IOException("استجابة تحديث الجلسة غير مكتملة")
            prefs.edit().putString("access_token", access).putString("refresh_token", nextRefresh).apply()
            access
        }
    }

    /** Called at app start before showing local academy data. */
    suspend fun validateStoredSession(): AuthResult? = withContext(Dispatchers.IO) {
        if (!hasSession()) return@withContext null
        try {
            val access = refreshAccessToken() ?: return@withContext null
            val id = currentUserId() ?: return@withContext null
            val phone = currentPhone() ?: return@withContext null
            val profile = fetchActiveProfile(id, phone, access)
            prefs.edit().putString("organization_id", profile.organizationId).putString("role", profile.role)
                .putBoolean("must_change_password", profile.mustChangePassword).apply()
            profile
        } catch (_: Exception) {
            clearSession()
            null
        }
    }

    fun currentUserId(): String? = prefs.getString("user_id", null)
    fun currentPhone(): String? = prefs.getString("phone", null)
    fun currentOrganizationId(): String? = prefs.getString("organization_id", null)
    fun currentRole(): String? = prefs.getString("role", null)
    fun accessToken(): String? = prefs.getString("access_token", null)
    fun mustChangePassword(): Boolean = prefs.getBoolean("must_change_password", false)
    fun hasSession(): Boolean = !prefs.getString("refresh_token", null).isNullOrBlank()

    suspend fun signOut() = withContext(Dispatchers.IO) {
        val access = prefs.getString("access_token", null)
        try {
            if (!access.isNullOrBlank()) {
                val request = Request.Builder()
                    .url("${BuildConfig.SUPABASE_URL}/auth/v1/logout")
                    .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
                    .header("Authorization", "Bearer $access")
                    .post("{}".toRequestBody("application/json".toMediaType()))
                    .build()
                client.newCall(request).execute().close()
            }
        } finally { clearSession() }
    }

    private fun clearSession() { prefs.edit().clear().apply() }
}
