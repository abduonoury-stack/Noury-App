package com.tahseel.students.sync

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.tahseel.students.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Noury phone-number + password login backed by a deterministic synthetic email.
 * The synthetic address is an internal Auth identifier only; users never need an inbox.
 */
class SupabaseAuth(context: Context) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
    private val prefs = EncryptedSharedPreferences.create(
        context,
        "noury_supabase_auth",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    data class AuthResult(val userId: String, val email: String?)

    /** Normalizes Egyptian mobile numbers to E.164 (+20XXXXXXXXXX). */
    fun normalizeEgyptianPhone(input: String): String {
        val digits = input.filter(Char::isDigit)
        val normalized = when {
            digits.startsWith("0020") -> "+" + digits.drop(2)
            digits.startsWith("20") -> "+$digits"
            digits.startsWith("0") -> "+20${digits.drop(1)}"
            else -> "+20$digits"
        }
        require(Regex("^\\+201[0125]\\d{8}$").matches(normalized)) {
            "أدخل رقم موبايل مصري صحيحًا (01XXXXXXXXX)"
        }
        return normalized
    }


    /**
     * Maps an Egyptian phone number to a stable, non-deliverable synthetic email.
     * The reserved .invalid TLD prevents accidental delivery to a real mailbox.
     * Supabase Email confirmation MUST be disabled for this authentication design.
     */
    fun syntheticEmailForPhone(rawPhone: String): String {
        val phone = normalizeEgyptianPhone(rawPhone)
        val digits = phone.filter(Char::isDigit)
        return "$digits@users.noury.invalid"
    }

    /** Signs in with phone + password through Supabase email/password Auth; no OTP. */
    suspend fun signInWithPassword(rawPhone: String, password: String): AuthResult = withContext(Dispatchers.IO) {
        val phone = normalizeEgyptianPhone(rawPhone)
        require(password.isNotBlank()) { "أدخل كلمة المرور" }
        // Earlier project builds used both .invalid and .app synthetic domains.
        // Try the canonical .invalid address first, then the legacy .app address
        // only when Supabase explicitly reports invalid credentials.
        val primaryEmail = syntheticEmailForPhone(phone)
        val legacyEmail = primaryEmail.replace("@users.noury.invalid", "@users.noury.app")
        val result = try {
            requestPasswordGrant(primaryEmail, password)
        } catch (first: AuthHttpException) {
            if (!first.isInvalidCredentials || legacyEmail == primaryEmail) throw first
            requestPasswordGrant(legacyEmail, password)
        }
        val syntheticEmail = result.optJSONObject("user")?.optString("email")?.takeIf { it.isNotBlank() } ?: primaryEmail
            val access = result.optString("access_token")
            val refresh = result.optString("refresh_token")
            val user = result.optJSONObject("user") ?: throw IOException("استجابة تسجيل الدخول غير مكتملة")
            val userId = user.optString("id")
            if (access.isBlank() || refresh.isBlank() || userId.isBlank()) throw IOException("بيانات الجلسة غير مكتملة")
            val profileRequest = Request.Builder()
                .url("${BuildConfig.SUPABASE_URL}/rest/v1/noury_user_profiles?select=organization_id,role,is_active&user_id=eq.$userId")
                .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Authorization", "Bearer $access")
                .header("Accept", "application/json")
                .get().build()
            val profile = client.newCall(profileRequest).execute().use { profileResponse ->
                val profileBody = profileResponse.body?.string().orEmpty()
                if (!profileResponse.isSuccessful) throw IOException("تعذر التحقق من صلاحيات الحساب (HTTP ${profileResponse.code}). راجع صلاحيات جدول noury_user_profiles وسياسات RLS.")
                org.json.JSONArray(profileBody).optJSONObject(0)
                    ?: throw IOException("هذا الرقم غير مسجل ضمن مستخدمي Noury.")
            }
            if (!profile.optBoolean("is_active", false)) throw IOException("هذا الحساب موقوف. تواصل مع مالك البرنامج.")
            val organizationId = profile.optString("organization_id")
            val role = profile.optString("role")
            if (organizationId.isBlank() || role !in setOf("owner", "admin", "accountant", "teacher"))
                throw IOException("ملف المستخدم أو صلاحياته غير صالحة")
            prefs.edit().putString("access_token", access).putString("refresh_token", refresh)
                .putString("user_id", userId).putString("organization_id", organizationId)
                .putString("role", role).putString("phone", phone)
                .putString("email", syntheticEmail).apply()
            AuthResult(userId, syntheticEmail)
    }

    private class AuthHttpException(
        val httpCode: Int,
        val authCode: String?,
        val authMessage: String?
    ) : IOException("فشل تسجيل الدخول إلى Supabase (HTTP $httpCode): ${authMessage ?: authCode ?: "خطأ غير معروف"}") {
        val isInvalidCredentials: Boolean
            get() = authCode == "invalid_credentials" || authMessage.equals("Invalid login credentials", ignoreCase = true)
    }

    private fun requestPasswordGrant(email: String, password: String): JSONObject {
        val json = JSONObject().put("email", email).put("password", password)
        val request = Request.Builder()
            .url("${BuildConfig.SUPABASE_URL}/auth/v1/token?grant_type=password")
            .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Content-Type", "application/json")
            .post(json.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val error = try { JSONObject(body) } catch (_: Exception) { JSONObject() }
                throw AuthHttpException(
                    response.code,
                    error.optString("code").takeIf { it.isNotBlank() },
                    (error.optString("msg").takeIf { it.isNotBlank() }
                        ?: error.optString("message").takeIf { it.isNotBlank() }
                        ?: error.optString("error_description").takeIf { it.isNotBlank() }
                        ?: error.optString("error").takeIf { it.isNotBlank() })
                )
            }
            return JSONObject(body)
        }
    }

    /** Refresh the short-lived access token before background synchronization. */
    suspend fun refreshAccessToken(): String? = withContext(Dispatchers.IO) {
        val refresh = prefs.getString("refresh_token", null) ?: return@withContext null
        val json = JSONObject().put("refresh_token", refresh)
        val request = Request.Builder()
            .url("${BuildConfig.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token")
            .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Content-Type", "application/json")
            .post(json.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("تعذر تحديث جلسة المزامنة (HTTP ${response.code})")
            val result = JSONObject(body)
            val access = result.optString("access_token")
            val nextRefresh = result.optString("refresh_token")
            if (access.isBlank() || nextRefresh.isBlank()) throw IOException("استجابة تحديث الجلسة غير مكتملة")
            prefs.edit().putString("access_token", access).putString("refresh_token", nextRefresh).apply()
            access
        }
    }

    fun currentUserId(): String? = prefs.getString("user_id", null)
    fun currentPhone(): String? = prefs.getString("phone", null)
    fun currentOrganizationId(): String? = prefs.getString("organization_id", null)
    fun currentRole(): String? = prefs.getString("role", null)
    fun accessToken(): String? = prefs.getString("access_token", null)
    fun hasSession(): Boolean = !prefs.getString("refresh_token", null).isNullOrBlank()
    suspend fun signOut() = withContext(Dispatchers.IO) {
        val access = prefs.getString("access_token", null)
        try {
            if (!access.isNullOrBlank()) {
                val request = Request.Builder()
                    .url("${BuildConfig.SUPABASE_URL}/auth/v1/logout")
                    .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
                    .header("Authorization", "Bearer $access")
                    .post("{}".toRequestBody("application/json".toMediaType()))
                    .build()
                client.newCall(request).execute().close()
            }
        } finally {
            prefs.edit().clear().apply()
        }
    }
}
