package com.tahseel.students.ui

import android.content.Context
import android.graphics.Bitmap
import android.media.ExifInterface
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.tahseel.students.util.PhotoDecoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * نافذة ضبط صورة الطالب: تحريك بالسحب، تكبير بإصبعين أو بالشريط، وتدوير 90°.
 * الناتج مربع 600×600 JPEG يُحفظ في مخزن التطبيق ويُعاد مساره كنص (file://) ليُخزَّن في photoUri.
 */
@Composable
fun PhotoCropDialog(source: Uri, onDismiss: () -> Unit, onDone: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var loadFailed by remember { mutableStateOf(false) }
    var saveFailed by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var zoom by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val boxDp = 260.dp
    val boxPx = with(LocalDensity.current) { boxDp.toPx() }

    LaunchedEffect(source) {
        val decoded = withContext(Dispatchers.IO) {
            runCatching { PhotoDecoder.decode(context, source, 1600, Bitmap.Config.ARGB_8888) }.getOrNull()
        }
        if (decoded == null) loadFailed = true else bitmap = decoded
    }

    // 1x = الصورة كاملة داخل الإطار (Fit). عند التكبير نمنع خروج حافة الصورة للداخل؛ وإن كان بُعد أصغر من الإطار يبقى متمركزًا.
    fun clampOffset(o: Offset, z: Float, bmp: Bitmap): Offset {
        val aspect = bmp.width.toFloat() / bmp.height.toFloat()
        val dispW = if (aspect >= 1f) boxPx else boxPx * aspect
        val dispH = if (aspect >= 1f) boxPx / aspect else boxPx
        val maxX = ((dispW * z - boxPx) / 2f).coerceAtLeast(0f)
        val maxY = ((dispH * z - boxPx) / 2f).coerceAtLeast(0f)
        return Offset(o.x.coerceIn(-maxX, maxX), o.y.coerceIn(-maxY, maxY))
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.padding(16.dp).fillMaxWidth().widthIn(max = 420.dp)
        ) {
            Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("ضبط الجزء الظاهر من الصورة", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                val bmp = bitmap
                if (loadFailed) {
                    Text("تعذر فتح الصورة. اختر صورة أخرى.", color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
                    TextButton(onClick = onDismiss) { Text("إغلاق") }
                } else if (bmp == null) {
                    CircularProgressIndicator()
                } else {
                    // أقصى تكبير = 4 أضعاف حجم "تغطية الدائرة"، أي أكبر من الحد الأدنى بحسب أبعاد الصورة.
                    val zMax = 4f * maxOf(bmp.width, bmp.height).toFloat() / minOf(bmp.width, bmp.height).toFloat()
                    Text(
                        "هذه صورتك كاملة. كبّرها بإصبعين أو بالشريط واسحبها لتضع الوجه داخل الدائرة؛ الدائرة هي الجزء الذي سيظهر.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Box(
                        Modifier.size(boxDp).clip(RoundedCornerShape(18.dp)).background(Color.White)
                            .pointerInput(bmp) {
                                detectTransformGestures { _, pan, gestureZoom, _ ->
                                    val nz = (zoom * gestureZoom).coerceIn(1f, zMax)
                                    zoom = nz
                                    offset = clampOffset(offset + pan, nz, bmp)
                                }
                            }
                    ) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "الصورة المراد قصها",
                            modifier = Modifier.fillMaxSize().graphicsLayer(scaleX = zoom, scaleY = zoom, translationX = offset.x, translationY = offset.y),
                            contentScale = ContentScale.Fit
                        )
                        Canvas(Modifier.fillMaxSize()) {
                            val circle = Path().apply { addOval(Rect(0f, 0f, size.width, size.height)) }
                            clipPath(circle, clipOp = ClipOp.Difference) { drawRect(Color.Black.copy(alpha = 0.55f)) }
                            drawCircle(Color.White, radius = size.minDimension / 2f - 1.5.dp.toPx(), style = Stroke(width = 3.dp.toPx()))
                        }
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("تكبير", style = MaterialTheme.typography.labelLarge)
                        Slider(
                            value = zoom,
                            onValueChange = { nz -> zoom = nz; offset = clampOffset(offset, nz, bmp) },
                            valueRange = 1f..zMax,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                bitmap = PhotoDecoder.applyOrientation(bmp, ExifInterface.ORIENTATION_ROTATE_90)
                                zoom = 1f
                                offset = Offset.Zero
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("تدوير 90°", maxLines = 1) }
                        OutlinedButton(onClick = { zoom = 1f; offset = Offset.Zero }, modifier = Modifier.weight(1f)) { Text("الصورة كاملة", maxLines = 1) }
                    }
                    if (saveFailed) Text("تعذر حفظ الصورة. حاول مرة أخرى.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                saving = true
                                saveFailed = false
                                val z = zoom
                                val o = offset
                                scope.launch {
                                    val saved = withContext(Dispatchers.IO) { runCatching { saveCropped(context, bmp, z, o, boxPx) }.getOrNull() }
                                    saving = false
                                    if (saved != null) onDone(saved) else saveFailed = true
                                }
                            },
                            enabled = !saving,
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                        ) { Text("استخدام الصورة") }
                        TextButton(onClick = onDismiss, enabled = !saving) { Text("إلغاء") }
                    }
                }
            }
        }
    }
}

/**
 * يرسم ما يظهر داخل الإطار المربع كما في المعاينة تمامًا (بما فيه الهوامش البيضاء إن كانت الصورة كاملة غير مكبّرة)
 * في صورة مربعة 600×600، ويحفظها JPEG في مخزن التطبيق.
 */
private fun saveCropped(context: Context, bmp: Bitmap, zoom: Float, offset: Offset, boxPx: Float): String {
    val outSize = 600
    val k = outSize / boxPx
    val scale = (boxPx / maxOf(bmp.width, bmp.height).toFloat()) * zoom * k
    val matrix = android.graphics.Matrix().apply {
        postTranslate(-bmp.width / 2f, -bmp.height / 2f)
        postScale(scale, scale)
        postTranslate(outSize / 2f + offset.x * k, outSize / 2f + offset.y * k)
    }
    val out = Bitmap.createBitmap(outSize, outSize, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(out)
    canvas.drawColor(android.graphics.Color.WHITE)
    canvas.drawBitmap(bmp, matrix, android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG or android.graphics.Paint.ANTI_ALIAS_FLAG))
    val dir = File(context.filesDir, "student_photos").apply { mkdirs() }
    val file = File(dir, "student_${System.currentTimeMillis()}.jpg")
    file.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
    return Uri.fromFile(file).toString()
}
