package com.tahseel.students.vm

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tahseel.students.data.AppDatabase
import com.tahseel.students.data.PaymentRepository
import com.tahseel.students.util.AcademyProfileStore
import com.tahseel.students.util.FullDatabaseBackup
import com.tahseel.students.util.CsvExporter
import com.tahseel.students.util.TimeUtil
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream

data class PendingRestore(val validatedJson: String, val exportedAt: Long, val rowCount: Int)

data class BackupUi(
    val busy: Boolean = false,
    val message: String? = null,
    val isError: Boolean = false,
    val pending: PendingRestore? = null,
    val hasSnapshot: Boolean = false
)

class BackupViewModel(private val repo: PaymentRepository, private val db: AppDatabase, private val context: Context) : ViewModel() {
    private val _state = MutableStateFlow(BackupUi())
    val state: StateFlow<BackupUi> = _state.asStateFlow()

    private companion object {
        const val MAX_BYTES = 100L * 1024 * 1024
        const val SAFETY_DIR = "pre_restore_backups"
        const val SAFETY_PREFIX = "pre-restore-"
        const val KEEP_SNAPSHOTS = 5
    }

    init { _state.update { it.copy(hasSnapshot = latestSnapshot() != null) } }

    private fun receiptProfileJson(): org.json.JSONObject = AcademyProfileStore.exportJson(context)

    private fun photoDir(): File = File(context.filesDir, "student_photos")

    private fun snapshotFiles(): List<File> =
        File(context.filesDir, SAFETY_DIR).listFiles { f -> f.name.startsWith(SAFETY_PREFIX) }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()

    private fun latestSnapshot(): File? = snapshotFiles().firstOrNull()

    /** نسخة أمان من البيانات الحالية قبل أي استعادة؛ إن فشلت أو لم تُتحقق تُلغى الاستعادة. */
    private fun saveSafetySnapshot(): File {
        val dir = File(context.filesDir, SAFETY_DIR).apply { mkdirs() }
        val json = FullDatabaseBackup.export(db.openHelper.writableDatabase, System.currentTimeMillis(), receiptProfileJson())
        // milliseconds prevent two restore attempts in the same minute from overwriting the safety copy.
        val file = File(dir, "$SAFETY_PREFIX${System.currentTimeMillis()}.json")
        file.writeText(json, Charsets.UTF_8)
        FullDatabaseBackup.validate(file.readText(Charsets.UTF_8))
        snapshotFiles().drop(KEEP_SNAPSHOTS).forEach { it.delete() }
        return file
    }

    private fun finish(text: String, error: Boolean) =
        _state.update { it.copy(busy = false, message = text, isError = error) }

    private fun launchOp(block: suspend () -> Unit) {
        if (_state.value.busy) return
        _state.update { it.copy(busy = true, message = null) }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                block()
            } catch (e: Exception) {
                finish("فشلت العملية: ${e.message ?: "خطأ غير معروف"}", true)
            }
        }
    }

    private fun write(cr: ContentResolver, uri: Uri, bytes: ByteArray) {
        val out = cr.openOutputStream(uri, "wt") ?: error("تعذر فتح الملف للكتابة")
        out.use { it.write(bytes); it.flush() }
    }

    private fun read(cr: ContentResolver, uri: Uri): ByteArray {
        val input = cr.openInputStream(uri) ?: error("تعذر فتح الملف للقراءة")
        input.use { ins ->
            val bos = ByteArrayOutputStream()
            val buf = ByteArray(16 * 1024)
            var total = 0L
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                total += n
                if (total > MAX_BYTES) error("الملف أكبر من الحد المسموح")
                bos.write(buf, 0, n)
            }
            return bos.toByteArray()
        }
    }

    fun createBackup(uri: Uri, cr: ContentResolver) = launchOp {
        val json = FullDatabaseBackup.export(db.openHelper.writableDatabase, System.currentTimeMillis(), receiptProfileJson(), photoDir())
        write(cr, uri, json.toByteArray(Charsets.UTF_8))
        val checked = FullDatabaseBackup.validate(String(read(cr, uri), Charsets.UTF_8))
        val count = FullDatabaseBackup.rowCount(checked)
        val photos = FullDatabaseBackup.photoCount(checked)
        val skipped = FullDatabaseBackup.photosSkipped(checked)
        val photoNote = " و$photos صورة" + if (skipped > 0) " (تعذر تضمين $skipped صورة: غير موجودة أو تجاوزت الحد)" else ""
        finish("تم إنشاء نسخة احتياطية شاملة والتحقق منها بنجاح ($count سجل من جميع الجداول$photoNote)", skipped > 0)
    }

    /** فحص النسخة بالكامل قبل طلب موافقة المستخدم أو لمس قاعدة البيانات. */
    fun prepareRestore(uri: Uri, cr: ContentResolver) = launchOp {
        val checked = FullDatabaseBackup.validate(String(read(cr, uri), Charsets.UTF_8))
        val root = org.json.JSONObject(checked)
        _state.update { it.copy(busy = false, pending = PendingRestore(checked, root.optLong("exportedAt", 0L), FullDatabaseBackup.rowCount(checked))) }
    }

    /** يجهّز الاستعادة من آخر نسخة أمان أُخذت تلقائيًا قبل استعادة سابقة. */
    fun prepareRestoreFromSnapshot() = launchOp {
        val file = latestSnapshot() ?: error("لا توجد نسخة أمان محفوظة")
        val checked = FullDatabaseBackup.validate(file.readText(Charsets.UTF_8))
        val root = org.json.JSONObject(checked)
        _state.update { it.copy(busy = false, pending = PendingRestore(checked, root.optLong("exportedAt", 0L), FullDatabaseBackup.rowCount(checked))) }
    }

    fun cancelRestore() = _state.update { it.copy(pending = null) }

    /** الاستعادة داخل Transaction واحدة؛ إما كل الجداول أو لا شيء. */
    fun confirmRestore() {
        val p = _state.value.pending ?: return
        _state.update { it.copy(pending = null) }
        launchOp {
            // نسخة أمان من الوضع الحالي أولًا؛ أي فشل هنا يمنع الاستعادة قبل لمس البيانات.
            saveSafetySnapshot()
            FullDatabaseBackup.restore(db.openHelper.writableDatabase, p.validatedJson, photoDir())
            val profile = org.json.JSONObject(p.validatedJson).optJSONObject("receiptProfile") ?: org.json.JSONObject()
            AcademyProfileStore.save(
                context,
                profile.optString("name", AcademyProfileStore.DEFAULT_NAME),
                profile.optString("address", ""),
                profile.optString("phone", "01555713020")
            )
            val restored = FullDatabaseBackup.rowCount(p.validatedJson)
            val missingPhotos = FullDatabaseBackup.missingPhotoCount(db.openHelper.writableDatabase)
            val photoNote = if (missingPhotos > 0) " تنبيه: $missingPhotos طالبًا لا تتوفر صورهم على هذا الجهاز (النسخة لا تتضمنها)؛ تظهر لهم الصورة الافتراضية ولم يُعدَّل أي سجل، ويمكن إعادة رفع الصورة من ملف الطالب." else ""
            _state.update { it.copy(hasSnapshot = latestSnapshot() != null) }
            finish("تمت استعادة النسخة الشاملة بنجاح ($restored سجل). حُفظت نسخة أمان من بياناتك السابقة ويمكن الرجوع إليها من هذه الشاشة، وتم تحديث اسم الأكاديمية في الواجهات فورًا.$photoNote", false)
        }
    }

    fun exportCsv(uri: Uri, cr: ContentResolver) = launchOp {
        val list = repo.dao.getAllAsc()
        write(cr, uri, CsvExporter.build(list))
        finish("تم تصدير ${list.size} عملية إلى ملف CSV", false)
    }
}
