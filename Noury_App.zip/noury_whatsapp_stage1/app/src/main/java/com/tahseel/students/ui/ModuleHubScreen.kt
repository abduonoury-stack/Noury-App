package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private data class ModuleItem(val title: String, val description: String, val icon: ImageVector, val route: String)

@Composable
fun ModuleHubScreen(section: String, onBack: () -> Unit, onOpen: (String) -> Unit) {
    val title: String
    val subtitle: String
    val items: List<ModuleItem>
    when (section) {
        "finance" -> {
            title = "التحصيل والمالية"
            subtitle = "إدارة التحصيل والمحاسبة والمرتبات والحسابات"
            items = listOf(
                ModuleItem("متابعة السداد", "معرفة المسدد والمتبقي لكل طالب", Icons.Default.AccountBalanceWallet, "collection-status"),
                ModuleItem("سجل التحصيل", "مراجعة جميع الحركات والإيصالات", Icons.Default.ReceiptLong, "ledger"),
                ModuleItem("الاستردادات", "صرف المبالغ الزائدة ومراجعة أرصدتها", Icons.Default.AccountBalanceWallet, "refunds"),
                ModuleItem("الإدارة المالية والمحاسبة", "الفواتير والقيود اليومية والمرتبات والتقارير المالية", Icons.Default.AccountBalance, "expenses"),
                ModuleItem("تسوية طالب منسحب", "حساب المستحقات والتسويات والتصحيحات", Icons.Default.Calculate, "student-exit")
            )
        }
        "system" -> {
            title = "التقارير والنظام"
            subtitle = "متابعة أداء الأكاديمية وحماية بياناتك"
            items = listOf(
                ModuleItem("إعدادات وإدارة النظام", "بيانات الأكاديمية وإعدادات البرنامج وحماية البيانات", Icons.Default.Settings, "system-settings")
            )
        }
        else -> {
            title = "إدارة الطلاب"
            subtitle = "ملفات الأطفال والفصول والحضور والمتابعة اليومية"
            items = listOf(
                ModuleItem("ملفات الطلاب", "عرض بيانات الأطفال وتحديثها", Icons.Default.People, "students"),
                ModuleItem("إدارة الفصول", "توزيع الطلاب على الفصول", Icons.Default.Groups, "classrooms"),
                ModuleItem("الحضور والغياب", "تسجيل ومراجعة حضور الأطفال", Icons.Default.FactCheck, "attendance"),
                ModuleItem("أعياد الميلاد", "متابعة مناسبات وأعياد ميلاد الأطفال", Icons.Default.Cake, "birthdays")
            )
        }
    }

    AppScaffold(title = title, onBack = onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(shape = MaterialTheme.shapes.large, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(title, style = MaterialTheme.typography.headlineSmall, color = Color.White, fontWeight = FontWeight.Bold)
                    Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = .86f))
                    Text("${items.size} خدمات متاحة", style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = .72f))
                }
            }
            items.forEach { item ->
                Card(onClick = { onOpen(item.route) }, shape = MaterialTheme.shapes.large, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .7f)), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.size(48.dp)) {
                            Box(contentAlignment = Alignment.Center) { Icon(item.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp)) }
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(item.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
