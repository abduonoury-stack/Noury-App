package com.tahseel.students.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import kotlinx.coroutines.flow.Flow

/** Minimal teacher-only attendance queue. Contains no student contact, finance or address data. */
@Entity(
    tableName = "teacher_attendance_outbox",
    indices = [Index(value = ["clientEventId"], unique = true), Index(value = ["attendanceDate", "classroomId"]), Index(value = ["organizationId", "teacherUserId"])]
)
data class TeacherAttendanceOutbox(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientEventId: String,
    val organizationId: String,
    val teacherUserId: String,
    val classroomId: String,
    val studentId: String,
    val attendanceDate: String,
    val status: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface TeacherAttendanceOutboxDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun enqueue(event: TeacherAttendanceOutbox): Long

    @Query("SELECT * FROM teacher_attendance_outbox WHERE organizationId = :organizationId AND teacherUserId = :teacherUserId ORDER BY id ASC")
    suspend fun pending(organizationId: String, teacherUserId: String): List<TeacherAttendanceOutbox>

    @Query("DELETE FROM teacher_attendance_outbox WHERE id IN (:ids)")
    suspend fun deleteUploaded(ids: List<Long>)

    @Query("SELECT COUNT(*) FROM teacher_attendance_outbox WHERE organizationId = :organizationId AND teacherUserId = :teacherUserId")
    fun observePendingCount(organizationId: String, teacherUserId: String): Flow<Int>
}
