package com.tahseel.students.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Class
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import com.tahseel.students.util.StudentRosterPrinter
import com.tahseel.students.util.Money
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.data.Classroom
import com.tahseel.students.data.Student
import java.time.Instant
import java.time.LocalDate
import java.time.Period
import java.time.ZoneId
import com.tahseel.students.vm.ClassroomsViewModel

@Composable
fun ClassroomsScreen(vm: ClassroomsViewModel, onBack: () -> Unit, onProfile: (Long) -> Unit) {
    val rooms by vm.classrooms.collectAsStateWithLifecycle()
    val students by vm.allStudents.collectAsStateWithLifecycle()
    var selectedId by remember { mutableStateOf<Long?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    var editingClass by remember { mutableStateOf<Classroom?>(null) }
    var showPicker by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    val context = LocalContext.current
    val selected = rooms.firstOrNull { it.id == selectedId }
    val roster = students.filter { selected != null && it.className == selected.name }.sortedWith(
        compareBy<Student> { it.birthDate == null }.thenBy { it.birthDate ?: Long.MAX_VALUE }
    )
    val activeCount = roster.count { it.status == "active" }
    val unassigned = students.filter { it.className.isBlank() && it.status == "active" }.sortedWith(
        compareBy<Student> { it.birthDate == null }.thenBy { it.birthDate ?: Long.MAX_VALUE }
    )
    val unassignedDisplay = students.filter { it.className.isBlank() }.sortedWith(
        compareBy<Student> { it.birthDate == null }.thenBy { it.birthDate ?: Long.MAX_VALUE }
    )

    AppScaffold(title = "إدارة الفصول", onBack = onBack) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (selected == null) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.weight(1f)) {
                        Text("الفصول الدراسية", style = MaterialTheme.typography.titleLarge)
                        Text("أنشئ الفصول ثم وزّع الطلاب عليها", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilledTonalButton(onClick = { showCreate = true }) { Icon(Icons.Default.Add, null); Text("فصل جديد") }
                        OutlinedButton(onClick = {
                            val active = students.filter { it.status == "active" }.sortedBy { it.fullName.trim() }
                            if (active.isEmpty()) Toast.makeText(context, "لا يوجد طلاب نشطون للطباعة", Toast.LENGTH_SHORT).show()
                            else StudentRosterPrinter.print(context, active, "كشف جميع الطلاب النشطين", "جميع الفصول")
                        }) { Text("طباعة جميع النشطين") }
                    }
                }
                if (rooms.isEmpty()) {
                    Card(shape = MaterialTheme.shapes.large) { Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Class, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(42.dp))
                        Text("لسه مفيش فصول مضافة")
                        Text("ابدأ بإنشاء أول فصل دراسي", style = MaterialTheme.typography.bodySmall)
                    } }
                } else {
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(rooms, key = { it.id }) { room ->
                            val members = students.filter { it.className == room.name }
                            val count = members.count { it.status == "active" }
                            Card(Modifier.fillMaxWidth().clickable { selectedId = room.id }, shape = MaterialTheme.shapes.large) {
                                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Class, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Text(room.name, style = MaterialTheme.typography.titleMedium)
                                        Text(listOf(room.level, if (room.teacherName.isNotBlank()) "المعلمة: ${room.teacherName}" else "").filter { it.isNotBlank() }.joinToString(" • ").ifBlank { "بدون مرحلة محددة" }, style = MaterialTheme.typography.bodySmall)
                                        Text("$count من ${room.capacity} طالب", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                                    }
                                    IconButton(onClick = { editingClass = room }) { Icon(Icons.Default.Edit, contentDescription = "تعديل الفصل") }
                                    Text("›", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
                val unplacedTotal = unassignedDisplay.size
                Text("طلاب غير موزعين: $unplacedTotal", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.secondary)
                if (unassignedDisplay.isEmpty()) {
                    Text("كل الطلاب مسجلون في فصول", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                        items(unassignedDisplay, key = { "unassigned-${it.id}" }) { student ->
                            Card(Modifier.fillMaxWidth().clickable { onProfile(student.id) }, shape = MaterialTheme.shapes.medium) {
                                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    StudentAvatar(student.photoUri, 44.dp, student.id, student.gender)
                                    Spacer(Modifier.width(9.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(student.fullName, style = MaterialTheme.typography.titleSmall)
                                        Text("العمر: ${studentAgeLabel(student.birthDate)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Text("غير موزع", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                                }
                            }
                        }
                    }
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(onClick = { selectedId = null }) { Text("‹", style = MaterialTheme.typography.headlineMedium) }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(selected.name, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
                        Text(selected.level.ifBlank { "بدون مرحلة محددة" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { editingClass = selected }) { Icon(Icons.Default.Edit, contentDescription = "تعديل الفصل") }
                }
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = MaterialTheme.shapes.large) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(activeCount.toString(), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text("طلاب نشطون", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                        VerticalDivider(Modifier.height(42.dp), color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .25f))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(selected.capacity.toString(), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text("السعة القصوى", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                        VerticalDivider(Modifier.height(42.dp), color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .25f))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text((selected.capacity - activeCount).coerceAtLeast(0).toString(), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text("أماكن متاحة", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                }
                if (selected.teacherName.isNotBlank()) {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(12.dp)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Class, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text("المعلمة: ${selected.teacherName}", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        val activeRoster = roster.filter { it.status == "active" }
                        if (activeRoster.isEmpty()) Toast.makeText(context, "لا يوجد طلاب نشطون في هذا الفصل", Toast.LENGTH_SHORT).show()
                        else StudentRosterPrinter.print(context, activeRoster, "كشف طلاب الفصل النشطين", selected.name)
                    }, modifier = Modifier.weight(1f), enabled = activeCount > 0) {
                        Text("طباعة كشف النشطين")
                    }
                    FilledTonalButton(onClick = { showPicker = true }, modifier = Modifier.weight(1f), enabled = activeCount < selected.capacity && unassigned.isNotEmpty()) {
                        Icon(Icons.Default.PersonAdd, null); Spacer(Modifier.width(5.dp)); Text("إضافة طالب")
                    }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("قائمة الطلاب", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    Text("${roster.size} طالب", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (roster.isEmpty()) {
                    Card(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.medium) {
                        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.PersonAdd, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
                            Text("الفصل لا يحتوي على طلاب بعد", style = MaterialTheme.typography.titleSmall)
                            Text("استخدم زر إضافة طالب لبدء توزيع الطلاب", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                } else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(roster, key = { it.id }) { student ->
                        Card(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.medium, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Row(Modifier.fillMaxWidth().clickable { onProfile(student.id) }.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(student.fullName, style = MaterialTheme.typography.titleSmall)
                                    Text("العمر: ${studentAgeLabel(student.birthDate)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("هاتف الأم: ${student.motherWhatsapp.ifBlank { "غير مسجل" }}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Surface(color = if (student.status == "active") MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.large) {
                                        Text(if (student.status == "active") "نشط" else "غير نشط", modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall)
                                    }
                                    TextButton(onClick = { vm.unassign(student) }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) { Icon(Icons.Default.SwapHoriz, null); Text("إلغاء التوزيع") }
                                }
                            }
                        }
                    }
                }
            }
            if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.error)
        }
    }


    editingClass?.let { room ->
        EditClassDialog(room = room, onDismiss = { editingClass = null }, onSave = { name, level, teacher, capacity ->
            vm.updateClassroom(room, name, level, teacher, capacity) { err ->
                message = err ?: "تم تعديل بيانات الفصل بنجاح"
                if (err == null) editingClass = null
            }
        })
    }

    if (showCreate) CreateClassDialog(onDismiss = { showCreate = false }, onCreate = { name, level, teacher, capacity ->
        vm.create(name, level, teacher, capacity) { err -> message = err ?: "تم إنشاء الفصل"; if (err == null) showCreate = false }
    })
    if (showPicker && selected != null) {
        AlertDialog(onDismissRequest = { showPicker = false }, title = { Text("اختيار الطلاب للفصل") },
            text = {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (unassigned.isEmpty()) Text("لا يوجد طلاب غير موزعين")
                    unassigned.forEach { student ->
                        Row(Modifier.fillMaxWidth().clickable {
                            vm.assign(student, selected, activeCount) { err -> message = err ?: "تم توزيع ${student.fullName}" }
                        }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(student.fullName, style = MaterialTheme.typography.titleSmall)
                                Text("العمر: ${studentAgeLabel(student.birthDate)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                Text("اضغط لإضافة الطالب", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Icon(Icons.Default.Add, null, tint = MaterialTheme.colorScheme.primary)
                        }
                        HorizontalDivider()
                    }
                }
            }, confirmButton = { TextButton(onClick = { showPicker = false }) { Text("تم") } })
    }
}

private fun studentAgeLabel(birthDate: Long?): String {
    if (birthDate == null) return "غير مسجل"
    val birth = Instant.ofEpochMilli(birthDate).atZone(ZoneId.systemDefault()).toLocalDate()
    val age = Period.between(birth, LocalDate.now())
    return "${age.years} سنة و${age.months} شهر"
}

@Composable
private fun CreateClassDialog(onDismiss: () -> Unit, onCreate: (String, String, String, Int) -> Unit) {
    var name by remember { mutableStateOf("") }
    var level by remember { mutableStateOf("") }
    var teacher by remember { mutableStateOf("") }
    var capacity by remember { mutableStateOf("20") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إنشاء فصل جديد") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("اسم الفصل *") }, singleLine = true)
                OutlinedTextField(level, { level = it }, label = { Text("المرحلة / المستوى") }, singleLine = true)
                OutlinedTextField(teacher, { teacher = it }, label = { Text("اسم المعلمة (اختياري)") }, singleLine = true)
                OutlinedTextField(capacity, { capacity = it.filter(Char::isDigit) }, label = { Text("السعة القصوى") }, singleLine = true)
            }
        }, confirmButton = { Button(onClick = { onCreate(name, level, teacher, capacity.toIntOrNull() ?: 20) }, enabled = name.isNotBlank()) { Text("إنشاء") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}


@Composable
private fun EditClassDialog(room: Classroom, onDismiss: () -> Unit, onSave: (String, String, String, Int) -> Unit) {
    var name by remember(room.id) { mutableStateOf(room.name) }
    var level by remember(room.id) { mutableStateOf(room.level) }
    var teacher by remember(room.id) { mutableStateOf(room.teacherName) }
    var capacity by remember(room.id) { mutableStateOf(room.capacity.toString()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("تعديل بيانات الفصل") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("اسم الفصل *") }, singleLine = true)
                OutlinedTextField(level, { level = it }, label = { Text("المرحلة / المستوى") }, singleLine = true)
                OutlinedTextField(teacher, { teacher = it }, label = { Text("اسم المعلمة (اختياري)") }, singleLine = true)
                OutlinedTextField(capacity, { capacity = it.filter(Char::isDigit) }, label = { Text("السعة القصوى") }, singleLine = true)
            }
        }, confirmButton = { Button(onClick = { onSave(name, level, teacher, capacity.toIntOrNull() ?: 0) }, enabled = name.isNotBlank() && (capacity.toIntOrNull() ?: 0) > 0) { Text("حفظ التعديلات") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
private fun StudentFullProfileDialog(student: Student, onDismiss: () -> Unit) {
    val zone = ZoneId.systemDefault()
    val birth = student.birthDate?.let { Instant.ofEpochMilli(it).atZone(zone).toLocalDate() }
    val enrollment = Instant.ofEpochMilli(student.enrollmentDate).atZone(zone).toLocalDate()
    val age = birth?.let { Period.between(it, LocalDate.now()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("الملف الكامل للطالب") },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(student.fullName, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                HorizontalDivider()
                ProfileLine("الحالة", if (student.status == "active") "منتظم" else "منقطع")
                ProfileLine("الفصل", student.className.ifBlank { "غير موزع" })
                ProfileLine("تاريخ الميلاد", birth?.toString() ?: "غير مسجل")
                ProfileLine("العمر الحالي", age?.let { "${it.years} سنة و${it.months} شهر" } ?: "غير متاح")
                ProfileLine("تاريخ الالتحاق", enrollment.toString())
                ProfileLine("ميعاد الانصراف", if (student.attendanceEndHour == 15) "صباحية 8 ص – 1 م" else "مسائية 10 ص – 3 م")
                ProfileLine("الاشتراك الشهري", student.monthlyFeeOverridePiasters?.let { Money.format(it) } ?: "حسب سعر الفترة")
                ProfileLine("اسم الأم", student.motherName)
                ProfileLine("واتساب الأم", student.motherWhatsapp)
                ProfileLine("اسم الأب", student.fatherName)
                ProfileLine("هاتف الأب", student.fatherPhone)
                ProfileLine("العنوان", student.address)
                ProfileLine("ملاحظات", student.notes)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("إغلاق") } }
    )
}

@Composable
private fun ProfileLine(label: String, value: String) {
    if (value.isNotBlank()) Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}
