package com.tahseel.students.ui

import android.content.ContentValues
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.sqlite.db.SupportSQLiteDatabase
import com.tahseel.students.data.AppDatabase
import org.json.JSONObject

private data class SyncConflictRow(
    val eventId: String,
    val entityType: String,
    val entityKey: String,
    val operation: String,
    val remotePayload: String?
)

@Composable
fun SyncConflictScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val db = remember(context) { AppDatabase.create(context).openHelper.writableDatabase }
    var rows by remember { mutableStateOf<List<SyncConflictRow>>(emptyList()) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun reload() {
        rows = runCatching {
            val result = mutableListOf<SyncConflictRow>()
            db.query("SELECT event_id,entity_type,entity_key,operation,remote_payload FROM noury_sync_conflicts ORDER BY created_at DESC").use { c ->
                while (c.moveToNext()) result += SyncConflictRow(
                    c.getString(0), c.getString(1), c.getString(2), c.getString(3),
                    if (c.isNull(4)) null else c.getString(4)
                )
            }
            result
        }.getOrDefault(emptyList())
    }
    LaunchedEffect(Unit) { reload() }

    AppScaffold("حل تعارضات المزامنة", onBack) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                "اختر لكل سجل النسخة التي تريد الاحتفاظ بها. لن يتم استبدال البيانات المتعارضة دون اختيارك.",
                style = MaterialTheme.typography.bodyMedium
            )
            message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
            if (rows.isEmpty()) {
                Text("لا توجد تعارضات معلّقة حاليًا.")
            } else {
                Text("عدد التعارضات: ${rows.size}", style = MaterialTheme.typography.titleMedium)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(rows, key = { it.eventId }) { item ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(
                                Modifier.fillMaxWidth().padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text("الجدول: ${item.entityType}", style = MaterialTheme.typography.titleMedium)
                                Text("مفتاح السجل: ${item.entityKey}", style = MaterialTheme.typography.bodySmall)
                                Text(
                                    if (item.operation == "delete") "التعديل السحابي: حذف السجل"
                                    else "التعديل السحابي: إضافة أو تحديث",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        enabled = !busy,
                                        onClick = {
                                            busy = true
                                            try {
                                                // Keep the local row and its pending outbox event.
                                                db.execSQL("DELETE FROM noury_sync_conflicts WHERE event_id=?", arrayOf(item.eventId))
                                                message = "تم الاحتفاظ بنسخة هذا الجهاز."
                                                reload()
                                            } catch (e: Exception) {
                                                message = e.message ?: "تعذر حفظ الاختيار"
                                            } finally { busy = false }
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) { Text("الاحتفاظ بنسخة الجهاز") }
                                    Button(
                                        enabled = !busy,
                                        onClick = {
                                            busy = true
                                            try {
                                                applyCloudChoice(db, item)
                                                message = "تم اعتماد النسخة السحابية لهذا السجل."
                                                reload()
                                            } catch (e: Exception) {
                                                message = e.message ?: "تعذر تطبيق النسخة السحابية"
                                            } finally { busy = false }
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) { Text("اعتماد نسخة السحابة") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun applyCloudChoice(db: SupportSQLiteDatabase, item: SyncConflictRow) {
    require(item.entityType.matches(Regex("[A-Za-z0-9_]+"))) { "اسم الجدول غير صالح" }
    val key = JSONObject(item.entityKey)
    require(key.length() > 0) { "مفتاح السجل غير صالح" }
    val table = quoteSql(item.entityType)
    val keyNames = key.keys().asSequence().toList()
    val where = keyNames.joinToString(" AND ") { "${quoteSql(it)}=?" }
    val args = keyNames.map { key.get(it) }.toTypedArray()

    db.beginTransaction()
    try {
        db.execSQL("UPDATE noury_sync_meta SET suppress_capture=1 WHERE id=1")
        if (item.operation == "delete") {
            db.execSQL("DELETE FROM $table WHERE $where", args)
        } else {
            val payload = JSONObject(item.remotePayload ?: error("بيانات النسخة السحابية غير موجودة"))
            val values = ContentValues()
            val iterator = payload.keys()
            while (iterator.hasNext()) {
                val name = iterator.next()
                require(name.matches(Regex("[A-Za-z0-9_]+"))) { "اسم عمود غير صالح" }
                when (val value = payload.opt(name)) {
                    null, JSONObject.NULL -> values.putNull(name)
                    is Boolean -> values.put(name, if (value) 1 else 0)
                    is Int -> values.put(name, value)
                    is Long -> values.put(name, value)
                    is Double -> values.put(name, value)
                    else -> values.put(name, value.toString())
                }
            }
            val primaryKeys = mutableListOf<Pair<Int, String>>()
            db.query("PRAGMA table_info($table)").use { c ->
                val nameIndex = c.getColumnIndex("name")
                val pkIndex = c.getColumnIndex("pk")
                while (c.moveToNext()) if (c.getInt(pkIndex) > 0) {
                    primaryKeys += c.getInt(pkIndex) to c.getString(nameIndex)
                }
            }
            require(primaryKeys.isNotEmpty()) { "لا يمكن تحديد المفتاح الأساسي لهذا الجدول" }
            val names = values.keySet().toList()
            val pkNames = primaryKeys.sortedBy { it.first }.map { it.second }
            val updateNames = names.filterNot { it in pkNames }
            require(names.isNotEmpty()) { "النسخة السحابية فارغة" }
            val sql = buildString {
                append("INSERT INTO $table (")
                append(names.joinToString(",") { quoteSql(it) })
                append(") VALUES (")
                append(names.joinToString(",") { "?" })
                append(") ON CONFLICT (")
                append(pkNames.joinToString(",") { quoteSql(it) })
                append(") ")
                if (updateNames.isEmpty()) append("DO NOTHING") else {
                    append("DO UPDATE SET ")
                    append(updateNames.joinToString(",") { "${quoteSql(it)}=excluded.${quoteSql(it)}" })
                }
            }
            db.execSQL(sql, names.map { values.get(it) }.toTypedArray())
        }
        // Cloud was explicitly selected: supersede local pending events for this row.
        db.execSQL(
            "UPDATE noury_sync_outbox SET synced=1,last_error=NULL WHERE entity_type=? AND entity_key=?",
            arrayOf(item.entityType, item.entityKey)
        )
        db.execSQL("DELETE FROM noury_sync_conflicts WHERE event_id=?", arrayOf(item.eventId))
        db.execSQL("UPDATE noury_sync_meta SET suppress_capture=0 WHERE id=1")
        db.setTransactionSuccessful()
    } finally {
        runCatching { db.execSQL("UPDATE noury_sync_meta SET suppress_capture=0 WHERE id=1") }
        db.endTransaction()
    }
}

private fun quoteSql(value: String) = "\"${value.replace("\"", "\"\"")}\""
