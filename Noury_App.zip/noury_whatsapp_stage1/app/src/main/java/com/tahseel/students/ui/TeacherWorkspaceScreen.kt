package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.tahseel.students.App
import com.tahseel.students.sync.SupabaseAuth
import com.tahseel.students.sync.TeacherScopedSync
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import java.time.LocalDate

@Composable
fun TeacherWorkspaceScreen(app: App, onBack: () -> Unit) {
    val context = LocalContext.current
    val auth = remember(context) { SupabaseAuth(context) }
    val api = remember { TeacherScopedSync(auth, app.db.teacherAttendanceOutboxDao()) }
    if (auth.currentRole() == "owner") OwnerTeacherAssignments(app, api, onBack)
    else TeacherClassroomWorkspace(app, api, onBack)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun OwnerTeacherAssignments(app: App, api: TeacherScopedSync, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val teachers = remember { mutableStateListOf<TeacherScopedSync.Teacher>() }
    val classrooms by app.db.classroomDao().observeAll().collectAsState(initial = emptyList())
    var selectedTeacher by remember { mutableStateOf<TeacherScopedSync.Teacher?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("جارٍ تحميل المدرسين...") }
    LaunchedEffect(Unit) {
        runCatching { api.loadActiveTeachers() }.onSuccess {
            teachers.clear(); teachers.addAll(it); message = if (it.isEmpty()) "لا يوجد مدرسون نشطون حاليًا" else "اختر مدرسًا ثم أسند إليه فصلًا أو أكثر"
        }.onFailure { message = it.message ?: "تعذر تحميل المدرسين" }
    }
    Scaffold(topBar = { TopAppBar(title = { Text("توزيع الفصول على المدرسين") }, navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(message, style = MaterialTheme.typography.bodyMedium)
            if (selectedTeacher != null) Text("الفصول التي ستُسند إلى: ${selectedTeacher!!.displayName}", style = MaterialTheme.typography.titleMedium)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (selectedTeacher == null) {
                    items(teachers, key = { it.userId }) { teacher ->
                        Card(Modifier.fillMaxWidth(), onClick = { selectedTeacher = teacher }) {
                            Column(Modifier.padding(14.dp)) {
                                Text(teacher.displayName, style = MaterialTheme.typography.titleMedium)
                                Text(teacher.phone, style = MaterialTheme.typography.bodySmall)
                                Text("اختيار المدرس", color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                } else {
                    item { TextButton(onClick = { selectedTeacher = null }) { Text("اختيار مدرس آخر") } }
                    items(classrooms, key = { it.cloudId }) { classroom ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text(classroom.name, style = MaterialTheme.typography.titleMedium)
                                Text("المعرّف السحابي: ${classroom.cloudId.take(8)}…", style = MaterialTheme.typography.bodySmall)
                            }
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Button(enabled = !busy && classroom.cloudId.isNotBlank(), onClick = {
                                    scope.launch {
                                        busy = true
                                        message = try {
                                            api.setTeacherClass(selectedTeacher!!.userId, classroom.cloudId, classroom.name, true)
                                            "تم إسناد ${classroom.name} إلى ${selectedTeacher!!.displayName}"
                                        } catch (e: Exception) { e.message ?: "تعذر إسناد الفصل" }
                                        busy = false
                                    }
                                }) { Text("إسناد") }
                                OutlinedButton(enabled = !busy && classroom.cloudId.isNotBlank(), onClick = {
                                    scope.launch {
                                        busy = true
                                        message = try {
                                            val roster = app.db.classroomDao().observeStudents(classroom.name).first()
                                                .filter { it.status == "active" && it.cloudId.isNotBlank() }
                                                .map { it.cloudId to it.fullName }
                                            api.publishRoster(classroom.cloudId, classroom.name, roster)
                                            "تم نشر أسماء ${roster.size} طفلًا. رفع الصور سيُستكمل في دفعة الصور القادمة."
                                        } catch (e: Exception) { e.message ?: "تعذر نشر قائمة الأطفال" }
                                        busy = false
                                    }
                                }) { Text("نشر الأسماء") }
                            }
                        }
                        Divider()
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TeacherClassroomWorkspace(app: App, api: TeacherScopedSync, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val classes = remember { mutableStateListOf<TeacherScopedSync.AssignedClass>() }
    val students = remember { mutableStateListOf<TeacherScopedSync.StudentCard>() }
    val context = LocalContext.current
    val auth = remember(context) { SupabaseAuth(context) }
    val pending by app.db.teacherAttendanceOutboxDao().observePendingCount(auth.currentOrganizationId().orEmpty(), auth.currentUserId().orEmpty()).collectAsState(initial = 0)
    var selectedClass by remember { mutableStateOf<TeacherScopedSync.AssignedClass?>(null) }
    var message by remember { mutableStateOf("جارٍ تحميل الفصول المسندة...") }
    var busy by remember { mutableStateOf(false) }
    val today = remember { LocalDate.now().toString() }
    LaunchedEffect(Unit) {
        runCatching { api.loadTeacherAssignments() }.onSuccess {
            classes.clear(); classes.addAll(it); message = if (it.isEmpty()) "لم يسند المالك إليك أي فصل حتى الآن" else "اختر الفصل لعرض الأطفال"
        }.onFailure { message = it.message ?: "تعذر تحميل الفصول" }
    }
    Scaffold(topBar = { TopAppBar(title = { Text("فصولي والحضور") }, navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(message)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("حضور اليوم: $today")
                Text("معلّق للمزامنة: $pending")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = !busy && pending > 0, onClick = {
                    scope.launch {
                        busy = true
                        message = try { "تم رفع ${api.uploadPendingAttendance()} سجل حضور" } catch (e: Exception) { e.message ?: "تعذرت المزامنة" }
                        busy = false
                    }
                }) { Text("مزامنة الحضور") }
                OutlinedButton(enabled = !busy, onClick = {
                    scope.launch {
                        busy = true
                        runCatching { api.loadTeacherAssignments() }.onSuccess { classes.clear(); classes.addAll(it); message = "تم تحديث الفصول" }
                            .onFailure { message = it.message ?: "تعذر التحديث" }
                        busy = false
                    }
                }) { Text("تحديث الفصول") }
            }
            if (selectedClass == null) {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(classes, key = { it.classroomId }) { classroom ->
                        Card(Modifier.fillMaxWidth(), onClick = {
                            selectedClass = classroom
                            scope.launch {
                                message = "جارٍ تحميل قائمة الأطفال..."
                                runCatching { api.loadStudents(classroom.classroomId) }.onSuccess { students.clear(); students.addAll(it); message = "الأطفال في ${classroom.classroomName}" }
                                    .onFailure { message = it.message ?: "تعذر تحميل الأطفال" }
                            }
                        }) { Text(classroom.classroomName, Modifier.padding(18.dp), style = MaterialTheme.typography.titleMedium) }
                    }
                }
            } else {
                TextButton(onClick = { selectedClass = null; students.clear() }) { Text("العودة للفصول") }
                Text(selectedClass!!.classroomName, style = MaterialTheme.typography.titleLarge)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(students, key = { it.studentId }) { student ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                // Only the allow-listed display name is rendered; no financial or family fields are fetched.
                                Text(student.displayName, style = MaterialTheme.typography.titleMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(enabled = !busy, onClick = {
                                        scope.launch { runCatching { api.queueAttendance(student.classroomId, student.studentId, today, "present") }
                                            .onSuccess { message = "تم تسجيل حضور ${student.displayName} محليًا" }
                                            .onFailure { message = it.message ?: "تعذر حفظ الحضور" } }
                                    }) { Text("حاضر") }
                                    OutlinedButton(enabled = !busy, onClick = {
                                        scope.launch { runCatching { api.queueAttendance(student.classroomId, student.studentId, today, "absent") }
                                            .onSuccess { message = "تم تسجيل غياب ${student.displayName} محليًا" }
                                            .onFailure { message = it.message ?: "تعذر حفظ الغياب" } }
                                    }) { Text("غائب") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
