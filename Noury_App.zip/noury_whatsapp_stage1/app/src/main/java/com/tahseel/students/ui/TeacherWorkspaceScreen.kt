package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.tahseel.students.App
import com.tahseel.students.sync.SupabaseAuth
import com.tahseel.students.sync.TeacherScopedSync
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import java.time.LocalDate

@Composable
fun TeacherWorkspaceScreen(app: App, onBack: () -> Unit) {
    val context = LocalContext.current
    val auth = remember(context) { SupabaseAuth(context) }
    val api = remember { TeacherScopedSync(auth, app.db.teacherAttendanceOutboxDao()) }
    if (auth.currentRole() == "owner") OwnerTeacherAssignments(app, api, onBack)
    else TeacherClassroomWorkspace(app, api, onBack)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun OwnerTeacherAssignments(app: App, api: TeacherScopedSync, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val teachers = remember { mutableStateListOf<TeacherScopedSync.Teacher>() }
    val classrooms by app.db.classroomDao().observeAll().collectAsState(initial = emptyList())
    var selectedTeacher by remember { mutableStateOf<TeacherScopedSync.Teacher?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("جارٍ تحميل المدرسين...") }
    LaunchedEffect(Unit) {
        runCatching { api.loadActiveTeachers() }.onSuccess {
            teachers.clear(); teachers.addAll(it); message = if (it.isEmpty()) "لا يوجد مدرسون نشطون حاليًا" else "اختر مدرسًا ثم أسند إليه فصلًا أو أكثر"
        }.onFailure { message = it.message ?: "تعذر تحميل المدرسين" }
    }
    Scaffold(topBar = { TopAppBar(title = { Text("توزيع الفصول على المدرسين") }, navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(message, style = MaterialTheme.typography.bodyMedium)
            if (selectedTeacher != null) Text("الفصول التي ستُسند إلى: ${selectedTeacher!!.displayName}", style = MaterialTheme.typography.titleMedium)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (selectedTeacher == null) {
                    items(teachers, key = { it.userId }) { teacher ->
                        Card(modifier = Modifier.fillMaxWidth().clickable { selectedTeacher = teacher }) {
                            Column(Modifier.padding(14.dp)) {
                                Text(teacher.displayName, style = MaterialTheme.typography.titleMedium)
                                Text(teacher.phone, style = MaterialTheme.typography.bodySmall)
                                Text("اختيار المدرس", color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                } else {
                    item { TextButton(onClick = { selectedTeacher = null }) { Text("اختيار مدرس آخر") } }
                    items(classrooms, key = { it.cloudId }) { classroom ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text(classroom.name, style = MaterialTheme.typography.titleMedium)
                                Text("المعرّف السحابي: ${classroom.cloudId.take(8)}…", style = MaterialTheme.typography.bodySmall)
                            }
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Button(enabled = !busy && classroom.cloudId.isNotBlank(), onClick = {
                                    scope.launch {
                                        busy = true
                                        message = try {
                                            api.setTeacherClass(selectedTeacher!!.userId, classroom.cloudId, classroom.name, true)
                                            "تم إسناد ${classroom.name} إلى ${selectedTeacher!!.displayName}"
                                        } catch (e: Exception) { e.message ?: "تعذر إسناد الفصل" }
                                        busy = false
                                    }
                                }) { Text("إسناد") }
                                OutlinedButton(enabled = !busy && classroom.cloudId.isNotBlank(), onClick = {
                                    scope.launch {
                                        busy = true
                                        message = try {
                                            val roster = app.db.classroomDao().observeStudents(classroom.name).first()
                                                .filter { it.status == "active" && it.cloudId.isNotBlank() }
                                                .map { it.cloudId to it.fullName }
                                            api.publishRoster(classroom.cloudId, classroom.name, roster)
                                            "تم نشر أسماء ${roster.size} طفلًا. رفع الصور سيُستكمل في دفعة الصور القادمة."
                                        } catch (e: Exception) { e.message ?: "تعذر نشر قائمة الأطفال" }
                                        busy = false
                                    }
                                }) { Text("نشر الأسماء") }
                            }
                        }
                        Divider()
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TeacherClassroomWorkspace(app: App, api: TeacherScopedSync, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val classes = remember { mutableStateListOf<TeacherScopedSync.AssignedClass>() }
    val students = remember { mutableStateListOf<TeacherScopedSync.StudentCard>() }
    val context = LocalContext.current
    val auth = remember(context) { SupabaseAuth(context) }
    val pending by app.db.teacherAttendanceOutboxDao()
        .observePendingCount(auth.currentOrganizationId().orEmpty(), auth.currentUserId().orEmpty())
        .collectAsState(initial = 0)

    var selectedClass by remember { mutableStateOf<TeacherScopedSync.AssignedClass?>(null) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    val marks = remember { mutableStateMapOf<String, String>() }
    var message by remember { mutableStateOf("جارٍ تحميل الفصول المسندة...") }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        runCatching { api.loadTeacherAssignments() }.onSuccess {
            classes.clear(); classes.addAll(it)
            message = if (it.isEmpty()) "لم يسند المالك إليك أي فصل حتى الآن" else "اختر الفصل لعرض الأطفال وتسجيل الحضور"
        }.onFailure { message = it.message ?: "تعذر تحميل الفصول" }
    }

    val presentCount = students.count { marks["${selectedDate}_${it.studentId}"] == "present" }
    val absentCount = students.count { marks["${selectedDate}_${it.studentId}"] == "absent" }
    val recordedCount = presentCount + absentCount
    val dayName = remember(selectedDate) {
        selectedDate.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, java.util.Locale.forLanguageTag("ar"))
    }
    val displayDate = remember(selectedDate) {
        selectedDate.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd"))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("فصولي والحضور") },
                navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } }
            )
        },
        bottomBar = {
            if (selectedClass != null && students.isNotEmpty()) {
                Surface(shadowElevation = 8.dp, color = MaterialTheme.colorScheme.surface) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("حاضر $presentCount  •  غائب $absentCount  •  لم يسجل ${students.size - recordedCount}", style = MaterialTheme.typography.bodyMedium)
                        Button(
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !busy && recordedCount > 0,
                            onClick = {
                                scope.launch {
                                    busy = true
                                    message = try {
                                        students.forEach { student ->
                                            val status = marks["${selectedDate}_${student.studentId}"]
                                            if (status != null) api.queueAttendance(student.classroomId, student.studentId, selectedDate.toString(), status)
                                        }
                                        "تم حفظ كشف ${selectedClass!!.classroomName} محليًا، وسيتم رفعه عند المزامنة"
                                    } catch (e: Exception) { e.message ?: "تعذر حفظ الكشف" }
                                    busy = false
                                }
                            }
                        ) { Text("حفظ كشف اليوم") }
                    }
                }
            }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Date hero mirrors the owner's attendance page, but is scoped to the teacher's assigned classes.
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF4B2F78))
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(onClick = { selectedDate = selectedDate.minusDays(1); message = "" }) {
                        Icon(Icons.Filled.ChevronLeft, contentDescription = "اليوم السابق", tint = Color.White)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                        Text(dayName, color = Color.White.copy(alpha = .9f), style = MaterialTheme.typography.titleMedium)
                        Text(displayDate, color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Surface(color = Color(0xFFF2DFA5), shape = RoundedCornerShape(50)) {
                            Text("تسجيل حضور وغياب", modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp), color = Color(0xFF49351C), style = MaterialTheme.typography.labelMedium)
                        }
                    }
                    IconButton(onClick = { selectedDate = selectedDate.plusDays(1); message = "" }) {
                        Icon(Icons.Filled.ChevronRight, contentDescription = "اليوم التالي", tint = Color.White)
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TeacherStatCard("حاضر", presentCount, Color(0xFFE0F3ED), Color(0xFF16856F), Modifier.weight(1f))
                TeacherStatCard("غائب", absentCount, Color(0xFFFCE8E6), Color(0xFFB3261E), Modifier.weight(1f))
                TeacherStatCard("تم التسجيل", "$recordedCount/${students.size}", Color(0xFFF0EAF8), Color(0xFF56377F), Modifier.weight(1f))
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("الفصول المسندة إليك", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("معلّق للمزامنة: $pending", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    modifier = Modifier.weight(1f), enabled = !busy,
                    onClick = { scope.launch {
                        busy = true
                        runCatching { api.loadTeacherAssignments() }.onSuccess { classes.clear(); classes.addAll(it); message = "تم تحديث الفصول" }
                            .onFailure { message = it.message ?: "تعذر تحديث الفصول" }
                        busy = false
                    } }
                ) { Text("تحديث الفصول") }
                Button(
                    modifier = Modifier.weight(1f), enabled = !busy && pending > 0,
                    onClick = { scope.launch {
                        busy = true
                        message = try { "تمت مزامنة ${api.uploadPendingAttendance()} سجل حضور" }
                            catch (e: Exception) { e.message ?: "تعذرت المزامنة" }
                        busy = false
                    } }
                ) { Text("مزامنة الحضور") }
            }

            if (selectedClass == null) {
                if (classes.isEmpty()) {
                    Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                        items(classes, key = { it.classroomId }) { classroom ->
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable {
                                    selectedClass = classroom
                                    students.clear()
                                    scope.launch {
                                        busy = true
                                        message = "جارٍ تحميل الأطفال..."
                                        runCatching { api.loadStudents(classroom.classroomId) }.onSuccess {
                                            students.clear(); students.addAll(it)
                                            message = "تم تحميل ${it.size} طفلًا في ${classroom.classroomName}"
                                        }.onFailure { message = it.message ?: "تعذر تحميل الأطفال" }
                                        busy = false
                                    }
                                },
                                shape = RoundedCornerShape(20.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF3EEF9))
                            ) {
                                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column(Modifier.weight(1f)) {
                                        Text(classroom.classroomName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                        Text("فتح كشف الحضور لهذا الفصل", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Text("${classes.indexOf(classroom) + 1}", color = Color(0xFF56377F), style = MaterialTheme.typography.titleLarge)
                                }
                            }
                        }
                    }
                }
            } else {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = { selectedClass = null; students.clear(); marks.clear() }) { Text("العودة للفصول") }
                    Text(selectedClass!!.classroomName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }
                if (students.isEmpty()) {
                    Text(message.ifBlank { "لا يوجد أطفال منشورون لهذا الفصل حتى الآن" }, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(modifier = Modifier.weight(1f), enabled = !busy, onClick = {
                            students.forEach { marks["${selectedDate}_${it.studentId}"] = "present" }
                        }) { Text("الكل حاضر") }
                        OutlinedButton(modifier = Modifier.weight(1f), enabled = !busy, onClick = {
                            students.forEach { marks["${selectedDate}_${it.studentId}"] = "absent" }
                        }) { Text("الكل غائب") }
                    }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
                        items(students, key = { it.studentId }) { student ->
                            val status = marks["${selectedDate}_${student.studentId}"]
                            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Column(Modifier.weight(1f)) {
                                        Text(student.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                        Text(when (status) { "present" -> "حاضر"; "absent" -> "غائب"; else -> "لم يتم التسجيل" }, color = when (status) { "present" -> Color(0xFF16856F); "absent" -> Color(0xFFB3261E); else -> MaterialTheme.colorScheme.onSurfaceVariant }, style = MaterialTheme.typography.bodySmall)
                                    }
                                    OutlinedButton(enabled = !busy, onClick = { marks["${selectedDate}_${student.studentId}"] = "absent" }) { Text("غائب") }
                                    Button(enabled = !busy, onClick = { marks["${selectedDate}_${student.studentId}"] = "present" }) { Text("حاضر") }
                                }
                            }
                        }
                    }
                }
            }
            if (message.isNotBlank() && selectedClass != null) {
                Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun TeacherStatCard(label: String, value: Any, background: Color, foreground: Color, modifier: Modifier = Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = background)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value.toString(), color = foreground, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(label, color = foreground, style = MaterialTheme.typography.bodySmall)
        }
    }
}
