package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.tahseel.students.BuildConfig
import com.tahseel.students.sync.SupabaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

private data class NouryRegistrationRequest(val id: String, val phone: String, val displayName: String)

private data class NouryStaffUser(
    val userId: String,
    val phone: String,
    val displayName: String,
    val role: String,
    val active: Boolean
)

@Composable
fun NouryUserManagementScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val auth = remember(context) { SupabaseAuth(context) }
    val scope = rememberCoroutineScope()
    var users by remember { mutableStateOf<List<NouryStaffUser>>(emptyList()) }
    var requests by remember { mutableStateOf<List<NouryRegistrationRequest>>(emptyList()) }
    var initialPasswords by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    suspend fun callOwnerApi(payload: JSONObject): JSONObject = withContext(Dispatchers.IO) {
        val token = auth.accessToken() ?: throw IOException("انتهت جلسة الدخول. سجّل الدخول مرة أخرى.")
        val request = Request.Builder()
            .url("${BuildConfig.SUPABASE_URL}/functions/v1/owner-manage-users")
            .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Authorization", "Bearer $token")
            .header("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()
        OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
            .newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val detail = runCatching { JSONObject(text).optString("error") }.getOrNull()
                    throw IOException(detail?.takeIf { it.isNotBlank() } ?: "فشل تنفيذ العملية (HTTP ${response.code})")
                }
                JSONObject(text)
            }
    }

    suspend fun reloadRequests() {
        val result = callOwnerApi(JSONObject().put("action", "list_pending"))
        val array = result.optJSONArray("requests") ?: JSONArray()
        requests = (0 until array.length()).mapNotNull { i ->
            val item = array.optJSONObject(i) ?: return@mapNotNull null
            NouryRegistrationRequest(item.optString("id"), item.optString("phone"), item.optString("display_name"))
        }
    }

    fun reload() {
        scope.launch {
            loading = true
            try {
                val result = callOwnerApi(JSONObject().put("action", "list"))
                val array = result.optJSONArray("users") ?: JSONArray()
                users = (0 until array.length()).mapNotNull { i ->
                    val item = array.optJSONObject(i) ?: return@mapNotNull null
                    NouryStaffUser(
                        item.optString("user_id"), item.optString("phone"), item.optString("display_name"),
                        item.optString("role"), item.optBoolean("is_active")
                    )
                }
                reloadRequests()
                message = "تم تحديث قائمة المستخدمين وطلبات التسجيل"
            } catch (e: Exception) { message = e.message ?: "تعذر تحميل المستخدمين" }
            finally { loading = false }
        }
    }

    LaunchedEffect(Unit) {
        if (auth.currentRole() == "owner") reload()
    }

    AppScaffold("إدارة مستخدمي Noury", onBack) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (auth.currentRole() != "owner") {
                Text("هذه الشاشة متاحة لمالك البرنامج فقط.", color = MaterialTheme.colorScheme.error)
            } else {
                Text("أنت وحدك تستطيع مراجعة المستخدمين وتفعيلهم أو إيقافهم وتعديل أدوارهم.", style = MaterialTheme.typography.bodyMedium)
                Text("طلبات المدرسين تظهر هنا. أنت تحدد كلمة المرور الأولية وتوافق على إنشاء الحساب أو ترفض الطلب.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("طلبات تسجيل المدرسين", style = MaterialTheme.typography.titleLarge)
                OutlinedButton(onClick = { reload() }, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                    if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("تحديث القائمة")
                }
                if (requests.isEmpty()) Text("لا توجد طلبات تسجيل معلّقة.", style = MaterialTheme.typography.bodySmall)
                requests.forEach { request ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(request.displayName, style = MaterialTheme.typography.titleMedium)
                            Text(request.phone)
                            OutlinedTextField(value = initialPasswords[request.id].orEmpty(), onValueChange = { initialPasswords = initialPasswords + (request.id to it) }, label = { Text("كلمة المرور الأولية (8 أحرف على الأقل)") }, modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !loading)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(enabled = !loading && initialPasswords[request.id].orEmpty().length >= 8, onClick = {
                                    scope.launch {
                                        loading = true
                                        try {
                                            callOwnerApi(JSONObject().put("action", "approve_teacher").put("request_id", request.id).put("initial_password", initialPasswords[request.id]))
                                            initialPasswords = initialPasswords - request.id
                                            message = "تم إنشاء حساب المدرس. سلّمه رقم الموبايل وكلمة المرور التي حددتها."
                                            reload()
                                        } catch (e: Exception) { message = e.message ?: "تعذرت الموافقة" }
                                        finally { loading = false }
                                    }
                                }) { Text("موافقة وإنشاء الحساب") }
                                OutlinedButton(enabled = !loading, onClick = {
                                    scope.launch {
                                        loading = true
                                        try { callOwnerApi(JSONObject().put("action", "reject_teacher").put("request_id", request.id)); message = "تم رفض الطلب"; reload() }
                                        catch (e: Exception) { message = e.message ?: "تعذر رفض الطلب" }
                                        finally { loading = false }
                                    }
                                }) { Text("رفض") }
                            }
                        }
                    }
                }
                Divider()
                Text("حسابات المستخدمين", style = MaterialTheme.typography.titleLarge)
                users.forEach { user ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text(user.displayName, style = MaterialTheme.typography.titleMedium)
                            Text(user.phone, style = MaterialTheme.typography.bodyMedium)
                            Text("الدور: ${roleLabel(user.role)}", style = MaterialTheme.typography.bodySmall)
                            var roleMenu by remember(user.userId) { mutableStateOf(false) }
                            Box {
                                TextButton(onClick = { roleMenu = true }, enabled = !loading && user.role != "owner") { Text("تغيير الدور") }
                                DropdownMenu(expanded = roleMenu, onDismissRequest = { roleMenu = false }) {
                                    listOf("teacher", "accountant", "admin").filter { it != user.role }.forEach { newRole ->
                                        DropdownMenuItem(text = { Text(roleLabel(newRole)) }, onClick = {
                                            roleMenu = false
                                            scope.launch {
                                                loading = true
                                                try { callOwnerApi(JSONObject().put("action", "set_role").put("user_id", user.userId).put("role", newRole)); message = "تم تحديث دور المستخدم"; reload() }
                                                catch (e: Exception) { message = e.message ?: "تعذر تغيير الدور" }
                                                finally { loading = false }
                                            }
                                        })
                                    }
                                }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (user.active) "الحساب مفعّل" else "الحساب موقوف")
                                Switch(
                                    checked = user.active,
                                    enabled = !loading && user.role != "owner",
                                    onCheckedChange = { active ->
                                        scope.launch {
                                            loading = true
                                            try {
                                                callOwnerApi(JSONObject().put("action", "set_active").put("user_id", user.userId).put("is_active", active))
                                                message = if (active) "تم تفعيل الحساب" else "تم إيقاف الحساب"
                                                reload()
                                            } catch (e: Exception) { message = e.message ?: "تعذر تعديل حالة الحساب" }
                                            finally { loading = false }
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
            message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        }
    }


}

private fun roleLabel(role: String): String = when (role) {
    "owner" -> "مالك البرنامج"
    "admin" -> "مدير"
    "accountant" -> "محاسب"
    "teacher" -> "مدرس"
    else -> role
}
