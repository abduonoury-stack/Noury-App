package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.tahseel.students.BuildConfig
import com.tahseel.students.sync.SupabaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

private data class NouryStaffUser(
    val userId: String,
    val phone: String,
    val displayName: String,
    val role: String,
    val active: Boolean
)

@Composable
fun NouryUserManagementScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val auth = remember(context) { SupabaseAuth(context) }
    val scope = rememberCoroutineScope()
    var users by remember { mutableStateOf<List<NouryStaffUser>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("teacher") }

    suspend fun callOwnerApi(payload: JSONObject): JSONObject = withContext(Dispatchers.IO) {
        val token = auth.accessToken() ?: throw IOException("انتهت جلسة الدخول. سجّل الدخول مرة أخرى.")
        val request = Request.Builder()
            .url("${BuildConfig.SUPABASE_URL}/functions/v1/owner-manage-users")
            .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Authorization", "Bearer $token")
            .header("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()
        OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
            .newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val detail = runCatching { JSONObject(text).optString("error") }.getOrNull()
                    throw IOException(detail?.takeIf { it.isNotBlank() } ?: "فشل تنفيذ العملية (HTTP ${response.code})")
                }
                JSONObject(text)
            }
    }

    fun reload() {
        scope.launch {
            loading = true
            try {
                val result = callOwnerApi(JSONObject().put("action", "list"))
                val array = result.optJSONArray("users") ?: JSONArray()
                users = (0 until array.length()).mapNotNull { i ->
                    val item = array.optJSONObject(i) ?: return@mapNotNull null
                    NouryStaffUser(
                        item.optString("user_id"), item.optString("phone"), item.optString("display_name"),
                        item.optString("role"), item.optBoolean("is_active")
                    )
                }
                message = "تم تحديث قائمة المستخدمين"
            } catch (e: Exception) { message = e.message ?: "تعذر تحميل المستخدمين" }
            finally { loading = false }
        }
    }

    LaunchedEffect(Unit) {
        if (auth.currentRole() == "owner") reload()
    }

    AppScaffold("إدارة مستخدمي Noury", onBack) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (auth.currentRole() != "owner") {
                Text("هذه الشاشة متاحة لمالك البرنامج فقط.", color = MaterialTheme.colorScheme.error)
            } else {
                Text("أنت وحدك تستطيع إنشاء حسابات الموظفين وتفعيلها أو إيقافها.", style = MaterialTheme.typography.bodyMedium)
                Button(onClick = { showCreate = true }, modifier = Modifier.fillMaxWidth()) { Text("إضافة مستخدم جديد") }
                OutlinedButton(onClick = { reload() }, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                    if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("تحديث القائمة")
                }
                users.forEach { user ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text(user.displayName, style = MaterialTheme.typography.titleMedium)
                            Text(user.phone, style = MaterialTheme.typography.bodyMedium)
                            Text("الدور: ${roleLabel(user.role)}", style = MaterialTheme.typography.bodySmall)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (user.active) "الحساب مفعّل" else "الحساب موقوف")
                                Switch(
                                    checked = user.active,
                                    enabled = !loading && user.role != "owner",
                                    onCheckedChange = { active ->
                                        scope.launch {
                                            loading = true
                                            try {
                                                callOwnerApi(JSONObject().put("action", "set_active").put("user_id", user.userId).put("is_active", active))
                                                message = if (active) "تم تفعيل الحساب" else "تم إيقاف الحساب"
                                                reload()
                                            } catch (e: Exception) { message = e.message ?: "تعذر تعديل حالة الحساب" }
                                            finally { loading = false }
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
            message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        }
    }

    if (showCreate) {
        AlertDialog(
            onDismissRequest = { if (!loading) showCreate = false },
            title = { Text("إضافة حساب موظف") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("اسم الموظف") }, singleLine = true)
                    OutlinedTextField(phone, { phone = it.filter { c -> c.isDigit() || c == '+' || c == ' ' } }, label = { Text("رقم الموبايل") }, placeholder = { Text("01XXXXXXXXX") }, singleLine = true)
                    Text("نوع الحساب")
                    listOf("admin", "accountant", "teacher").forEach { value ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                            RadioButton(selected = role == value, onClick = { role = value })
                            Text(roleLabel(value), modifier = Modifier.padding(top = 12.dp))
                        }
                    }
                    Text("سيتم إرسال كود التحقق على واتساب عند أول تسجيل دخول بعد إعداد مزود واتساب.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(enabled = !loading && name.isNotBlank() && phone.isNotBlank(), onClick = {
                    scope.launch {
                        loading = true
                        try {
                            val normalized = auth.normalizeEgyptianPhone(phone)
                            callOwnerApi(JSONObject().put("action", "create").put("display_name", name.trim()).put("phone", normalized).put("role", role))
                            message = "تم إنشاء حساب الموظف. أصبح بإمكانه تسجيل الدخول برقم واتساب المسجل."
                            showCreate = false; name = ""; phone = ""
                            reload()
                        } catch (e: Exception) { message = e.message ?: "تعذر إنشاء الحساب" }
                        finally { loading = false }
                    }
                }) { Text("إنشاء الحساب") }
            },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("إلغاء") } }
        )
    }
}

private fun roleLabel(role: String): String = when (role) {
    "owner" -> "مالك البرنامج"
    "admin" -> "مدير"
    "accountant" -> "محاسب"
    "teacher" -> "مدرس"
    else -> role
}
