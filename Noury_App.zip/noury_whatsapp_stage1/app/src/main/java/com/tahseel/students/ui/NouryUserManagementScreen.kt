package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.tahseel.students.BuildConfig
import com.tahseel.students.sync.SupabaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

private data class NouryStaffUser(val userId: String, val phone: String, val displayName: String, val role: String, val active: Boolean, val mustChangePassword: Boolean)
private data class NouryRegistrationRequest(val id: String, val fullName: String, val phone: String, val jobTitle: String, val address: String, val status: String)

@Composable
fun NouryUserManagementScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val auth = remember(context) { SupabaseAuth(context) }
    val scope = rememberCoroutineScope()
    var users by remember { mutableStateOf<List<NouryStaffUser>>(emptyList()) }
    var requests by remember { mutableStateOf<List<NouryRegistrationRequest>>(emptyList()) }
    var selectedRoles by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    suspend fun callOwnerApi(payload: JSONObject): JSONObject = withContext(Dispatchers.IO) {
        val token = auth.accessToken() ?: throw IOException("انتهت جلسة الدخول. سجّل الدخول مرة أخرى.")
        val request = Request.Builder()
            .url("${BuildConfig.SUPABASE_URL}/functions/v1/owner-manage-users")
            .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Authorization", "Bearer $token")
            .header("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()
        OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
            .newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val detail = runCatching { JSONObject(text).optString("error") }.getOrNull()
                    throw IOException(detail?.takeIf { it.isNotBlank() } ?: "فشل تنفيذ العملية (HTTP ${response.code})")
                }
                JSONObject(text)
            }
    }

    suspend fun loadData() {
        val userResult = callOwnerApi(JSONObject().put("action", "list"))
        val userArray = userResult.optJSONArray("users") ?: JSONArray()
        users = (0 until userArray.length()).mapNotNull { i ->
            val item = userArray.optJSONObject(i) ?: return@mapNotNull null
            NouryStaffUser(item.optString("user_id"), item.optString("phone"), item.optString("display_name"), item.optString("role"), item.optBoolean("is_active"), item.optBoolean("must_change_password"))
        }
        val requestResult = callOwnerApi(JSONObject().put("action", "list_requests"))
        val requestArray = requestResult.optJSONArray("requests") ?: JSONArray()
        requests = (0 until requestArray.length()).mapNotNull { i ->
            val item = requestArray.optJSONObject(i) ?: return@mapNotNull null
            NouryRegistrationRequest(item.optString("id"), item.optString("full_name"), item.optString("phone"), item.optString("job_title"), item.optString("address"), item.optString("status"))
        }
        requests.forEach { request -> if (selectedRoles[request.id] == null) selectedRoles = selectedRoles + (request.id to "teacher") }
    }

    fun reload() {
        scope.launch {
            loading = true
            try { loadData(); message = "تم تحديث المستخدمين وطلبات التسجيل" }
            catch (e: Exception) { message = e.message ?: "تعذر تحميل البيانات" }
            finally { loading = false }
        }
    }

    LaunchedEffect(Unit) { if (auth.currentRole() == "owner") reload() }

    AppScaffold("إدارة المستخدمين وطلبات التسجيل", onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (auth.currentRole() != "owner") {
                Text("هذه الشاشة متاحة لمالك البرنامج فقط.", color = MaterialTheme.colorScheme.error)
            } else {
                Text("طلبات التسجيل الجديدة", style = MaterialTheme.typography.titleLarge)
                Text("الطلبات لا تنشئ حسابات تلقائيًا. اختر الدور ثم اعتمد أو ارفض الطلب.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedButton(onClick = { reload() }, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                    if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("تحديث القائمة")
                }
                if (requests.isEmpty()) Text("لا توجد طلبات معلقة حاليًا.", style = MaterialTheme.typography.bodyMedium)
                requests.forEach { request ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(request.fullName, style = MaterialTheme.typography.titleMedium)
                            Text("الهاتف: ${request.phone}")
                            Text("الوظيفة: ${request.jobTitle}")
                            Text("العنوان: ${request.address}")
                            if (request.status == "approving") Text("حالة الطلب: جارٍ الاعتماد. لا تكرر العملية.", color = MaterialTheme.colorScheme.error)
                            Text("الدور بعد الموافقة:", style = MaterialTheme.typography.labelLarge)
                            listOf("admin", "accountant", "teacher").forEach { value ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                                    RadioButton(selected = selectedRoles[request.id] == value, onClick = { selectedRoles = selectedRoles + (request.id to value) }, enabled = !loading && request.status == "pending")
                                    Text(roleLabel(value), modifier = Modifier.padding(top = 12.dp))
                                }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = {
                                    scope.launch {
                                        loading = true
                                        try {
                                            callOwnerApi(JSONObject().put("action", "approve_request").put("request_id", request.id).put("role", selectedRoles[request.id] ?: "teacher"))
                                            message = "تم اعتماد الطلب وإرسال بيانات الدخول المؤقتة إلى واتساب."
                                            loadData()
                                        } catch (e: Exception) { message = e.message ?: "تعذر اعتماد الطلب" }
                                        finally { loading = false }
                                    }
                                }, enabled = !loading && request.status == "pending", modifier = Modifier.weight(1f)) { Text("قبول وإنشاء الحساب") }
                                OutlinedButton(onClick = {
                                    scope.launch {
                                        loading = true
                                        try {
                                            callOwnerApi(JSONObject().put("action", "reject_request").put("request_id", request.id))
                                            message = "تم رفض طلب التسجيل"
                                            loadData()
                                        } catch (e: Exception) { message = e.message ?: "تعذر رفض الطلب" }
                                        finally { loading = false }
                                    }
                                }, enabled = !loading && request.status == "pending", modifier = Modifier.weight(1f)) { Text("رفض") }
                            }
                        }
                    }
                }

                Divider()
                Text("حسابات المستخدمين", style = MaterialTheme.typography.titleLarge)
                users.forEach { user ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text(user.displayName, style = MaterialTheme.typography.titleMedium)
                            Text(user.phone, style = MaterialTheme.typography.bodyMedium)
                            Text("الدور: ${roleLabel(user.role)}", style = MaterialTheme.typography.bodySmall)
                            Text(if (user.mustChangePassword) "ينتظر تغيير كلمة المرور المؤقتة" else "كلمة المرور مفعّلة", style = MaterialTheme.typography.bodySmall)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (user.active) "الحساب مفعّل" else "الحساب موقوف")
                                Switch(checked = user.active, enabled = !loading && user.role != "owner", onCheckedChange = { active ->
                                    scope.launch {
                                        loading = true
                                        try {
                                            callOwnerApi(JSONObject().put("action", "set_active").put("user_id", user.userId).put("is_active", active))
                                            message = if (active) "تم تفعيل الحساب" else "تم إيقاف الحساب وإبطال جلساته الخادمية"
                                            loadData()
                                        } catch (e: Exception) { message = e.message ?: "تعذر تعديل حالة الحساب" }
                                        finally { loading = false }
                                    }
                                })
                            }
                        }
                    }
                }
            }
            message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        }
    }
}

private fun roleLabel(role: String): String = when (role) {
    "owner" -> "مالك البرنامج"
    "admin" -> "مدير"
    "accountant" -> "محاسب"
    "teacher" -> "مدرس"
    else -> role
}
