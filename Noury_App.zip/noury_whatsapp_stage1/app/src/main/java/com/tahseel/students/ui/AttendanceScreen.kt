package com.tahseel.students.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Call
import androidx.compose.material3.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material.icons.filled.PersonOff
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.data.Attendance
import com.tahseel.students.data.Student
import com.tahseel.students.util.AcademyProfileStore
import com.tahseel.students.vm.AttendanceViewModel
import java.net.URLEncoder
import java.time.Instant
import java.time.LocalDate
import java.time.Period
import java.time.ZoneId
import com.tahseel.students.util.WorkdaySettings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceScreen(vm: AttendanceViewModel, onBack: () -> Unit, onProfile: (Long) -> Unit) {
    val rooms by vm.classrooms.collectAsStateWithLifecycle()
    val allStudents by vm.students.collectAsStateWithLifecycle()
    val dayRows by vm.day.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val allDay by vm.allDay.collectAsStateWithLifecycle()
    val workdays by vm.workdays.collectAsStateWithLifecycle()
    var roomName by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now()) }
    LaunchedEffect(workdays) { date = WorkdaySettings.onOrBefore(date, workdays) }
    LaunchedEffect(Unit) { vm.refreshWorkdays() }
    var marks by remember { mutableStateOf<Map<Long, Boolean>>(emptyMap()) }
    var savedMessage by remember { mutableStateOf("") }
    var report by remember { mutableStateOf<List<Pair<Attendance, List<String>>>?>(null) }
    var absenceClassDetail by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val roster = allStudents.filter { it.className == roomName && it.status == "active" }.sortedWith(
        compareBy<Student> { it.birthDate == null }.thenBy { it.birthDate ?: Long.MAX_VALUE }
    )
    LaunchedEffect(roomName, date) { if (roomName.isNotBlank()) vm.load(roomName, date.toString()) }
    LaunchedEffect(date) { vm.loadAllDay(date.toString()) }
    LaunchedEffect(dayRows, roster) {
        if (dayRows.isNotEmpty()) marks = dayRows.associate { it.studentId to (it.status == "present") }
        else marks = roster.associate { it.id to true }
    }
    val presentNow = roster.count { marks[it.id] == true }
    val absentNow = roster.size - presentNow
    val dayName = remember(date) { date.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, java.util.Locale.forLanguageTag("ar")) }
    AppScaffold(
        title = if (absenceClassDetail != null) "غياب فصل $absenceClassDetail" else "حضور وغياب الطلاب",
        onBack = { if (absenceClassDetail != null) absenceClassDetail = null else onBack() },
        bottomBar = {
            if (rooms.isNotEmpty() && absenceClassDetail == null && roomName.isNotBlank() && roster.isNotEmpty()) {
                AttendanceSaveBar(
                    present = presentNow,
                    absent = absentNow,
                    message = savedMessage,
                    onSave = { vm.save(roomName, date.toString(), roster.map { it.id }, marks) { err -> savedMessage = err ?: "تم حفظ كشف الحضور" } }
                )
            }
        }
    ) { pad ->
        if (rooms.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize().padding(20.dp), contentAlignment = Alignment.Center) {
                PremiumCard {
                    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        DuotoneIcon(Icons.Filled.ChildCare, iconSize = 34.dp, tileSize = 68.dp)
                        Text("لا توجد فصول مسجلة", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                        Text("أضف الفصول أولاً من إدارة الفصول، ثم ارجع لتسجيل الحضور.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.padding(pad).fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item(key = "attendance-date") {
                    AttendanceHero(
                        dayName = dayName,
                        date = date.toString(),
                        isWorkday = WorkdaySettings.isWorkday(date, workdays),
                        onPrevious = { date = WorkdaySettings.previous(date.minusDays(1), workdays) },
                        onNext = { date = WorkdaySettings.next(date.plusDays(1), workdays) }
                    )
                }

                if (absenceClassDetail == null) {
                    val totalAbsent = allDay.count { it.status == "absent" }
                    val totalPresent = allDay.count { it.status == "present" }
                    val savedRooms = rooms.count { room -> allDay.any { it.className.normalizedClassName() == room.name.normalizedClassName() } }
                    item(key = "overview-title") { SectionTitle("كشف الغياب اليومي لجميع الفصول") }
                    item(key = "overview-metrics") {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                AttendanceStatTile("غائب", totalAbsent.toString(), Icons.Filled.PersonOff, LdaPalette.ErrorContainer, LdaPalette.Error, Modifier.weight(1f))
                                AttendanceStatTile("حاضر", totalPresent.toString(), Icons.Filled.HowToReg, LdaPalette.SuccessContainer, LdaPalette.Success, Modifier.weight(1f))
                                AttendanceStatTile("كشف مسجل", "$savedRooms/${rooms.size}", Icons.Filled.TaskAlt, LdaPalette.Lilac, LdaPalette.RoyalMid, Modifier.weight(1f))
                            }
                            AttendanceBar(
                                fraction = if (rooms.isEmpty()) 0f else savedRooms.toFloat() / rooms.size.toFloat(),
                                fill = LdaPalette.RoyalMid,
                                track = LdaPalette.Lilac
                            )
                        }
                    }
                    items(rooms, key = { "room-${it.id}" }) { room ->
                        val rows = allDay.filter { it.className.normalizedClassName() == room.name.normalizedClassName() }
                        val absent = rows.filter { it.status == "absent" }
                        val enrolledCount = allStudents.count { it.className.normalizedClassName() == room.name.normalizedClassName() && it.status == "active" }
                        AttendanceRoomCard(
                            name = room.name,
                            saved = rows.isNotEmpty(),
                            present = rows.count { it.status == "present" },
                            absentNames = absent.map { it.studentName },
                            enrolled = enrolledCount,
                            onClick = {
                                roomName = room.name
                                marks = emptyMap()
                                absenceClassDetail = room.name
                            }
                        )
                    }
                    item(key = "consecutive-absence") {
                        AttendanceActionCard(
                            title = "كشف الغياب 3 أيام متتالية أو أكثر",
                            subtitle = "طلاب يحتاجون متابعة مع أولياء الأمور",
                            icon = Icons.Filled.EventBusy,
                            onClick = { vm.consecutiveAbsenteesAll(date.toString()) { report = it } }
                        )
                    }
                    item(key = "attendance-entry-title") {
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            SectionTitle("تسجيل حضور الفصل")
                            Text("اختر الفصل لعرض أسماء طلابه وتسجيل حالتهم في التاريخ المحدد.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    item(key = "attendance-room-picker") {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 2.dp)) {
                            items(rooms, key = { "chip-${it.id}" }) { room ->
                                AttendanceRoomChip(name = room.name, selected = room.name == roomName) {
                                    roomName = room.name
                                    marks = emptyMap()
                                    savedMessage = ""
                                }
                            }
                        }
                    }
                    if (roomName.isBlank()) {
                        item(key = "attendance-select-hint") {
                            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = LdaPalette.Lilac)) {
                                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    DuotoneIcon(Icons.Filled.Groups, containerColor = Color.White)
                                    Text("بعد اختيار الفصل ستظهر أسماء الطلاب هنا مباشرة.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    } else {
                        item(key = "attendance-roster-tools") {
                            AttendanceRosterHeader(
                                roomName = roomName,
                                total = roster.size,
                                present = presentNow,
                                absent = absentNow,
                                onAllPresent = { marks = roster.associate { it.id to true }; savedMessage = "" },
                                onAllAbsent = { marks = roster.associate { it.id to false }; savedMessage = "" }
                            )
                        }
                        if (roster.isEmpty()) {
                            item(key = "attendance-empty-roster") {
                                PremiumCard {
                                    Text("لا يوجد طلاب منتظمون في هذا الفصل", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                                    Text("راجع توزيع الطلاب على الفصول وحالة انتظامهم من إدارة الطلاب.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        } else {
                            items(roster, key = { "student-${it.id}" }) { student ->
                                AttendanceStudentRow(
                                    student = student,
                                    present = marks[student.id] == true,
                                    onToggle = {
                                        marks = marks + (student.id to !(marks[student.id] == true))
                                        savedMessage = ""
                                    },
                                    onProfile = { onProfile(student.id) }
                                )
                            }
                        }
                    }
                } else {
                    val detailClassName = absenceClassDetail.orEmpty()
                    val absentStudents = allDay.filter { it.className.normalizedClassName() == detailClassName.normalizedClassName() && it.status == "absent" }
                    item(key = "absence-detail-heading") {
                        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Brush.linearGradient(listOf(LdaPalette.RoyalDeep, LdaPalette.RoyalMid)))) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                AttendanceRoundNav(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") { absenceClassDetail = null }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("غياب فصل $absenceClassDetail", style = MaterialTheme.typography.titleLarge, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${absentStudents.size} طالب غائب • $date", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.82f))
                                }
                            }
                        }
                    }
                    if (absentStudents.isEmpty()) {
                        item(key = "absence-detail-empty") {
                            PremiumCard {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    DuotoneIcon(Icons.Filled.HowToReg, tint = LdaPalette.Success, containerColor = LdaPalette.SuccessContainer)
                                    Text("لا توجد أسماء غياب مسجلة لهذا الفصل في هذا اليوم. قد يكون كشف الفصل لم يُحفظ بعد أو أن جميع الطلاب حاضرون.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    } else {
                        items(absentStudents, key = { "absent-${it.studentId}" }) { row ->
                            val student = allStudents.firstOrNull { it.id == row.studentId }
                            val hasPhone = !student?.motherWhatsapp.isNullOrBlank()
                            Card(
                                Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(22.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, LdaPalette.Error.copy(alpha = 0.25f)),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                            ) {
                                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.border(2.dp, LdaPalette.Error, CircleShape).padding(3.dp)) {
                                        StudentAvatar(student?.photoUri, 48.dp, row.studentId, student?.gender ?: "boy")
                                    }
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f).clickable { onProfile(row.studentId) }, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Text(row.studentName, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        Text("غائب • $date", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                                    }
                                    FilledTonalIconButton(
                                        onClick = { openAbsenceWhatsApp(context, student, listOf(date.toString())) },
                                        enabled = hasPhone,
                                        colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = LdaPalette.SuccessContainer, contentColor = LdaPalette.Success)
                                    ) { Icon(Icons.Filled.Message, contentDescription = "واتساب") }
                                    FilledTonalIconButton(
                                        onClick = { openAbsenceMotherCall(context, student) },
                                        enabled = hasPhone,
                                        colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = LdaPalette.Lilac, contentColor = LdaPalette.RoyalMid)
                                    ) { Icon(Icons.Filled.Call, contentDescription = "اتصال") }
                                }
                            }
                        }
                    }
                    item(key = "absence-detail-back-to-attendance") {
                        OutlinedButton(onClick = { absenceClassDetail = null }, modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp), shape = RoundedCornerShape(18.dp)) {
                            Text("العودة لتسجيل حضور الفصل – $roomName")
                        }
                    }
                }
            }
        }
    }
    report?.let { rows ->
        AlertDialog(onDismissRequest = { report = null }, title = { Text("الطلاب الغائبون 3 أيام عمل متتالية أو أكثر") },
            text = { if (rows.isEmpty()) Text("لا يوجد طلاب غائبون في آخر 3 أيام عمل مسجلة قبل التاريخ المحدد.") else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.heightIn(max = 440.dp)) { items(rows, key = { it.first.studentId }) { (rec, dates) ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    val reportStudent = allStudents.firstOrNull { it.id == rec.studentId }
                    StudentAvatar(reportStudent?.photoUri, 44.dp, rec.studentId, reportStudent?.gender ?: "boy")
                    Text(rec.studentName, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.clickable { onProfile(rec.studentId) })
                }
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("الفصل: ${rec.className} • ${dates.size} أيام غياب متتالية على الأقل", style = MaterialTheme.typography.bodySmall)
                    Text("تواريخ الغياب: ${dates.joinToString("، ")}", style = MaterialTheme.typography.bodySmall)
                    val student = allStudents.firstOrNull { it.id == rec.studentId }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { openAbsenceWhatsApp(context, student, dates) },
                            enabled = !student?.motherWhatsapp.isNullOrBlank(),
                            modifier = Modifier.weight(1f)
                        ) { Icon(Icons.Default.Message, null); Spacer(Modifier.width(5.dp)); Text("واتساب") }
                        OutlinedButton(
                            onClick = { openAbsenceMotherCall(context, student) },
                            enabled = !student?.motherWhatsapp.isNullOrBlank(),
                            modifier = Modifier.weight(1f)
                        ) { Icon(Icons.Default.Call, null); Spacer(Modifier.width(5.dp)); Text("اتصال") }
                    }
                }
            } } }, confirmButton = { TextButton(onClick = { report = null }) { Text("إغلاق") } })
    }
}


@Composable
private fun AttendanceHero(dayName: String, date: String, isWorkday: Boolean, onPrevious: () -> Unit, onNext: () -> Unit) {
    Box(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(LdaPalette.RoyalDeep, LdaPalette.RoyalMid)))
    ) {
        Box(Modifier.size(130.dp).offset(x = (-34).dp, y = (-46).dp).background(Color.White.copy(alpha = 0.07f), CircleShape))
        Box(Modifier.size(96.dp).align(Alignment.BottomEnd).offset(x = 30.dp, y = 36.dp).background(LdaPalette.Gold.copy(alpha = 0.16f), CircleShape))
        Icon(Icons.Filled.Star, contentDescription = null, tint = LdaPalette.Gold.copy(alpha = 0.9f), modifier = Modifier.align(Alignment.TopStart).padding(start = 84.dp, top = 12.dp).size(14.dp))
        Icon(Icons.Filled.Star, contentDescription = null, tint = LdaPalette.Peach.copy(alpha = 0.85f), modifier = Modifier.align(Alignment.BottomStart).padding(start = 96.dp, bottom = 14.dp).size(10.dp))
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // الواجهة RTL دائمًا: "السابق" على اليمين و"التالي" على اليسار.
            AttendanceRoundNav(Icons.Filled.ChevronRight, "اليوم السابق", onPrevious)
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(dayName, style = MaterialTheme.typography.labelLarge, color = Color.White.copy(alpha = 0.85f))
                Text(date, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = Color.White)
                Surface(shape = RoundedCornerShape(50), color = if (isWorkday) LdaPalette.Gold else LdaPalette.PeachContainer) {
                    Text(
                        if (isWorkday) "يوم عمل" else "إجازة أسبوعية",
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF3C2B08)
                    )
                }
            }
            AttendanceRoundNav(Icons.Filled.ChevronLeft, "اليوم التالي", onNext)
        }
    }
}

@Composable
private fun AttendanceRoundNav(icon: ImageVector, description: String, onClick: () -> Unit) {
    Box(
        Modifier.size(46.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.16f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = description, tint = Color.White, modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun AttendanceStatTile(label: String, value: String, icon: ImageVector, container: Color, tint: Color, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(22.dp), color = container) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = tint)
            Text(label, style = MaterialTheme.typography.labelSmall, color = tint.copy(alpha = 0.85f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun AttendanceBar(fraction: Float, fill: Color, track: Color, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(track)) {
        Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).fillMaxHeight().clip(RoundedCornerShape(50)).background(fill))
    }
}

@Composable
private fun AttendanceRoomCard(name: String, saved: Boolean, present: Int, absentNames: List<String>, enrolled: Int, onClick: () -> Unit) {
    val absent = absentNames.size
    val accent = when { !saved -> LdaPalette.Warning; absent > 0 -> LdaPalette.Error; else -> LdaPalette.Success }
    val soft = when { !saved -> LdaPalette.WarningContainer; absent > 0 -> LdaPalette.ErrorContainer; else -> LdaPalette.SuccessContainer }
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.28f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).clip(CircleShape).background(soft), contentAlignment = Alignment.Center) {
                    Text(name.trim().take(1), color = accent, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(name, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        if (!saved) "لم يتم حفظ كشف الحضور لهذا الفصل في هذا التاريخ" else "$present حاضر • $absent غائب • $enrolled طالب منتظم",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(8.dp))
                Surface(shape = RoundedCornerShape(50), color = soft) {
                    Text(
                        if (!saved) "لم يسجل" else if (absent > 0) "$absent غائب" else "الكل حاضر",
                        modifier = Modifier.padding(horizontal = 11.dp, vertical = 5.dp),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = accent
                    )
                }
                Icon(Icons.Filled.ChevronLeft, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (saved && present + absent > 0) {
                AttendanceBar(fraction = present.toFloat() / (present + absent).toFloat(), fill = LdaPalette.Success, track = if (absent > 0) LdaPalette.ErrorContainer else LdaPalette.SuccessContainer)
            }
            if (absentNames.isNotEmpty()) {
                Text("الغائبون: ${absentNames.joinToString("، ")}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error, maxLines = 3, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun AttendanceActionCard(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = LdaPalette.WarningContainer),
        border = BorderStroke(1.dp, LdaPalette.Warning.copy(alpha = 0.25f))
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            DuotoneIcon(icon, tint = LdaPalette.Warning, containerColor = Color.White)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, style = MaterialTheme.typography.titleSmall, color = LdaPalette.RoyalDeep)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Filled.ChevronLeft, contentDescription = null, tint = LdaPalette.Warning)
        }
    }
}

@Composable
private fun AttendanceRoomChip(name: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape)
            .background(if (selected) LdaPalette.Royal else Color.White)
            .border(1.dp, if (selected) LdaPalette.Royal else LdaPalette.Border, shape)
            .clickable(onClick = onClick)
            .heightIn(min = 44.dp)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(name, color = if (selected) Color.White else LdaPalette.Royal, style = MaterialTheme.typography.labelLarge, maxLines = 1)
    }
}

@Composable
private fun AttendanceCounter(label: String, value: Int, tint: Color, container: Color, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(16.dp), color = container) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.labelLarge, color = tint)
            Text(value.toString(), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = tint)
        }
    }
}

@Composable
private fun AttendanceRosterHeader(roomName: String, total: Int, present: Int, absent: Int, onAllPresent: () -> Unit, onAllAbsent: () -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = LdaPalette.Lilac),
        border = BorderStroke(1.dp, LdaPalette.Border)
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                DuotoneIcon(Icons.Filled.Groups, containerColor = Color.White)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("طلاب فصل $roomName", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("$total طالب", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                AttendanceCounter("حاضر", present, LdaPalette.Success, LdaPalette.SuccessContainer, Modifier.weight(1f))
                AttendanceCounter("غائب", absent, LdaPalette.Error, LdaPalette.ErrorContainer, Modifier.weight(1f))
            }
            AttendanceBar(
                fraction = if (total > 0) present.toFloat() / total.toFloat() else 0f,
                fill = LdaPalette.Success,
                track = if (absent > 0) LdaPalette.ErrorContainer else Color.White
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = onAllPresent,
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = LdaPalette.Success, contentColor = Color.White)
                ) {
                    Icon(Icons.Filled.HowToReg, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("الكل حاضر", maxLines = 1)
                }
                OutlinedButton(
                    onClick = onAllAbsent,
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = LdaPalette.Error),
                    border = BorderStroke(1.dp, LdaPalette.Error.copy(alpha = 0.5f))
                ) {
                    Icon(Icons.Filled.PersonOff, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("الكل غائب", maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun AttendanceStudentRow(student: Student, present: Boolean, onToggle: () -> Unit, onProfile: () -> Unit) {
    val accent = if (present) LdaPalette.Success else LdaPalette.Error
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = if (present) Color.White else LdaPalette.ErrorContainer.copy(alpha = 0.55f)),
        border = BorderStroke(1.dp, accent.copy(alpha = if (present) 0.18f else 0.35f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.border(2.dp, accent, CircleShape).padding(3.dp)) {
                StudentAvatar(student.photoUri, 48.dp, student.id, student.gender)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f).clickable(onClick = onProfile), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(student.fullName, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("العمر: ${attendanceStudentAgeLabel(student.birthDate)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(8.dp))
            AttendanceStatusPill(present, onToggle)
        }
    }
}

/** زر واحد يبدّل الحالة بلمسة: أخضر "حاضر" ↔ أحمر "غائب". */
@Composable
private fun AttendanceStatusPill(present: Boolean, onToggle: () -> Unit) {
    val tint = if (present) LdaPalette.Success else LdaPalette.Error
    val bg = if (present) LdaPalette.SuccessContainer else LdaPalette.ErrorContainer
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(bg).clickable(onClick = onToggle).heightIn(min = 44.dp).padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(if (present) Icons.Filled.CheckCircle else Icons.Filled.Cancel, contentDescription = if (present) "حاضر، اضغط للتغيير إلى غائب" else "غائب، اضغط للتغيير إلى حاضر", tint = tint, modifier = Modifier.size(20.dp))
        Text(if (present) "حاضر" else "غائب", color = tint, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun AttendanceSaveBar(present: Int, absent: Int, message: String, onSave: () -> Unit) {
    Surface(shadowElevation = 14.dp, color = Color.White, shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("$present حاضر • $absent غائب", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (message.isNotBlank()) {
                    Text(message, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = if (message.startsWith("تم")) LdaPalette.Success else LdaPalette.Error)
                }
            }
            Button(
                onClick = onSave,
                modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = LdaPalette.Royal, contentColor = Color.White)
            ) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("حفظ كشف اليوم")
            }
        }
    }
}

private fun openAbsenceMotherCall(context: android.content.Context, student: Student?) {
    if (student == null) return
    val raw = student.motherWhatsapp.trim()
    val digits = raw.filter { it.isDigit() }
    val phone = when {
        raw.startsWith("+") -> digits
        digits.startsWith("00") -> digits.drop(2)
        digits.startsWith("0") -> "20${digits.drop(1)}"
        digits.startsWith("20") -> digits
        else -> digits
    }
    if (phone.length < 10) {
        Toast.makeText(context, "رقم الأم غير مسجل أو غير صحيح", Toast.LENGTH_LONG).show()
        return
    }
    try {
        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")))
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(context, "تعذر فتح تطبيق الاتصال", Toast.LENGTH_LONG).show()
    }
}

private fun openAbsenceWhatsApp(context: android.content.Context, student: Student?, dates: List<String>) {
    if (student == null) return
    val raw = student.motherWhatsapp.trim()
    val digits = raw.filter { it.isDigit() }
    val phone = when { raw.startsWith("+") -> digits; digits.startsWith("00") -> digits.drop(2); digits.startsWith("0") -> "20${digits.drop(1)}"; digits.startsWith("20") -> digits; else -> digits }
    if (phone.length < 10) { Toast.makeText(context, "رقم واتساب الأم غير مسجل أو غير صحيح", Toast.LENGTH_LONG).show(); return }
    val message = "أهلًا بحضرتك 🌷\nبنطمن على ${student.fullName}، لاحظنا غيابه عن الحضانة خلال الأيام: ${dates.joinToString("، ")}، ونتمنى يكون بخير. يا ريت تطمنينا عليه.\n${AcademyProfileStore.getName(context)}"
    val uri = Uri.parse("https://wa.me/$phone?text=${URLEncoder.encode(message, "UTF-8")}")
    for (pkg in listOf("com.whatsapp.w4b", "com.whatsapp")) try { context.startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg)); return } catch (_: ActivityNotFoundException) { }
    try { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: ActivityNotFoundException) { Toast.makeText(context, "واتساب غير مثبت على الجهاز", Toast.LENGTH_LONG).show() }
}


private fun String.normalizedClassName(): String = trim().replace(Regex("\\s+"), " ").lowercase()

private fun attendanceStudentAgeLabel(birthDate: Long?): String {
    if (birthDate == null) return "غير مسجل"
    val birth = Instant.ofEpochMilli(birthDate).atZone(ZoneId.systemDefault()).toLocalDate()
    val age = Period.between(birth, LocalDate.now())
    return "${age.years} سنة و${age.months} شهر"
}
