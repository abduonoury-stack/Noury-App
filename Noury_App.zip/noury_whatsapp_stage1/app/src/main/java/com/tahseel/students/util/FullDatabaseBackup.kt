package com.tahseel.students.util

import android.content.ContentValues
import android.database.Cursor
import android.util.Base64
import androidx.sqlite.db.SupportSQLiteDatabase
import com.tahseel.students.data.StudentGender
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** نسخة كاملة من جداول Room مع الاحتفاظ بالمعرّفات والعلاقات بين السجلات. */
object FullDatabaseBackup {
    const val APP = "tahseel-students"
    const val VERSION = 14
    // ترتيب الإدخال يحترم المفاتيح الأجنبية؛ الحذف يتم بالعكس.
    private val legacyTablesV3 = listOf("students", "payments", "fee_plans", "student_fees", "receipts", "refund_credits", "subscription_payments", "refund_transactions", "audit_logs", "app_settings", "classrooms", "attendance", "expenses")
    private val legacyTablesV4 = legacyTablesV3 + listOf("employees", "employee_attendance", "employee_leaves", "employee_payroll", "employee_loans", "employee_adjustments")
    // الإصدار 5: تسويات انسحاب الطلاب وسجل أحداثها. تأتي بعد students لأنها تشير إليه بمفتاح أجنبي.
    private val exitTables = listOf("student_exit_settlements", "student_exit_settlement_events")
    private val legacyV5Tables = legacyTablesV4 + exitTables
    private val periodTables = listOf("attendance_periods", "period_price_history")
    private val legacyV6Tables = legacyV5Tables + periodTables
    private val legacyV7Tables = legacyV6Tables + "employee_payroll_payments"
    private val legacyV8Tables = legacyV7Tables + listOf("cash_opening_balance", "cash_counts")
    private val legacyV9Tables = legacyV8Tables
    private val legacyV10Tables = legacyV9Tables + "expense_payments"
    private val legacyV11Tables = legacyV10Tables + listOf("cash_accounts", "cash_transfers")
    private val v12Tables = legacyV11Tables + listOf("employee_payroll_reversals", "employee_payroll_recovery_transactions")
    private val v13Tables = v12Tables + listOf("accounting_accounts", "accounting_periods", "journal_entries", "journal_lines", "accounting_vendors", "accounting_expenses", "accounting_expense_payments", "accounting_source_posts")
    // الإصدار 14: أقفال أشهر المصروفات (expense_month_locks) كانت خارج النسخة الاحتياطية.
    val tables = v13Tables + "expense_month_locks"
    private val legacyV2Tables = legacyTablesV3.take(10)

    fun export(db: SupportSQLiteDatabase, exportedAt: Long, receiptProfile: JSONObject = JSONObject(), photoDir: File? = null): String {
        // نفّذ checkpoint قبل المعاملة، ثم اقرأ كل الجداول داخل معاملة واحدة
        // حتى تمثل النسخة لحظة بيانات واحدة ولا تختلط بتعديلات متزامنة.
        db.query("PRAGMA wal_checkpoint(FULL)").use { }
        db.beginTransaction()
        try {
            val root = JSONObject().put("app", APP).put("version", VERSION).put("exportedAt", exportedAt).put("receiptProfile", JSONObject(receiptProfile.toString()))
            val all = JSONObject()
            var totalRows = 0
            tables.forEach { table ->
                val rows = JSONArray()
                db.query("SELECT * FROM `$table` ORDER BY 1").use { c ->
                    while (c.moveToNext()) {
                        val row = JSONObject()
                        for (i in 0 until c.columnCount) {
                            val key = c.getColumnName(i)
                            when (c.getType(i)) {
                                Cursor.FIELD_TYPE_NULL -> row.put(key, JSONObject.NULL)
                                Cursor.FIELD_TYPE_INTEGER -> row.put(key, c.getLong(i))
                                Cursor.FIELD_TYPE_FLOAT -> row.put(key, c.getDouble(i))
                                Cursor.FIELD_TYPE_BLOB -> row.put(key, JSONObject().put("__blob", Base64.encodeToString(c.getBlob(i), Base64.NO_WRAP)))
                                else -> row.put(key, c.getString(i))
                            }
                        }
                        rows.put(row); totalRows++
                    }
                }
                all.put(table, rows)
            }
            root.put("tables", all).put("rowCount", totalRows)
            // الصور ملفات خارج Room: تُضمَّن بترميز Base64 عند توفير مجلد الصور (النسخة اليدوية فقط).
            if (photoDir != null) embedPhotos(db, root, photoDir)
            val canonical = canonicalJson(root)
            root.put("checksum", sha256(canonical))
            db.setTransactionSuccessful()
            return root.toString(2)
        } finally {
            db.endTransaction()
        }
    }

    /** حدّ إجمالي حجم الصور الخام داخل نسخة واحدة؛ ما زاد يُتخطى ويُعلن في photosSkipped. */
    const val MAX_PHOTO_BYTES = 12L * 1024 * 1024

    private fun photoFile(uri: String, photoDir: File): File? = runCatching {
        val f = File(java.net.URI(uri).path)
        // لا نقرأ إلا ملفات داخل مجلد صور الطلاب، حتى لا تُصدَّر ملفات عشوائية من الجهاز.
        if (f.isFile && f.canonicalFile.parentFile == photoDir.canonicalFile) f else null
    }.getOrNull()

    private fun embedPhotos(db: SupportSQLiteDatabase, root: JSONObject, photoDir: File) {
        val photos = JSONObject(); var total = 0L; var skipped = 0
        val uris = mutableListOf<String>()
        db.query("SELECT DISTINCT photoUri FROM students WHERE photoUri IS NOT NULL AND photoUri != ''").use { c ->
            while (c.moveToNext()) uris += c.getString(0)
        }
        for (uri in uris) {
            val f = photoFile(uri, photoDir)
            if (f == null) { skipped++; continue }          // ملف غير موجود أو خارج مجلد الصور
            if (photos.has(f.name)) continue                // الصورة نفسها مضمّنة سابقًا
            if (total + f.length() > MAX_PHOTO_BYTES) { skipped++; continue }
            val bytes = f.readBytes(); total += bytes.size
            photos.put(f.name, Base64.encodeToString(bytes, Base64.NO_WRAP))
        }
        root.put("photos", photos).put("photosSkipped", skipped)
    }

    fun photoCount(json: String): Int = JSONObject(json).optJSONObject("photos")?.length() ?: 0
    fun photosSkipped(json: String): Int = JSONObject(json).optInt("photosSkipped", 0)

    /** يكتب الصور في مجلد التطبيق باسم يعتمد على محتواها (لا يُستبدل ولا يُحذف أي ملف موجود). */
    private fun materializePhotos(root: JSONObject, photoDir: File, created: MutableList<File>): Map<String, String> {
        val photos = root.optJSONObject("photos") ?: return emptyMap()
        photoDir.mkdirs()
        val mapping = mutableMapOf<String, String>()
        val names = photos.keys()
        while (names.hasNext()) {
            val original = names.next()
            val bytes = Base64.decode(photos.getString(original), Base64.DEFAULT)
            val file = File(photoDir, "bk_${sha256Bytes(bytes).take(16)}.jpg")
            if (!file.exists() || file.length() != bytes.size.toLong()) {
                val tmp = File(photoDir, file.name + ".tmp")
                created += tmp                                   // يُحذف عند الفشل؛ إن تمت إعادة التسمية يصبح غير موجود
                tmp.writeBytes(bytes)
                created += file
                check(tmp.renameTo(file) || file.exists()) { "تعذر حفظ صورة مستعادة" }
            }
            mapping[original] = android.net.Uri.fromFile(file).toString()
        }
        return mapping
    }

    fun validate(json: String): String {
        val root = JSONObject(json.removePrefix("\uFEFF"))
        require(root.optString("app") == APP) { "هذا الملف ليس نسخة احتياطية لتطبيق تحصيل الطلاب" }
        val backupVersion = root.optInt("version")
        require(backupVersion in 2..VERSION) { "إصدار النسخة غير مدعوم" }
        val tablesObject = root.getJSONObject("tables")
        val requiredTables = when (backupVersion) { 2 -> legacyV2Tables; 3 -> legacyTablesV3; 4 -> legacyTablesV4; 5 -> legacyV5Tables; 6 -> legacyV6Tables; 7 -> legacyV7Tables; 8 -> legacyV7Tables; 9 -> legacyV9Tables; 10 -> legacyV10Tables; 11 -> legacyV11Tables; 12 -> v12Tables; 13 -> v13Tables; else -> tables }
        requiredTables.forEach { require(tablesObject.has(it) && tablesObject.get(it) is JSONArray) { "النسخة غير مكتملة: جدول $it غير موجود" } }
        if (backupVersion >= 11) {
            val accounts = tablesObject.getJSONArray("cash_accounts")
            val accountIds = mutableSetOf<String>()
            var hasCash = false
            for (i in 0 until accounts.length()) {
                val account = accounts.getJSONObject(i)
                val id = account.getString("id")
                require(accountIds.add(id)) { "دليل الحسابات يحتوي على معرّف مكرر: $id" }
                if (id == "cash" && account.optString("type") == "cash") hasCash = true
            }
            require(hasCash) { "النسخة لا تحتوي على حساب الخزينة النقدية الأساسي" }
            val transfers = tablesObject.getJSONArray("cash_transfers")
            for (i in 0 until transfers.length()) {
                val transfer = transfers.getJSONObject(i)
                val from = transfer.getString("fromAccountId")
                val to = transfer.getString("toAccountId")
                require(from != to && from in accountIds && to in accountIds && transfer.getLong("amountPiasters") > 0L) {
                    "بيانات تحويل غير صالحة بين الحسابات في السجل رقم ${i + 1}"
                }
            }
        }
        // ملفات الإصدار 2 لم تكن تحتوي على الفصول والحضور والمصروفات؛ لا نلمس هذه الجداول عند استعادتها.
        val expected = root.getString("checksum")
        root.remove("checksum")
        // Compatibility: older exports hashed JSONObject insertion-order JSON, while
        // newer exports hash canonical (sorted-key) JSON. Accept either verified SHA-256
        // representation so valid backups from both generations can be restored.
        val canonicalChecksum = sha256(canonicalJson(root))
        val legacyChecksum = sha256(root.toString())
        require(canonicalChecksum == expected || legacyChecksum == expected) {
            "فشل فحص سلامة النسخة؛ قد يكون الملف تالفًا أو معدلًا"
        }
        // تحقق إضافي من عدد السجلات المعلن، حتى لا تمر نسخة مبتورة منطقيًا رغم سلامة JSON.
        if (root.has("rowCount")) {
            var actualRows = 0
            requiredTables.forEach { actualRows += tablesObject.getJSONArray(it).length() }
            require(root.getInt("rowCount") == actualRows) { "عدد السجلات داخل النسخة لا يطابق بيانات الجداول" }
        }
        root.put("checksum", expected)
        return root.toString()
    }

    fun restore(db: SupportSQLiteDatabase, validatedJson: String, photoDir: File? = null) =
        SyncRestoreGuard.exclusive {
            // ملفات الصور التي أنشأتها هذه الاستعادة فقط؛ تُزال إن فشلت الاستعادة حتى لا تبقى ملفات يتيمة.
            // لا يُحذف أي ملف كان موجودًا قبل الاستعادة.
            val created = mutableListOf<File>()
            val preexisting = photoDir?.listFiles()?.map { it.absolutePath }?.toSet().orEmpty()
            try {
                restoreLocked(db, validatedJson, photoDir, created)
            } catch (e: Throwable) {
                created.filter { it.absolutePath !in preexisting }.forEach { runCatching { it.delete() } }
                throw e
            }
        }

    /** عدد الطلاب الذين يشير سجلهم إلى ملف صورة محلي غير موجود على هذا الجهاز (لا يُعدَّل أي سجل). */
    fun missingPhotoCount(db: SupportSQLiteDatabase): Int {
        var missing = 0
        db.query("SELECT photoUri FROM students WHERE photoUri IS NOT NULL AND photoUri != ''").use { c ->
            while (c.moveToNext()) {
                val path = runCatching { java.net.URI(c.getString(0)).takeIf { it.scheme == "file" }?.path }.getOrNull()
                if (path != null && !File(path).isFile) missing++
            }
        }
        return missing
    }

    private fun restoreLocked(db: SupportSQLiteDatabase, validatedJson: String, photoDir: File?, created: MutableList<File>) {
        val root = JSONObject(validatedJson)
        val data = root.getJSONObject("tables")
        val photoMap = if (photoDir != null) materializePhotos(root, photoDir, created) else emptyMap()
        db.beginTransaction()
        try {
            // الاستعادة ليست تعديلًا يوميًا: لا تُسجَّل آلاف أحداث حذف/إضافة في outbox لتُرسل للسحابة.
            // يُعاد المفتاح إلى 0 قبل الإتمام؛ وعند أي فشل تتراجع المعاملة كاملة بما فيها هذا المفتاح.
            val hasSyncMeta = db.query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='noury_sync_meta'").use { it.moveToFirst() }
            if (hasSyncMeta) db.execSQL("UPDATE noury_sync_meta SET suppress_capture=1 WHERE id=1")
            // نسخة قديمة بلا جداول التسوية: لا نحذف تسويات موجودة ولا نتركها تتعارض مع حذف الطلاب.
            if (exitTables.any { !data.has(it) }) {
                exitTables.forEach { t ->
                    db.query("SELECT COUNT(*) FROM `$t`").use { c ->
                        check(!(c.moveToFirst() && c.getLong(0) > 0)) {
                            "هذه النسخة قديمة ولا تحتوي على تسويات انسحاب الطلاب، بينما توجد تسويات محفوظة حاليًا. لم تتم الاستعادة حفاظًا على التسويات؛ استعد من نسخة أحدث."
                        }
                    }
                }
            }
            if (!data.has("employee_payroll_payments")) {
                db.query("SELECT COUNT(*) FROM employee_payroll_payments").use { c ->
                    check(!(c.moveToFirst() && c.getLong(0) > 0)) {
                        "هذه النسخة لا تحتوي على سجل دفعات المرتبات، بينما توجد دفعات محفوظة حاليًا. لم تتم الاستعادة حفاظًا على سجل الصرف؛ استخدم نسخة أحدث."
                    }
                }
            }
            if (!data.has("cash_opening_balance") || !data.has("cash_counts")) {
                listOf("cash_opening_balance", "cash_counts").forEach { table ->
                    db.query("SELECT COUNT(*) FROM `$table`").use { c ->
                        check(!(c.moveToFirst() && c.getLong(0) > 0)) {
                            "هذه النسخة لا تحتوي على بيانات ضبط الخزينة ($table)، بينما توجد بيانات محفوظة حاليًا. لم تتم الاستعادة حتى لا يختل رصيد الخزينة أو سجل الجرد؛ استخدم نسخة أحدث."
                        }
                    }
                }
            }
            if (!data.has("expense_payments")) {
                db.query("SELECT COUNT(*) FROM expense_payments").use { c ->
                    check(!(c.moveToFirst() && c.getLong(0) > 0)) {
                        "هذه النسخة لا تحتوي على سجل دفعات المصروفات التفصيلي، بينما توجد دفعات محفوظة حاليًا. لم تتم الاستعادة حفاظًا على سجل الصرف؛ استخدم نسخة أحدث."
                    }
                }
            }
            if (!data.has("cash_transfers")) {
                db.query("SELECT COUNT(*) FROM cash_transfers").use { c ->
                    check(!(c.moveToFirst() && c.getLong(0) > 0)) {
                        "هذه النسخة لا تحتوي على سجل التحويلات بين الحسابات، بينما توجد تحويلات محفوظة حاليًا. لم تتم الاستعادة حفاظًا على أرصدة الحسابات."
                    }
                }
            }
            if (!data.has("cash_accounts")) {
                db.query("SELECT COUNT(*) FROM cash_accounts WHERE id!='cash'").use { c ->
                    check(!(c.moveToFirst() && c.getLong(0) > 0)) {
                        "هذه النسخة لا تحتوي على دليل الحسابات النقدية، بينما توجد حسابات إضافية محفوظة حاليًا. لم تتم الاستعادة حفاظًا على تصنيف الحركات؛ استخدم نسخة أحدث."
                    }
                }
            }
            if (root.optInt("version") < 12) {
                db.query("SELECT COUNT(*) FROM refund_credits WHERE sourceType='manual_payment'").use { c ->
                    check(!(c.moveToFirst() && c.getLong(0) > 0)) {
                        "هذه النسخة أقدم من دورة الاسترداد اليدوي، بينما توجد طلبات استرداد يدوية محفوظة حاليًا. لم تتم الاستعادة حتى لا تُفقد هذه الأرصدة أو مستنداتها؛ استخدم نسخة Backup 12 أو أحدث."
                    }
                }
            }
            if (!data.has("journal_entries")) {
                listOf("journal_entries", "accounting_expenses", "accounting_vendors").forEach { table ->
                    db.query("SELECT COUNT(*) FROM `$table`").use { c ->
                        check(!(c.moveToFirst() && c.getLong(0) > 0)) {
                            "هذه النسخة أقدم من نظام المحاسبة الجديد، وتوجد قيود أو فواتير محاسبية على الجهاز. لم تتم الاستعادة حتى لا تُفقد البيانات المحاسبية الجديدة."
                        }
                    }
                }
            }
            if (!data.has("employee_payroll_reversals") || !data.has("employee_payroll_recovery_transactions")) {
                listOf("employee_payroll_reversals", "employee_payroll_recovery_transactions").forEach { table ->
                    db.query("SELECT COUNT(*) FROM `$table`").use { c ->
                        check(!(c.moveToFirst() && c.getLong(0) > 0)) {
                            "هذه النسخة لا تحتوي على سجل عكس المرتبات وتحصيل المديونيات ($table)، بينما توجد حركات محفوظة حاليًا. لم تتم الاستعادة حفاظًا على السجل المالي؛ استخدم نسخة أحدث."
                        }
                    }
                }
            }
            val includedTables = tables.filter { data.has(it) }
            includedTables.asReversed().forEach { db.delete(it, null, null) }
            includedTables.forEach { table ->
                val rows = data.getJSONArray(table)
                for (i in 0 until rows.length()) {
                    val obj = rows.getJSONObject(i)
                    val values = ContentValues()
                    val keys = obj.keys()
                    while (keys.hasNext()) {
                        val key = keys.next(); val value = obj.get(key)
                        when {
                            table == "students" && key == "photoUri" && value is String && photoMap.isNotEmpty() ->
                                values.put(key, photoMap[runCatching { java.net.URI(value).path.substringAfterLast('/') }.getOrDefault("")] ?: value)
                            table == "students" && key == "gender" ->
                                values.put(key, StudentGender.normalize(if (value == JSONObject.NULL) null else value.toString()))
                            value == JSONObject.NULL -> values.putNull(key)
                            value is JSONObject && value.has("__blob") -> values.put(key, Base64.decode(value.getString("__blob"), Base64.DEFAULT))
                            value is Boolean -> values.put(key, if (value) 1 else 0)
                            value is Int -> values.put(key, value)
                            value is Long -> values.put(key, value)
                            value is Double -> values.put(key, value)
                            else -> values.put(key, value.toString())
                        }
                    }
                    // Backups created before Room 26 may omit gender entirely.
                    // Supplying a safe default also covers schemas without a SQL DEFAULT.
                    if (table == "students" && !obj.has("gender")) values.put("gender", "boy")
                    check(db.insert(table, android.database.sqlite.SQLiteDatabase.CONFLICT_ABORT, values) >= 0) { "تعذر استعادة سجل من جدول $table" }
                }
            }
            // النسخ حتى الإصدار 11 لم تكن تحتوي على أرصدة موحدة لتسويات الانسحاب.
            // أنشئها بعد استعادة السجلات القديمة، واربط أحداث الصرف السابقة بها مرة واحدة.
            if (root.optInt("version") < 12) backfillExitSettlementCredits(db)
            if (hasSyncMeta) db.execSQL("UPDATE noury_sync_meta SET suppress_capture=0 WHERE id=1")
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    private fun backfillExitSettlementCredits(db: SupportSQLiteDatabase) {
        db.execSQL("""INSERT OR IGNORE INTO refund_credits (studentId,paymentId,originalAmountPiasters,remainingAmountPiasters,createdAt,note,sourceType,sourceId,approvalStatus,reason,documentReference,approvedAt)
            SELECT s.studentId,NULL,s.refundAmountPiasters,
                CASE WHEN s.settlementStatus='active' THEN MAX(0,s.refundAmountPiasters-COALESCE(SUM(CASE WHEN e.eventType='refund_paid' THEN e.amountPiasters ELSE 0 END),0)) ELSE 0 END,
                s.createdAt,'ترحيل رصيد من تسوية انسحاب #' || s.id,'exit_settlement',s.id,
                CASE WHEN s.settlementStatus='active' THEN 'approved' ELSE 'cancelled' END,
                'رصيد مرحّل من تسوية انسحاب محفوظة','تسوية انسحاب #' || s.id,s.createdAt
            FROM student_exit_settlements s
            LEFT JOIN student_exit_settlement_events e ON e.settlementId=s.id
            WHERE s.refundAmountPiasters>0
            GROUP BY s.id""")
        db.execSQL("""INSERT INTO refund_transactions (refundCreditId,amountPiasters,refundedAt,method,note,accountId)
            SELECT c.id,e.amountPiasters,e.createdAt,'exit_settlement',e.details || ' [exit_event=' || e.id || ']',e.accountId
            FROM student_exit_settlement_events e
            INNER JOIN refund_credits c ON c.sourceType='exit_settlement' AND c.sourceId=e.settlementId
            WHERE e.eventType='refund_paid' AND e.amountPiasters>0
              AND NOT EXISTS (SELECT 1 FROM refund_transactions rt WHERE rt.refundCreditId=c.id AND rt.refundedAt=e.createdAt AND rt.amountPiasters=e.amountPiasters AND rt.note=e.details || ' [exit_event=' || e.id || ']')""")
    }

    /** يعدّ فقط الجداول الموجودة في [reference]؛ لمقارنة الاستعادة من نسخة أقدم لا تحتوي كل الجداول الحالية. */
    fun rowCountMatching(json: String, reference: String): Int {
        val t = JSONObject(json).getJSONObject("tables"); val r = JSONObject(reference).getJSONObject("tables")
        return tables.sumOf { if (t.has(it) && r.has(it)) t.getJSONArray(it).length() else 0 }
    }

    fun rowCount(json: String): Int {
        val t = JSONObject(json).getJSONObject("tables")
        return tables.sumOf { if (t.has(it)) t.getJSONArray(it).length() else 0 }
    }
    /** Stable JSON representation: PostgreSQL JSONB does not preserve object-key order. */
    private fun canonicalJson(value: Any?): String = when (value) {
        null, JSONObject.NULL -> "null"
        is JSONObject -> {
            val keys = value.keys().asSequence().toList().sorted()
            keys.joinToString(prefix = "{", postfix = "}") { key ->
                JSONObject.quote(key) + ":" + canonicalJson(value.get(key))
            }
        }
        is JSONArray -> (0 until value.length()).joinToString(prefix = "[", postfix = "]") {
            canonicalJson(value.get(it))
        }
        is String -> JSONObject.quote(value)
        is Number, is Boolean -> value.toString()
        else -> JSONObject.quote(value.toString())
    }

    private fun sha256Bytes(bytes: ByteArray): String = java.security.MessageDigest.getInstance("SHA-256")
        .digest(bytes).joinToString("") { "%02x".format(it) }

    private fun sha256(value: String): String = java.security.MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}
