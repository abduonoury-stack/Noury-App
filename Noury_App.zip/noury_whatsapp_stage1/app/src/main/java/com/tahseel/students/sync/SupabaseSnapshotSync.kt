package com.tahseel.students.sync

import android.content.Context
import androidx.sqlite.db.SupportSQLiteDatabase
import com.tahseel.students.BuildConfig
import com.tahseel.students.util.FullDatabaseBackup
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.UUID
import java.util.concurrent.TimeUnit

/** Stage 9: creates an immutable cloud snapshot; it never overwrites local data. */
class SupabaseSnapshotSync(context: Context, private val auth: SupabaseAuth) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("noury_sync_device", Context.MODE_PRIVATE)
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(90, TimeUnit.SECONDS)
        .build()

    fun deviceId(): String = prefs.getString("device_id", null) ?: UUID.randomUUID().toString().also {
        prefs.edit().putString("device_id", it).apply()
    }

    data class UploadResult(val snapshotId: String, val rowCount: Int, val checksum: String)

    suspend fun uploadPrimarySnapshot(db: SupportSQLiteDatabase, receiptProfile: JSONObject = JSONObject()): UploadResult = withContext(Dispatchers.IO) {
        val userId = auth.currentUserId() ?: throw IOException("سجّل الدخول إلى حساب المزامنة أولًا")
        val organizationId = auth.currentOrganizationId() ?: throw IOException("ملف المؤسسة غير متاح؛ سجّل الدخول مرة أخرى")
        val accessToken = auth.accessToken() ?: throw IOException("جلسة الدخول غير متاحة؛ سجّل الدخول مرة أخرى")
        // FullDatabaseBackup reads every application table in one consistent SQLite transaction.
        val backupText = FullDatabaseBackup.export(db, System.currentTimeMillis(), receiptProfile)
        val backup = FullDatabaseBackup.validate(backupText)
        val payload = JSONObject(backup)
        val body = JSONObject()
            .put("owner_id", userId)
            .put("organization_id", organizationId)
            .put("device_id", deviceId())
            .put("app_version", "${BuildConfig.VERSION_NAME}")
            .put("backup_version", payload.getInt("version"))
            .put("row_count", payload.getInt("rowCount"))
            .put("checksum", payload.getString("checksum"))
            .put("payload", payload)
        val request = Request.Builder()
            .url("${BuildConfig.SUPABASE_URL}/rest/v1/noury_sync_snapshots")
            .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Authorization", "Bearer $accessToken")
            .header("Content-Type", "application/json")
            .header("Prefer", "return=representation")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            val responseText = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail = runCatching { JSONObject(responseText).optString("message") }.getOrNull()
                throw IOException(detail?.takeIf { it.isNotBlank() } ?: "فشل رفع النسخة إلى Supabase (HTTP ${response.code}). تأكد من تنفيذ ملف SQL الخاص بالمرحلة التاسعة.")
            }
            val first = org.json.JSONArray(responseText).optJSONObject(0)
                ?: throw IOException("تم إرسال النسخة لكن لم يصل تأكيد الحفظ من Supabase")
            UploadResult(first.optString("id"), payload.getInt("rowCount"), payload.getString("checksum"))
        }
    }

    data class DownloadResult(val snapshotId: String, val rowCount: Int, val checksum: String, val payload: String)

    /** Downloads the newest immutable snapshot shared by the signed-in user's organization. */
    suspend fun downloadLatestSnapshot(): DownloadResult = withContext(Dispatchers.IO) {
        val organizationId = auth.currentOrganizationId() ?: throw IOException("ملف المؤسسة غير متاح؛ سجّل الدخول مرة أخرى")
        val accessToken = auth.accessToken() ?: throw IOException("جلسة الدخول غير متاحة؛ سجّل الدخول مرة أخرى")
        val request = Request.Builder()
            .url("${BuildConfig.SUPABASE_URL}/rest/v1/noury_sync_snapshots?select=id,row_count,checksum,payload,created_at&organization_id=eq.$organizationId&order=created_at.desc&limit=1")
            .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Authorization", "Bearer $accessToken")
            .header("Accept", "application/json")
            .get().build()
        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("تعذر قراءة النسخة السحابية (HTTP ${response.code}): ${text.take(300)}")
            val row = org.json.JSONArray(text).optJSONObject(0) ?: throw IOException("لا توجد نسخة سحابية لهذا الحساب")
            val payload = row.optJSONObject("payload") ?: throw IOException("النسخة السحابية لا تحتوي على بيانات")
            val payloadText = payload.toString()
            val checked = FullDatabaseBackup.validate(payloadText)
            val actualCount = FullDatabaseBackup.rowCount(checked)
            if (row.optInt("row_count", -1) != actualCount) throw IOException("عدد السجلات في النسخة لا يطابق بياناتها")
            if (row.optString("checksum") != payload.optString("checksum")) throw IOException("بصمة النسخة السحابية غير متطابقة")
            DownloadResult(row.getString("id"), actualCount, row.getString("checksum"), checked)
        }
    }

}
