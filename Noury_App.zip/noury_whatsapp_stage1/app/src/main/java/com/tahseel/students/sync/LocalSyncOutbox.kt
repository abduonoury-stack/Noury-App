package com.tahseel.students.sync

import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Durable local change journal for Noury automatic sync.
 * SQLite triggers capture inserts, updates and deletes for every Room application table.
 * Remote-apply code must set sync_meta.suppress_capture=1 inside the same transaction.
 */
object LocalSyncOutbox {
    private const val OUTBOX = "noury_sync_outbox"
    private const val META = "noury_sync_meta"
    private val excluded = setOf(
        OUTBOX, META, "noury_sync_conflicts", "android_metadata", "room_master_table", "sqlite_sequence"
    )

    fun install(db: SupportSQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS $META (
            id INTEGER PRIMARY KEY CHECK(id=1), suppress_capture INTEGER NOT NULL DEFAULT 0
        )""".trimIndent())
        db.execSQL("INSERT OR IGNORE INTO $META(id,suppress_capture) VALUES(1,0)")
        db.execSQL("""CREATE TABLE IF NOT EXISTS $OUTBOX (
            local_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
            event_id TEXT NOT NULL UNIQUE,
            entity_type TEXT NOT NULL,
            entity_key TEXT NOT NULL,
            operation TEXT NOT NULL CHECK(operation IN ('upsert','delete')),
            payload TEXT,
            created_at INTEGER NOT NULL,
            attempt_count INTEGER NOT NULL DEFAULT 0,
            last_error TEXT,
            synced INTEGER NOT NULL DEFAULT 0
        )""".trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS index_${OUTBOX}_pending ON $OUTBOX(synced,local_id)")

        val tables = mutableListOf<String>()
        db.query("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").use { c ->
            val nameIndex = c.getColumnIndex("name")
            while (c.moveToNext()) {
                val name = c.getString(nameIndex)
                if (name !in excluded && !name.startsWith("room_fts")) tables += name
            }
        }
        tables.forEach { table -> installTableTriggers(db, table) }
    }

    private fun installTableTriggers(db: SupportSQLiteDatabase, table: String) {
        val quotedTable = quote(table)
        val columns = mutableListOf<String>()
        val primaryKeys = mutableListOf<Pair<Int, String>>()
        db.query("PRAGMA table_info($quotedTable)").use { c ->
            val nameIndex = c.getColumnIndex("name")
            val pkIndex = c.getColumnIndex("pk")
            while (c.moveToNext()) {
                val name = c.getString(nameIndex)
                columns += name
                val pkOrder = c.getInt(pkIndex)
                if (pkOrder > 0) primaryKeys += pkOrder to name
            }
        }
        if (columns.isEmpty() || primaryKeys.isEmpty()) return
        val keyColumns = primaryKeys.sortedBy { it.first }.map { it.second }
        val newPayload = jsonObject(columns, "NEW")
        val oldKey = jsonObject(keyColumns, "OLD")
        val newKey = jsonObject(keyColumns, "NEW")
        val safe = table.replace(Regex("[^A-Za-z0-9_]"), "_")
        val guard = "(SELECT suppress_capture FROM $META WHERE id=1)=0"

        db.execSQL("DROP TRIGGER IF EXISTS trg_noury_${safe}_ins")
        db.execSQL("DROP TRIGGER IF EXISTS trg_noury_${safe}_upd")
        db.execSQL("DROP TRIGGER IF EXISTS trg_noury_${safe}_del")
        db.execSQL("""CREATE TRIGGER trg_noury_${safe}_ins AFTER INSERT ON $quotedTable
            WHEN $guard BEGIN
              INSERT INTO $OUTBOX(event_id,entity_type,entity_key,operation,payload,created_at)
              VALUES(lower(hex(randomblob(4))||'-'||hex(randomblob(2))||'-4'||substr(hex(randomblob(2)),2)||'-a'||substr(hex(randomblob(2)),2)||'-'||hex(randomblob(6))),
              '${sqlLiteral(table)}',$newKey,'upsert',$newPayload,CAST(strftime('%s','now') AS INTEGER)*1000);
            END""".trimIndent())
        db.execSQL("""CREATE TRIGGER trg_noury_${safe}_upd AFTER UPDATE ON $quotedTable
            WHEN $guard BEGIN
              INSERT INTO $OUTBOX(event_id,entity_type,entity_key,operation,payload,created_at)
              VALUES(lower(hex(randomblob(4))||'-'||hex(randomblob(2))||'-4'||substr(hex(randomblob(2)),2)||'-a'||substr(hex(randomblob(2)),2)||'-'||hex(randomblob(6))),
              '${sqlLiteral(table)}',$newKey,'upsert',$newPayload,CAST(strftime('%s','now') AS INTEGER)*1000);
            END""".trimIndent())
        db.execSQL("""CREATE TRIGGER trg_noury_${safe}_del AFTER DELETE ON $quotedTable
            WHEN $guard BEGIN
              INSERT INTO $OUTBOX(event_id,entity_type,entity_key,operation,payload,created_at)
              VALUES(lower(hex(randomblob(4))||'-'||hex(randomblob(2))||'-4'||substr(hex(randomblob(2)),2)||'-a'||substr(hex(randomblob(2)),2)||'-'||hex(randomblob(6))),
              '${sqlLiteral(table)}',$oldKey,'delete',NULL,CAST(strftime('%s','now') AS INTEGER)*1000);
            END""".trimIndent())
    }

    private fun jsonObject(columns: List<String>, row: String): String =
        "json_object(" + columns.joinToString(",") { "'${sqlLiteral(it)}',$row.${quote(it)}" } + ")"

    private fun quote(identifier: String) = "\"${identifier.replace("\"", "\"\"")}\""
    private fun sqlLiteral(value: String) = value.replace("'", "''")
}
