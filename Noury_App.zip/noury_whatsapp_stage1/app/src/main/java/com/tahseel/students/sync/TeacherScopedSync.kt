package com.tahseel.students.sync

import com.tahseel.students.BuildConfig
import com.tahseel.students.data.TeacherAttendanceOutbox
import com.tahseel.students.data.TeacherAttendanceOutboxDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.UUID
import java.util.concurrent.TimeUnit

/** Network boundary for teacher-scoped data only. Never reads or writes full snapshots/sync_records. */
class TeacherScopedSync(
    private val auth: SupabaseAuth,
    private val outbox: TeacherAttendanceOutboxDao
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    data class Teacher(val userId: String, val displayName: String, val phone: String)
    data class AssignedClass(val classroomId: String, val classroomName: String)
    data class StudentCard(val studentId: String, val classroomId: String, val displayName: String, val photoPath: String?)

    private fun token(): String = auth.accessToken()?.takeIf { it.isNotBlank() }
        ?: throw IOException("جلسة الدخول غير متاحة؛ سجّل الدخول مرة أخرى")

    private fun request(path: String, method: String = "GET", body: String? = null, prefer: String? = null): String {
        val builder = Request.Builder()
            .url("${BuildConfig.SUPABASE_URL}$path")
            .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Authorization", "Bearer ${token()}")
            .header("Accept", "application/json")
        if (body != null) builder.header("Content-Type", "application/json")
        if (prefer != null) builder.header("Prefer", prefer)
        when (method) {
            "POST" -> builder.post((body ?: "{}").toRequestBody("application/json".toMediaType()))
            "PATCH" -> builder.patch((body ?: "{}").toRequestBody("application/json".toMediaType()))
            else -> builder.get()
        }
        client.newCall(builder.build()).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val message = runCatching { JSONObject(text).optString("message") }.getOrNull()
                throw IOException(message?.takeIf { it.isNotBlank() } ?: "فشل الاتصال بالخادم (HTTP ${response.code}): ${text.take(240)}")
            }
            return text
        }
    }

    suspend fun loadActiveTeachers(): List<Teacher> = withContext(Dispatchers.IO) {
        requireOwner()
        val rows = JSONArray(request("/rest/v1/noury_user_profiles?select=user_id,display_name,phone&role=eq.teacher&is_active=eq.true&organization_id=eq.${orgId()}&order=display_name.asc"))
        (0 until rows.length()).map { i -> rows.getJSONObject(i).let { Teacher(it.getString("user_id"), it.optString("display_name"), it.optString("phone")) } }
    }

    suspend fun loadTeacherAssignments(): List<AssignedClass> = withContext(Dispatchers.IO) {
        requireTeacher()
        val rows = JSONArray(request("/rest/v1/noury_teacher_class_assignments?select=classroom_id,classroom_name&teacher_user_id=eq.${userId()}&organization_id=eq.${orgId()}&is_active=eq.true&order=classroom_name.asc"))
        (0 until rows.length()).map { i -> rows.getJSONObject(i).let { AssignedClass(it.getString("classroom_id"), it.getString("classroom_name")) } }
    }

    suspend fun loadStudents(classroomId: String): List<StudentCard> = withContext(Dispatchers.IO) {
        requireTeacher()
        val rows = JSONArray(request("/rest/v1/noury_teacher_student_cards?select=classroom_id,student_id,display_name,photo_object_path&classroom_id=eq.$classroomId&organization_id=eq.${orgId()}&is_active=eq.true&order=display_name.asc"))
        (0 until rows.length()).map { i -> rows.getJSONObject(i).let {
            StudentCard(it.getString("student_id"), it.getString("classroom_id"), it.getString("display_name"), it.optString("photo_object_path").takeIf(String::isNotBlank))
        } }
    }

    /** Publishes only the teacher-safe allow-list. Photo paths stay null until the owner-side upload flow is completed. */
    suspend fun publishRoster(classroomId: String, classroomName: String, students: List<Pair<String, String>>) = withContext(Dispatchers.IO) {
        requireOwner()
        val cards = JSONArray()
        students.forEach { (studentCloudId, displayName) ->
            cards.put(JSONObject().put("student_id", studentCloudId).put("display_name", displayName).put("photo_object_path", JSONObject.NULL))
        }
        val payload = JSONObject().put("p_classroom_id", classroomId)
            .put("p_classroom_name", classroomName).put("p_students", cards)
        request("/rest/v1/rpc/noury_owner_publish_teacher_roster", "POST", payload.toString())
    }

    suspend fun setTeacherClass(teacherId: String, classroomId: String, classroomName: String, active: Boolean = true) = withContext(Dispatchers.IO) {
        requireOwner()
        val payload = JSONObject().put("p_teacher_user_id", teacherId).put("p_classroom_id", classroomId)
            .put("p_classroom_name", classroomName).put("p_is_active", active)
        request("/rest/v1/rpc/noury_owner_set_teacher_class", "POST", payload.toString())
    }

    suspend fun queueAttendance(classroomId: String, studentId: String, date: String, status: String) {
        requireTeacher()
        require(status == "present" || status == "absent") { "حالة الحضور غير صحيحة" }
        require(date.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) { "تاريخ الحضور غير صحيح" }
        outbox.enqueue(TeacherAttendanceOutbox(
            clientEventId = UUID.randomUUID().toString(), organizationId = orgId(), teacherUserId = userId(), classroomId = classroomId,
            studentId = studentId, attendanceDate = date, status = status
        ))
    }

    suspend fun uploadPendingAttendance(): Int = withContext(Dispatchers.IO) {
        requireTeacher()
        val pending = outbox.pending(orgId(), userId())
        if (pending.isEmpty()) return@withContext 0
        val events = JSONArray()
        pending.forEach { e ->
            events.put(JSONObject().put("classroom_id", e.classroomId).put("student_id", e.studentId)
                .put("attendance_date", e.attendanceDate).put("status", e.status).put("client_event_id", e.clientEventId))
        }
        request("/rest/v1/rpc/noury_teacher_sync_attendance", "POST", JSONObject().put("p_events", events).toString())
        outbox.deleteUploaded(pending.map { it.id })
        pending.size
    }

    private fun requireOwner() {
        if (auth.currentRole() != "owner") throw IOException("هذه الوظيفة متاحة للمالك فقط")
    }
    private fun requireTeacher() {
        if (auth.currentRole() != "teacher") throw IOException("هذه الوظيفة متاحة لحساب المدرس فقط")
    }
    private fun userId() = auth.currentUserId()?.takeIf { it.isNotBlank() } ?: throw IOException("معرّف المستخدم غير متاح")
    private fun orgId() = auth.currentOrganizationId()?.takeIf { it.isNotBlank() } ?: throw IOException("معرّف المؤسسة غير متاح")
}
