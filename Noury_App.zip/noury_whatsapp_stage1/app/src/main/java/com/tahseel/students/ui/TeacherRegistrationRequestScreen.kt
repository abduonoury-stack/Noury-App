package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.tahseel.students.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

@Composable
fun TeacherRegistrationRequestScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    AppScaffold("طلب حساب مدرس", onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("أرسل بياناتك إلى مالك البرنامج لمراجعتها. لن يتم إنشاء الحساب إلا بعد الموافقة.", style = MaterialTheme.typography.bodyMedium)
            OutlinedTextField(name, { name = it.take(80) }, label = { Text("اسم المدرس") }, singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = !busy)
            OutlinedTextField(phone, { phone = it.filter { c -> c.isDigit() || c == '+' }.take(16) }, label = { Text("رقم الموبايل") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = !busy)
            Button(onClick = {
                busy = true; message = null
                scope.launch {
                    try {
                        val result = withContext(Dispatchers.IO) {
                            val payload = JSONObject().put("action", "request_teacher").put("display_name", name).put("phone", phone)
                            val request = Request.Builder().url("${BuildConfig.SUPABASE_URL}/functions/v1/owner-manage-users").header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY).header("Content-Type", "application/json").post(payload.toString().toRequestBody("application/json".toMediaType())).build()
                            OkHttpClient().newCall(request).execute().use { response ->
                                val body = response.body?.string().orEmpty(); val json = runCatching { JSONObject(body) }.getOrElse { JSONObject() }
                                if (!response.isSuccessful) throw IOException(json.optString("error", "تعذر إرسال الطلب"))
                                json.optString("message", "تم إرسال الطلب")
                            }
                        }
                        message = result
                    } catch (e: Exception) { message = e.message ?: "تعذر إرسال الطلب" }
                    finally { busy = false }
                }
            }, enabled = !busy && name.trim().length >= 2 && phone.isNotBlank(), modifier = Modifier.fillMaxWidth()) { if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("إرسال طلب التسجيل") }
            message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        }
    }
}
