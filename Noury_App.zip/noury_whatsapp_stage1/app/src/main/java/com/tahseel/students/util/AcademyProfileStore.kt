package com.tahseel.students.util

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Single source of truth for academy identity across screens, receipts and reports. */
object AcademyProfileStore {
    const val DEFAULT_NAME = "Little Dreams Academy"
    private const val PREFS_NAME = "receipt_profile"

    private val mutableName = MutableStateFlow(DEFAULT_NAME)
    private val mutableAddress = MutableStateFlow("")
    private val mutablePhone = MutableStateFlow("")
    val name: StateFlow<String> = mutableName.asStateFlow()
    val address: StateFlow<String> = mutableAddress.asStateFlow()
    val phone: StateFlow<String> = mutablePhone.asStateFlow()

    private fun preferences(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** Existing installations with a previously customized profile are not sent through onboarding. */
    fun isSetupComplete(context: Context): Boolean {
        val prefs = preferences(context)
        if (prefs.getBoolean("setup_completed", false)) return true
        val savedName = prefs.getString("name", "")?.trim().orEmpty()
        val savedAddress = prefs.getString("address", "")?.trim().orEmpty()
        val savedPhone = prefs.getString("phone", "")?.trim().orEmpty()
        return savedName.isNotBlank() && savedName != DEFAULT_NAME ||
            savedAddress.isNotBlank() || savedPhone.isNotBlank()
    }

    /** Load persisted profile at app start or after a backup restore. */
    fun refresh(context: Context): String {
        val prefs = preferences(context)
        val saved = prefs.getString("name", DEFAULT_NAME)?.trim().orEmpty().ifBlank { DEFAULT_NAME }
        mutableName.value = saved
        mutableAddress.value = prefs.getString("address", "")?.trim().orEmpty()
        mutablePhone.value = prefs.getString("phone", "")?.trim().orEmpty()
        return saved
    }

    /** إعدادات الأكاديمية كما تُحفظ داخل النسخ الاحتياطية (اليدوية والسحابية). */
    fun exportJson(context: Context): org.json.JSONObject {
        val prefs = preferences(context)
        return org.json.JSONObject().put("name", refresh(context))
            .put("phone", prefs.getString("phone", "01555713020"))
            .put("address", prefs.getString("address", ""))
    }

    fun getName(context: Context): String = refresh(context)
    fun getAddress(context: Context): String = preferences(context).getString("address", "")?.trim().orEmpty()
    fun getPhone(context: Context): String = preferences(context).getString("phone", "")?.trim().orEmpty()

    /** Save once and publish all fields immediately to every observing screen. */
    fun save(context: Context, name: String, address: String, phone: String): String {
        val normalizedName = name.trim().ifBlank { DEFAULT_NAME }
        val normalizedAddress = address.trim()
        val normalizedPhone = phone.trim()
        preferences(context).edit()
            .putString("name", normalizedName)
            .putString("address", normalizedAddress)
            .putString("phone", normalizedPhone)
            .putBoolean("setup_completed", true)
            .apply()
        mutableName.value = normalizedName
        mutableAddress.value = normalizedAddress
        mutablePhone.value = normalizedPhone
        return normalizedName
    }
}
