package com.tahseel.students.sync

import android.content.ContentValues
import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.tahseel.students.BuildConfig
import com.tahseel.students.data.AppDatabase
import com.tahseel.students.util.SyncRestoreGuard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.UUID
import java.util.concurrent.TimeUnit

/** Incremental sync worker. Outbox rows remain pending until Supabase accepts them. */
class AutomaticSyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    private val auth = SupabaseAuth(context)
    private val client = OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
    private val prefs = context.getSharedPreferences("noury_auto_sync", Context.MODE_PRIVATE)
    private val deviceId: String = prefs.getString("device_id", null) ?: UUID.randomUUID().toString().also { prefs.edit().putString("device_id", it).apply() }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        // Teacher accounts must never use the organization-wide event stream.
        // Their scoped sync will be implemented through separate teacher-only RPCs.
        if (auth.currentRole() == "teacher") return@withContext Result.success()

        val result = try {
            val token = auth.refreshAccessToken() ?: auth.accessToken()
            if (token == null || auth.currentUserId() == null || auth.currentOrganizationId() == null) {
                Result.success()
            } else {
                val owner = auth.currentUserId()!!
                val organizationId = auth.currentOrganizationId()!!
                val db = AppDatabase.create(applicationContext).openHelper.writableDatabase
                // لا تعمل المزامنة أثناء استعادة نسخة؛ تُتخطى هذه الدورة وتُجدول التالية.
                SyncRestoreGuard.trySyncPass {
                    pushPending(db, token, owner, organizationId)
                    pullRemote(db, token, organizationId)
                }
                Result.success()
            }
        } catch (_: Exception) {
            Result.retry()
        }
        // A retry is managed by WorkManager. Append the next five-minute pass only
        // after a completed pass, preventing parallel self-scheduled workers.
        if (result == Result.success()) {
            AutomaticSyncScheduler.scheduleNext(applicationContext)
        }
        result
    }

    private fun pushPending(db: androidx.sqlite.db.SupportSQLiteDatabase, token: String, owner: String, organizationId: String) {
        val rows = JSONArray()
        val localIds = mutableListOf<Long>()
        db.query("SELECT local_id,event_id,entity_type,entity_key,operation,payload FROM noury_sync_outbox WHERE synced=0 ORDER BY local_id LIMIT 100").use { c ->
            while (c.moveToNext()) {
                val localId = c.getLong(0); localIds += localId
                val item = JSONObject()
                    .put("owner_id", owner).put("organization_id", organizationId)
                    .put("device_id", deviceId).put("event_id", c.getString(1))
                    .put("entity_type", c.getString(2)).put("entity_key", c.getString(3))
                    .put("operation", c.getString(4)).put("base_revision", 0)
                if (!c.isNull(5)) item.put("payload", JSONObject(c.getString(5)))
                rows.put(item)
            }
        }
        if (localIds.isEmpty()) return
        val request = baseRequest("${BuildConfig.SUPABASE_URL}/rest/v1/noury_sync_events", token)
            .header("Prefer", "resolution=ignore-duplicates,return=minimal")
            .post(rows.toString().toRequestBody("application/json".toMediaType())).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Supabase push HTTP ${response.code}: ${response.body?.string().orEmpty()}")
        }
        db.beginTransaction()
        try {
            localIds.forEach { id -> db.execSQL("UPDATE noury_sync_outbox SET synced=1,last_error=NULL WHERE local_id=?", arrayOf(id)) }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    private fun pullRemote(db: androidx.sqlite.db.SupportSQLiteDatabase, token: String, organizationId: String) {
        // Keep a separate pull cursor per organization so switching accounts cannot skip events.
        val cursorKey = "last_event_id_$organizationId"
        val cursor = prefs.getLong(cursorKey, 0L)
        val url = "${BuildConfig.SUPABASE_URL}/rest/v1/noury_sync_events?select=id,device_id,event_id,entity_type,entity_key,operation,payload,created_at&organization_id=eq.${enc(organizationId)}&id=gt.$cursor&order=id.asc&limit=200"
        val request = baseRequest(url, token).get().build()
        val events = client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Supabase pull HTTP ${response.code}: ${response.body?.string().orEmpty()}")
            JSONArray(response.body?.string().orEmpty())
        }
        var maxId = cursor
        for (i in 0 until events.length()) {
            val event = events.getJSONObject(i)
            val id = event.getLong("id"); maxId = maxOf(maxId, id)
            if (event.optString("device_id") != deviceId) applyRemoteEvent(db, event)
        }
        if (maxId > cursor) prefs.edit().putLong(cursorKey, maxId).apply()
    }

    private fun applyRemoteEvent(db: androidx.sqlite.db.SupportSQLiteDatabase, event: JSONObject) {
        val table = event.getString("entity_type")
        if (!table.matches(Regex("[A-Za-z0-9_]+"))) return
        val key = event.optJSONObject("entity_key") ?: JSONObject(event.optString("entity_key"))
        val operation = event.getString("operation")
        val payload = event.optJSONObject("payload")
        db.beginTransaction()
        try {
            db.execSQL("UPDATE noury_sync_meta SET suppress_capture=1 WHERE id=1")
            // If this row has unsent local edits, preserve them and record a conflict instead of overwriting.
            val keyWhere = key.keys().asSequence().toList().joinToString(" AND ") { "${quote(it)}=?" }
            val keyArgs = key.keys().asSequence().toList().map { key.get(it) }.toTypedArray()
            val remoteTime = runCatching {
                java.time.Instant.parse(event.optString("created_at")).toEpochMilli()
            }.getOrDefault(System.currentTimeMillis())
            val conflict = hasNewerLocalEvent(db, table, key, remoteTime)
            if (conflict) {
                db.execSQL("CREATE TABLE IF NOT EXISTS noury_sync_conflicts(event_id TEXT PRIMARY KEY,entity_type TEXT,entity_key TEXT,remote_payload TEXT,operation TEXT,created_at INTEGER)")
                db.execSQL("INSERT OR IGNORE INTO noury_sync_conflicts VALUES(?,?,?,?,?,?)", arrayOf(event.getString("event_id"), table, event.getString("entity_key"), payload?.toString(), operation, System.currentTimeMillis()))
            } else if (operation == "delete") {
                if (keyWhere.isNotBlank()) db.execSQL("DELETE FROM ${quote(table)} WHERE $keyWhere", keyArgs)
            } else if (payload != null) {
                val values = ContentValues()
                val it = payload.keys()
                while (it.hasNext()) {
                    val name = it.next()
                    if (!name.matches(Regex("[A-Za-z0-9_]+"))) continue
                    when (val v = payload.opt(name)) {
                        null, JSONObject.NULL -> values.putNull(name)
                        is Boolean -> values.put(name, if (v) 1 else 0)
                        is Int -> values.put(name, v)
                        is Long -> values.put(name, v)
                        is Double -> values.put(name, v)
                        else -> values.put(name, v.toString())
                    }
                }
                // Use an UPDATE-on-conflict statement rather than SQLite REPLACE: REPLACE
                // deletes the old row first and can cascade-delete related financial rows.
                val pkColumns = mutableListOf<Pair<Int, String>>()
                db.query("PRAGMA table_info(${quote(table)})").use { info ->
                    val nameCol = info.getColumnIndex("name")
                    val pkCol = info.getColumnIndex("pk")
                    while (info.moveToNext()) if (info.getInt(pkCol) > 0) pkColumns += info.getInt(pkCol) to info.getString(nameCol)
                }
                val names = values.keySet().toList()
                if (names.isNotEmpty() && pkColumns.isNotEmpty()) {
                    val pkNames = pkColumns.sortedBy { it.first }.map { it.second }
                    val updateNames = names.filterNot { it in pkNames }
                    val sql = buildString {
                        append("INSERT INTO ${quote(table)} (")
                        append(names.joinToString(",") { quote(it) })
                        append(") VALUES (")
                        append(names.joinToString(",") { "?" })
                        append(") ON CONFLICT (")
                        append(pkNames.joinToString(",") { quote(it) })
                        append(") ")
                        if (updateNames.isEmpty()) append("DO NOTHING") else {
                            append("DO UPDATE SET ")
                            append(updateNames.joinToString(",") { "${quote(it)}=excluded.${quote(it)}" })
                        }
                    }
                    db.execSQL(sql, names.map { values.get(it) }.toTypedArray())
                }
            }
            db.execSQL("UPDATE noury_sync_meta SET suppress_capture=0 WHERE id=1")
            db.setTransactionSuccessful()
        } finally {
            runCatching { db.execSQL("UPDATE noury_sync_meta SET suppress_capture=0 WHERE id=1") }
            db.endTransaction()
        }
    }


    private fun hasNewerLocalEvent(
        db: androidx.sqlite.db.SupportSQLiteDatabase,
        table: String,
        remoteKey: JSONObject,
        remoteTime: Long
    ): Boolean {
        db.query(
            "SELECT entity_key FROM noury_sync_outbox WHERE entity_type=? AND created_at>?",
            arrayOf(table, remoteTime)
        ).use { c ->
            while (c.moveToNext()) {
                val localKey = runCatching { JSONObject(c.getString(0)) }.getOrNull() ?: continue
                if (localKey.length() != remoteKey.length()) continue
                val same = remoteKey.keys().asSequence().all { k ->
                    localKey.has(k) && localKey.opt(k).toString() == remoteKey.opt(k).toString()
                }
                if (same) return true
            }
        }
        return false
    }

    private fun baseRequest(url: String, token: String) = Request.Builder().url(url)
        .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
        .header("Authorization", "Bearer $token")
        .header("Content-Type", "application/json")

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun quote(s: String) = "\"${s.replace("\"", "\"\"")}\""
}
