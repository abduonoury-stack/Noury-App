package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.data.*
import com.tahseel.students.util.Money
import com.tahseel.students.util.TimeUtil
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId

@Composable
fun StudentFinanceScreen(
    studentId: Long,
    students: StudentDao,
    finance: FinanceDao,
    payments: PaymentDao,
    periodDao: PeriodDao,
    onBack: () -> Unit,
    onAddPayment: () -> Unit,
    onProfile: () -> Unit
) {
    val student by students.observeById(studentId).collectAsStateWithLifecycle(initialValue = null)
    val subscriptions by finance.observeSubscriptionHistory(studentId).collectAsStateWithLifecycle(initialValue = emptyList())
    val allPayments by payments.observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val allPeriods by periodDao.observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val priceHistory by periodDao.observeAllPriceHistory().collectAsStateWithLifecycle(initialValue = emptyList())
    val child = student
    val history = remember(allPayments, child) {
        allPayments.filter { p -> !p.isCancelled && (p.studentId == studentId || (p.studentId == null && child != null && p.studentName.trim().equals(child.fullName.trim(), true))) }
            .sortedByDescending { it.createdAt }
    }
    // The monthly obligation exists even before a payment is recorded. Add the
    // current month as an unpaid row when the student is active and eligible.
    val financeRows = remember(subscriptions, child, allPeriods, priceHistory) {
        val rows = subscriptions.map { FinanceSubscriptionRow(it.periodKey, it.dueAmountPiasters, it.paidAmountPiasters, it.discountPiasters, it.discountNote) }.toMutableList()
        if (child != null && child.status == "active") {
            val currentMonth = YearMonth.now()
            val enrollmentDate = Instant.ofEpochMilli(child.enrollmentDate)
                .atZone(ZoneId.systemDefault()).toLocalDate()
            val enrollmentMonth = YearMonth.from(enrollmentDate)
            if (!currentMonth.isBefore(enrollmentMonth) && rows.none { it.periodKey == currentMonth.toString() }) {
                val currentDue = if (currentMonth == enrollmentMonth && child.firstMonthAmountPiasters != null) {
                    child.firstMonthAmountPiasters
                } else {
                    val pid = child.periodId ?: if (child.attendanceEndHour == 16 || child.attendanceEndHour == 17) 2L else 1L
                    val at = currentMonth.atDay(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                    child.monthlyFeeOverridePiasters ?: resolvePeriodPricePiasters(priceHistory, pid, at) ?: 0L
                }
                if (currentDue > 0L) rows.add(FinanceSubscriptionRow(currentMonth.toString(), currentDue, 0L))
            }
        }
        rows.sortedByDescending { it.periodKey }
    }
    val due = financeRows.sumOf { it.dueAmountPiasters }
    val paid = financeRows.sumOf { it.paidAmountPiasters }
    val remaining = (due - paid).coerceAtLeast(0L)

    AppScaffold("الحساب المالي للطفل", onBack) { pad ->
        if (child == null) {
            Column(Modifier.padding(pad).padding(20.dp)) { CircularProgressIndicator(); Text("جارٍ تحميل ملف الطفل...") }
        } else {
            LazyColumn(Modifier.padding(pad).fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item { Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) { StudentAvatar(child.photoUri, 58.dp, child.id, child.gender); Text(child.fullName, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.clickable(onClick = onProfile)) } }
                item { Text("ملخص الاشتراكات المسجلة") }
                item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FinanceStat("المستحق", due, Modifier.weight(1f))
                    FinanceStat("المدفوع", paid, Modifier.weight(1f))
                    FinanceStat("المتبقي", remaining, Modifier.weight(1f))
                } }
                item { BigButton("تسجيل دفعة جديدة", Icons.Default.Add, onClick = onAddPayment) }
                item { Text("حالة الاشتراكات الشهرية", style = MaterialTheme.typography.titleLarge) }
                if (financeRows.isEmpty()) item { Text("لا توجد اشتراكات شهرية مستحقة لهذا الطفل حتى الآن.") }
                items(financeRows, key = { "subscription-${it.periodKey}" }) { sub ->
                    val balance = (sub.dueAmountPiasters - sub.paidAmountPiasters).coerceAtLeast(0L)
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(sub.periodKey, style = MaterialTheme.typography.titleMedium)
                            if (sub.discountPiasters > 0L) {
                                Text("الخصم: ${Money.format(sub.discountPiasters)}")
                                Text("قيمة الاشتراك قبل الخصم: ${Money.format(sub.dueAmountPiasters + sub.discountPiasters)}")
                            }
                            Text("المستحق بعد الخصم: ${Money.format(sub.dueAmountPiasters)}")
                            Text("المدفوع نقديًا: ${Money.format(sub.paidAmountPiasters)}")
                            Text(when {
                                sub.dueAmountPiasters == 0L && sub.discountPiasters > 0L -> "الحالة: تمت التسوية بالإعفاء الكامل"
                                balance == 0L -> "الحالة: مدفوع بالكامل"
                                sub.paidAmountPiasters > 0 -> "الحالة: مدفوع جزئيًا • المتبقي ${Money.format(balance)}"
                                else -> "الحالة: لم يُدفع • المتبقي ${Money.format(balance)}"
                            }, color = if (balance == 0L) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                            if (sub.discountNote.isNotBlank()) Text("سبب الخصم: ${sub.discountNote}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                item { Text("سجل الدفعات والإيصالات", style = MaterialTheme.typography.titleLarge) }
                if (history.isEmpty()) item { Text("لا توجد دفعات محفوظة لهذا الطفل.") }
                items(history, key = { "payment-${it.id}" }) { payment ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(if (payment.amountPiasters == 0L && payment.accountId == null) "إشعار إعفاء رقم: ${payment.receiptNo}" else "إيصال رقم: ${payment.receiptNo}", style = MaterialTheme.typography.titleMedium)
                            Text(if (payment.amountPiasters == 0L && payment.accountId == null) "إشعار إعفاء — لا توجد حركة نقدية" else "المبلغ: ${Money.format(payment.amountPiasters)}")
                            Text("التاريخ: ${TimeUtil.fmt(payment.createdAt)}")
                        }
                    }
                }
            }
        }
    }
}

private data class FinanceSubscriptionRow(
    val periodKey: String,
    val dueAmountPiasters: Long,
    val paidAmountPiasters: Long,
    val discountPiasters: Long = 0L,
    val discountNote: String = ""
)

@Composable
private fun FinanceStat(label: String, amount: Long, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Text(Money.format(amount), style = MaterialTheme.typography.titleMedium)
    } }
}
