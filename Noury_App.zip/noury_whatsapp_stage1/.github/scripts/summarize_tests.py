#!/usr/bin/env python3
"""Prints a markdown table of JUnit XML results (and failing test names) to stdout.
Usage: summarize_tests.py <title> <glob> [<glob> ...]. Exit code is always 0; the Gradle step decides pass/fail."""
import glob, sys, xml.etree.ElementTree as ET
title, patterns = sys.argv[1], sys.argv[2:]
files = sorted({f for p in patterns for f in glob.glob(p, recursive=True)})
tests = fails = errors = skipped = 0; bad = []
for f in files:
    try: root = ET.parse(f).getroot()
    except ET.ParseError: continue
    for s in ([root] if root.tag == "testsuite" else root.iter("testsuite")):
        tests += int(s.get("tests", 0)); fails += int(s.get("failures", 0)); errors += int(s.get("errors", 0)); skipped += int(s.get("skipped", 0))
    for c in root.iter("testcase"):
        if c.find("failure") is not None or c.find("error") is not None:
            bad.append(f'{c.get("classname")}.{c.get("name")}')
print(f"### {title}")
if not files: print("**No result files were produced (build or test step failed before running tests).**")
else:
    print(f"| files | tests | failures | errors | skipped |\n|---|---|---|---|---|\n| {len(files)} | {tests} | {fails} | {errors} | {skipped} |")
    for b in bad: print(f"- FAILED: `{b}`")
