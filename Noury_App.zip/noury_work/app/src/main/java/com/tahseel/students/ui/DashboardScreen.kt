package com.tahseel.students.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.R
import com.tahseel.students.util.AcademyProfileStore
import com.tahseel.students.util.Money
import com.tahseel.students.util.TimeUtil
import com.tahseel.students.vm.DashboardViewModel
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val DashPurple = LdaPalette.Royal
private val DashDeep = LdaPalette.RoyalDeep
private val DashLilac = LdaPalette.Lilac
private val DashMint = LdaPalette.SuccessContainer
private val DashPeach = LdaPalette.PeachContainer

@Composable
fun DashboardScreen(
    vm: DashboardViewModel,
    onAdd: () -> Unit, onLedger: () -> Unit, onSearch: () -> Unit, onReports: () -> Unit,
    onStudents: () -> Unit, onSubscription: () -> Unit, onCollectionStatus: () -> Unit,
    onBirthdays: () -> Unit, onClassrooms: () -> Unit, onAttendance: () -> Unit,
    onExpenses: () -> Unit, onHr: () -> Unit, onStudentExit: () -> Unit,
    onHub: (String) -> Unit, onStudentProfile: (Long) -> Unit
) {
    val s by vm.state.collectAsStateWithLifecycle()
    val academyName by AcademyProfileStore.name.collectAsStateWithLifecycle()
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refreshDay() }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(30_000) } }
    val locale = remember { Locale("ar", "EG") }
    val dateText = remember(now) { now.format(DateTimeFormatter.ofPattern("EEEE، d MMMM yyyy", locale)) }
    val progress = if (s.expected > 0L) (s.collected.toFloat() / s.expected.toFloat()).coerceIn(0f, 1f) else 0f

    AppScaffold(title = "الرئيسية", onBack = null, showTopBar = false, bottomBar = {
        DashboardBottomBar(
            onHome = {}, onReports = onReports, onStudents = onStudents,
            onSubscriptions = onSubscription, onMore = { onHub("system") }
        )
    }) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).background(Brush.verticalGradient(listOf(Color(0xFFF8F3FF), Color(0xFFF0E8FF), Color(0xFFFFFBFF))))
                .verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp)
        ) {
            // Academy identity header
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Image(painter = androidx.compose.ui.res.painterResource(R.drawable.noury_wordmark), contentDescription = "Noury App", modifier = Modifier.width(142.dp).height(44.dp), contentScale = ContentScale.Fit)
                    Text(academyName, color = DashPurple, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(dateText, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                }
                Surface(shape = CircleShape, color = Color.White, border = BorderStroke(2.dp, DashLilac), shadowElevation = 3.dp) {
                    Image(painter = androidx.compose.ui.res.painterResource(R.drawable.canaria_logo), contentDescription = "شعار الأكاديمية", modifier = Modifier.size(58.dp).padding(5.dp))
                }
            }

            // Actual hero artwork extracted from the user's supplied visual reference.
            Card(shape = RoundedCornerShape(26.dp), elevation = CardDefaults.cardElevation(4.dp), border = BorderStroke(1.dp, Color.White)) {
                Box(Modifier.fillMaxWidth().height(132.dp)) {
                    Image(painter = androidx.compose.ui.res.painterResource(R.drawable.dashboard_hero), contentDescription = "صورة ترحيبية بأطفال الأكاديمية", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                }
            }

            // Three finance cards use live database-backed values only.
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DashboardMetricCard("صافي الحركة النقدية", Money.format(s.net), Icons.Default.Wallet, DashMint, Color(0xFF087E55), Modifier.weight(1f))
                    DashboardMetricCard("المصروفات", Money.format(s.expenses), Icons.Default.Payments, DashLilac, DashPurple, Modifier.weight(1f))
                }
                DashboardMetricCard("المتحصل", Money.format(s.totalCollected), Icons.Default.AccountBalanceWallet, DashPeach, Color(0xFFB66A00), Modifier.fillMaxWidth())
            }

            // Monthly collection progress
            Card(shape = RoundedCornerShape(23.dp), colors = CardDefaults.cardColors(containerColor = Color.White), border = BorderStroke(1.dp, Color(0xFFE8DDF8)), elevation = CardDefaults.cardElevation(2.dp)) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("نسبة التحصيل", color = DashDeep, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
                            Text("اشتراكات ${s.month}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = vm::previousMonth) { Text("›", color = DashPurple, fontSize = 25.sp) }
                            IconButton(onClick = vm::nextMonth) { Text("‹", color = DashPurple, fontSize = 25.sp) }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Box(Modifier.size(112.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(progress = { 1f }, modifier = Modifier.fillMaxSize(), strokeWidth = 11.dp, color = Color(0xFFEDE5F8), trackColor = Color.Transparent)
                            CircularProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxSize(), strokeWidth = 11.dp, color = Color(0xFF20BE78), trackColor = Color.Transparent)
                            Text("${(progress * 100).toInt()}%", color = DashDeep, fontWeight = FontWeight.ExtraBold, fontSize = 25.sp)
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            DashboardValueLine("المحصل", Money.format(s.collected), Color(0xFF128A57))
                            DashboardValueLine("المستحق", Money.format(s.expected), DashDeep)
                            DashboardValueLine("المتبقي", Money.format(s.remaining), Color(0xFFB66A00))
                        }
                    }
                    Text("مسدد ${s.paidStudents} طفل  •  متبقي ${s.unpaidStudents} طفل", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
                }
            }

            DashboardSectionTitle("الفترات الدراسية", "المبالغ حسب الفترات المعرفة في النظام", Icons.Default.CalendarMonth)
            if (s.periodSummaries.isEmpty()) {
                Surface(color = Color.White, shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, LdaPalette.Border)) {
                    Text("لا توجد اشتراكات مرتبطة بفترات خلال هذا الشهر", Modifier.fillMaxWidth().padding(16.dp), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                s.periodSummaries.forEachIndexed { index, period ->
                    val periodProgress = if (period.expected > 0L) (period.collected.toFloat() / period.expected).coerceIn(0f, 1f) else 0f
                    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = if (index % 2 == 0) Color(0xFFF4EDFF) else Color(0xFFFFF3E5)), border = BorderStroke(1.dp, Color.White)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                DuotoneIcon(Icons.Default.CalendarMonth, tint = if (index % 2 == 0) DashPurple else Color(0xFFC17A00), containerColor = Color.White.copy(alpha = .8f), tileSize = 42.dp)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(period.name, color = DashDeep, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                    Text("${period.startTime} – ${period.endTime}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                                }
                                Text(Money.format(period.expected), color = DashDeep, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleSmall)
                            }
                            LinearProgressIndicator(progress = { periodProgress }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape), color = Color(0xFF20BE78), trackColor = Color.White)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("المحصل ${Money.format(period.collected)}", color = Color(0xFF128A57), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text("المتبقي ${Money.format((period.expected - period.collected).coerceAtLeast(0L))}", color = DashDeep, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }

            DashboardSectionTitle("الوصول السريع", "أهم عمليات الأكاديمية", Icons.Default.TrendingUp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                DashboardAction("إضافة طفل", Icons.Default.ChildCare, Color(0xFFDDF8E9), Color(0xFF128A57), { onHub("students") }, Modifier.weight(1f))
                DashboardAction("تحصيل اشتراك", Icons.Default.ReceiptLong, Color(0xFFFFEEDB), Color(0xFFB66A00), onSubscription, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                DashboardAction("تسجيل دفعة", Icons.Default.AddCard, Color(0xFFF2E6FF), DashPurple, onAdd, Modifier.weight(1f))
                DashboardAction("الفصول", Icons.Default.Groups, Color(0xFFDDF8E9), Color(0xFF128A57), onClassrooms, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                DashboardAction("إدارة الأطفال", Icons.Default.Groups, Color(0xFFDDF8E9), Color(0xFF128A57), onStudents, Modifier.weight(1f))
                DashboardAction("التقارير", Icons.Default.Assessment, Color(0xFFECE4FF), DashPurple, onReports, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                DashboardAction("الإدارة المالية", Icons.Default.AccountBalance, Color(0xFFFFF0DF), Color(0xFFB66A00), onExpenses, Modifier.weight(1f))
                DashboardAction("كشف المتأخرات", Icons.Default.Search, Color(0xFFE4F7F0), Color(0xFF128A57), onCollectionStatus, Modifier.weight(1f))
            }

            DashboardSectionTitle("ملخص الأداء", "مؤشرات النشاط المسجلة", Icons.Default.Assessment)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DashboardStat("الأطفال النشطون", s.activeStudents.toString(), Icons.Default.ChildCare, Modifier.weight(1f))
                DashboardStat("عدد الإيصالات", s.count.toString(), Icons.Default.ReceiptLong, Modifier.weight(1f))
            }
            DashboardStat("عمليات اليوم", s.todayCount.toString(), Icons.Default.CalendarMonth, Modifier.fillMaxWidth())

            DashboardSectionTitle("أقسام الأكاديمية", "كل الوظائف الحالية ما زالت متاحة", Icons.Default.Groups)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DashboardAction("الفصول", Icons.Default.Groups, Color(0xFFECE4FF), DashPurple, onClassrooms, Modifier.weight(1f))
                DashboardAction("الحضور", Icons.Default.CalendarMonth, Color(0xFFDDF8E9), Color(0xFF128A57), onAttendance, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DashboardAction("أعياد الميلاد", Icons.Default.ChildCare, Color(0xFFFFF0DF), Color(0xFFB66A00), onBirthdays, Modifier.weight(1f))
                DashboardAction("إخلاء طفل", Icons.Default.ChildCare, Color(0xFFFFE7E7), Color(0xFFB3261E), onStudentExit, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DashboardAction("السجل المالي", Icons.Default.Wallet, Color(0xFFECE4FF), DashPurple, onLedger, Modifier.weight(1f))
                DashboardAction("شؤون العاملين", Icons.Default.Groups, Color(0xFFDDF8E9), Color(0xFF128A57), onHr, Modifier.weight(1f))
                DashboardAction("بحث", Icons.Default.Search, Color(0xFFFFF0DF), Color(0xFFB66A00), onSearch, Modifier.weight(1f))
            }
            val last = s.last
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White), border = BorderStroke(1.dp, LdaPalette.Border)) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("آخر عملية تحصيل", color = DashDeep, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (last == null) Text("لا توجد عمليات مسجلة حتى الآن", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else {
                        Text(last.studentName, style = MaterialTheme.typography.titleMedium, color = DashPurple, modifier = last.studentId?.let { id -> Modifier.clickable { onStudentProfile(id) } } ?: Modifier)
                        Text("إيصال ${last.receiptNo}  •  ${Money.format(last.amountPiasters)}", fontWeight = FontWeight.SemiBold, color = DashDeep)
                        Text(TimeUtil.fmt(last.createdAt), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            Text("NOURY APP  •  ${academyName.uppercase(Locale.ROOT)}", modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun DashboardMetricCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, bg: Color, accent: Color, modifier: Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = bg), border = BorderStroke(1.dp, Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(27.dp))
            Text(value, color = DashDeep, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(title, color = accent, fontWeight = FontWeight.Bold, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2, lineHeight = 15.sp)
        }
    }
}

@Composable
private fun DashboardValueLine(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
        Text(value, color = color, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleSmall, maxLines = 1)
    }
}

@Composable
private fun DashboardSectionTitle(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(Modifier.fillMaxWidth().padding(top = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        DuotoneIcon(icon, tint = DashPurple, containerColor = Color(0xFFECE4FF), tileSize = 39.dp, iconSize = 21.dp)
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text(title, color = DashDeep, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun DashboardAction(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, bg: Color, accent: Color, onClick: () -> Unit, modifier: Modifier) {
    Card(onClick = onClick, modifier = modifier.heightIn(min = 96.dp), shape = RoundedCornerShape(21.dp), colors = CardDefaults.cardColors(containerColor = bg), border = BorderStroke(1.dp, Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 7.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Surface(shape = RoundedCornerShape(14.dp), color = Color.White.copy(alpha = .78f)) {
                Icon(icon, contentDescription = title, tint = accent, modifier = Modifier.padding(9.dp).size(27.dp))
            }
            Text(title, color = DashDeep, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge, textAlign = TextAlign.Center, maxLines = 2)
        }
    }
}

@Composable
private fun DashboardStat(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White), border = BorderStroke(1.dp, LdaPalette.Border)) {
        Column(Modifier.fillMaxWidth().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(icon, null, tint = DashPurple, modifier = Modifier.size(23.dp))
            Text(value, color = DashDeep, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
            Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, maxLines = 2)
        }
    }
}

@Composable
private fun DashboardBottomBar(onHome: () -> Unit, onReports: () -> Unit, onStudents: () -> Unit, onSubscriptions: () -> Unit, onMore: () -> Unit) {
    Surface(color = Color.White, shadowElevation = 10.dp, tonalElevation = 2.dp) {
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 5.dp, vertical = 7.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            DashboardNavItem("الرئيسية", Icons.Default.Home, true, onHome)
            DashboardNavItem("التقارير", Icons.Default.Assessment, false, onReports)
            DashboardNavItem("الأطفال", Icons.Default.Groups, false, onStudents)
            DashboardNavItem("الاشتراكات", Icons.Default.ReceiptLong, false, onSubscriptions)
            DashboardNavItem("المزيد", Icons.Default.MoreHoriz, false, onMore)
        }
    }
}

@Composable
private fun DashboardNavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) DashPurple else Color.Transparent
    val fg = if (selected) Color.White else DashDeep
    Column(Modifier.clip(RoundedCornerShape(18.dp)).background(bg).clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Icon(icon, contentDescription = label, tint = fg, modifier = Modifier.size(22.dp))
        Text(label, color = fg, fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.SemiBold, fontSize = 10.sp, maxLines = 2, textAlign = TextAlign.Center, lineHeight = 12.sp)
    }
}
