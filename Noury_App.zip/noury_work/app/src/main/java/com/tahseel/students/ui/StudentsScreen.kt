package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.runtime.produceState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import com.tahseel.students.util.StudentExcel
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import android.app.DatePickerDialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.data.Student
import com.tahseel.students.util.Money
import com.tahseel.students.vm.StudentsViewModel
import java.time.Instant
import java.time.LocalDate
import java.time.Period
import java.time.ZoneId

@Composable
fun StudentsScreen(vm: StudentsViewModel, onBack: () -> Unit, onProfile: (Long) -> Unit, onFinance: (Long) -> Unit, openAddInitially: Boolean = false) {
    val students by vm.students.collectAsStateWithLifecycle()
    val classrooms by vm.classrooms.collectAsStateWithLifecycle()
    val periods by vm.periods.collectAsStateWithLifecycle()
    var showAdd by remember { mutableStateOf(openAddInitially) }
    var editing by remember { mutableStateOf<Student?>(null) }
    var changingStatus by remember { mutableStateOf<Student?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var filter by remember { mutableStateOf("all") }
    var search by remember { mutableStateOf("") }
    val context = LocalContext.current
    var importPreview by remember { mutableStateOf<List<Student>?>(null) }
    var importErrors by remember { mutableStateOf<List<String>>(emptyList()) }
    val templateLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) { uri -> if(uri!=null) runCatching { StudentExcel.writeTemplate(context,uri) }.onSuccess { Toast.makeText(context,"تم إنشاء نموذج Excel",Toast.LENGTH_SHORT).show() }.onFailure { message=it.message ?: "تعذر إنشاء النموذج" } }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if(uri!=null) runCatching { val rows=StudentExcel.read(context,uri); val (valid,errors)=StudentExcel.toStudents(rows,classrooms.map{it.name}.toSet(),students); importPreview=valid; importErrors=errors }.onFailure { message=it.message ?: "تعذر قراءة ملف Excel" } }
    // ترتيب موحد دائمًا: الأكبر سنًا أولًا (تاريخ ميلاد أقدم)، ومن لا يملك تاريخ ميلاد في النهاية.
    val visibleStudents = students.filter { student ->
        val matchesFilter = when (filter) {
            "regular" -> student.status == "active"
            "disconnected" -> student.status != "active"
            else -> true
        }
        val query = normalizeSearch(search)
        val matchesSearch = query.isBlank() || normalizeSearch(student.fullName).contains(query) ||
            normalizeSearch(student.motherWhatsapp).contains(query)
        matchesFilter && matchesSearch
    }.sortedWith(
        compareBy<Student> { it.birthDate ?: Long.MAX_VALUE }
            .thenBy { normalizeSearch(it.fullName) }
    )
    AppScaffold(title = "ملفات الطلاب", onBack = onBack) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            BigButton("إضافة طالب جديد", Icons.Default.PersonAdd, { showAdd = true })
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick={ templateLauncher.launch("Little_Dreams_Students_Template.xlsx") }, modifier=Modifier.weight(1f)) { Text("تحميل نموذج Excel") }
                OutlinedButton(onClick={ importLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/vnd.ms-excel")) }, modifier=Modifier.weight(1f)) { Text("استيراد Excel") }
            }
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f)
            ) {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("إجمالي ملفات الطلاب", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${students.size}", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                    }
                    Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                        Text("منتظم ${students.count { it.status == "active" }}  •  منقطع ${students.count { it.status != "active" }}", style = MaterialTheme.typography.titleSmall)
                        Text("الترتيب: الأكبر سنًا إلى الأصغر", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            OutlinedTextField(
                value = search, onValueChange = { search = it }, singleLine = true,
                label = { Text("ابحث باسم الطالب أو رقم واتساب الأم") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = filter == "all", onClick = { filter = "all" }, label = { Text("الكل") })
                FilterChip(selected = filter == "regular", onClick = { filter = "regular" }, label = { Text("منتظم") })
                FilterChip(selected = filter == "disconnected", onClick = { filter = "disconnected" }, label = { Text("منقطع") })
            }
            if (visibleStudents.isEmpty()) Text("لا توجد ملفات في هذا التصنيف")
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                items(visibleStudents, key = { it.id }) { student ->
                    StudentCard(
                        student = student,
                        period = periods.firstOrNull { it.id == student.periodId },
                        onEdit = { editing = student },
                        onProfile = { onProfile(student.id) },
                        onFinance = { onFinance(student.id) },
                        onStatus = { changingStatus = student }
                    )
                }
            }
        }
    }
    if (showAdd) StudentEditorDialog(classroomNames = classrooms.map { it.name }, periods = periods.filter { it.isActive }, onDismiss = { showAdd = false }) { fields ->
        saveFields(vm, fields, null, periods) { error -> message = error ?: "تم حفظ ملف الطالب"; if (error == null) showAdd = false }
    }
    editing?.let { student ->
        StudentEditorDialog(student = student, classroomNames = classrooms.map { it.name }, periods = periods, onDismiss = { editing = null }) { fields ->
            saveFields(vm, fields, student, periods) { error -> message = error ?: "تم تحديث بيانات الطالب"; if (error == null) editing = null }
        }
    }
    changingStatus?.let { student ->
        val makeRegular = student.status != "active"
        AlertDialog(
            onDismissRequest = { changingStatus = null },
            title = { Text(if (makeRegular) "إعادة الطالب إلى منتظم؟" else "تأكيد انقطاع الطالب") },
            text = { Text(if (makeRegular) "سيظهر الطالب ضمن الطلاب المنتظمين، ويمكن تسجيل اشتراكاته الجديدة." else "سيتوقف إنشاء اشتراكات جديدة للطالب. ستظل كل التحصيلات والإيصالات والأرصدة السابقة محفوظة.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.setRegularity(student, makeRegular) { error ->
                        message = error ?: if (makeRegular) "تم إعادة الطالب إلى منتظم" else "تم تغيير حالة الطالب إلى منقطع"
                        changingStatus = null
                    }
                }) { Text(if (makeRegular) "تأكيد الانتظام" else "تأكيد الانقطاع") }
            },
            dismissButton = { TextButton(onClick = { changingStatus = null }) { Text("رجوع") } }
        )
    }
    importPreview?.let { ready ->
        AlertDialog(onDismissRequest={importPreview=null}, title={Text("مراجعة الاستيراد")}, text={ Column(Modifier.heightIn(max=420.dp).verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(6.dp)) { Text("طلاب جاهزون للإضافة: ${ready.size}"); if(importErrors.isNotEmpty()) { Text("ملاحظات وأخطاء (${importErrors.size})", color=MaterialTheme.colorScheme.error); importErrors.take(30).forEach { Text("• $it", style=MaterialTheme.typography.bodySmall) }; if(importErrors.size>30) Text("وهناك أخطاء أخرى...") }; Text("لن يتم إنشاء أي اشتراكات أو دفعات أو إيصالات.") } }, confirmButton={ TextButton(enabled=ready.isNotEmpty(),onClick={ vm.importStudents(ready){ err -> message=err ?: "تم استيراد ${ready.size} طالب بنجاح"; importPreview=null } }){Text("تأكيد إضافة ${ready.size} طالب")} }, dismissButton={TextButton(onClick={importPreview=null}){Text("إلغاء")}})
    }
    message?.let { msg -> AlertDialog(onDismissRequest = { message = null }, confirmButton = { TextButton(onClick = { message = null }) { Text("حسنًا") } }, text = { Text(msg) }) }
}

private fun saveFields(vm: StudentsViewModel, fields: List<String>, existing: Student?, periods: List<com.tahseel.students.data.AttendancePeriod>, onResult: (String?) -> Unit) {
    val birthDate = if (fields[2].isBlank()) null else parseStudentDate(fields[2])
    val birthMillis = birthDate?.atStartOfDay(ZoneId.systemDefault())?.toInstant()?.toEpochMilli()
    if (fields[2].isNotBlank() && birthMillis == null) { onResult("تاريخ الميلاد غير صحيح. اكتب اليوم/الشهر/السنة مثل 15/08/2022"); return }
    val enrollmentMillis = runCatching {
        LocalDate.parse(fields[3]).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    }.getOrNull()
    if (enrollmentMillis == null) { onResult("اكتب تاريخ الالتحاق بصيغة YYYY-MM-DD مثل 2026-11-02"); return }
    if (birthMillis != null && Instant.ofEpochMilli(birthMillis).atZone(ZoneId.systemDefault()).toLocalDate().isAfter(LocalDate.now())) { onResult("تاريخ الميلاد لا يمكن أن يكون في المستقبل"); return }
    val selectedPeriod = periods.firstOrNull { it.id.toString() == fields[12] }
    if (selectedPeriod == null) { onResult("اختر فترة حضور مسجلة ونشطة"); return }
    val endHour = if (selectedPeriod.endTime == "15:00" && selectedPeriod.startTime == "10:00") 16 else 15
    vm.save(
        fields[0], fields[1], birthMillis, enrollmentMillis, endHour, selectedPeriod.id, fields[13], fields[5],
        fields[6], fields[7], fields[8], fields[9], fields[10], fields[11], existing, fields.getOrNull(14), fields.getOrNull(15) ?: "boy", onResult
    )
}

@Composable
private fun StudentCard(student: Student, period: com.tahseel.students.data.AttendancePeriod?, onEdit: () -> Unit, onProfile: () -> Unit, onFinance: () -> Unit, onStatus: () -> Unit) {
    val regular = student.status == "active"
    val ageText = student.birthDate?.let { birth ->
        val dob = Instant.ofEpochMilli(birth).atZone(ZoneId.systemDefault()).toLocalDate()
        val age = Period.between(dob, LocalDate.now())
        "${age.years} سنة و${age.months} شهر"
    } ?: "العمر غير مسجل"
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StudentAvatar(photoUri = student.photoUri, size = 58.dp, studentId = student.id, gender = student.gender)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(student.fullName, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.clickable(onClick = onProfile))
                    Text(ageText, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                AssistChip(onClick = onStatus, label = { Text(if (regular) "منتظم" else "منقطع") })
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f))
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("${period?.name ?: if (student.attendanceEndHour == 16) "مسائية" else "صباحية"}  •  ${period?.let { "${it.startTime} – ${it.endTime}" } ?: "المواعيد غير محددة"}", style = MaterialTheme.typography.bodyMedium)
                if (student.className.isNotBlank()) Text("الفصل: ${student.className}", style = MaterialTheme.typography.bodyMedium)
                Text("الرسوم الشهرية: ${student.monthlyFeeOverridePiasters?.let { Money.format(it) + " (سعر معتمد)" } ?: "سعر الفترة الساري"}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (student.motherWhatsapp.isNotBlank()) Text("واتساب الأم: ${student.motherWhatsapp}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = onFinance, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 5.dp, vertical = 9.dp)) { Text("الحساب المالي", style = MaterialTheme.typography.labelMedium) }
                OutlinedButton(onClick = onEdit, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 5.dp, vertical = 9.dp)) { Text("تعديل", style = MaterialTheme.typography.labelMedium) }
                OutlinedButton(onClick = onStatus, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 5.dp, vertical = 9.dp)) { Text(if (regular) "تسجيل انقطاع" else "إعادة انتظام", style = MaterialTheme.typography.labelMedium) }
            }
        }
    }
}

@Composable
private fun StudentEditorDialog(student: Student? = null, classroomNames: List<String>, periods: List<com.tahseel.students.data.AttendancePeriod>, onDismiss: () -> Unit, onSave: (List<String>) -> Unit) {
    val context = LocalContext.current
    val values = remember(student?.id) {
        mutableStateListOf(
            student?.fullName.orEmpty(), student?.className.orEmpty(),
            student?.birthDate?.let { formatStudentDate(Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()).toLocalDate()) }.orEmpty(),
            student?.let { Instant.ofEpochMilli(it.enrollmentDate).atZone(ZoneId.systemDefault()).toLocalDate().toString() } ?: LocalDate.now().toString(),
            (student?.attendanceEndHour ?: 15).toString(),
            student?.firstMonthAmountPiasters?.let { (it / 100).toString() }.orEmpty(),
            student?.motherName.orEmpty(), student?.motherWhatsapp.orEmpty(), student?.fatherName.orEmpty(),
            student?.fatherPhone.orEmpty(), student?.address.orEmpty(), student?.notes.orEmpty(),
            (student?.periodId ?: if (student?.attendanceEndHour == 16) 2L else 1L).toString(),
            student?.monthlyFeeOverridePiasters?.let { (it / 100).toString() }.orEmpty(),
            student?.photoUri.orEmpty(),
            student?.gender ?: "boy"
        )
    }
    var validationMessage by remember { mutableStateOf<String?>(null) }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                values[14] = uri.toString()
            }.onFailure { validationMessage = "تعذر حفظ صلاحية الوصول للصورة. اختر صورة أخرى." }
        }
    }
    var classMenu by remember { mutableStateOf(false) }
    var periodMenu by remember { mutableStateOf(false) }

    fun chooseDate(index: Int) {
        val current = if (index == 2) parseStudentDate(values[index]) ?: LocalDate.now() else runCatching { LocalDate.parse(values[index]) }.getOrElse { LocalDate.now() }
        DatePickerDialog(
            context,
            { _, year, month, day ->
                val selected = LocalDate.of(year, month + 1, day)
                values[index] = if (index == 2) formatStudentDate(selected) else selected.toString()
            },
            current.year, current.monthValue - 1, current.dayOfMonth
        ).apply {
            if (index == 2) datePicker.maxDate = System.currentTimeMillis()
        }.show()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(if (student == null) "إضافة طالب جديد" else "تعديل بيانات الطالب")
                Text("أدخل البيانات في الأقسام التالية", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 590.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                FormSection(title = "بيانات الطفل", subtitle = "الاسم وتاريخ الميلاد والفصل") {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StudentAvatar(photoUri = values[14], size = 82.dp, studentId = student?.id ?: 0L, gender = values[15])
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("صورة الطالب", style = MaterialTheme.typography.titleSmall)
                            OutlinedButton(onClick = { photoPicker.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) { Text(if (values[14].isBlank()) "اختيار صورة من الجهاز" else "تغيير الصورة") }
                            if (values[14].isNotBlank()) TextButton(onClick = { values[14] = "" }, modifier = Modifier.align(androidx.compose.ui.Alignment.End)) { Text("إزالة الصورة") }
                        }
                    }
                    Text("نوع الصورة الافتراضية", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = values[15] == "boy", onClick = { values[15] = "boy" }, label = { Text("ولد 👦") }, modifier = Modifier.weight(1f))
                        FilterChip(selected = values[15] == "girl", onClick = { values[15] = "girl" }, label = { Text("بنت 👧") }, modifier = Modifier.weight(1f))
                    }
                    OutlinedTextField(
                        value = values[0], onValueChange = { values[0] = it },
                        label = { Text("الاسم رباعي *") }, placeholder = { Text("اسم الطفل بالكامل") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true
                    )
                    Box(Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = values[1], onValueChange = {}, readOnly = true,
                            label = { Text("الفصل / المجموعة") }, placeholder = { Text("اختر الفصل") },
                            trailingIcon = { Text("▾") }, modifier = Modifier.fillMaxWidth()
                        )
                        Box(Modifier.matchParentSize().clickable { classMenu = true })
                        DropdownMenu(expanded = classMenu, onDismissRequest = { classMenu = false }) {
                            DropdownMenuItem(text = { Text("بدون فصل / غير موزع") }, onClick = { values[1] = ""; classMenu = false })
                            classroomNames.forEach { room -> DropdownMenuItem(text = { Text(room) }, onClick = { values[1] = room; classMenu = false }) }
                            if (classroomNames.isEmpty()) DropdownMenuItem(text = { Text("لا توجد فصول مسجلة بعد") }, onClick = { classMenu = false })
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = values[2],
                            onValueChange = { input -> values[2] = input.filter { it.isDigit() || it == '/' || it == '-' }.take(10) },
                            label = { Text("تاريخ الميلاد (اختياري)") },
                            placeholder = { Text("15/08/2022 أو 15082022") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedButton(onClick = { chooseDate(2) }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 15.dp)) {
                            Text("التقويم")
                        }
                    }
                    Text("اكتب 15/08/2022 أو 15082022، أو اختَر التاريخ من التقويم.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    DateInputField("تاريخ الالتحاق *", values[3], { chooseDate(3) })
                }

                FormSection(title = "بيانات الالتحاق", subtitle = "الفترة وقيمة شهر الالتحاق عند الحاجة") {
                    Box(Modifier.fillMaxWidth()) {
                        val chosenPeriod = periods.firstOrNull { it.id.toString() == values[12] }
                        OutlinedTextField(
                            value = chosenPeriod?.let { "${it.name} • ${it.startTime} – ${it.endTime} • ${Money.format(it.monthlyFeePiasters)} شهريًا" }.orEmpty(),
                            onValueChange = {}, readOnly = true, label = { Text("فترة الحضور *") },
                            placeholder = { Text("اختر فترة مسجلة") }, trailingIcon = { Text("▾") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Box(Modifier.matchParentSize().clickable { periodMenu = true })
                        DropdownMenu(expanded = periodMenu, onDismissRequest = { periodMenu = false }) {
                            periods.filter { it.isActive || it.id.toString() == values[12] }.forEach { item ->
                                DropdownMenuItem(text = { Text("${item.name} (${item.startTime}–${item.endTime}) — ${Money.format(item.monthlyFeePiasters)}") }, onClick = {
                                    values[12] = item.id.toString()
                                    values[4] = if (item.endTime == "15:00" && item.startTime == "10:00") "16" else "15"
                                    periodMenu = false
                                })
                            }
                        }
                    }
                    OutlinedTextField(
                        value = values[13], onValueChange = { values[13] = it.filter(Char::isDigit) },
                        label = { Text("السعر الشهري المعتمد للطالب (تعديل إداري)") },
                        placeholder = { Text("امسحه ليتبع الطالب سعر الفترة الساري") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(), singleLine = true
                    )
                    Text("الطالب يحتفظ بالسعر المكتوب هنا. اكتب السعر الجديد يدويًا لتثبيته له؛ وترك الحقل فارغًا يجعله يتبع سعر الفترة الساري تلقائيًا.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedTextField(
                        value = values[5], onValueChange = { values[5] = it.filter(Char::isDigit) },
                        label = { Text("مبلغ شهر الالتحاق الجزئي (جنيه)") },
                        placeholder = { Text("يُترك فارغًا إذا لم ينطبق") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(), singleLine = true
                    )
                }

                FormSection(title = "بيانات ولي الأمر", subtitle = "وسائل التواصل مع الأسرة") {
                    OutlinedTextField(value = values[6], onValueChange = { values[6] = it }, label = { Text("اسم الأم") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(
                        value = values[7], onValueChange = { values[7] = it.filter { ch -> ch.isDigit() || ch == '+' || ch == ' ' || ch == '-' } },
                        label = { Text("واتساب الأم") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth(), singleLine = true
                    )
                    OutlinedTextField(value = values[8], onValueChange = { values[8] = it }, label = { Text("اسم الأب") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(
                        value = values[9], onValueChange = { values[9] = it.filter { ch -> ch.isDigit() || ch == '+' || ch == ' ' || ch == '-' } },
                        label = { Text("هاتف الأب") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth(), singleLine = true
                    )
                    OutlinedTextField(value = values[10], onValueChange = { values[10] = it }, label = { Text("العنوان") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                }

                FormSection(title = "ملاحظات", subtitle = "معلومات إضافية تساعد في متابعة الطفل") {
                    OutlinedTextField(value = values[11], onValueChange = { values[11] = it }, label = { Text("ملاحظات خاصة بالطفل") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                }
                validationMessage?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                Text("* الحقول المطلوبة", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            Button(onClick = {
                val nameParts = values[0].trim().split(Regex("\\s+")).filter { it.isNotBlank() }
                when {
                    nameParts.size < 4 -> validationMessage = "من فضلك اكتب اسم الطفل رباعيًا"
                    values[3].isBlank() -> validationMessage = "اختر تاريخ الالتحاق"
                    else -> { validationMessage = null; onSave(values.toList()) }
                }
            }) { Text(if (student == null) "حفظ ملف الطالب" else "حفظ التعديلات") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}


@Composable
private fun FormSection(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.42f))
    ) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            content()
        }
    }
}

private fun parseStudentDate(value: String): LocalDate? {
    val normalized = value.map { ch -> when (ch) {
        in '٠'..'٩' -> ('0'.code + (ch - '٠')).toChar()
        in '۰'..'۹' -> ('0'.code + (ch - '۰')).toChar()
        else -> ch
    } }.joinToString("").trim()
    return runCatching {
        when {
            normalized.contains('/') -> {
                val parts = normalized.split('/')
                require(parts.size == 3)
                LocalDate.of(parts[2].toInt(), parts[1].toInt(), parts[0].toInt())
            }
            normalized.contains('-') -> LocalDate.parse(normalized)
            normalized.length == 8 && normalized.all(Char::isDigit) ->
                LocalDate.of(normalized.substring(4, 8).toInt(), normalized.substring(2, 4).toInt(), normalized.substring(0, 2).toInt())
            else -> null
        }
    }.getOrNull()
}

private fun formatStudentDate(date: LocalDate): String =
    "%02d/%02d/%04d".format(java.util.Locale.US, date.dayOfMonth, date.monthValue, date.year)

@Composable
private fun DateInputField(label: String, value: String, onClick: () -> Unit, optional: Boolean = false) {
    OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 13.dp)) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(label + if (optional) " (اختياري)" else "", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

private fun normalizeSearch(value: String): String = value
    .map { ch -> when (ch) { in '٠'..'٩' -> ('0'.code + (ch - '٠')).toChar(); in '۰'..'۹' -> ('0'.code + (ch - '۰')).toChar(); else -> ch } }
    .filter { it.isLetterOrDigit() }
    .joinToString("")
    .lowercase()
