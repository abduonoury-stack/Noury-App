# بيان إصدار Noury App 2.2.86

- Version Name: `2.2.86`
- Version Code: `105`
- قاعدة البيانات: Room `26` (دون تغيير)
- نوع التسليم الحالي: مصدر Android Kotlin/Jetpack Compose
- APK: غير مرفق؛ يتطلب البناء والاختبار عبر Android SDK وGradle.

## نطاق هذه الدفعة
تحسينات مشتركة لنظام الألوان والخطوط والبطاقات وشريط العنوان، وتحديثات مرئية لشاشات الرئيسية والإعدادات والتحصيل والاشتراك، دون تغيير منطق المحاسبة أو بيانات قاعدة البيانات.

## شرط اعتماد الإصدار
لا يعتمد الإصدار كتسليم نهائي قابل للتثبيت إلا بعد نجاح:
1. `testDebugUnitTest`
2. `assembleDebug`
3. `connectedDebugAndroidTest`

ويُستخرج APK من `app/build/outputs/apk/debug/app-debug.apk` بعد نجاح سير العمل.
