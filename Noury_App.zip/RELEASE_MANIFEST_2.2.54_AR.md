# بيان تسليم المصدر — Little Dreams Academy 2.2.54

- الإصدار: 2.2.54
- versionCode: 73
- Room database version: 20
- Full database backup version: 11
- نقطة الانطلاق: مصدر 2.2.53
- الغرض: فصل حسابات النقدية والبنوك والمحافظ، وتوحيد إسناد الحركات الجديدة إلى الحساب الصحيح.

## الملفات الأساسية المتغيرة
- `app/src/main/java/com/tahseel/students/data/CashAccounts.kt`
- `app/src/main/java/com/tahseel/students/data/CashLedger.kt`
- `app/src/main/java/com/tahseel/students/data/CashControl.kt`
- `app/src/main/java/com/tahseel/students/data/AppDatabase.kt`
- `app/src/main/java/com/tahseel/students/data/Payment.kt`
- `app/src/main/java/com/tahseel/students/data/PaymentRepository.kt`
- `app/src/main/java/com/tahseel/students/data/SubscriptionRepository.kt`
- `app/src/main/java/com/tahseel/students/data/Expense.kt`
- `app/src/main/java/com/tahseel/students/data/FeeModels.kt`
- `app/src/main/java/com/tahseel/students/data/HrModels.kt`
- `app/src/main/java/com/tahseel/students/data/RefundRepository.kt`
- `app/src/main/java/com/tahseel/students/util/FullDatabaseBackup.kt`
- شاشات إدارة الحسابات والتحصيل والمصروفات والمرتبات والاسترداد وتسوية الانسحاب والتقارير.

## التحقق المنفذ
- محاكاة SQLite لترحيل 19 إلى 20: نجحت، مع فحص العلاقات الأجنبية دون أخطاء.
- فحص ترجمة Kotlin مستقل لطبقة دفتر الحركة والحسابات/ضبط النقدية باستخدام stubs: نجح.
- اختبار دخان لمنطق فصل النقدية والبنك والتحويل والحركات غير المصنفة: نجح.
- لم يتم تشغيل Gradle unit tests أو Android instrumentation tests، ولم يتم بناء APK؛ بيئة العمل لا تحتوي على Gradle Wrapper أو Android SDK.
