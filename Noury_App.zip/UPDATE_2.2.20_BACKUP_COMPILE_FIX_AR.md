# إصلاح الإصدار 2.2.20 — خطأ تجميع النسخ الاحتياطي

## سبب الخطأ
كان فحص عدد السجلات يستدعي `root.getJSONArray("tables")`، بينما `JSONObject` لا يوفّر `getJSONArray` باسم المفتاح؛ هذه الدالة تتوقع فهرسًا صحيحًا، ولذلك ظهر Type mismatch: String but Int was expected.

## الإصلاح
استخدمنا كائن الجداول الذي تم الحصول عليه مسبقًا من `root.getJSONObject("tables")`، ثم نقرأ كل جدول عبر `tablesObject.getJSONArray(it)`. لم يتغير منطق النسخ أو التحقق أو الاستعادة.

## الإصدار
versionCode=40، versionName=2.2.20.

## التحقق
تم فحص سلامة أرشيف ZIP. لم يتم تشغيل Gradle أو compileDebugKotlin في بيئة العمل الحالية لعدم توفر Gradle wrapper التنفيذي/أمر Gradle؛ لذلك يلزم إعادة تشغيل GitHub Actions للتأكد من نجاح التجميع.
