# Release Manifest — Noury 2.2.106

- Version name: `2.2.106` — Version code: `126` — Application id: `com.noury.academy.offline` (لم يتغير)
- Database schema: `32` (لا هجرات، لا تغيير في الجداول أو الحسابات المالية)
- Backup format: `16` (يقبل 2–16)
- Permissions: السياسة المركزية في **وضع المراقبة** (`PermissionPolicy.enforcing = false`). لا منع فعليًا للعمليات؛ الرفض المحتمل يُسجَّل `PERMISSION_WOULD_DENY`.
- Build status: **لم يُبنَ ولم تُشغَّل الاختبارات في بيئة التحضير** (لا Gradle/SDK/شبكة). يجب تشغيل GitHub Actions: Noury Tests (workflow_dispatch).
