# Noury 2.3.0 — Playful Professional UI (المرحلة الأولى: الأساس)

## ما تم فعليًا
- Theme.kt: لوحة ألوان جديدة (سماوي، تركواز، أصفر دافئ، مرجاني، نعناعي) بنفس أسماء LdaPalette، فتنتقل إلى كل الشاشات تلقائيًا.
- NouryDesign.kt (جديد): NourySpacing, NouryRadius, NouryStatusBadge, NouryMetricCard, NouryEmptyState, NouryLoadingState, NouryErrorState, NourySectionHeader, NouryTextField, NouryConfirmDialog, NourySheet.
- DashboardScreen: قسم «ملخص الأكاديمية» ببيانات حقيقية من DashboardViewModel، يُعرض حسب صلاحيات الدور (UserRoles.canOpen).
- UserLoginScreen: خلفية متدرجة، شعار Noury، عرض أقصى للبطاقة، وإبقاء منطق الدخول وتشفير كلمات المرور كما هو.
- build.gradle.kts: versionName 2.3.0 / versionCode 127.

## لم يُنفَّذ بعد
- Splash، تحويل بقية الشاشات (~35 ملفًا) لاستخدام مكونات NouryDesign، التنقل السفلي، مؤشرات الحضور/الموظفين/التنبيهات في الداشبورد (تحتاج استعلامات جديدة).

## لم يُشغَّل
- البناء والاختبارات: بيئة التطوير لا تحتوي Android SDK ولا اتصال شبكة. الكود لم يُترجم بعد.

## لم يتغير
قاعدة البيانات، Room، الحسابات، تسجيل الدخول، PermissionGuard، النسخ الاحتياطي.
