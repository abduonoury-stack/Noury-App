# Noury 2.2.100 — Release Manifest

- Version name: `2.2.100-expenses-vendors-stage3`
- Version code: `120`
- Database schema: `28`
- Scope: expense and vendor workflow redesign (Stage 3)
- Database migration: none (query/UI-only changes)
- Data deletion or automatic historical re-posting: none
- Build status: source package prepared; Android APK build not run in this environment
- Required before production: Gradle build, Room query compilation, Android UI tests, backup/restore verification, and reconciliation against a copy of real operational data.
