# Noury – Offline Single-Device Edition

This repository contains the standalone, single-device Noury Android app.

See [README_AR.md](README_AR.md) for the full Arabic setup, offline operation, backup, and build instructions.

This edition has no sign-in, Supabase client, network permission, teacher assignment, cloud upload, or automatic synchronization. It intentionally retains the on-device Room/SQLite database for student, attendance, finance, and report data.
