# Release Manifest — Noury 2.3.1

- Version name: `2.3.1` — Version code: `128` — Application id: `com.noury.academy.offline` (لم يتغير)
- Database schema: `32` (لا هجرات ولا تغيير في جداول Room)
- Backup format: `17` (يقبل 2–17، بما فيها النسخ القديمة التي لا تحتوي على شعار)
- Academy identity: تضمين شعار الأكاديمية في النسخ اليدوية ونسخ الأمان واستعادته من ملف الهوية.
- Printed documents: شعار الأكاديمية الحقيقي في PDF الإيصالات والتقرير المالي الشهري وكشف الطلاب.
- Financial operations, student records, authentication and permissions: لا تغيير في منطقها.
- Build status: **لم يُبنَ ولم تُشغَّل الاختبارات في بيئة التحضير** لعدم توفر Gradle/Android SDK. يجب تشغيل GitHub Actions قبل اعتماد APK.
