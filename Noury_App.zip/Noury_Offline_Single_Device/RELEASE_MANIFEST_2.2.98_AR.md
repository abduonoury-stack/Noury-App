# Noury 2.2.98 — Financial Management Stage 1

- versionCode: 118
- versionName: 2.2.98-financial-management-stage1
- Base source: 2.2.97 / versionCode 117
- Room database: 27 (no schema migration in this stage)

## Included
- Unified cash ledger now observes `accounting_expense_payments` and includes each actual payment using its real payment date and cash account.
- Added a unit test for accounting invoice payments in the cash ledger.
- Financial hub reorganized into six work centers: revenue/collections, accounting/expenses, cash/banks, payroll, refunds/settlements, and financial control.
- Receipt ledger and cash movement ledger are named distinctly.
- Removed duplicate payroll shortcut from the accounting screen. The finance payroll screen remains a read-only summary; payment actions remain in HR in this stage.
- No historical rows were deleted or automatically migrated.

## Verification status
- Source changes and basic structural checks completed.
- Android build and unit/instrumented tests were not run because Gradle and an executable Gradle wrapper are unavailable in this environment.
- Do not install on production data until CI build and tests pass.
