# Release Manifest — Noury 2.2.104

- Version name: `2.2.104-local-users-rbac`
- Version code: `124`
- Database schema: `32`
- Base: Noury 2.2.103 Accounting DAO Build Fix
- Scope: Single-device local user accounts, sign-in, role-based screen access, and account activity audit.
- Database migration: `31 -> 32` (creates `app_users` and `user_activity_logs`; preserves existing business and financial records).
- Build status: Source package prepared; Android Gradle build not run in this environment.
- Required first-run action: Create the initial System Administrator account. No default credentials are shipped.
