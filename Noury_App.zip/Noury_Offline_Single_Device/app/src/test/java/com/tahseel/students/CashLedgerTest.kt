package com.tahseel.students

import com.tahseel.students.data.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.YearMonth
import java.time.ZoneId

class CashLedgerTest {
    private val month = YearMonth.of(2026, 11)
    private val zone = ZoneId.of("UTC")
    private fun at(day: Int) = month.atDay(day).atStartOfDay(zone).toInstant().toEpochMilli()

    @Test fun cancelled_receipts_are_not_cash_movements_and_active_receipts_are_inflows() {
        val rows = buildCashMovements(
            payments = listOf(
                Payment(1, "طفل أ", "R1", 10000, at(2)),
                Payment(2, "طفل ب", "R2", 7000, at(3), isCancelled = true),
                // Full tuition exemption is stored as a zero-value, non-cash record.
                Payment(3, "طفل ج", "EXEMPT-1", 0, at(4), accountId = null)
            ), expenses = emptyList(), refundCredits = emptyList(), refundTransactions = emptyList(),
            settlements = emptyList(), settlementEvents = emptyList(), payrollPayments = emptyList(),
            payrollRows = emptyList(), employees = emptyList(), loans = emptyList()
        )
        val summary = summarizeCashMovements(rows, month, zone)
        assertEquals(10000L, summary.inflowsPiasters)
        assertEquals(0L, summary.outflowsPiasters)
        assertEquals(1, rows.size)
    }

    @Test fun hr_synced_and_manual_salary_expenses_are_excluded_to_avoid_double_counting() {
        val rows = buildCashMovements(
            payments = emptyList(), expenses = listOf(
                Expense(1, "المرتبات", "المرتبات", 50000, at(1), paidAmountPiasters = 50000, updatedAt = at(4)),
                Expense(2, "إيجار", "إيجار", 20000, at(1), paidAmountPiasters = 10000, updatedAt = at(5)),
                Expense(3, "المرتبات", "المرتبات", 50000, at(1), note = "HR_SYNC: auto", paidAmountPiasters = 50000, updatedAt = at(6))
            ), refundCredits = emptyList(), refundTransactions = emptyList(), settlements = emptyList(),
            settlementEvents = emptyList(), payrollPayments = emptyList(), payrollRows = emptyList(),
            employees = emptyList(), loans = emptyList()
        )
        val summary = summarizeCashMovements(rows, month, zone)
        assertEquals(10000L, summary.outflowsPiasters)
        assertEquals(1, summary.excludedCount)
        assertFalse(rows.first { it.id == "expense-legacy:1" }.includedInTotals)
        assertTrue(rows.first { it.id == "expense-legacy:2" }.includedInTotals)
        assertFalse(rows.any { it.id == "expense:3" })
    }

    @Test fun possible_duplicate_refund_pair_is_visible_but_excluded_from_totals() {
        val credit = RefundCredit(1, 7, 1, 5000, 0, createdAt = at(1))
        val settlement = StudentExitSettlement(1, 7, "2026-11", "2026-11-10", 10, 10000, 10000, 5000, 5000, 0)
        val tx = RefundTransaction(1, 1, 5000, at(12))
        val event = StudentExitSettlementEvent(1, 1, "refund_paid", 5000, "رد نقدي", at(12) + 60_000)
        val rows = buildCashMovements(
            payments = emptyList(), expenses = emptyList(), refundCredits = listOf(credit),
            refundTransactions = listOf(tx), settlements = listOf(settlement), settlementEvents = listOf(event),
            payrollPayments = emptyList(), payrollRows = emptyList(), employees = emptyList(), loans = emptyList()
        )
        val summary = summarizeCashMovements(rows, month, zone)
        assertEquals(0L, summary.outflowsPiasters)
        assertEquals(2, summary.excludedCount)
        assertTrue(rows.all { !it.includedInTotals })
    }

    @Test fun exact_expense_payments_use_each_payment_date_and_method_without_legacy_double_count() {
        val expense = Expense(10, "إيجار", "الإيجار", 30000, at(1), paidAmountPiasters = 15000, updatedAt = at(20))
        val exact = listOf(
            ExpensePayment(1, 10, 5000, at(4), "نقدي"),
            ExpensePayment(2, 10, 10000, at(12), "تحويل بنكي")
        )
        val rows = buildCashMovements(
            payments = emptyList(), expenses = listOf(expense), refundCredits = emptyList(), refundTransactions = emptyList(),
            settlements = emptyList(), settlementEvents = emptyList(), payrollPayments = emptyList(), payrollRows = emptyList(),
            employees = emptyList(), loans = emptyList(), expensePayments = exact
        )
        val summary = summarizeCashMovements(rows, month, zone)
        assertEquals(15000L, summary.outflowsPiasters)
        assertEquals(listOf(at(12), at(4)), rows.map { it.timestamp })
        assertTrue(rows.all { it.note.contains("طريقة الدفع") })
        assertFalse(rows.any { it.id.startsWith("expense-legacy:") })
    }

    @Test fun accounting_invoice_payments_are_included_as_dated_cash_outflows() {
        val invoice = AccountingExpense(
            id = 42, title = "إيجار المقر", categoryAccountId = 9, documentDate = at(1),
            dueDate = at(10), amountPiasters = 30000, periodKey = month.toString()
        )
        val payment = AccountingExpensePayment(
            id = 77, expenseId = 42, amountPiasters = 12000, paidAt = at(14),
            cashAccountId = "bank_main", method = "تحويل بنكي", note = "دفعة أولى"
        )
        val rows = buildCashMovements(
            payments = emptyList(), expenses = emptyList(), refundCredits = emptyList(), refundTransactions = emptyList(),
            settlements = emptyList(), settlementEvents = emptyList(), payrollPayments = emptyList(), payrollRows = emptyList(),
            employees = emptyList(), loans = emptyList(), accountingExpenses = listOf(invoice),
            accountingExpensePayments = listOf(payment)
        )
        val bank = summarizeCashMovements(rows, month, zone, accountId = "bank_main")
        assertEquals(12000L, bank.outflowsPiasters)
        assertEquals(1, bank.movements.size)
        assertEquals(at(14), bank.movements.single().timestamp)
        assertEquals("مصروف محاسبي", bank.movements.single().category)
        assertEquals("إيجار المقر", bank.movements.single().description)
        assertTrue(bank.movements.single().note.contains("تحويل بنكي"))
    }

    @Test fun legacy_paid_residual_remains_visible_when_exact_history_is_incomplete() {
        val expense = Expense(11, "كهرباء", "كهرباء", 20000, at(1), paidAmountPiasters = 12000, updatedAt = at(18))
        val rows = buildCashMovements(
            payments = emptyList(), expenses = listOf(expense), refundCredits = emptyList(), refundTransactions = emptyList(),
            settlements = emptyList(), settlementEvents = emptyList(), payrollPayments = emptyList(), payrollRows = emptyList(),
            employees = emptyList(), loans = emptyList(), expensePayments = listOf(ExpensePayment(3, 11, 7000, at(5), "نقدي"))
        )
        assertEquals(12000L, summarizeCashMovements(rows, month, zone).outflowsPiasters)
        assertEquals(5000L, rows.single { it.id == "expense-legacy:11" }.amountPiasters)
    }

    @Test fun bank_receipt_is_not_in_cash_drawer_and_transfer_moves_between_accounts() {
        val rows = buildCashMovements(
            payments = listOf(
                Payment(10, "طفل", "B1", 12000, at(2), accountId = "bank_main"),
                Payment(11, "طفل", "C1", 3000, at(3), accountId = "cash")
            ),
            expenses = emptyList(), refundCredits = emptyList(), refundTransactions = emptyList(),
            settlements = emptyList(), settlementEvents = emptyList(), payrollPayments = emptyList(),
            payrollRows = emptyList(), employees = emptyList(), loans = emptyList(),
            transfers = listOf(CashTransfer(1, "cash", "bank_main", 1000, at(4)))
        )
        val cash = summarizeCashMovements(rows, month, zone, accountId = "cash")
        val bank = summarizeCashMovements(rows, month, zone, accountId = "bank_main")
        assertEquals(3000L, cash.inflowsPiasters)
        assertEquals(1000L, cash.outflowsPiasters)
        assertEquals(13000L, bank.inflowsPiasters)
        assertEquals(0L, bank.outflowsPiasters)
        assertEquals(2000L, cash.netMovementPiasters)
        assertEquals(13000L, bank.netMovementPiasters)
    }

    @Test fun historical_unassigned_movements_are_not_reclassified_as_cash() {
        val rows = buildCashMovements(
            payments = listOf(Payment(12, "طفل", "OLD", 8000, at(5))),
            expenses = emptyList(), refundCredits = emptyList(), refundTransactions = emptyList(),
            settlements = emptyList(), settlementEvents = emptyList(), payrollPayments = emptyList(),
            payrollRows = emptyList(), employees = emptyList(), loans = emptyList()
        )
        val cash = summarizeCashMovements(rows, month, zone, accountId = "cash")
        assertEquals(0L, cash.inflowsPiasters)
        assertEquals(1, cash.unassignedCount)
    }

    @Test fun unassigned_legacy_movements_can_be_reviewed_without_assigning_them_to_an_account() {
        val rows = buildCashMovements(
            payments = listOf(Payment(13, "طفل", "OLD2", 9000, at(6))),
            expenses = emptyList(), refundCredits = emptyList(), refundTransactions = emptyList(),
            settlements = emptyList(), settlementEvents = emptyList(), payrollPayments = emptyList(),
            payrollRows = emptyList(), employees = emptyList(), loans = emptyList()
        )
        val unassigned = summarizeCashMovements(rows, month, zone, accountId = "__unassigned__")
        assertEquals(1, unassigned.movements.size)
        assertEquals(0L, unassigned.inflowsPiasters)
    }

    @Test fun new_employee_loan_uses_the_actual_issue_date_not_record_creation_date() {
        val loan = EmployeeLoan(20, 1, 5000, 1000, 5000, "2026-11", createdAt = at(2), issuedAt = at(9), accountId = "cash")
        val rows = buildCashMovements(
            payments = emptyList(), expenses = emptyList(), refundCredits = emptyList(), refundTransactions = emptyList(),
            settlements = emptyList(), settlementEvents = emptyList(), payrollPayments = emptyList(), payrollRows = emptyList(),
            employees = listOf(Employee(1, fullName = "موظف", jobTitle = "معلم", phone = "", hireDate = "2026-01-01", baseSalaryPiasters = 30000)),
            loans = listOf(loan)
        )
        assertEquals(at(9), rows.single().timestamp)
        assertTrue(rows.single().note.contains("تاريخ الصرف المسجل"))
    }

    @Test fun active_payroll_payments_and_employee_loans_are_cash_outflows() {
        val employee = Employee(1, fullName = "موظف", jobTitle = "معلم", phone = "", hireDate = "2026-01-01", baseSalaryPiasters = 30000)
        val payroll = EmployeePayroll(1, 1, "2026-11", 30000, netPiasters = 30000, paidPiasters = 10000)
        val payrollPayment = EmployeePayrollPayment(1, 1, 10000, "2026-11-08", "cash")
        val loan = EmployeeLoan(1, 1, 5000, 1000, 5000, "2026-11", createdAt = at(9))
        val rows = buildCashMovements(
            payments = emptyList(), expenses = emptyList(), refundCredits = emptyList(), refundTransactions = emptyList(),
            settlements = emptyList(), settlementEvents = emptyList(), payrollPayments = listOf(payrollPayment),
            payrollRows = listOf(payroll), employees = listOf(employee), loans = listOf(loan)
        )
        val summary = summarizeCashMovements(rows, month, zone)
        assertEquals(15000L, summary.outflowsPiasters)
    }
    @Test fun reversed_paid_salary_keeps_original_outflow_and_adds_only_actual_recovery_as_inflow() {
        val original = EmployeePayrollPayment(
            id = 50, payrollId = 7, amountPiasters = 10000, paymentDate = "2026-11-10",
            paymentMethod = "نقدي", status = "reversed", voidedAt = at(12), voidReason = "صرف بالخطأ", accountId = "cash"
        )
        val recoveries = listOf(
            EmployeePayrollRecoveryTransaction(id = 1, reversalId = 3, amountPiasters = 4000, receivedAt = at(15), accountId = "cash")
        )
        val rows = buildCashMovements(
            payments = emptyList(), expenses = emptyList(), refundCredits = emptyList(), refundTransactions = emptyList(),
            settlements = emptyList(), settlementEvents = emptyList(), payrollPayments = listOf(original),
            payrollRows = listOf(EmployeePayroll(id = 7, employeeId = 2, monthKey = "2026-11", basePiasters = 10000, netPiasters = 10000)),
            employees = listOf(Employee(id = 2, fullName = "موظف", jobTitle = "معلم", phone = "", hireDate = "2025-01-01", baseSalaryPiasters = 10000)),
            loans = emptyList(), payrollRecoveries = recoveries
        )
        val summary = summarizeCashMovements(rows, month, zone, accountId = "cash")
        assertEquals(4000L, summary.inflowsPiasters)
        assertEquals(10000L, summary.outflowsPiasters)
        assertEquals(-6000L, summary.netMovementPiasters)
        assertTrue(rows.any { it.sourceReference == "employee_payroll_payments#50" && it.direction == CashDirection.OUTFLOW })
        assertTrue(rows.any { it.sourceReference == "employee_payroll_recovery_transactions#1" && it.direction == CashDirection.INFLOW })
    }

    @Test fun exit_settlement_refund_credit_and_event_are_counted_once_in_cash_ledger() {
        val settlement = StudentExitSettlement(id = 22, studentId = 7, periodKey = "2026-11", withdrawalDate = "2026-11-12", attendedDays = 10, monthlyFeePiasters = 10000, paidAmountPiasters = 10000, earnedAmountPiasters = 4000, refundAmountPiasters = 6000, amountDuePiasters = 0, refundedAmountPiasters = 2500)
        val credit = RefundCredit(id = 5, studentId = 7, paymentId = null, originalAmountPiasters = 6000, remainingAmountPiasters = 3500, sourceType = "exit_settlement", sourceId = 22)
        val tx = RefundTransaction(id = 9, refundCreditId = 5, amountPiasters = 2500, refundedAt = at(15), method = "exit_settlement", accountId = "cash")
        val event = StudentExitSettlementEvent(id = 11, settlementId = 22, eventType = "refund_paid", amountPiasters = 2500, details = "صرف", createdAt = at(15) + 1000, accountId = "cash")
        val rows = buildCashMovements(
            payments = emptyList(), expenses = emptyList(), refundCredits = listOf(credit), refundTransactions = listOf(tx),
            settlements = listOf(settlement), settlementEvents = listOf(event), payrollPayments = emptyList(),
            payrollRows = emptyList(), employees = emptyList(), loans = emptyList()
        )
        val summary = summarizeCashMovements(rows, month, zone, accountId = "cash")
        assertEquals(2500L, summary.outflowsPiasters)
        assertEquals(1, summary.excludedCount)
        assertTrue(rows.single { it.id == "refund:9" }.includedInTotals)
        assertFalse(rows.single { it.id == "exit-refund:11" }.includedInTotals)
    }

}
