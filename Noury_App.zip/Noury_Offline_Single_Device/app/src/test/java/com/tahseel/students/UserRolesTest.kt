package com.tahseel.students

import com.tahseel.students.data.UserRoles
import org.junit.Assert.*
import org.junit.Test

class UserRolesTest {
    @Test fun adminCanOpenAllRoutes() {
        assertTrue(UserRoles.canOpen(UserRoles.ADMIN, "users"))
        assertTrue(UserRoles.canOpen(UserRoles.ADMIN, "financial-control"))
        assertTrue(UserRoles.canOpen(UserRoles.ADMIN, "system-settings"))
    }

    @Test fun viewerIsRestrictedToReadOnlyReportsAndDashboard() {
        assertTrue(UserRoles.canOpen(UserRoles.VIEWER, "dashboard"))
        assertTrue(UserRoles.canOpen(UserRoles.VIEWER, "reports"))
        assertFalse(UserRoles.canOpen(UserRoles.VIEWER, "add"))
        assertFalse(UserRoles.canOpen(UserRoles.VIEWER, "expenses"))
        assertFalse(UserRoles.canOpen(UserRoles.VIEWER, "users"))
    }

    @Test fun cashierCannotAccessPayrollOrUserAdministration() {
        assertTrue(UserRoles.canOpen(UserRoles.CASHIER, "add"))
        assertTrue(UserRoles.canOpen(UserRoles.CASHIER, "cash-accounts"))
        assertFalse(UserRoles.canOpen(UserRoles.CASHIER, "hr"))
        assertFalse(UserRoles.canOpen(UserRoles.CASHIER, "users"))
    }

    @Test fun nurseryCannotAccessAccountingScreens() {
        assertTrue(UserRoles.canOpen(UserRoles.NURSERY, "attendance"))
        assertTrue(UserRoles.canOpen(UserRoles.NURSERY, "students"))
        assertFalse(UserRoles.canOpen(UserRoles.NURSERY, "expenses"))
        assertFalse(UserRoles.canOpen(UserRoles.NURSERY, "financial-control"))
    }
}
