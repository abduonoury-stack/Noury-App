package com.tahseel.students

import com.tahseel.students.util.FullDatabaseBackup
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.MessageDigest

class FullDatabaseBackupValidationTest {
    private fun checksum(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    private fun canonical(value: Any?): String = when (value) {
        null, JSONObject.NULL -> "null"
        is JSONObject -> value.keys().asSequence().toList().sorted().joinToString(prefix = "{", postfix = "}") { JSONObject.quote(it) + ":" + canonical(value.get(it)) }
        is JSONArray -> (0 until value.length()).joinToString(prefix = "[", postfix = "]") { canonical(value.get(it)) }
        is String -> JSONObject.quote(value)
        is Number, is Boolean -> value.toString()
        else -> JSONObject.quote(value.toString())
    }

    /** يبني نسخة من القائمة الفعلية للجداول، فلا تنكسر الاختبارات عند إضافة جدول جديد. */
    private fun backup(rowCount: Int, version: Int = FullDatabaseBackup.VERSION, omit: Set<String> = emptySet(), extra: (JSONObject) -> Unit = {}): String {
        val tables = JSONObject()
        FullDatabaseBackup.tables.filterNot { it in omit }.forEach { tables.put(it, JSONArray()) }
        tables.put("cash_accounts", JSONArray().put(JSONObject().put("id", "cash").put("name", "الخزينة النقدية").put("type", "cash").put("isActive", true).put("createdAt", 0L)))
        val root = JSONObject().put("app", FullDatabaseBackup.APP).put("version", version)
            .put("exportedAt", 123L).put("receiptProfile", JSONObject()).put("tables", tables).put("rowCount", rowCount)
        extra(root)
        root.put("checksum", checksum(canonical(root)))
        return root.toString()
    }

    @Test fun accepts_complete_empty_backup() {
        assertEquals(1, FullDatabaseBackup.rowCount(FullDatabaseBackup.validate(backup(1))))
    }

    @Test fun rejects_row_count_mismatch_even_when_checksum_is_valid() {
        val error = runCatching { FullDatabaseBackup.validate(backup(2)) }.exceptionOrNull()
        assertTrue(error?.message?.contains("عدد السجلات") == true)
    }

    @Test fun accepts_backup_after_json_object_keys_are_reordered() {
        val original = JSONObject(backup(1))
        val reordered = JSONObject()
        original.keys().asSequence().toList().sortedDescending().forEach { key -> reordered.put(key, original.get(key)) }
        assertEquals(1, FullDatabaseBackup.rowCount(FullDatabaseBackup.validate(reordered.toString())))
    }

    @Test fun rejects_missing_required_table() {
        val root = JSONObject(backup(0))
        root.getJSONObject("tables").remove("employees")
        root.remove("checksum")
        root.put("checksum", checksum(canonical(root)))
        val error = runCatching { FullDatabaseBackup.validate(root.toString()) }.exceptionOrNull()
        assertTrue(error != null)
    }

    @Test fun backup_tables_include_expense_month_locks() {
        assertTrue("expense_month_locks" in FullDatabaseBackup.tables)
    }

    @Test fun accepts_older_v13_backup_without_expense_month_locks() {
        val v13 = backup(1, version = 13, omit = setOf("expense_month_locks"))
        assertEquals(1, FullDatabaseBackup.rowCount(FullDatabaseBackup.validate(v13)))
    }

    @Test fun rejects_current_version_backup_missing_expense_month_locks() {
        val bad = backup(1, omit = setOf("expense_month_locks"))
        assertTrue(runCatching { FullDatabaseBackup.validate(bad) }.exceptionOrNull() != null)
    }

    @Test fun embedded_photos_are_covered_by_checksum_and_not_counted_as_rows() {
        val withPhotos = backup(1) { it.put("photos", JSONObject().put("student_1.jpg", "AAAA")).put("photosSkipped", 0) }
        val checked = FullDatabaseBackup.validate(withPhotos)
        assertEquals(1, FullDatabaseBackup.rowCount(checked))
        assertEquals(1, FullDatabaseBackup.photoCount(checked))
        // أي تعديل في الصور بعد الحفظ يجب أن يُكشف.
        val tampered = JSONObject(withPhotos); tampered.getJSONObject("photos").put("student_1.jpg", "BBBB")
        assertTrue(runCatching { FullDatabaseBackup.validate(tampered.toString()) }.exceptionOrNull() != null)
    }

    @Test fun row_count_matching_ignores_tables_missing_from_older_reference() {
        val current = JSONObject(backup(1)); val old = backup(1, version = 13, omit = setOf("expense_month_locks"))
        current.getJSONObject("tables").put("expense_month_locks", JSONArray().put(JSONObject().put("monthKey", "2026-01")))
        assertEquals(1, FullDatabaseBackup.rowCountMatching(current.toString(), old))
    }

    private val financialControl = setOf("cash_statement_lines", "cash_statement_balances", "financial_period_close_audits")

    @Test fun backup_tables_include_financial_control_tables_after_their_parents() {
        val order = FullDatabaseBackup.tables
        assertEquals(17, FullDatabaseBackup.VERSION)
        financialControl.forEach { assertTrue(it in order) }
        // الحذف بالعكس: يجب أن تأتي هذه الجداول بعد cash_accounts وjournal_lines في الإدخال.
        financialControl.forEach { t ->
            assertTrue(order.indexOf(t) > order.indexOf("cash_accounts"))
            assertTrue(order.indexOf(t) > order.indexOf("journal_lines"))
        }
    }

    @Test fun accepts_older_v15_backup_without_financial_control_tables() {
        val v15 = backup(1, version = 15, omit = financialControl)
        assertEquals(1, FullDatabaseBackup.rowCount(FullDatabaseBackup.validate(v15)))
    }

    @Test fun rejects_v16_backup_missing_any_financial_control_table() {
        financialControl.forEach { missing ->
            val bad = backup(1, version = 16, omit = setOf(missing))
            assertTrue(missing, runCatching { FullDatabaseBackup.validate(bad) }.exceptionOrNull() != null)
        }
    }

    @Test fun rejects_v16_backup_with_tampered_financial_control_rows() {
        val good = JSONObject(backup(1, version = 16))
        good.getJSONObject("tables").getJSONArray("cash_statement_lines").put(JSONObject().put("id", 1))
        // الصفوف أضيفت بعد حساب المجموع الاختباري، فيجب رفض النسخة.
        assertTrue(runCatching { FullDatabaseBackup.validate(good.toString()) }.exceptionOrNull() != null)
    }

    private fun resealed(root: JSONObject): String {
        root.remove("checksum"); root.put("checksum", checksum(canonical(root))); return root.toString()
    }

    @Test fun v16_backup_with_rows_in_financial_control_tables_is_accepted_when_row_count_matches() {
        val root = JSONObject(backup(1, version = 16))
        val t = root.getJSONObject("tables")
        t.getJSONArray("cash_statement_lines").put(JSONObject().put("id", 1))
        t.getJSONArray("cash_statement_balances").put(JSONObject().put("id", 1))
        t.getJSONArray("financial_period_close_audits").put(JSONObject().put("id", 1))
        root.put("rowCount", 4)
        assertEquals(4, FullDatabaseBackup.rowCount(FullDatabaseBackup.validate(resealed(root))))
    }

    @Test fun v16_row_count_must_include_financial_control_rows() {
        val root = JSONObject(backup(1, version = 16))
        root.getJSONObject("tables").getJSONArray("cash_statement_lines").put(JSONObject().put("id", 1))
        // rowCount بقي 1 رغم وجود سجل إضافي: نسخة مبتورة منطقيًا يجب رفضها مع أن المجموع الاختباري صحيح.
        val error = runCatching { FullDatabaseBackup.validate(resealed(root)) }.exceptionOrNull()
        assertTrue(error?.message?.contains("عدد السجلات") == true)
    }

    @Test fun rejects_future_and_ancient_versions() {
        listOf(FullDatabaseBackup.VERSION + 1, 1, 0).forEach { v ->
            val error = runCatching { FullDatabaseBackup.validate(backup(1, version = v)) }.exceptionOrNull()
            assertTrue("v$v", error?.message?.contains("غير مدعوم") == true)
        }
    }

    @Test fun accepts_v14_and_v15_backups_missing_newer_tables() {
        val v15 = backup(1, version = 15, omit = financialControl)
        val v14 = backup(1, version = 14, omit = financialControl + "cash_account_ledger_mappings")
        assertEquals(1, FullDatabaseBackup.rowCount(FullDatabaseBackup.validate(v15)))
        assertEquals(1, FullDatabaseBackup.rowCount(FullDatabaseBackup.validate(v14)))
    }

    @Test fun v15_backup_is_still_valid_when_a_tool_added_extra_new_tables() {
        // الجداول الزائدة مغطاة بالمجموع الاختباري، ولا تُشترط لنسخة v15 ولا تُفشلها.
        val root = JSONObject(backup(1, version = 15))
        root.getJSONObject("tables").getJSONArray("cash_statement_lines").put(JSONObject().put("id", 9))
        assertTrue(runCatching { FullDatabaseBackup.validate(resealed(root)) }.isSuccess)
    }

    @Test fun table_list_has_no_duplicates_and_fk_parents_precede_children() {
        val order = FullDatabaseBackup.tables
        assertEquals(order.size, order.toSet().size)
        listOf("journal_entries", "journal_lines", "accounting_accounts", "cash_accounts", "students").forEach { assertTrue(it in order) }
        assertTrue(order.indexOf("journal_entries") < order.indexOf("journal_lines"))
        assertTrue(order.indexOf("accounting_accounts") < order.indexOf("journal_lines"))
        assertTrue(order.indexOf("students") < order.indexOf("payments"))
    }

    @Test fun v16_backup_without_academy_logo_remains_compatible() {
        val legacy = backup(1, version = 16)
        val checked = FullDatabaseBackup.validate(legacy)
        assertEquals(1, FullDatabaseBackup.rowCount(checked))
        assertTrue(JSONObject(checked).getJSONObject("receiptProfile").has("logoBase64").not())
    }

    @Test fun v17_backup_preserves_academy_logo_inside_receipt_profile() {
        val encoded = java.util.Base64.getEncoder().encodeToString(byteArrayOf(1, 2, 3, 4, 5))
        val root = JSONObject(backup(1))
        root.getJSONObject("receiptProfile").put("logoBase64", encoded)
        val checked = JSONObject(FullDatabaseBackup.validate(resealed(root)))
        assertEquals(encoded, checked.getJSONObject("receiptProfile").getString("logoBase64"))
    }

    @Test fun rejects_invalid_academy_logo_base64_even_when_checksum_matches() {
        val root = JSONObject(backup(1))
        root.getJSONObject("receiptProfile").put("logoBase64", "this-is-not-base64!")
        val error = runCatching { FullDatabaseBackup.validate(resealed(root)) }.exceptionOrNull()
        assertTrue(error?.message?.contains("شعار الأكاديمية") == true)
    }

    @Test fun users_and_activity_logs_are_not_part_of_the_backup() {
        assertTrue("app_users" !in FullDatabaseBackup.tables)
        assertTrue("user_activity_logs" !in FullDatabaseBackup.tables)
    }
}
