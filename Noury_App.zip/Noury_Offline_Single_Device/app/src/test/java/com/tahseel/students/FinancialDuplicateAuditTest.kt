package com.tahseel.students

import com.tahseel.students.data.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FinancialDuplicateAuditTest {
    @Test fun exact_same_direction_amount_account_within_window_is_candidate_only() {
        val rows = listOf(
            CashMovement("p1", 1_000L, CashDirection.OUTFLOW, "مصروف", "فاتورة", 5_000L, "expense#1", accountId = "cash"),
            CashMovement("p2", 2_000L, CashDirection.OUTFLOW, "مصروف", "فاتورة أخرى", 5_000L, "expense#2", accountId = "cash"),
            CashMovement("p3", 3_000L, CashDirection.INFLOW, "تحصيل", "إيصال", 5_000L, "payment#3", accountId = "cash"),
            CashMovement("p4", 4_000L, CashDirection.OUTFLOW, "مصروف", "بنك", 5_000L, "expense#4", accountId = "bank")
        )
        val candidates = findHistoricalDuplicateCandidates(rows, windowMillis = 2_000L)
        assertEquals(1, candidates.size)
        assertEquals("p1", candidates.single().firstMovementId)
        assertEquals("p2", candidates.single().secondMovementId)
        assertTrue(candidates.single().reason.contains("يلزم فحص"))
    }

    @Test fun same_source_reference_is_not_reported_as_duplicate() {
        val rows = listOf(
            CashMovement("view1", 1_000L, CashDirection.INFLOW, "تحصيل", "عملية", 900L, "same-source", accountId = "cash"),
            CashMovement("view2", 1_100L, CashDirection.INFLOW, "تحصيل", "عملية", 900L, "same-source", accountId = "cash")
        )
        assertTrue(findHistoricalDuplicateCandidates(rows).isEmpty())
    }
}
