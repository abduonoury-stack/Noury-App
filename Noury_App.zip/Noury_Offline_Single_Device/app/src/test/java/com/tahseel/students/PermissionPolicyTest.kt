package com.tahseel.students

import com.tahseel.students.data.AppUser
import com.tahseel.students.data.Permission
import com.tahseel.students.data.PermissionGuard
import com.tahseel.students.data.PermissionPolicy
import com.tahseel.students.data.SessionContext
import com.tahseel.students.data.UserRoles
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.time.LocalDate
import java.time.ZoneId

class PermissionPolicyTest {
    @After fun reset() { PermissionPolicy.enforcing = false; SessionContext.clear() }

    private val roles = listOf(UserRoles.ADMIN, UserRoles.FINANCE_MANAGER, UserRoles.ACCOUNTANT, UserRoles.CASHIER,
        UserRoles.NURSERY, UserRoles.RECEPTION, UserRoles.HR, UserRoles.VIEWER)

    private fun allowed(p: Permission) = roles.filter { PermissionPolicy.can(it, p) }.toSet()
    private fun user(role: String, id: Long = 1) = AppUser(id = id, username = "u$id", displayName = "u$id", role = role, passwordSalt = "s", passwordHash = "h")

    // ---------- المصفوفة (القرارات D1–D6) ----------
    @Test fun admin_has_every_permission() = Permission.values().forEach { assertTrue(PermissionPolicy.can(UserRoles.ADMIN, it)) }

    @Test fun unknown_or_missing_role_has_no_permission() = Permission.values().forEach {
        assertFalse(PermissionPolicy.can(null, it)); assertFalse(PermissionPolicy.can("GHOST", it))
    }

    @Test fun every_permission_has_an_explicit_grant_with_only_known_roles() {
        Permission.values().forEach { p ->
            assertTrue("no grant for $p", PermissionPolicy.rolesFor(p).isNotEmpty())
            assertTrue("unknown role in $p", roles.containsAll(PermissionPolicy.rolesFor(p)))
        }
    }

    @Test fun d1_finance_manager_and_accountant_are_separated() {
        listOf(Permission.REFUND_PAY, Permission.PAYROLL_PAY, Permission.PAYROLL_REVERSE, Permission.PAYROLL_RECOVERY,
            Permission.PERIOD_CLOSE, Permission.PAYMENT_CANCEL).forEach {
            assertTrue(it.name, PermissionPolicy.can(UserRoles.FINANCE_MANAGER, it))
            assertFalse(it.name, PermissionPolicy.can(UserRoles.ACCOUNTANT, it))
        }
        assertFalse(PermissionPolicy.can(UserRoles.ACCOUNTANT, Permission.REFUND_REQUEST))
    }

    @Test fun d2_cashier_requests_refunds_but_cannot_pay_them() {
        assertTrue(PermissionPolicy.can(UserRoles.CASHIER, Permission.REFUND_REQUEST))
        assertFalse(PermissionPolicy.can(UserRoles.CASHIER, Permission.REFUND_PAY))
        assertFalse(PermissionPolicy.can(UserRoles.RECEPTION, Permission.REFUND_REQUEST))
    }

    @Test fun d3_full_cancel_is_finance_manager_and_admin_only() {
        assertEquals(setOf(UserRoles.ADMIN, UserRoles.FINANCE_MANAGER), allowed(Permission.PAYMENT_CANCEL))
        assertEquals(setOf(UserRoles.ADMIN, UserRoles.FINANCE_MANAGER, UserRoles.ACCOUNTANT, UserRoles.CASHIER, UserRoles.RECEPTION),
            allowed(Permission.PAYMENT_CANCEL_SAME_DAY))
    }

    @Test fun d3_same_day_cancel_needs_today_receipt_and_a_reason() {
        val zone = ZoneId.of("Africa/Cairo")
        val noon = LocalDate.of(2026, 11, 28).atTime(12, 0).atZone(zone).toInstant().toEpochMilli()
        val lateNight = LocalDate.of(2026, 11, 28).atTime(23, 59).atZone(zone).toInstant().toEpochMilli()
        val yesterday = LocalDate.of(2026, 11, 27).atTime(23, 59).atZone(zone).toInstant().toEpochMilli()
        fun ok(role: String?, created: Long?, reason: String = "خطأ في المبلغ") =
            PermissionPolicy.canCancelPaymentSameDay(role, created, lateNight, reason, zone)
        assertTrue(ok(UserRoles.RECEPTION, noon))
        assertTrue(ok(UserRoles.CASHIER, noon))
        assertTrue(ok(UserRoles.ACCOUNTANT, noon))
        assertFalse("إيصال أمس", ok(UserRoles.RECEPTION, yesterday))
        assertFalse("بلا سبب", ok(UserRoles.RECEPTION, noon, "   "))
        assertFalse("تاريخ مجهول", ok(UserRoles.RECEPTION, null))
        assertFalse("دور بلا صلاحية", ok(UserRoles.NURSERY, noon))
        assertFalse("بلا دور", ok(null, noon))
        assertFalse(ok(UserRoles.HR, noon)); assertFalse(ok(UserRoles.VIEWER, noon))
    }

    @Test fun d4_hr_prepares_payroll_but_cannot_pay_or_reverse_it() {
        assertTrue(PermissionPolicy.can(UserRoles.HR, Permission.PAYROLL_PREPARE))
        listOf(Permission.PAYROLL_PAY, Permission.PAYROLL_REVERSE, Permission.PAYROLL_RECOVERY).forEach { assertFalse(PermissionPolicy.can(UserRoles.HR, it)) }
        assertEquals(setOf(UserRoles.ADMIN, UserRoles.FINANCE_MANAGER), allowed(Permission.PAYROLL_PAY))
    }

    @Test fun d5_stocktake_excludes_hr_viewer_and_viewer_has_nothing_sensitive() {
        assertEquals(setOf(UserRoles.ADMIN, UserRoles.FINANCE_MANAGER, UserRoles.ACCOUNTANT), allowed(Permission.STOCKTAKE_SAVE))
        Permission.values().forEach { assertFalse(it.name, PermissionPolicy.can(UserRoles.VIEWER, it)) }
    }

    @Test fun payments_csv_export_is_finance_only_and_never_hr_or_viewer() {
        assertEquals(setOf(UserRoles.ADMIN, UserRoles.FINANCE_MANAGER, UserRoles.ACCOUNTANT), allowed(Permission.DATA_EXPORT))
    }

    @Test fun backup_users_and_student_exit_are_admin_only() {
        listOf(Permission.BACKUP_CREATE, Permission.BACKUP_RESTORE, Permission.USER_MANAGE, Permission.STUDENT_EXIT_MANAGE).forEach {
            assertEquals(it.name, setOf(UserRoles.ADMIN), allowed(it))
        }
    }

    // ---------- الحارس: مراقبة مقابل فرض (D12) ----------
    @Test fun monitor_mode_logs_would_be_denials_without_blocking_and_says_so() {
        val logged = mutableListOf<Pair<String, String>>()
        SessionContext.auditSink = { action, details -> logged += action to details }
        assertFalse(PermissionPolicy.enforcing)
        assertTrue(PermissionGuard.allow(Permission.REFUND_PAY, UserRoles.CASHIER))
        assertEquals(1, logged.size)
        assertEquals("PERMISSION_WOULD_DENY", logged[0].first)
        assertTrue("يجب ألا يوحي السجل بمنع فعلي", logged[0].second.contains("لم تُمنع"))
        assertTrue(PermissionGuard.allow(Permission.REFUND_PAY, UserRoles.FINANCE_MANAGER))
        assertEquals(1, logged.size)
    }

    @Test fun enforcing_mode_blocks_and_logs_denials_including_missing_session() {
        val logged = mutableListOf<Pair<String, String>>()
        SessionContext.auditSink = { action, details -> logged += action to details }
        PermissionPolicy.enforcing = true
        assertFalse(PermissionGuard.allow(Permission.PAYROLL_PAY, UserRoles.HR))
        assertFalse(PermissionGuard.allow(Permission.PAYROLL_PAY, null))
        assertTrue(PermissionGuard.allow(Permission.PAYROLL_PAY, UserRoles.FINANCE_MANAGER))
        assertEquals(listOf("PERMISSION_DENIED", "PERMISSION_DENIED"), logged.map { it.first })
        assertTrue(logged[0].second.contains("مُنعت"))
    }

    @Test fun a_throwing_audit_sink_never_changes_the_decision() {
        SessionContext.auditSink = { _, _ -> error("disk full") }
        assertTrue(PermissionGuard.allow(Permission.REFUND_PAY, UserRoles.CASHIER))
        PermissionPolicy.enforcing = true
        assertFalse(PermissionGuard.allow(Permission.REFUND_PAY, UserRoles.CASHIER))
    }

    @Test fun guard_uses_session_role_by_default() {
        SessionContext.set(user(UserRoles.HR)); PermissionPolicy.enforcing = true
        assertFalse(PermissionGuard.allow(Permission.PAYROLL_PAY))
        SessionContext.set(user(UserRoles.FINANCE_MANAGER, 2))
        assertTrue(PermissionGuard.allow(Permission.PAYROLL_PAY))
    }

    // ---------- الجلسة ----------
    @Test fun clear_removes_user_and_audit_sink_so_nothing_of_previous_user_remains() {
        var calls = 0
        SessionContext.set(user(UserRoles.FINANCE_MANAGER, 7))
        SessionContext.auditSink = { _, _ -> calls++ }
        assertEquals(7L, SessionContext.userId); assertEquals("u7", SessionContext.username)
        SessionContext.clear()
        assertNull(SessionContext.userId); assertNull(SessionContext.role); assertEquals("", SessionContext.username)
        assertNull(SessionContext.auditSink)
        PermissionGuard.allow(Permission.REFUND_PAY, UserRoles.CASHIER)  // لا مسجِّل: لا استدعاء
        assertEquals(0, calls)
        PermissionPolicy.enforcing = true
        assertFalse("بعد الخروج لا صلاحية", PermissionGuard.allow(Permission.REFUND_PAY))
    }

    @Test fun set_replaces_previous_user_completely() {
        SessionContext.set(user(UserRoles.ADMIN, 1)); SessionContext.set(user(UserRoles.VIEWER, 2))
        assertEquals(2L, SessionContext.userId); assertEquals(UserRoles.VIEWER, SessionContext.role)
    }

    // ---------- فتح الشاشات: تكافؤ مع السلوك السابق إلا academy-setup (D6) ----------
    private val routes = listOf("dashboard", "hub/a", "academy-setup", "academy-profile", "add", "add-student", "attendance", "backup", "birthdays",
        "cash-accounts", "classrooms", "collection-status", "details/1", "edit/1", "expenses", "finance-payroll", "financial-control", "hr",
        "ledger", "periods", "refunds", "reports", "search", "student-exit", "student-finance/1", "student-profile/1", "students",
        "subscription", "system-settings", "users", "unknown-route")

    /** نسخة حرفية من canOpen قبل 2.2.106 (مع academy-setup مشتركة). */
    private fun legacyCanOpen(role: String, route: String): Boolean {
        if (role == UserRoles.ADMIN) return true
        val r = route.substringBefore("/")
        if (r in setOf("dashboard", "hub", "academy-setup")) return true
        val finance = setOf("expenses", "financial-control", "finance-payroll", "cash-accounts", "refunds", "ledger")
        val collection = setOf("add", "edit", "subscription", "collection-status", "details")
        val settings = setOf("system-settings", "academy-profile", "periods", "backup", "users")
        return when (role) {
            UserRoles.FINANCE_MANAGER -> r in finance || r in collection || r in setOf("reports", "student-profile", "student-finance", "search")
            UserRoles.ACCOUNTANT -> r in finance || r in setOf("reports") || r in collection || r in setOf("student-profile", "student-finance", "search")
            UserRoles.CASHIER -> r in setOf("add", "edit", "details", "ledger", "cash-accounts", "refunds", "subscription", "collection-status")
            UserRoles.NURSERY -> r in setOf("students", "add-student", "student-profile", "search", "birthdays", "classrooms", "attendance")
            UserRoles.RECEPTION -> r in setOf("students", "add-student", "student-profile", "search", "birthdays", "add", "details", "subscription", "collection-status")
            UserRoles.HR -> r == "hr" || r == "reports"
            UserRoles.VIEWER -> r == "reports"
            else -> false
        } && r !in settings
    }

    @Test fun can_open_is_unchanged_except_academy_setup_is_admin_only() {
        for (role in roles) for (route in routes) {
            val expected = if (route == "academy-setup") role == UserRoles.ADMIN else legacyCanOpen(role, route)
            assertEquals("$role -> $route", expected, UserRoles.canOpen(role, route))
        }
    }

    // ---------- تغطية نقاط الحراسة في الكود المصدري ----------
    private fun mainSources(): List<File>? {
        val dir = listOf(File("src/main/java"), File("app/src/main/java")).firstOrNull { it.isDirectory } ?: return null
        return dir.walkTopDown().filter { it.isFile && it.extension == "kt" }.toList()
    }

    @Test fun every_permission_is_referenced_by_a_real_guard_outside_the_policy_file() {
        val files = mainSources() ?: return   // لا يفشل إن شُغّل من مجلد غير متوقع
        val text = files.filter { it.name != "PermissionPolicy.kt" }.joinToString("\n") { it.readText(Charsets.UTF_8) }
        Permission.values().forEach { p ->
            val marker = if (p == Permission.PAYMENT_CANCEL_SAME_DAY) "canCancelPaymentSameDay" else "Permission.${p.name}"
            assertTrue("لا نقطة حراسة للصلاحية ${p.name}", text.contains(marker))
        }
    }

    @Test fun guarded_sensitive_functions_still_contain_their_guard() {
        val files = mainSources() ?: return
        fun body(name: String, fn: String, guard: String) {
            val src = files.first { it.name == name }.readText(Charsets.UTF_8)
            val i = src.indexOf(fn); assertTrue("$name: $fn غير موجودة", i >= 0)
            val window = src.substring(i, minOf(src.length, i + 700))
            assertTrue("$name: $fn بلا $guard", window.contains(guard))
        }
        body("RefundViewModel.kt", "fun refund(", "Permission.REFUND_PAY")
        body("RefundViewModel.kt", "fun createManualCredit(", "Permission.REFUND_REQUEST")
        body("HrViewModel.kt", "fun recordPayrollPayment(", "Permission.PAYROLL_PAY")
        body("HrViewModel.kt", "fun reversePaidPayrollPayment(", "Permission.PAYROLL_REVERSE")
        body("HrViewModel.kt", "fun voidOrCorrectPayrollPayment(", "Permission.PAYROLL_REVERSE")
        body("HrViewModel.kt", "fun recordPayrollRecovery(", "Permission.PAYROLL_RECOVERY")
        body("HrViewModel.kt", "fun generatePayroll(", "Permission.PAYROLL_PREPARE")
        body("AccountingModels.kt", "open suspend fun closePeriod(", "Permission.PERIOD_CLOSE")
        body("AccountingModels.kt", "open suspend fun reopenPeriod(", "Permission.PERIOD_CLOSE")
        body("FinancialControl.kt", "suspend fun recordCashCount(", "Permission.STOCKTAKE_SAVE")
        body("StudentExitViewModel.kt", "fun cancelSettlement(", "Permission.STUDENT_EXIT_MANAGE")
        body("StudentExitViewModel.kt", "fun recordRefund(", "Permission.STUDENT_EXIT_MANAGE")
        body("BackupViewModel.kt", "fun exportCsv(", "Permission.DATA_EXPORT")
        body("BackupViewModel.kt", "fun confirmRestore(", "Permission.BACKUP_RESTORE")
        body("DetailsViewModel.kt", "fun cancel(", "Permission.PAYMENT_CANCEL")
    }
}
