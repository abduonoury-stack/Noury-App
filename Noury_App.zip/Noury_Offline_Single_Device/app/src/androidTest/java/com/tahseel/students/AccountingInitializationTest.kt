package com.tahseel.students

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.tahseel.students.data.AppDatabase
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith

/** Verifies accounting chart initialization for fresh and previously incomplete databases. */
@RunWith(AndroidJUnit4::class)
class AccountingInitializationTest {
    @Test fun fresh_database_contains_subscription_and_cash_posting_accounts() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        context.deleteDatabase("tahseel.db")
        val db = AppDatabase.create(context)
        try {
            assertNotNull("subscription revenue account 4100 must exist", db.accountingDao().accountByCode("4100"))
            assertNotNull("cash ledger account 1100 must exist", db.accountingDao().accountByCode("1100"))
            assertNotNull("bank ledger account 1110 must exist", db.accountingDao().accountByCode("1110"))
            assertNotNull("physical cash account must exist", db.cashAccountDao().find("cash"))
            assertNotNull("physical cash must have a dedicated general-ledger mapping", db.cashAccountDao().ledgerMapping("cash"))
        } finally {
            db.close()
            context.deleteDatabase("tahseel.db")
        }
    }

    @Test fun opening_an_incomplete_database_repairs_missing_subscription_revenue_account() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        context.deleteDatabase("tahseel.db")
        val first = AppDatabase.create(context)
        first.openHelper.writableDatabase.execSQL("DELETE FROM accounting_accounts WHERE code='4100'")
        first.close()

        val reopened = AppDatabase.create(context)
        try {
            assertNotNull("missing subscription revenue account must be repaired on open", reopened.accountingDao().accountByCode("4100"))
        } finally {
            reopened.close()
            context.deleteDatabase("tahseel.db")
        }
    }
}
