package com.tahseel.students

import android.content.Context
import android.graphics.Bitmap
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.tahseel.students.data.AppDatabase
import com.tahseel.students.data.Student
import kotlinx.coroutines.runBlocking
import com.tahseel.students.util.AcademyProfileStore
import com.tahseel.students.util.FullDatabaseBackup
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.ByteArrayOutputStream
import java.io.File

/** Round-trip: export -> wipe -> restore on a real Room database, including photos and sync capture. */
@RunWith(AndroidJUnit4::class)
class BackupRestoreInstrumentedTest {
    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var photoDir: File

    @Before fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        context.deleteDatabase("tahseel.db")
        db = AppDatabase.create(context)
        photoDir = File(context.cacheDir, "student_photos_test").apply { deleteRecursively(); mkdirs() }
    }

    @After fun tearDown() {
        db.close()
        context.deleteDatabase("tahseel.db")
        photoDir.deleteRecursively()
        AcademyProfileStore.removeLogo(context)
        context.getSharedPreferences("receipt_profile", Context.MODE_PRIVATE).edit().clear().commit()
    }

    private fun count(table: String): Long =
        db.openHelper.writableDatabase.query("SELECT COUNT(*) FROM `$table`").use { it.moveToFirst(); it.getLong(0) }

    @Test fun academy_logo_is_backed_up_and_restored_but_legacy_backup_preserves_current_logo() {
        val prefs = context.getSharedPreferences("receipt_profile", Context.MODE_PRIVATE)
        prefs.edit().clear().commit()
        AcademyProfileStore.removeLogo(context)

        val bitmap = Bitmap.createBitmap(4, 4, Bitmap.Config.ARGB_8888)
        val logoBytes = ByteArrayOutputStream().use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            out.toByteArray()
        }
        bitmap.recycle()
        val encoded = java.util.Base64.getEncoder().encodeToString(logoBytes)
        val profile = org.json.JSONObject()
            .put("name", "أكاديمية اختبار")
            .put("address", "عنوان الاختبار")
            .put("phone", "01234567890")
            .put(AcademyProfileStore.BACKUP_LOGO_FIELD, encoded)

        val restored = AcademyProfileStore.restoreFromBackup(context, profile)
        assertTrue("logo must be written to private app storage", restored.logoRestored)
        val logoPath = prefs.getString("logo_path", "").orEmpty()
        assertTrue(File(logoPath).isFile)
        val exportedProfile = AcademyProfileStore.exportJson(context)
        assertEquals(encoded, exportedProfile.getString(AcademyProfileStore.BACKUP_LOGO_FIELD))
        val fullBackup = FullDatabaseBackup.validate(
            FullDatabaseBackup.export(db.openHelper.writableDatabase, 99L, exportedProfile)
        )
        assertEquals(
            encoded,
            org.json.JSONObject(fullBackup).getJSONObject("receiptProfile")
                .getString(AcademyProfileStore.BACKUP_LOGO_FIELD)
        )

        val legacyProfile = org.json.JSONObject()
            .put("name", "أكاديمية قديمة")
            .put("address", "عنوان قديم")
            .put("phone", "01111111111")
        val legacyResult = AcademyProfileStore.restoreFromBackup(context, legacyProfile)
        assertTrue("legacy backup must be recognized as having no logo field", !legacyResult.logoFieldPresent)
        assertEquals("legacy restore must preserve the current logo", logoPath, prefs.getString("logo_path", ""))

        val withoutLogo = org.json.JSONObject(profile.toString()).put(AcademyProfileStore.BACKUP_LOGO_FIELD, "")
        val removed = AcademyProfileStore.restoreFromBackup(context, withoutLogo)
        assertTrue("a new-format backup explicitly saved without a logo removes the custom logo", removed.logoRemoved)
        assertEquals("", prefs.getString("logo_path", ""))
        AcademyProfileStore.removeLogo(context)
        prefs.edit().clear().commit()
    }

    @Test fun round_trip_restores_expense_month_locks_and_photos_without_growing_outbox() {
        val sql = db.openHelper.writableDatabase
        val photo = File(photoDir, "student_1.jpg").apply { writeBytes(byteArrayOf(1, 2, 3, 4)) }
        runBlocking { db.studentDao().insert(Student(fullName = "طالب", enrollmentDate = 1L, photoUri = android.net.Uri.fromFile(photo).toString())) }
        sql.execSQL("INSERT INTO expense_month_locks (monthKey,closedAt,closedBy,note) VALUES ('2026-01',5,'authorized_user','')")
        val json = FullDatabaseBackup.validate(FullDatabaseBackup.export(sql, 1L, org.json.JSONObject(), photoDir))
        assertEquals(1, FullDatabaseBackup.photoCount(json))

        sql.execSQL("DELETE FROM expense_month_locks"); sql.execSQL("DELETE FROM students"); photo.delete()
        val outboxBefore = count("noury_sync_outbox")
        FullDatabaseBackup.restore(sql, json, photoDir)

        assertEquals(1, count("expense_month_locks"))
        assertEquals(1, count("students"))
        assertEquals("restore must not enqueue sync events", outboxBefore, count("noury_sync_outbox"))
        val uri = sql.query("SELECT photoUri FROM students").use { it.moveToFirst(); it.getString(0) }
        assertTrue("photo must be rewritten to a restored local file", File(java.net.URI(uri).path).readBytes().contentEquals(byteArrayOf(1, 2, 3, 4)))
        val suppress = sql.query("SELECT suppress_capture FROM noury_sync_meta WHERE id=1").use { it.moveToFirst(); it.getInt(0) }
        assertEquals("capture must be re-enabled after restore", 0, suppress)
    }

    @Test fun failed_restore_rolls_back_everything_and_keeps_capture_enabled() {
        val sql = db.openHelper.writableDatabase
        sql.execSQL("INSERT INTO expense_month_locks (monthKey,closedAt,closedBy,note) VALUES ('2026-02',5,'authorized_user','')")
        val json = FullDatabaseBackup.validate(FullDatabaseBackup.export(sql, 1L))
        val broken = org.json.JSONObject(json)
        // صف بعمود غير موجود يفشل عند الإدخال بعد حذف الجداول -> يجب التراجع الكامل.
        broken.getJSONObject("tables").getJSONArray("expense_month_locks").put(org.json.JSONObject().put("noSuchColumn", 1))
        val failed = runCatching { FullDatabaseBackup.restore(sql, broken.toString()) }.isFailure
        assertTrue(failed)
        assertEquals(1, count("expense_month_locks"))
        assertEquals(0, sql.query("SELECT suppress_capture FROM noury_sync_meta WHERE id=1").use { it.moveToFirst(); it.getInt(0) })
    }

    private fun addStudent(name: String, uri: String?) =
        runBlocking { db.studentDao().insert(Student(fullName = name, enrollmentDate = 1L, photoUri = uri)) }

    private fun firstPhotoUri(): String =
        db.openHelper.writableDatabase.query("SELECT photoUri FROM students ORDER BY id LIMIT 1").use { it.moveToFirst(); it.getString(0) }

    @Test fun failed_restore_after_photos_were_written_removes_new_files_and_keeps_database_and_paths() {
        val sql = db.openHelper.writableDatabase
        val original = File(photoDir, "student_1.jpg").apply { writeBytes(byteArrayOf(9, 9, 9)) }
        val originalUri = android.net.Uri.fromFile(original).toString()
        addStudent("طالب", originalUri)
        sql.execSQL("INSERT INTO expense_month_locks (monthKey,closedAt,closedBy,note) VALUES ('2026-03',5,'authorized_user','')")
        val json = FullDatabaseBackup.validate(FullDatabaseBackup.export(sql, 1L, org.json.JSONObject(), photoDir))
        assertEquals(1, FullDatabaseBackup.photoCount(json))
        original.delete() // يجب أن تكتب الاستعادة ملفًا جديدًا فعلًا قبل أن تفشل

        val broken = org.json.JSONObject(json)
        // الجدول الأخير في الترتيب: تفشل الإدخالات بعد كتابة الصور وبعد إدخال جداول سابقة (students).
        broken.getJSONObject("tables").getJSONArray("expense_month_locks").put(org.json.JSONObject().put("noSuchColumn", 1))
        assertTrue(runCatching { FullDatabaseBackup.restore(sql, broken.toString(), photoDir) }.isFailure)

        assertTrue("restored photo files must be removed after a failed restore",
            photoDir.listFiles().orEmpty().none { it.name.startsWith("bk_") || it.name.endsWith(".tmp") })
        assertEquals(1, count("students"))
        assertEquals("student photo path must be unchanged", originalUri, firstPhotoUri())
        assertEquals(1, count("expense_month_locks"))
        assertEquals(0, sql.query("SELECT suppress_capture FROM noury_sync_meta WHERE id=1").use { it.moveToFirst(); it.getInt(0) })
        assertEquals("the original file was deleted by the test, DB must still report it missing", 1, FullDatabaseBackup.missingPhotoCount(sql))
    }

    @Test fun failed_restore_never_deletes_photo_files_that_existed_before() {
        val sql = db.openHelper.writableDatabase
        val original = File(photoDir, "student_2.jpg").apply { writeBytes(byteArrayOf(5, 6, 7)) }
        addStudent("طالب", android.net.Uri.fromFile(original).toString())
        val json = FullDatabaseBackup.validate(FullDatabaseBackup.export(sql, 1L, org.json.JSONObject(), photoDir))
        val broken = org.json.JSONObject(json)
        broken.getJSONObject("tables").getJSONArray("expense_month_locks").put(org.json.JSONObject().put("noSuchColumn", 1))
        assertTrue(runCatching { FullDatabaseBackup.restore(sql, broken.toString(), photoDir) }.isFailure)
        assertTrue("pre-existing photo must survive", original.isFile && original.readBytes().contentEquals(byteArrayOf(5, 6, 7)))
    }

    @Test fun export_counts_missing_and_oversize_photos_as_skipped() {
        val sql = db.openHelper.writableDatabase
        val a = File(photoDir, "a.jpg").apply { writeBytes(ByteArray(7 * 1024 * 1024)) }
        val b = File(photoDir, "b.jpg").apply { writeBytes(ByteArray(7 * 1024 * 1024) { 1 }) }
        val gone = File(photoDir, "gone.jpg") // never created
        addStudent("أ", android.net.Uri.fromFile(a).toString())
        addStudent("ب", android.net.Uri.fromFile(b).toString())
        addStudent("ج", android.net.Uri.fromFile(gone).toString())
        val json = FullDatabaseBackup.validate(FullDatabaseBackup.export(sql, 1L, org.json.JSONObject(), photoDir))
        assertEquals("only one 7MB photo fits under the 12MB cap", 1, FullDatabaseBackup.photoCount(json))
        assertEquals("one oversize + one missing file", 2, FullDatabaseBackup.photosSkipped(json))
    }

    @Test fun restore_without_embedded_photos_keeps_paths_and_reports_missing() {
        val sql = db.openHelper.writableDatabase
        val original = File(photoDir, "student_3.jpg").apply { writeBytes(byteArrayOf(1)) }
        val uri = android.net.Uri.fromFile(original).toString()
        addStudent("طالب", uri)
        val json = FullDatabaseBackup.validate(FullDatabaseBackup.export(sql, 1L)) // لا صور (مثل نسخة السحابة)
        assertEquals(0, FullDatabaseBackup.photoCount(json))
        original.delete()
        FullDatabaseBackup.restore(sql, json, photoDir)
        assertEquals("path must not be rewritten or blanked", uri, firstPhotoUri())
        assertEquals(1, FullDatabaseBackup.missingPhotoCount(sql))
    }

    private val insertStatementBalance =
        "INSERT INTO cash_statement_balances (cashAccountId,periodKey,openingBalancePiasters,closingBalancePiasters,note,savedAt) VALUES ('cash','2026-01',0,100,'',1)"

    @Test fun restoring_pre_v16_backup_over_statement_data_is_rejected_and_changes_nothing() {
        val sql = db.openHelper.writableDatabase
        val old = org.json.JSONObject(FullDatabaseBackup.validate(FullDatabaseBackup.export(sql, 1L)))
        old.put("version", 15)
        listOf("cash_statement_lines", "cash_statement_balances", "financial_period_close_audits").forEach { old.getJSONObject("tables").remove(it) }
        sql.execSQL(insertStatementBalance)
        val error = runCatching { FullDatabaseBackup.restore(sql, old.toString()) }.exceptionOrNull()
        assertTrue("يجب رفض الاستعادة", error?.message?.contains("مطابقة كشوف") == true)
        assertEquals("لا يضيع شيء", 1, count("cash_statement_balances"))
    }

    @Test fun v16_round_trip_restores_statement_balances_with_valid_foreign_keys() {
        val sql = db.openHelper.writableDatabase
        sql.execSQL(insertStatementBalance)
        val json = FullDatabaseBackup.validate(FullDatabaseBackup.export(sql, 1L))
        sql.execSQL("DELETE FROM cash_statement_balances")
        FullDatabaseBackup.restore(sql, json)
        assertEquals(1, count("cash_statement_balances"))
        assertEquals(0, sql.query("PRAGMA foreign_key_check").use { it.count })
    }

    @Test fun integrity_check_rejects_orphan_rows() {
        val sql = db.openHelper.writableDatabase
        try {
            sql.execSQL("PRAGMA foreign_keys=OFF")
            sql.execSQL("INSERT INTO cash_statement_balances (cashAccountId,periodKey,openingBalancePiasters,closingBalancePiasters,note,savedAt) VALUES ('ghost','2026-01',0,1,'',1)")
            val failed = runCatching { FullDatabaseBackup.verifyIntegrity(sql) }.isFailure
            assertTrue("يجب كشف السجل اليتيم", failed)
        } finally {
            sql.execSQL("DELETE FROM cash_statement_balances")
            sql.execSQL("PRAGMA foreign_keys=ON")
        }
    }
}
