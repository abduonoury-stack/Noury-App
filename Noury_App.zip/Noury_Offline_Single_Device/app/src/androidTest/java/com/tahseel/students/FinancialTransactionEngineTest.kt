package com.tahseel.students

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.tahseel.students.data.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.assertNotEquals
import kotlinx.coroutines.flow.first
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class FinancialTransactionEngineTest {
    private fun freshDb(): AppDatabase {
        val context = ApplicationProvider.getApplicationContext<Context>()
        context.deleteDatabase("tahseel.db")
        return AppDatabase.create(context)
    }

    @Test fun manual_receipt_is_saved_with_one_balanced_journal_in_same_flow() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = freshDb()
        try {
            val result = PaymentRepository(db).add("ولي أمر تجريبي", "MAN-TEST-001", 12_500L, "cash")
            assertTrue(result is SaveResult.Success)
            val payment = db.dao().getAllAsc().single()
            val source = db.accountingDao().sourcePost("manual_receipt", payment.id.toString())
            assertNotNull(source)
            val journalId = source!!.journalEntryId
            assertEquals(db.accountingDao().debitTotal(journalId), db.accountingDao().creditTotal(journalId))
            assertEquals(12_500L, db.accountingDao().debitTotal(journalId))
        } finally {
            db.close()
            context.deleteDatabase("tahseel.db")
        }
    }

    @Test fun cash_transfer_is_saved_with_balanced_general_ledger_entry() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = freshDb()
        try {
            db.cashAccountDao().insert(CashAccount(id = "bank_test", name = "بنك تجريبي", type = "bank"))
            val cashMapping = db.cashAccountDao().ledgerMapping("cash")
            val bankMapping = db.cashAccountDao().ledgerMapping("bank_test")
            assertNotNull(cashMapping)
            assertNotNull(bankMapping)
            assertNotEquals("كل حساب تشغيلي يجب أن يرتبط بحساب أستاذ مستقل", cashMapping!!.ledgerAccountId, bankMapping!!.ledgerAccountId)
            val transferId = CashTransferRepository(db).record(
                CashTransfer(fromAccountId = "cash", toAccountId = "bank_test", amountPiasters = 8_000L,
                    transferredAt = System.currentTimeMillis(), note = "اختبار تحويل")
            )
            val source = db.accountingDao().sourcePost("cash_transfer", transferId.toString())
            assertNotNull(source)
            val journalId = source!!.journalEntryId
            assertEquals(8_000L, db.accountingDao().debitTotal(journalId))
            assertEquals(8_000L, db.accountingDao().creditTotal(journalId))
            val statement = db.cashAccountDao().observeStatement("bank_test", 0L, Long.MAX_VALUE).first()
            assertTrue("كشف حساب البنك يجب أن يعرض حركة التحويل الواردة", statement.any { it.entryId == journalId && it.debitPiasters == 8_000L })
        } finally {
            db.close()
            context.deleteDatabase("tahseel.db")
        }
    }
    @Test fun rent_invoice_of_5000_with_2000_partial_payment_keeps_accrual_payable_and_bank_effect_distinct() = runBlocking {
        val db = freshDb()
        try {
            val now = System.currentTimeMillis()
            val month = java.time.YearMonth.now()
            val start = month.atDay(1).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
            val end = month.atEndOfMonth().atTime(23,59,59).atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
            db.accountingDao().ensurePeriod(month.toString(), start, end)
            db.cashAccountDao().insert(CashAccount(id = "rent_bank", name = "حساب البنك للإيجار", type = "bank"))
            val bankMapping = db.cashAccountDao().ledgerMapping("rent_bank")!!
            val invoiceId = db.accountingDao().recordAccruedExpense(
                AccountingExpense(
                    documentNo = "RENT-TEST-001", title = "إيجار تجريبي", categoryAccountId = db.accountingDao().accountByCode("5100")!!.id,
                    documentDate = now, dueDate = now, amountPiasters = 500_000L, periodKey = month.toString()
                )
            )
            val invoice = db.accountingDao().expenseById(invoiceId)!!
            assertEquals(500_000L, invoice.amountPiasters)
            assertEquals(0L, invoice.paidPiasters)
            val paymentId = db.accountingDao().recordExpensePayment(invoiceId, 200_000L, "rent_bank", "bank", now, "دفعة جزئية")
            val updated = db.accountingDao().expenseById(invoiceId)!!
            assertEquals(200_000L, updated.paidPiasters)
            assertEquals(300_000L, updated.amountPiasters - updated.paidPiasters)
            val accrualId = invoice.journalEntryId!!
            val payment = db.accountingDao().observeExpensePayments().first().single { it.id == paymentId }
            val paymentJournalId = payment.journalEntryId!!
            assertEquals(500_000L, db.accountingDao().debitTotal(accrualId))
            assertEquals(500_000L, db.accountingDao().creditTotal(accrualId))
            assertEquals(200_000L, db.accountingDao().debitTotal(paymentJournalId))
            assertEquals(200_000L, db.accountingDao().creditTotal(paymentJournalId))
            val paymentLines = db.accountingDao().linesForEntry(paymentJournalId)
            assertTrue("السداد يجب أن يخفض حساب الأستاذ الفرعي للبنك", paymentLines.any { it.accountId == bankMapping.ledgerAccountId && it.creditPiasters == 200_000L })
            val payableId = db.accountingDao().accountByCode("2100")!!.id
            assertTrue("السداد يجب أن يخفض الموردين المستحقين", paymentLines.any { it.accountId == payableId && it.debitPiasters == 200_000L })
        } finally {
            db.close()
            ApplicationProvider.getApplicationContext<Context>().deleteDatabase("tahseel.db")
        }
    }

}
