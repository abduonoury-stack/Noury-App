package com.tahseel.students

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.tahseel.students.data.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class FinancialTransactionEngineTest {
    private fun freshDb(): AppDatabase {
        val context = ApplicationProvider.getApplicationContext<Context>()
        context.deleteDatabase("tahseel.db")
        return AppDatabase.create(context)
    }

    @Test fun manual_receipt_is_saved_with_one_balanced_journal_in_same_flow() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = freshDb()
        try {
            val result = PaymentRepository(db).add("ولي أمر تجريبي", "MAN-TEST-001", 12_500L, "cash")
            assertTrue(result is SaveResult.Success)
            val payment = db.dao().getAllAsc().single()
            val source = db.accountingDao().sourcePost("manual_receipt", payment.id.toString())
            assertNotNull(source)
            val journalId = source!!.journalEntryId
            assertEquals(db.accountingDao().debitTotal(journalId), db.accountingDao().creditTotal(journalId))
            assertEquals(12_500L, db.accountingDao().debitTotal(journalId))
        } finally {
            db.close()
            context.deleteDatabase("tahseel.db")
        }
    }

    @Test fun cash_transfer_is_saved_with_balanced_general_ledger_entry() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = freshDb()
        try {
            db.cashAccountDao().insert(CashAccount(id = "bank_test", name = "بنك تجريبي", type = "bank"))
            val transferId = CashTransferRepository(db).record(
                CashTransfer(fromAccountId = "cash", toAccountId = "bank_test", amountPiasters = 8_000L,
                    transferredAt = System.currentTimeMillis(), note = "اختبار تحويل")
            )
            val source = db.accountingDao().sourcePost("cash_transfer", transferId.toString())
            assertNotNull(source)
            val journalId = source!!.journalEntryId
            assertEquals(8_000L, db.accountingDao().debitTotal(journalId))
            assertEquals(8_000L, db.accountingDao().creditTotal(journalId))
        } finally {
            db.close()
            context.deleteDatabase("tahseel.db")
        }
    }
}
