package com.tahseel.students.ui

import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Delete
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.Alignment
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.tahseel.students.util.AcademyProfileStore

@Composable
fun AcademyProfileScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(AcademyProfileStore.name.value) }
    var address by remember { mutableStateOf(AcademyProfileStore.address.value) }
    var phone by remember { mutableStateOf(AcademyProfileStore.phone.value) }
    var message by remember { mutableStateOf<String?>(null) }
    val logoPath by AcademyProfileStore.logoPath.collectAsState()
    val logoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) message = if (AcademyProfileStore.saveLogo(context, uri)) "تم حفظ شعار الأكاديمية." else "تعذر حفظ الصورة. تأكد أنها صورة سليمة وألا يتجاوز حجمها 8 ميجابايت."
    }
    AppScaffold("بيانات الأكاديمية", onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = MaterialTheme.shapes.large) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    AcademyLogo(logoPath, size = 68.dp)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("شعار الأكاديمية", style = MaterialTheme.typography.titleMedium, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        Text("يظهر الشعار في الإيصالات والتقارير وكشوف الطباعة، ويُحفظ داخل النسخة الاحتياطية ويُستعاد مع بيانات الأكاديمية.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { logoPicker.launch("image/*") }) { Icon(Icons.Default.Image, null); Spacer(Modifier.width(5.dp)); Text("اختيار شعار") }
                            if (logoPath.isNotBlank()) TextButton(onClick = { AcademyProfileStore.removeLogo(context); message = "تم حذف الشعار المخصص." }) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(5.dp)); Text("إزالة") }
                        }
                    }
                }
            }
            Text("اسم الأكاديمية هنا هو الاسم الرئيسي المستخدم في جميع شاشات البرنامج، والإيصالات، والتقارير، وكشوف الطباعة ورسائل أولياء الأمور. يجب استكمال الاسم والعنوان ورقم التواصل حتى تظهر بيانات الأكاديمية في الشاشات والمستندات.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(name, { name = it; message = null }, label = { Text("اسم الحضانة / الأكاديمية") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(address, { address = it; message = null }, label = { Text("العنوان") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            OutlinedTextField(phone, { phone = it; message = null }, label = { Text("رقم الهاتف") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
            Button(onClick = {
                when {
                    name.isBlank() -> message = "اكتب اسم الأكاديمية أولًا"
                    address.isBlank() -> message = "اكتب عنوان الأكاديمية"
                    phone.filter(Char::isDigit).length < 8 -> message = "اكتب رقم تواصل صحيحًا"
                    else -> {
                        AcademyProfileStore.save(context, name, address, phone)
                        message = "تم حفظ بيانات الأكاديمية وتحديثها في البرنامج."
                    }
                }
            }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Save, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("حفظ البيانات") }
            message?.let { Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium) }
        }
    }
}
