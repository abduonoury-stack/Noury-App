package com.tahseel.students.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tahseel.students.util.AcademyProfileStore

/** Nubian palette for the login gate. Nile blue and cream carry the screen; turquoise, terracotta and gold are accents only. */
object NubianPalette {
    val NileDeep = Color(0xFF0B3A52)
    val Turquoise = Color(0xFF14A3A0)
    val TurquoiseSoft = Color(0xFF7FD0CC)
    val Sand = Color(0xFFE8C99A)
    val Terracotta = Color(0xFFC4572F)
    val Cream = Color(0xFFFBF4E6)
    val CreamDeep = Color(0xFFF3E7CE)
    val Gold = Color(0xFFD9A441)
    val InkSoft = Color(0xFF5B6F7A)
}

/** Row of Nubian triangles (zigzag) filling the width; colours cycle through [colors]. */
@Composable
fun NubianTriangleBand(
    modifier: Modifier = Modifier,
    colors: List<Color> = listOf(NubianPalette.Turquoise, NubianPalette.Gold, NubianPalette.Terracotta, NubianPalette.Gold),
    pointsDown: Boolean = true,
    background: Color = Color.Transparent
) {
    Canvas(modifier.fillMaxWidth().height(14.dp)) {
        if (background != Color.Transparent) drawRect(background)
        val unit = 14.dp.toPx()
        val count = (size.width / unit).toInt().coerceAtLeast(1)
        val w = size.width / count
        for (i in 0 until count) {
            val path = Path().apply {
                if (pointsDown) {
                    moveTo(i * w, 0f); lineTo((i + 1) * w, 0f); lineTo(i * w + w / 2f, size.height)
                } else {
                    moveTo(i * w, size.height); lineTo((i + 1) * w, size.height); lineTo(i * w + w / 2f, 0f)
                }
                close()
            }
            drawPath(path, colors[i % colors.size])
        }
    }
}

private fun DrawScope.drawChild(cx: Float, baseY: Float, scale: Float, body: Color, skin: Color) {
    val r = 9f * scale
    drawRoundRect(body, Offset(cx - r * 1.1f, baseY - r * 3.4f), Size(r * 2.2f, r * 3.4f), CornerRadius(r))
    drawCircle(skin, r, Offset(cx, baseY - r * 4.1f))
}

/** Flat nursery-building illustration drawn with Canvas (no bitmaps): sun, Nubian-roofed house, doorway and two children. */
@Composable
fun NurseryIllustration(modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxWidth().height(110.dp)) {
        val w = size.width
        val h = size.height
        val ground = h - 4f
        // sun
        drawCircle(NubianPalette.Gold, h * 0.2f, Offset(w * 0.2f, h * 0.38f))
        drawCircle(NubianPalette.Gold.copy(alpha = 0.25f), h * 0.3f, Offset(w * 0.2f, h * 0.38f))
        // building body
        val bw = (w * 0.42f).coerceAtMost(260.dp.toPx())
        val bx = (w - bw) / 2f
        val bh = h * 0.5f
        drawRect(NubianPalette.Sand, Offset(bx, ground - bh), Size(bw, bh))
        // stepped Nubian roof triangles
        val roof = Path().apply {
            moveTo(bx - 8f, ground - bh); lineTo(bx + bw / 2f, ground - bh - h * 0.3f); lineTo(bx + bw + 8f, ground - bh); close()
        }
        drawPath(roof, NubianPalette.Terracotta)
        val inner = Path().apply {
            moveTo(bx + bw * 0.3f, ground - bh - 4f); lineTo(bx + bw / 2f, ground - bh - h * 0.2f); lineTo(bx + bw * 0.7f, ground - bh - 4f); close()
        }
        drawPath(inner, NubianPalette.Gold)
        // door
        val dw = bw * 0.22f
        drawRoundRect(NubianPalette.NileDeep, Offset(bx + (bw - dw) / 2f, ground - bh * 0.62f), Size(dw, bh * 0.62f), CornerRadius(dw / 2f))
        // windows
        val ws = bw * 0.16f
        drawRoundRect(NubianPalette.Turquoise, Offset(bx + bw * 0.1f, ground - bh * 0.78f), Size(ws, ws), CornerRadius(6f))
        drawRoundRect(NubianPalette.Turquoise, Offset(bx + bw * 0.74f, ground - bh * 0.78f), Size(ws, ws), CornerRadius(6f))
        // children
        val skin = Color(0xFFF1C9A0)
        drawChild(bx - w * 0.07f, ground, 1.5f, NubianPalette.Turquoise, skin)
        drawChild(bx + bw + w * 0.05f, ground, 1.3f, NubianPalette.Terracotta, skin)
        drawChild(bx + bw + w * 0.12f, ground, 1.1f, NubianPalette.Gold, skin)
        // ground line
        drawRect(NubianPalette.TurquoiseSoft.copy(alpha = 0.5f), Offset(0f, ground), Size(w, 4f))
    }
}

/**
 * Academy identity header. Reads the saved profile straight from [AcademyProfileStore] (single source of truth).
 * Empty fields are simply not rendered; no placeholder academy data is ever shown.
 */
@Composable
fun AcademyIdentityHeader(modifier: Modifier = Modifier) {
    val name by AcademyProfileStore.name.collectAsState()
    val address by AcademyProfileStore.address.collectAsState()
    val phone by AcademyProfileStore.phone.collectAsState()
    Column(modifier.fillMaxWidth()) {
        Column(
            Modifier.fillMaxWidth().background(NubianPalette.NileDeep).padding(start = 24.dp, end = 24.dp, top = 28.dp, bottom = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                if (name.isBlank()) "أهلًا بك" else "بوابة الدخول",
                color = NubianPalette.Gold, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(6.dp))
            Text(
                if (name.isBlank()) "نظام Noury لإدارة الحضانات" else name,
                color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth()
            )
            if (address.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                IdentityLine(address, isPhone = false)
            }
            if (phone.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                IdentityLine(phone, isPhone = true)
            }
            Spacer(Modifier.height(6.dp))
            NurseryIllustration()
        }
        NubianTriangleBand()
    }
}

@Composable
private fun IdentityLine(text: String, isPhone: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally), modifier = Modifier.fillMaxWidth()) {
        Icon(if (isPhone) Icons.Outlined.Phone else Icons.Outlined.LocationOn, null, tint = NubianPalette.TurquoiseSoft, modifier = Modifier.size(18.dp))
        Text(text, color = Color(0xFFDCEAF0), style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, modifier = Modifier.weight(1f, fill = false))
    }
}

/** Small footer crediting Noury as the operating system of the academy. */
@Composable
fun NouryPoweredFooter(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth().padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("يعمل بنظام", color = NubianPalette.InkSoft, fontSize = 12.sp)
        Spacer(Modifier.height(2.dp))
        Image(
            painterResource(com.tahseel.students.R.drawable.noury_wordmark), contentDescription = "Noury App",
            modifier = Modifier.width(96.dp).height(30.dp), contentScale = ContentScale.Fit
        )
        Spacer(Modifier.height(10.dp))
        NubianTriangleBand(pointsDown = false)
    }
}
