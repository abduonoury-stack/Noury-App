package com.tahseel.students.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tahseel.students.data.Payment
import com.tahseel.students.data.PaymentRepository
import com.tahseel.students.data.CancelResult
import com.tahseel.students.data.Permission
import com.tahseel.students.data.PermissionGuard
import com.tahseel.students.data.PermissionPolicy
import com.tahseel.students.data.SessionContext
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DetailsViewModel(private val repo: PaymentRepository, private val id: Long) : ViewModel() {
    val payment: StateFlow<Payment?> =
        repo.dao.observeById(id).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _events = Channel<FormEvent>(Channel.BUFFERED)
    val events: Flow<FormEvent> = _events.receiveAsFlow()

    /** إلغاء محاسبي يحافظ على الإيصال وسجل التدقيق بدل حذف البيانات نهائيًا. */
    fun cancel(reason: String) {
        viewModelScope.launch {
            val sameDay = PermissionPolicy.canCancelPaymentSameDay(SessionContext.role, payment.value?.createdAt, System.currentTimeMillis(), reason)
            if (!sameDay && !PermissionGuard.allow(Permission.PAYMENT_CANCEL)) { _events.send(FormEvent.Message(PermissionGuard.DENIED_MESSAGE)); return@launch }
            when (val result = repo.cancel(id, reason)) {
                CancelResult.Success -> _events.send(FormEvent.Done)
                CancelResult.NotFound -> _events.send(FormEvent.Message("العملية غير موجودة"))
                CancelResult.AlreadyCancelled -> _events.send(FormEvent.Message("العملية ملغاة بالفعل"))
                CancelResult.HasRefunds -> _events.send(FormEvent.Message("لا يمكن إلغاء العملية لوجود حركة مالية مرتبطة بها"))
                is CancelResult.Error -> _events.send(FormEvent.Message(result.message))
            }
        }
    }
}
