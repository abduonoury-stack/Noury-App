package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.data.AppDatabase
import com.tahseel.students.data.Payment
import com.tahseel.students.util.Money
import com.tahseel.students.util.ReceiptLoader
import com.tahseel.students.util.ReceiptPdf
import com.tahseel.students.util.ReceiptPrint
import com.tahseel.students.util.TimeUtil
import com.tahseel.students.vm.LedgerViewModel
import com.tahseel.students.vm.Period
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun LedgerScreen(vm: LedgerViewModel, onBack: () -> Unit, onOpen: (Long) -> Unit, onStudentProfile: (Long) -> Unit, db: AppDatabase) {
    val s by vm.state.collectAsStateWithLifecycle()
    val f by vm.filter.collectAsStateWithLifecycle()
    var showPicker by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectMode by remember { mutableStateOf(false) }
    var selectedIds by remember { mutableStateOf(setOf<Long>()) }
    var printing by remember { mutableStateOf(false) }
    var viewing by remember { mutableStateOf<Payment?>(null) }
    var printMessage by remember { mutableStateOf<String?>(null) }
    // "طباعة الكل" تشمل العمليات الظاهرة حسب البحث/الفترة، دون الملغاة؛ والملغاة تُطبع فقط إذا حددتها بنفسك.
    val printableAll = s.rows.filterNot { it.payment.isCancelled }
    val selectedRows = s.rows.filter { it.payment.id in selectedIds }

    fun printRows(rows: List<com.tahseel.students.vm.LedgerRow>) {
        if (rows.isEmpty() || printing) return
        printing = true
        scope.launch {
            runCatching {
                // الأقدم أولًا (حسب المسلسل) ليخرج الإيصال رقم 1 قبل 2 قبل 3.
                val ordered = rows.sortedBy { it.serial }.map { it.payment }
                val receipts = ReceiptLoader.loadAll(db, ordered)
                val file = withContext(Dispatchers.IO) { ReceiptPdf.createMany(context, receipts, "receipts-${System.currentTimeMillis()}.pdf") }
                ReceiptPrint.print(context, file, receipts.size, "إيصالات التحصيل (${receipts.size})")
            }.onFailure { printMessage = "تعذرت الطباعة: ${it.localizedMessage}" }
            printing = false
        }
    }

    AppScaffold(
        title = "سجل التحصيل", onBack = onBack,
        bottomBar = {
            Surface(color = MaterialTheme.colorScheme.primary, shadowElevation = 8.dp) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("إجمالي التحصيل", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.bodyMedium)
                        Text(Money.format(s.total), color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.titleLarge)
                    }
                    Text("${s.rows.size} عملية", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 12.dp)) {
            OutlinedTextField(
                value = f.query, onValueChange = vm::setQuery, singleLine = true,
                label = { Text("بحث بالاسم أو رقم الإيصال") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = f.period == Period.ALL, onClick = { vm.setPeriod(Period.ALL) }, label = { Text("الكل") })
                FilterChip(selected = f.period == Period.DAY, onClick = { vm.setPeriod(Period.DAY) }, label = { Text("يوم") })
                FilterChip(selected = f.period == Period.MONTH, onClick = { vm.setPeriod(Period.MONTH) }, label = { Text("شهر") })
            }
            if (s.rows.isNotEmpty()) {
                if (!selectMode) {
                    Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = { printRows(printableAll) }, enabled = printableAll.isNotEmpty() && !printing, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Print, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
                            Text("طباعة الكل (${printableAll.size})")
                        }
                        OutlinedButton(onClick = { selectMode = true; selectedIds = emptySet() }, enabled = !printing, modifier = Modifier.weight(1f)) { Text("تحديد للطباعة") }
                    }
                } else {
                    Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = { printRows(selectedRows) }, enabled = selectedRows.isNotEmpty() && !printing, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Print, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
                            Text("طباعة المحدد (${selectedRows.size})")
                        }
                        OutlinedButton(onClick = {
                            selectedIds = if (selectedRows.size == s.rows.size) emptySet() else s.rows.map { it.payment.id }.toSet()
                        }, enabled = !printing) { Text(if (selectedRows.size == s.rows.size) "إلغاء التحديد" else "تحديد الكل") }
                        TextButton(onClick = { selectMode = false; selectedIds = emptySet() }) { Text("إنهاء") }
                    }
                }
                if (printing) LinearProgressIndicator(Modifier.fillMaxWidth())
            }
            if (f.period == Period.DAY || f.period == Period.MONTH) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    // في RTL: السهم الأيمن = السابق، الأيسر = التالي
                    IconButton(onClick = { if (f.period == Period.DAY) vm.shiftDay(-1) else vm.shiftMonth(-1) }) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "السابق")
                    }
                    Text(
                        if (f.period == Period.DAY) TimeUtil.fmtDate(f.day) else TimeUtil.fmtMonth(f.month),
                        modifier = Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.titleMedium
                    )
                    if (f.period == Period.DAY) IconButton(onClick = { showPicker = true }) { Icon(Icons.Default.DateRange, "اختيار تاريخ") }
                    IconButton(onClick = { if (f.period == Period.DAY) vm.shiftDay(1) else vm.shiftMonth(1) }) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "التالي")
                    }
                }
            }
            if (s.rows.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(if (s.allCount == 0) "لا توجد عمليات مسجلة بعد" else "لا توجد نتائج مطابقة", style = MaterialTheme.typography.bodyLarge)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                    items(s.rows, key = { it.payment.id }) { r ->
                        val id = r.payment.id
                        val toggle = { selectedIds = if (id in selectedIds) selectedIds - id else selectedIds + id }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (selectMode) Checkbox(checked = id in selectedIds, onCheckedChange = { toggle() })
                            Box(Modifier.weight(1f)) {
                                PaymentRow(
                                    r.payment, r.serial,
                                    onClick = { if (selectMode) toggle() else onOpen(id) },
                                    onStudentClick = if (selectMode) null else r.payment.studentId?.let { sid -> { onStudentProfile(sid) } },
                                    onReceiptClick = if (selectMode) null else { { viewing = r.payment } }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
    if (showPicker) DatePickerDialogSimple(f.day, onPick = vm::setDay, onDismiss = { showPicker = false })
    viewing?.let { ReceiptViewerDialog(it, db, onDismiss = { viewing = null }) }
    printMessage?.let { msg ->
        AlertDialog(onDismissRequest = { printMessage = null }, confirmButton = { TextButton(onClick = { printMessage = null }) { Text("حسنًا") } }, text = { Text(msg) })
    }
}
