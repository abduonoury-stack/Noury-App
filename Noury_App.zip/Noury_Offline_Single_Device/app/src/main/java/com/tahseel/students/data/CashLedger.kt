package com.tahseel.students.data

import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId

/** Read-only projection of existing records; it does not create or mutate financial transactions. */
data class CashMovement(
    val id: String,
    val timestamp: Long,
    val direction: CashDirection,
    val category: String,
    val description: String,
    val amountPiasters: Long,
    val sourceReference: String,
    val note: String = "",
    val includedInTotals: Boolean = true,
    val accountId: String? = null
)

enum class CashDirection { INFLOW, OUTFLOW }

data class CashLedgerSummary(
    val month: YearMonth,
    val movements: List<CashMovement>,
    val inflowsPiasters: Long,
    val outflowsPiasters: Long,
    val netMovementPiasters: Long,
    val excludedCount: Int,
    val unassignedCount: Int = 0
)

/**
 * Creates a single cash-movement view from existing source ledgers.
 * Potential duplicate refunds and legacy manual salary expenses are visible but excluded
 * from totals until reviewed, preventing an unverified double count.
 */
fun buildCashMovements(
    payments: List<Payment>,
    expenses: List<Expense>,
    refundCredits: List<RefundCredit>,
    refundTransactions: List<RefundTransaction>,
    settlements: List<StudentExitSettlement>,
    settlementEvents: List<StudentExitSettlementEvent>,
    payrollPayments: List<EmployeePayrollPayment>,
    payrollRows: List<EmployeePayroll>,
    employees: List<Employee>,
    loans: List<EmployeeLoan>,
    expensePayments: List<ExpensePayment> = emptyList(),
    transfers: List<CashTransfer> = emptyList(),
    cashAccounts: List<CashAccount> = emptyList(),
    payrollRecoveries: List<EmployeePayrollRecoveryTransaction> = emptyList(),
    accountingExpenses: List<AccountingExpense> = emptyList(),
    accountingExpensePayments: List<AccountingExpensePayment> = emptyList()
): List<CashMovement> {
    val accountNames = cashAccounts.associate { it.id to it.name }
    val rows = mutableListOf<CashMovement>()
    payments.filter { !it.isCancelled && it.amountPiasters > 0L }.forEach {
        rows += CashMovement("receipt:${it.id}", it.createdAt, CashDirection.INFLOW, "تحصيل", "إيصال ${it.receiptNo} • ${it.studentName}", it.amountPiasters, "payments#${it.id}", accountId = it.accountId)
    }

    // Exact dated expense payments are authoritative for the amount they cover.
    val paymentsByExpense = expensePayments.groupBy { it.expenseId }
    expenses.filter { it.paidAmountPiasters > 0L && !it.note.startsWith("HR_SYNC:") }.forEach { expense ->
        val salaryLike = expense.title.trim() == "المرتبات" || expense.category.trim() == "المرتبات"
        val exactRows = paymentsByExpense[expense.id].orEmpty()
        exactRows.forEach { payment ->
            rows += CashMovement(
                "expense-payment:${payment.id}", payment.paidAt, CashDirection.OUTFLOW,
                "مصروف", expense.title, payment.amountPiasters.coerceAtLeast(0L),
                "expense_payments#${payment.id}", "طريقة الدفع: ${payment.paymentMethod}" + if (payment.note.isBlank()) "" else " • ${payment.note}",
                accountId = payment.accountId
            )
        }
        val exactTotal = exactRows.sumOf { it.amountPiasters.coerceAtLeast(0L) }
        val legacyResidual = (expense.paidAmountPiasters.coerceIn(0L, expense.amountPiasters.coerceAtLeast(0L)) - exactTotal).coerceAtLeast(0L)
        if (legacyResidual > 0L) rows += CashMovement(
            "expense-legacy:${expense.id}", expense.updatedAt, CashDirection.OUTFLOW,
            if (salaryLike) "بند مرتبات قديم" else "مصروف قديم", expense.title, legacyResidual,
            "expenses#${expense.id}", "دفعة تاريخية بلا تاريخ صرف تفصيلي؛ التاريخ المعروض هو آخر تحديث للبند.",
            includedInTotals = !salaryLike
        )
    }

    // New accounting invoices have their own dated payment ledger. Include the actual
    // cash disbursements here; invoice accruals themselves are not cash movements.
    val accountingExpensesById = accountingExpenses.associateBy { it.id }
    accountingExpensePayments.filter { it.amountPiasters > 0L }.forEach { payment ->
        val invoice = accountingExpensesById[payment.expenseId]
        rows += CashMovement(
            "accounting-expense-payment:${payment.id}", payment.paidAt, CashDirection.OUTFLOW,
            "مصروف محاسبي", invoice?.title ?: "دفعة فاتورة محاسبية #${payment.expenseId}",
            payment.amountPiasters, "accounting_expense_payments#${payment.id}",
            "طريقة الدفع: ${payment.method}" + if (payment.note.isBlank()) "" else " • ${payment.note}",
            accountId = payment.cashAccountId
        )
    }

    val credits = refundCredits.associateBy { it.id }
    val settlementById = settlements.associateBy { it.id }
    val duplicateRefundIds = mutableSetOf<Long>()
    val duplicateEventIds = mutableSetOf<Long>()
    refundTransactions.forEach { tx ->
        val studentId = credits[tx.refundCreditId]?.studentId ?: return@forEach
        val candidates = settlementEvents.filter { event ->
            if (event.eventType != "refund_paid" || event.amountPiasters != tx.amountPiasters) return@filter false
            val settlement = settlementById[event.settlementId] ?: return@filter false
            settlement.studentId == studentId &&
                (event.accountId == null || tx.accountId == null || event.accountId == tx.accountId) &&
                timestampDistance(event.createdAt, tx.refundedAt) <= 86_400_000L
        }
        if (candidates.isNotEmpty()) {
            val linkedExitCredit = credits[tx.refundCreditId]
            val exactLinkedExit = linkedExitCredit?.sourceType == "exit_settlement" && candidates.any { it.settlementId == linkedExitCredit.sourceId }
            if (exactLinkedExit) {
                // The refund transaction is the cash movement; its matching settlement event is audit-only.
                duplicateEventIds += candidates.filter { it.settlementId == linkedExitCredit?.sourceId }.map { it.id }
            } else {
                duplicateRefundIds += tx.id
                duplicateEventIds += candidates.map { it.id }
            }
        }
    }
    refundTransactions.filter { it.amountPiasters > 0L }.forEach { tx ->
        val student = credits[tx.refundCreditId]?.studentId
        val duplicate = tx.id in duplicateRefundIds
        rows += CashMovement(
            "refund:${tx.id}", tx.refundedAt, CashDirection.OUTFLOW, "استرداد ولي أمر",
            "حركة استرداد #${tx.id}", tx.amountPiasters, "refund_transactions#${tx.id}",
            if (duplicate) "احتمال تكرار مع تسوية انسحاب للطالب نفسه وبالقيمة نفسها خلال 24 ساعة؛ مستبعد مؤقتًا من الإجمالي." else "طريقة الرد: ${tx.method}",
            includedInTotals = !duplicate && student != null, accountId = tx.accountId
        )
    }
    settlementEvents.filter { it.eventType == "refund_paid" && it.amountPiasters > 0L }.forEach { event ->
        val settlement = settlementById[event.settlementId]
        val duplicate = event.id in duplicateEventIds
        rows += CashMovement(
            "exit-refund:${event.id}", event.createdAt, CashDirection.OUTFLOW, "استرداد انسحاب",
            "صرف تسوية انسحاب #${event.settlementId}", event.amountPiasters, "student_exit_settlement_events#${event.id}",
            if (duplicate) "احتمال تكرار مع حركة استرداد أخرى؛ مستبعد مؤقتًا من الإجمالي." else event.details,
            includedInTotals = !duplicate && settlement != null, accountId = event.accountId
        )
    }

    val payrollById = payrollRows.associateBy { it.id }
    val employeeById = employees.associateBy { it.id }
    // الصرف الأصلي يظل ظاهرًا حتى بعد عكس المرتب؛ status=reversed لا يمحو خروج النقد.
    payrollPayments.filter { it.status in setOf("active", "reversed") && it.amountPiasters > 0L }.forEach { payment ->
        val payroll = payrollById[payment.payrollId]
        val employeeName = payroll?.let { employeeById[it.employeeId]?.fullName }.orEmpty()
        val timestamp = parseDateStart(payment.paymentDate) ?: payment.createdAt
        rows += CashMovement(
            "payroll:${payment.id}", timestamp, CashDirection.OUTFLOW, "مرتبات",
            "${employeeName.ifBlank { "موظف" }} • ${payment.paymentDate}", payment.amountPiasters,
            "employee_payroll_payments#${payment.id}", "طريقة الصرف: ${payment.paymentMethod}", accountId = payment.accountId
        )
    }

    payrollRecoveries.filter { it.amountPiasters > 0L }.forEach { recovery ->
        rows += CashMovement(
            "payroll-recovery:${recovery.id}", recovery.receivedAt, CashDirection.INFLOW,
            "تحصيل مديونية مرتب", "استرداد مبلغ من موظف • عكس #${recovery.reversalId}",
            recovery.amountPiasters, "employee_payroll_recovery_transactions#${recovery.id}",
            recovery.note, accountId = recovery.accountId
        )
    }

    transfers.filter { it.amountPiasters > 0L && it.fromAccountId != it.toAccountId }.forEach { transfer ->
        rows += CashMovement(
            "transfer-out:${transfer.id}", transfer.transferredAt, CashDirection.OUTFLOW,
            "تحويل داخلي صادر", "تحويل إلى ${accountNames[transfer.toAccountId] ?: transfer.toAccountId} #${transfer.id}", transfer.amountPiasters,
            "cash_transfers#${transfer.id}", transfer.note, accountId = transfer.fromAccountId
        )
        rows += CashMovement(
            "transfer-in:${transfer.id}", transfer.transferredAt, CashDirection.INFLOW,
            "تحويل داخلي وارد", "تحويل من ${accountNames[transfer.fromAccountId] ?: transfer.fromAccountId} #${transfer.id}", transfer.amountPiasters,
            "cash_transfers#${transfer.id}", transfer.note, accountId = transfer.toAccountId
        )
    }

    loans.filter { it.amountPiasters > 0L }.forEach { loan ->
        val name = employeeById[loan.employeeId]?.fullName.orEmpty()
        val issuedAt = loan.issuedAt.takeIf { it > 0L } ?: loan.createdAt
        val timingNote = if (loan.issuedAt > 0L) "تاريخ الصرف المسجل" else "تاريخ الصرف غير محدد؛ التاريخ المعروض هو تاريخ إنشاء السلفة القديم كتقدير فقط."
        rows += CashMovement(
            "loan:${loan.id}", issuedAt, CashDirection.OUTFLOW, "سلفة موظف",
            "${name.ifBlank { "موظف" }} • سلفة #${loan.id}", loan.amountPiasters,
            "employee_loans#${loan.id}", timingNote, accountId = loan.accountId
        )
    }
    return rows.sortedWith(compareByDescending<CashMovement> { it.timestamp }.thenByDescending { it.id })
}

fun summarizeCashMovements(rows: List<CashMovement>, month: YearMonth, zone: ZoneId = ZoneId.systemDefault(), accountId: String? = null): CashLedgerSummary {
    val monthRows = rows.filter { movement ->
        YearMonth.from(Instant.ofEpochMilli(movement.timestamp).atZone(zone).toLocalDate()) == month
    }
    val unassigned = if (accountId == null) 0 else monthRows.count { it.accountId == null }
    val filtered = monthRows.filter { accountId == null || if (accountId == "__unassigned__") it.accountId == null else it.accountId == accountId }
    val included = if (accountId == "__unassigned__") emptyList() else filtered.filter { it.includedInTotals }
    val inflows = included.filter { it.direction == CashDirection.INFLOW }.sumOf { it.amountPiasters.coerceAtLeast(0L) }
    val outflows = included.filter { it.direction == CashDirection.OUTFLOW }.sumOf { it.amountPiasters.coerceAtLeast(0L) }
    return CashLedgerSummary(month, filtered, inflows, outflows, inflows - outflows,
        filtered.count { !it.includedInTotals } + if (accountId == "__unassigned__") filtered.size else 0, unassigned)
}

private fun parseDateStart(value: String): Long? = runCatching {
    LocalDate.parse(value).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
}.getOrNull()

private fun timestampDistance(a: Long, b: Long): Long = if (a >= b) a - b else b - a

/** Returns null when no approved opening balance exists; never fabricates a cash balance. */
fun expectedCashBalance(
    movements: List<CashMovement>,
    opening: CashOpeningBalance?,
    asOf: Long, accountId: String = "cash"
): Long? {
    opening ?: return null
    if (asOf < opening.effectiveAt) return null
    val delta = movements.asSequence()
        .filter { it.includedInTotals && it.accountId == accountId && it.timestamp >= opening.effectiveAt && it.timestamp <= asOf }
        .sumOf { movement ->
            val amount = movement.amountPiasters.coerceAtLeast(0L)
            if (movement.direction == CashDirection.INFLOW) amount else -amount
        }
    return opening.amountPiasters + delta
}
