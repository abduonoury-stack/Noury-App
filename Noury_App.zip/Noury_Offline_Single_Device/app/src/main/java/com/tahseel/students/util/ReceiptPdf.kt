package com.tahseel.students.util

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** All values needed to draw one receipt. Amounts are in piasters. */
data class ReceiptData(
    val nurseryName: String,
    val nurseryAddress: String,
    val nurseryPhone: String,
    val studentName: String,
    val period: String,
    val receiptNo: String,
    val duePiasters: Long,
    val paidPiasters: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val guardianName: String = "",
    val className: String = "",
    val discountPiasters: Long = 0L,
    val discountNote: String = "",
    /** Overrides "اشتراك شهر <period>" for payments that are not tied to a subscription month. */
    val statement: String? = null,
    val isCancelled: Boolean = false
)

/** A5 portrait receipt or exemption notice, RTL. One receipt per page; many receipts can share one PDF. */
object ReceiptPdf {
    private val purple = Color.rgb(73, 49, 111)
    private val purpleSoft = Color.rgb(242, 237, 248)
    private val peach = Color.rgb(245, 190, 151)
    private val ink = Color.rgb(42, 35, 52)
    private val muted = Color.rgb(112, 103, 120)

    fun create(
        context: Context,
        nurseryName: String,
        nurseryAddress: String,
        nurseryPhone: String,
        studentName: String,
        period: String,
        receiptNo: String,
        duePiasters: Long,
        paidPiasters: Long,
        createdAt: Long = System.currentTimeMillis(),
        guardianName: String = "",
        className: String = "",
        discountPiasters: Long = 0L,
        discountNote: String = ""
    ): File {
        val safeNo = receiptNo.replace(Regex("[^A-Za-z0-9._-]"), "_")
        return createMany(
            context,
            listOf(ReceiptData(nurseryName, nurseryAddress, nurseryPhone, studentName, period, receiptNo, duePiasters, paidPiasters, createdAt, guardianName, className, discountPiasters, discountNote)),
            "receipt-$safeNo.pdf"
        )
    }

    /** Builds one PDF with a page per receipt, in the given order. */
    fun createMany(context: Context, receipts: List<ReceiptData>, fileName: String): File {
        require(receipts.isNotEmpty()) { "no receipts" }
        val file = File(context.cacheDir, fileName)
        val doc = PdfDocument()
        try {
            receipts.forEachIndexed { index, d ->
                // A5 portrait in PDF points (148 x 210 mm approximately).
                val page = doc.startPage(PdfDocument.PageInfo.Builder(420, 595, index + 1).create())
                drawReceipt(page.canvas, d)
                doc.finishPage(page)
            }
            FileOutputStream(file).use { doc.writeTo(it) }
        } finally {
            doc.close()
        }
        return file
    }

    private fun drawReceipt(canvas: Canvas, d: ReceiptData) {
        val regular = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ink; textSize = 11f; typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        val bold = Paint(regular).apply { typeface = Typeface.create("sans-serif", Typeface.BOLD) }
        val white = Paint(bold).apply { color = Color.WHITE }
        val center = Paint(bold).apply { textAlign = Paint.Align.CENTER }
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(224, 216, 234); strokeWidth = 1f }
        val pageRect = RectF(12f, 12f, 408f, 583f)

        fun rounded(rect: RectF, color: Int, radius: Float = 10f, stroke: Int? = null) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; style = Paint.Style.FILL }
            canvas.drawRoundRect(rect, radius, radius, p)
            if (stroke != null) {
                p.color = stroke; p.style = Paint.Style.STROKE; p.strokeWidth = 1f
                canvas.drawRoundRect(rect, radius, radius, p)
            }
        }
        fun rtl(text: String, x: Float, y: Float, width: Int, size: Float = 11f, color: Int = ink, isBold: Boolean = false, align: Layout.Alignment = Layout.Alignment.ALIGN_OPPOSITE) {
            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                this.color = color; textSize = size
                typeface = Typeface.create("sans-serif", if (isBold) Typeface.BOLD else Typeface.NORMAL)
            }
            val layout = StaticLayout.Builder.obtain(text, 0, text.length, tp, width)
                .setAlignment(align).setTextDirection(TextDirectionHeuristics.RTL)
                .setIncludePad(false).build()
            canvas.save(); canvas.translate(x, y); layout.draw(canvas); canvas.restore()
        }
        fun divider(y: Float) { canvas.drawLine(28f, y, 392f, y, linePaint) }
        fun labelValue(label: String, value: String, y: Float, valueSize: Float = 12f) {
            rtl(label, 30f, y, 170, 10.5f, muted, true)
            rtl(value.ifBlank { "غير مسجل" }, 205f, y - 1f, 185, valueSize, ink, true)
        }

        // Clean paper and subtle outer frame.
        canvas.drawColor(Color.WHITE)
        rounded(pageRect, Color.WHITE, 14f, Color.rgb(224, 216, 234))
        rounded(RectF(20f, 20f, 400f, 116f), purple, 13f)
        canvas.drawCircle(374f, 43f, 5f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = peach })
        canvas.drawCircle(355f, 43f, 2.5f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
        center.color = Color.WHITE; center.textSize = 18f
        if (d.nurseryName.isNotBlank()) canvas.drawText(d.nurseryName.trim(), 210f, 51f, center)
        center.textSize = 15f; center.color = Color.WHITE
        val isFullExemption = d.duePiasters == 0L && d.paidPiasters == 0L && d.discountPiasters > 0L
        canvas.drawText(if (isFullExemption) "إشعار إعفاء من الاشتراك" else "إيصال استلام نقدية", 210f, 94f, center)
        center.textSize = 8.5f; center.color = Color.rgb(239, 224, 250)
        val contact = listOf(d.nurseryAddress.trim(), d.nurseryPhone.trim().takeIf { it.isNotBlank() }?.let { "هاتف: $it" })
            .filterNotNull().filter { it.isNotBlank() }.joinToString("   •   ")
        if (contact.isNotBlank()) canvas.drawText(contact.take(82), 210f, 108f, center)

        // Receipt identity row.
        rounded(RectF(28f, 126f, 392f, 166f), purpleSoft, 9f)
        rtl(if (isFullExemption) "رقم الإشعار" else "رقم الإيصال", 35f, 135f, 100, 9f, muted, true)
        rtl(d.receiptNo, 35f, 149f, 155, 12f, purple, true)
        rtl(if (isFullExemption) "تاريخ التسجيل" else "تاريخ الاستلام", 215f, 135f, 165, 9f, muted, true)
        val date = SimpleDateFormat("yyyy/MM/dd  -  hh:mm a", Locale.getDefault()).format(Date(d.createdAt))
        rtl(date, 215f, 149f, 165, 10f, ink, true)

        rtl(if (isFullExemption) "بيانات ولي أمر الطالب" else "استلمنا من ولي أمر الطالب", 30f, 181f, 360, 10f, muted, true)
        rtl(d.guardianName.ifBlank { "................................................" }, 30f, 196f, 360, 13f, ink, true)
        divider(220f)
        labelValue("اسم الطالب", d.studentName, 231f, 12f)
        labelValue("الفصل", d.className, 256f, 11.5f)
        labelValue("بيان الاشتراك", d.statement?.takeIf { it.isNotBlank() } ?: "اشتراك شهر ${d.period}", 281f, 11.5f)

        // Financial summary distinguishes the original fee, discount, net due and actual cash received.
        rounded(RectF(28f, 307f, 392f, 427f), purpleSoft, 11f)
        val originalFee = d.duePiasters + d.discountPiasters
        rtl("قيمة الاشتراك الأصلية", 38f, 319f, 170, 9.5f, muted, true)
        rtl(Money.format(originalFee), 215f, 319f, 165, 11.5f, purple, true)
        rtl("قيمة الخصم", 38f, 342f, 170, 9.5f, muted, true)
        rtl(Money.format(d.discountPiasters), 215f, 342f, 165, 11.5f, purple, true)
        rtl("صافي المستحق بعد الخصم", 38f, 365f, 170, 9.5f, muted, true)
        rtl(Money.format(d.duePiasters), 215f, 365f, 165, 11.5f, purple, true)
        rtl(if (isFullExemption) "المبلغ المحصل نقديًا" else "المبلغ المستلم فعليًا", 38f, 388f, 170, 9.5f, muted, true)
        rtl(Money.format(d.paidPiasters), 215f, 388f, 165, 11.5f, purple, true)
        divider(398f)
        val remaining = (d.duePiasters - d.paidPiasters).coerceAtLeast(0L)
        rtl(if (isFullExemption) "حالة الاشتراك" else "المتبقي من هذا الاشتراك", 38f, 410f, 170, 9.5f, muted, true)
        rtl(if (isFullExemption) "تمت التسوية بالإعفاء الكامل" else Money.format(remaining), 205f, 407f, 185, 10.5f, if (remaining == 0L) purple else Color.rgb(166, 65, 65), true)

        rtl(if (isFullExemption) "لا توجد حركة نقدية؛ تمت التسوية بالإعفاء." else "طريقة السداد: نقدًا", 30f, 442f, 360, 10f, ink, true)
        rtl("سبب الخصم: ${d.discountNote.ifBlank { "غير محدد" }}", 30f, 464f, 360, 9.5f, muted, true)
        rtl("ملاحظات:", 30f, 486f, 360, 9.5f, muted, true)
        canvas.drawLine(30f, 508f, 390f, 508f, linePaint)
        canvas.drawLine(30f, 525f, 390f, 525f, linePaint)

        rtl(if (isFullExemption) "اعتماد الإدارة" else "توقيع المستلم", 30f, 535f, 150, 9.5f, purple, true)
        rtl("ختم الأكاديمية", 235f, 535f, 155, 9.5f, purple, true)
        canvas.drawLine(30f, 566f, 170f, 566f, linePaint)
        canvas.drawLine(235f, 566f, 390f, 566f, linePaint)

        if (d.isCancelled) {
            canvas.save()
            canvas.rotate(-24f, 210f, 300f)
            val stampPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(150, 190, 40, 40); textSize = 54f; textAlign = Paint.Align.CENTER
                typeface = Typeface.create("sans-serif", Typeface.BOLD)
            }
            canvas.drawText("ملغاة", 210f, 318f, stampPaint)
            canvas.restore()
        }
    }
}
