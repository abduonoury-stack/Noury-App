package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.data.*
import com.tahseel.students.util.Money
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinancialControlScreen(db: AppDatabase, onBack: () -> Unit) {
    val accounting = db.accountingDao()
    val controlDao = db.financialControlDao()
    val repository = remember(db) { FinancialControlRepository(db) }
    val periods by accounting.observePeriods().collectAsStateWithLifecycle(emptyList())
    val vendors by accounting.observeVendors().collectAsStateWithLifecycle(emptyList())
    val invoices by accounting.observeExpenses().collectAsStateWithLifecycle(emptyList())
    val expensePayments by accounting.observeExpensePayments().collectAsStateWithLifecycle(emptyList())
    val cashAccounts by accounting.observeActiveCashAccounts().collectAsStateWithLifecycle(emptyList())
    val mappings by db.cashAccountDao().observeLedgerMappings().collectAsStateWithLifecycle(emptyList())
    val closeAudits by controlDao.observeCloseAudits().collectAsStateWithLifecycle(emptyList())
    val scope = rememberCoroutineScope()

    var section by remember { mutableStateOf("vendors") }
    var selectedPeriodKey by remember { mutableStateOf(YearMonth.now().toString()) }
    var selectedCashAccountId by remember { mutableStateOf("cash") }
    var message by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }
    var vendorSnapshot by remember { mutableStateOf<VendorReconciliationSnapshot?>(null) }
    var closeReadiness by remember { mutableStateOf<FinancialCloseReadiness?>(null) }
    var readinessBusy by remember { mutableStateOf(false) }
    var readinessRevision by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        val month = YearMonth.now()
        val zone = ZoneId.systemDefault()
        val start = month.atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
        val end = month.atEndOfMonth().atTime(23, 59, 59).atZone(zone).toInstant().toEpochMilli()
        accounting.ensurePeriod(month.toString(), start, end)
    }
    LaunchedEffect(periods) {
        if (periods.isNotEmpty() && periods.none { it.periodKey == selectedPeriodKey }) {
            selectedPeriodKey = periods.firstOrNull { it.status == "open" }?.periodKey ?: periods.first().periodKey
        }
    }
    LaunchedEffect(cashAccounts) {
        if (cashAccounts.none { it.id == selectedCashAccountId }) selectedCashAccountId = cashAccounts.firstOrNull()?.id.orEmpty()
    }
    val selectedPeriod = periods.firstOrNull { it.periodKey == selectedPeriodKey }
    var selectedStatementLineId by remember { mutableStateOf<Long?>(null) }
    val selectedAccount = cashAccounts.firstOrNull { it.id == selectedCashAccountId }
    val statementRows by remember(selectedCashAccountId) {
        controlDao.observeStatementLines(selectedCashAccountId)
    }.collectAsStateWithLifecycle(emptyList())
    val periodStatements = statementRows.filter { it.periodKey == selectedPeriodKey }
    val statementBalance by remember(selectedCashAccountId, selectedPeriodKey) {
        controlDao.observeStatementBalance(selectedCashAccountId, selectedPeriodKey)
    }.collectAsStateWithLifecycle(null)
    val bookLines by remember(selectedCashAccountId, selectedPeriodKey) {
        controlDao.observeBookLines(selectedCashAccountId, selectedPeriodKey)
    }.collectAsStateWithLifecycle(emptyList())
    val matchedLineIds = periodStatements.mapNotNull { it.matchedJournalLineId }.toSet()
    val bookNet = bookLines.fold(0L) { sum, row -> Math.addExact(sum, row.debitPiasters - row.creditPiasters) }
    val statementNet = periodStatements.fold(0L) { sum, row -> Math.addExact(sum, row.debitPiasters - row.creditPiasters) }
    val unmatchedBook = bookLines.count { it.entryStatus == "posted" && it.journalLineId !in matchedLineIds }
    val unmatchedStatements = periodStatements.count { it.matchedJournalLineId == null }
    val counts by remember(selectedCashAccountId) {
        db.cashControlDao().observeCounts(selectedCashAccountId)
    }.collectAsStateWithLifecycle(emptyList())
    val mapping = mappings.firstOrNull { it.cashAccountId == selectedCashAccountId }
    val ledgerRows by remember(mapping?.ledgerAccountId) {
        if (mapping == null) emptyFlow<List<AccountLedgerRow>>() else accounting.observeAccountLedger(mapping.ledgerAccountId)
    }.collectAsStateWithLifecycle(emptyList())
    val currentCount = counts.filter { it.countedAt in (selectedPeriod?.startDate ?: Long.MIN_VALUE)..(selectedPeriod?.endDate ?: Long.MAX_VALUE) }.maxByOrNull { it.countedAt }
    val bookBalance = selectedPeriod?.let { period -> ledgerRows.filter { it.entryDate <= period.endDate }.fold(0L) { sum, line -> Math.addExact(sum, line.debitPiasters - line.creditPiasters) } } ?: 0L
    val bankStatementMovement = periodStatements.fold(0L) { sum, line -> Math.addExact(sum, line.debitPiasters - line.creditPiasters) }
    val bankBookBalance = bookBalance
    var cashCountAmount by remember(selectedCashAccountId, selectedPeriodKey) { mutableStateOf("") }
    var cashCountNote by remember(selectedCashAccountId, selectedPeriodKey) { mutableStateOf("") }
    LaunchedEffect(selectedCashAccountId, selectedPeriodKey) { selectedStatementLineId = null }

    LaunchedEffect(selectedPeriod?.endDate, vendors, invoices, expensePayments) {
        val asOf = selectedPeriod?.endDate ?: System.currentTimeMillis()
        runCatching { repository.vendorReconciliation(asOf) }
            .onSuccess { vendorSnapshot = it }
            .onFailure { errorMessage = it.message ?: "تعذر حساب مطابقة الموردين" }
    }
    LaunchedEffect(selectedPeriodKey, readinessRevision, periods, invoices, expensePayments, cashAccounts,
        statementRows, statementBalance, bookLines, counts, mappings, ledgerRows) {
        if (selectedPeriodKey.isNotBlank() && periods.any { it.periodKey == selectedPeriodKey }) {
            readinessBusy = true
            runCatching { repository.closeReadiness(selectedPeriodKey) }
                .onSuccess { closeReadiness = it }
                .onFailure { errorMessage = it.message ?: "تعذر فحص جاهزية الإقفال" }
            readinessBusy = false
        }
    }

    AppScaffold(title = "المطابقة والإقفال المالي", onBack = onBack) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("مركز الرقابة المالية", style = MaterialTheme.typography.titleLarge)
                Text(
                    "المطابقة تقارن الدفاتر بالمستندات والأرصدة الرقابية. لا يتم إنشاء قيود تسوية أو تغيير أرصدة تلقائيًا.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item {
                var periodMenu by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = periodMenu, onExpandedChange = { periodMenu = !periodMenu }) {
                    OutlinedTextField(
                        value = selectedPeriod?.let { "${it.periodKey} • ${if (it.status == "open") "مفتوحة" else "مغلقة"}" } ?: selectedPeriodKey,
                        onValueChange = {}, readOnly = true,
                        label = { Text("الفترة المالية محل المراجعة") },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = periodMenu) }
                    )
                    ExposedDropdownMenu(expanded = periodMenu, onDismissRequest = { periodMenu = false }) {
                        periods.forEach { p ->
                            DropdownMenuItem(
                                text = { Text("${p.periodKey} • ${if (p.status == "open") "مفتوحة" else "مغلقة"}") },
                                onClick = { selectedPeriodKey = p.periodKey; periodMenu = false }
                            )
                        }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = section == "vendors", onClick = { section = "vendors" }, label = { Text("مطابقة الموردين") })
                    FilterChip(selected = section == "banks", onClick = { section = "banks" }, label = { Text("البنوك والخزائن") })
                    FilterChip(selected = section == "closing", onClick = { section = "closing" }, label = { Text("الإقفال الشهري") })
                }
            }
            if (message.isNotBlank()) item { Text(message, color = MaterialTheme.colorScheme.primary) }
            if (errorMessage.isNotBlank()) item { Text(errorMessage, color = MaterialTheme.colorScheme.error) }

            when (section) {
                "vendors" -> {
                    item {
                        val snapshot = vendorSnapshot
                        Text("مطابقة دفتر الموردين مع الأستاذ العام", style = MaterialTheme.typography.titleMedium)
                        if (snapshot == null) Text("جارٍ احتساب الأرصدة…") else {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FinancialMetric("دفتر الموردين", Money.format(snapshot.subledgerBalancePiasters), Modifier.weight(1f))
                                FinancialMetric("حساب الرقابة 2100", Money.format(snapshot.controlAccountBalancePiasters), Modifier.weight(1f))
                            }
                            FinancialMetric(
                                "فرق المطابقة",
                                Money.format(snapshot.differencePiasters),
                                Modifier.fillMaxWidth(),
                                if (snapshot.differencePiasters == 0L && snapshot.unassignedInvoiceCount == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                            if (snapshot.unassignedInvoiceCount > 0) {
                                Text("يوجد ${snapshot.unassignedInvoiceCount} فاتورة بلا مورد محدد. هذه الفواتير لا يمكن نسب رصيدها إلى مورد بعينه.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                            }
                            Text("الرصيد المستحق لا يتطلب سدادًا كاملًا للإقفال؛ المهم أن يطابق مجموع دفتر الموردين حساب الرقابة. يمكن أن تنتقل أرصدة الموردين المستحقة للشهر التالي.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    val rows = vendorSnapshot?.rows.orEmpty()
                    if (rows.isEmpty()) item { Text("لا توجد فواتير موردين حتى نهاية الفترة المحددة.") }
                    items(rows, key = { it.vendorId ?: -1L }) { row ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(row.vendorName, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                                    Text(if (row.balancePiasters == 0L) "مسدد" else "مستحق", color = if (row.balancePiasters == 0L) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary)
                                }
                                Text("الفواتير: ${row.invoiceCount} • إجماليها: ${Money.format(row.invoicesPiasters)}", style = MaterialTheme.typography.bodySmall)
                                Text("المدفوع: ${Money.format(row.paidPiasters)} • المتبقي: ${Money.format(row.balancePiasters)}", style = MaterialTheme.typography.bodySmall)
                                if (row.unassignedInvoices > 0) Text("يحتاج تحديد المورد لهذه الفواتير: ${row.unassignedInvoices}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                "banks" -> {
                    item {
                        Text("مطابقة كشف الحساب مع الأستاذ", style = MaterialTheme.typography.titleMedium)
                        Text("أدخل حركات كشف البنك أو المحفظة كما وردت في كشف الجهة المالية. تتم المطابقة مع سطر أستاذ للحساب نفسه وبقيمة واتجاه مطابقين، وبفارق تاريخ لا يزيد عن 7 أيام.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        CashAccountPicker(cashAccounts, selectedCashAccountId) { selectedCashAccountId = it }
                    }
                    item {
                        if (selectedAccount?.type == "cash") {
                            FinancialMetric("صافي حركة الخزينة في الأستاذ", Money.format(bookNet), Modifier.fillMaxWidth())
                            Text("تتم مراجعة الخزينة النقدية بالجرد الفعلي ومقارنة رصيدها الدفتري، وليس بإدخال كشف بنك.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FinancialMetric("حركة الأستاذ", Money.format(bookNet), Modifier.weight(1f))
                                FinancialMetric("حركة الكشف", Money.format(statementNet), Modifier.weight(1f))
                            }
                            FinancialMetric("فرق حركة الشهر", Money.format(bookNet - statementNet), Modifier.fillMaxWidth(), if (bookNet == statementNet) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                            if (statementBalance != null) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FinancialMetric("رصيد أول الفترة", Money.format(statementBalance!!.openingBalancePiasters), Modifier.weight(1f))
                                    FinancialMetric("رصيد آخر الفترة", Money.format(statementBalance!!.closingBalancePiasters), Modifier.weight(1f))
                                }
                                FinancialMetric("رصيد الأستاذ حتى نهاية الفترة", Money.format(bankBookBalance), Modifier.fillMaxWidth())
                                FinancialMetric("فرق رصيد الإقفال", Money.format(bankBookBalance - statementBalance!!.closingBalancePiasters), Modifier.fillMaxWidth(), if (bankBookBalance == statementBalance!!.closingBalancePiasters) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                                val statementMovementDifference = (statementBalance!!.closingBalancePiasters - statementBalance!!.openingBalancePiasters) - bankStatementMovement
                                if (statementMovementDifference != 0L) Text("حركة كشف الحساب لا تساوي الفرق بين رصيد أول وآخر الفترة: ${Money.format(statementMovementDifference)}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                            } else {
                                Text("لم يتم تسجيل رصيد أول وآخر الفترة من كشف البنك بعد.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                            }
                            Text("بنود كشف غير مطابقة: $unmatchedStatements • حركات أستاذ غير مطابقة: $unmatchedBook", color = if (unmatchedStatements + unmatchedBook == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    if (selectedAccount?.type == "cash") {
                        item {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("الجرد الفعلي للخزينة", style = MaterialTheme.typography.titleSmall)
                                    Text("رصيد الأستاذ حتى نهاية الفترة: ${Money.format(bookBalance)}", style = MaterialTheme.typography.bodyMedium)
                                    Text("آخر جرد في الفترة: ${currentCount?.let { Money.format(it.actualAmountPiasters) } ?: "لم يسجل"}", style = MaterialTheme.typography.bodyMedium)
                                    if (currentCount != null) {
                                        val diff = currentCount.actualAmountPiasters - bookBalance
                                        Text("فرق الجرد: ${Money.format(diff)}", color = if (diff == 0L) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                                    }
                                    OutlinedTextField(cashCountAmount, { cashCountAmount = it }, label = { Text("المبلغ الفعلي بالجنيه") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    OutlinedTextField(cashCountNote, { cashCountNote = it }, label = { Text("ملاحظات / اسم القائم بالجرد") }, modifier = Modifier.fillMaxWidth())
                                    Button(
                                        enabled = selectedPeriod?.status == "open" && Money.parseNonNegative(cashCountAmount) != null,
                                        onClick = {
                                            val amount = Money.parseNonNegative(cashCountAmount) ?: 0L
                                            scope.launch {
                                                runCatching { repository.recordCashCount(selectedCashAccountId, selectedPeriodKey, amount, cashCountNote) }
                                                    .onSuccess { message = "تم حفظ الجرد الفعلي"; cashCountAmount = ""; cashCountNote = ""; readinessRevision++ }
                                                    .onFailure { errorMessage = it.message ?: "تعذر حفظ الجرد" }
                                            }
                                        }, modifier = Modifier.fillMaxWidth()
                                    ) { Text("حفظ جرد نهاية الفترة") }
                                }
                            }
                        }
                    } else {
                        item {
                            StatementBalanceForm(
                                periodKey = selectedPeriodKey,
                                periodOpen = selectedPeriod?.status == "open",
                                current = statementBalance,
                                onSave = { opening, closing, note ->
                                    scope.launch {
                                        runCatching { repository.saveStatementBalance(selectedCashAccountId, selectedPeriodKey, opening, closing, note) }
                                            .onSuccess { message = "تم حفظ رصيد أول وآخر الفترة من كشف البنك"; readinessRevision++ }
                                            .onFailure { errorMessage = it.message ?: "تعذر حفظ أرصدة كشف البنك" }
                                    }
                                }
                            )
                        }
                        item { StatementEntryForm(
                            periodKey = selectedPeriodKey,
                            periodOpen = selectedPeriod?.status == "open",
                            onSave = { date, reference, description, debit, credit ->
                                scope.launch {
                                    runCatching { repository.addStatementLine(selectedCashAccountId, date, reference, description, debit, credit) }
                                        .onSuccess { message = "تمت إضافة حركة كشف الحساب"; readinessRevision++ }
                                        .onFailure { errorMessage = it.message ?: "تعذر إضافة حركة كشف الحساب" }
                                }
                            }
                        ) }
                    }
                    if (selectedAccount?.type != "cash") {
                        item { Text("حركات كشف الحساب — $selectedPeriodKey", style = MaterialTheme.typography.titleSmall) }
                        items(periodStatements, key = { it.id }) { line ->
                            val selected = line.id == selectedStatementLineId
                            Card(colors = CardDefaults.cardColors(containerColor = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface)) {
                                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    TextButton(onClick = { selectedStatementLineId = if (selected) null else line.id }) {
                                        Text("${if (line.matchedJournalLineId == null) "غير مطابقة" else "مطابقة"} • ${line.description}")
                                    }
                                    Text("${formatDate(line.statementDate)} • ${line.reference}", style = MaterialTheme.typography.bodySmall)
                                    Text("إيداع: ${Money.format(line.debitPiasters)}  |  سحب: ${Money.format(line.creditPiasters)}", style = MaterialTheme.typography.bodySmall)
                                    if (line.matchedJournalLineId != null) Text("مرتبطة بسطر الأستاذ #${line.matchedJournalLineId}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                                    if (selected && line.matchedJournalLineId == null) {
                                        val from = line.statementDate - 7L * 24L * 60L * 60L * 1000L
                                        val to = line.statementDate + 7L * 24L * 60L * 60L * 1000L
                                        val candidates by controlDao.observeCandidates(selectedCashAccountId, line.periodKey, from, to).collectAsStateWithLifecycle(emptyList())
                                        var candidateExpanded by remember(line.id) { mutableStateOf(false) }
                                        var candidateId by remember(line.id) { mutableStateOf<Long?>(null) }
                                        val chosen = candidates.firstOrNull { it.journalLineId == candidateId }
                                        ExposedDropdownMenuBox(expanded = candidateExpanded, onExpandedChange = { candidateExpanded = !candidateExpanded }) {
                                            OutlinedTextField(
                                                value = chosen?.let { "${it.entryNo} • ${it.description} • ${Money.format(it.debitPiasters - it.creditPiasters)}" } ?: "اختر حركة الأستاذ المطابقة",
                                                onValueChange = {}, readOnly = true, label = { Text("حركة الأستاذ") },
                                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(candidateExpanded) },
                                                modifier = Modifier.menuAnchor().fillMaxWidth()
                                            )
                                            ExposedDropdownMenu(expanded = candidateExpanded, onDismissRequest = { candidateExpanded = false }) {
                                                candidates.forEach { candidate ->
                                                    DropdownMenuItem(
                                                        text = { Text("${candidate.entryNo} • ${candidate.description} • ${Money.format(candidate.debitPiasters - candidate.creditPiasters)}") },
                                                        onClick = { candidateId = candidate.journalLineId; candidateExpanded = false }
                                                    )
                                                }
                                            }
                                        }
                                        Button(
                                            enabled = candidateId != null && selectedPeriod?.status == "open" && line.periodKey == selectedPeriodKey,
                                            onClick = {
                                                val id = candidateId ?: return@Button
                                                scope.launch {
                                                    runCatching { repository.matchStatementLine(line.id, id) }
                                                        .onSuccess { message = "تمت مطابقة حركة كشف الحساب"; selectedStatementLineId = null; readinessRevision++ }
                                                        .onFailure { errorMessage = it.message ?: "تعذرت المطابقة" }
                                                }
                                            }, modifier = Modifier.fillMaxWidth()
                                        ) { Text("اعتماد المطابقة") }
                                    }
                                    if (selected && line.matchedJournalLineId != null) {
                                        OutlinedButton(
                                            enabled = selectedPeriod?.status == "open",
                                            onClick = {
                                                scope.launch {
                                                    runCatching { repository.unmatchStatementLine(line.id) }
                                                        .onSuccess { message = "تم إلغاء المطابقة ويمكن اختيار سطر آخر"; readinessRevision++ }
                                                        .onFailure { errorMessage = it.message ?: "تعذر إلغاء المطابقة" }
                                                }
                                            }, modifier = Modifier.fillMaxWidth()
                                        ) { Text("إلغاء المطابقة") }
                                    }
                                }
                            }
                        }
                    }
                }
                "closing" -> {
                    item {
                        Text("بوابة الإقفال المالي", style = MaterialTheme.typography.titleMedium)
                        Text("لا يُسمح بالإقفال إلا بعد اجتياز فحوص القيود والموردين والبنوك والخزائن. أرصدة الموردين المستحقة يمكن ترحيلها للشهر التالي ولا تمنع الإقفال وحدها.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (readinessBusy) LinearProgressIndicator(Modifier.fillMaxWidth())
                        val ready = closeReadiness
                        if (ready != null) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FinancialMetric("رصيد الموردين", Money.format(ready.vendorSubledgerPiasters), Modifier.weight(1f))
                                FinancialMetric("حساب 2100", Money.format(ready.vendorControlPiasters), Modifier.weight(1f))
                            }
                            FinancialMetric("فرق الرقابة", Money.format(ready.vendorDifferencePiasters), Modifier.fillMaxWidth(), if (ready.vendorDifferencePiasters == 0L) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                            Text(if (ready.canClose) "جميع فحوص الإقفال ناجحة." else "لا يمكن إقفال الفترة حاليًا — يلزم معالجة البنود التالية:", color = if (ready.canClose) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error, style = MaterialTheme.typography.titleSmall)
                            ready.issues.forEach { issue ->
                                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("${issue.title} • ${issue.count}", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onErrorContainer)
                                        Text(issue.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                                    }
                                }
                            }
                        }
                        var closeNote by remember(selectedPeriodKey) { mutableStateOf("") }
                        var reopenNote by remember(selectedPeriodKey) { mutableStateOf("") }
                        OutlinedTextField(closeNote, { closeNote = it }, label = { Text("ملاحظات الإقفال / اسم المراجع") }, modifier = Modifier.fillMaxWidth())
                        if (selectedPeriod?.status == "open") {
                            Button(
                                enabled = closeReadiness?.canClose == true && !readinessBusy,
                                onClick = {
                                    scope.launch {
                                        runCatching { accounting.closePeriod(selectedPeriodKey, closeNote) }
                                            .onSuccess { message = "تم إقفال الفترة $selectedPeriodKey وحفظ لقطة الرقابة"; closeNote = ""; readinessRevision++ }
                                            .onFailure { errorMessage = it.message ?: "تعذر إقفال الفترة" }
                                    }
                                }, modifier = Modifier.fillMaxWidth()
                            ) { Text("إقفال الشهر بعد اجتياز المراجعة") }
                        } else if (selectedPeriod?.status == "closed") {
                            Text("هذه الفترة مغلقة. إعادة الفتح تحتاج سببًا واضحًا، وتظل لقطة الإقفال السابقة محفوظة.", style = MaterialTheme.typography.bodySmall)
                            OutlinedTextField(reopenNote, { reopenNote = it }, label = { Text("سبب إعادة فتح الفترة") }, modifier = Modifier.fillMaxWidth())
                            OutlinedButton(
                                enabled = reopenNote.isNotBlank(),
                                onClick = {
                                    scope.launch {
                                        runCatching { accounting.reopenPeriod(selectedPeriodKey, reopenNote) }
                                            .onSuccess { message = "تمت إعادة فتح الفترة مع الاحتفاظ بسجل الإقفال السابق"; reopenNote = ""; readinessRevision++ }
                                            .onFailure { errorMessage = it.message ?: "تعذرت إعادة الفتح" }
                                    }
                                }, modifier = Modifier.fillMaxWidth()
                            ) { Text("إعادة فتح بمبرر") }
                        }
                        OutlinedButton(onClick = { readinessRevision++ }, modifier = Modifier.fillMaxWidth()) { Text("إعادة فحص جميع الضوابط") }
                    }
                    item {
                        Text("سجل لقطات الإقفال السابقة", style = MaterialTheme.typography.titleSmall)
                        if (closeAudits.isEmpty()) Text("لا توجد فترات تم إقفالها وفق ضوابط الرقابة الجديدة بعد.", style = MaterialTheme.typography.bodySmall)
                    }
                    items(closeAudits.take(12), key = { it.id }) { audit ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("${audit.periodKey} • ${formatDate(audit.closedAt)}", style = MaterialTheme.typography.titleSmall)
                                Text("دفتر الموردين: ${Money.format(audit.vendorSubledgerPiasters)} • حساب 2100: ${Money.format(audit.vendorControlPiasters)}", style = MaterialTheme.typography.bodySmall)
                                Text("فحوص البنك: فروق الأرصدة ${audit.bankStatementBalanceDifferences} • فروق الحركة ${audit.bankStatementMovementDifferences}", style = MaterialTheme.typography.bodySmall)
                                Text("تنبيهات التكرار: فواتير ${audit.possibleDuplicateInvoices} • مراجع كشف ${audit.duplicateStatementReferences}", style = MaterialTheme.typography.bodySmall)
                                Text("عمليات بلا قيد محاسبي وقت الإقفال: ${audit.missingOperationalPosts}", style = MaterialTheme.typography.bodySmall)
                                Text("ملاحظات الإقفال: ${audit.note.ifBlank { "لا توجد" }}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FinancialMetric(label: String, value: String, modifier: Modifier = Modifier, valueColor: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface) {
    Card(modifier) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.titleSmall, color = valueColor)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CashAccountPicker(accounts: List<CashAccount>, selectedId: String, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val current = accounts.firstOrNull { it.id == selectedId }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(
            value = current?.name ?: "اختر الحساب",
            onValueChange = {}, readOnly = true,
            label = { Text("الخزينة / البنك / المحفظة") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            accounts.forEach { account ->
                DropdownMenuItem(text = { Text("${account.name} • ${account.type}") }, onClick = { onSelected(account.id); expanded = false })
            }
        }
    }
}

@Composable
private fun StatementBalanceForm(
    periodKey: String,
    periodOpen: Boolean,
    current: CashStatementBalance?,
    onSave: (Long, Long, String) -> Unit
) {
    var opening by remember(periodKey, current?.id) { mutableStateOf(current?.let { Money.format(it.openingBalancePiasters) } ?: "") }
    var closing by remember(periodKey, current?.id) { mutableStateOf(current?.let { Money.format(it.closingBalancePiasters) } ?: "") }
    var note by remember(periodKey, current?.id) { mutableStateOf(current?.note.orEmpty()) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("أرصدة كشف البنك للفترة $periodKey", style = MaterialTheme.typography.titleSmall)
            OutlinedTextField(opening, { opening = it }, label = { Text("رصيد أول الفترة بالجنيه") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(closing, { closing = it }, label = { Text("رصيد آخر الفترة بالجنيه") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(note, { note = it }, label = { Text("مرجع الكشف / ملاحظات") }, modifier = Modifier.fillMaxWidth())
            Button(
                enabled = periodOpen && Money.parseNonNegative(opening) != null && Money.parseNonNegative(closing) != null,
                onClick = {
                    val openValue = Money.parseNonNegative(opening) ?: return@Button
                    val closeValue = Money.parseNonNegative(closing) ?: return@Button
                    onSave(openValue, closeValue, note)
                }, modifier = Modifier.fillMaxWidth()
            ) { Text(if (current == null) "حفظ أرصدة كشف البنك" else "تحديث أرصدة كشف البنك") }
            if (!periodOpen) Text("الفترة مغلقة؛ لا يمكن تعديل كشف البنك قبل إعادة فتحها.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun StatementEntryForm(
    periodKey: String,
    periodOpen: Boolean,
    onSave: (Long, String, String, Long, Long) -> Unit
) {
    var date by remember(periodKey) { mutableStateOf(runCatching { YearMonth.parse(periodKey).atEndOfMonth().toString() }.getOrDefault(LocalDate.now().toString())) }
    var reference by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var direction by remember { mutableStateOf("debit") }
    var localError by remember { mutableStateOf("") }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("إضافة بند من كشف البنك / المحفظة", style = MaterialTheme.typography.titleSmall)
            Text("سجّل الإيداع كزيادة لرصيد البنك في دفاترنا، والسحب كنقص. راجع اتجاه كشف البنك قبل الإدخال.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(date, { date = it }, label = { Text("تاريخ الكشف YYYY-MM-DD") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(reference, { reference = it }, label = { Text("رقم المرجع البنكي") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(description, { description = it }, label = { Text("البيان كما ورد في الكشف") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = direction == "debit", onClick = { direction = "debit" }, label = { Text("إيداع / زيادة رصيد الأستاذ") })
                FilterChip(selected = direction == "credit", onClick = { direction = "credit" }, label = { Text("سحب / نقص رصيد الأستاذ") })
            }
            OutlinedTextField(amount, { amount = it }, label = { Text("المبلغ بالجنيه") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), singleLine = true)
            if (localError.isNotBlank()) Text(localError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            Button(
                enabled = periodOpen && date.isNotBlank() && description.isNotBlank() && Money.parse(amount) != null,
                onClick = {
                    val parsedDate = runCatching { LocalDate.parse(date) }.getOrNull()
                    val parsedAmount = Money.parse(amount)
                    if (parsedDate == null || parsedAmount == null) {
                        localError = "راجع التاريخ والمبلغ"
                    } else if (YearMonth.from(parsedDate).toString() != periodKey) {
                        localError = "تاريخ الحركة يجب أن يكون داخل الفترة $periodKey"
                    } else {
                        val timestamp = parsedDate.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                        onSave(timestamp, reference, description, if (direction == "debit") parsedAmount else 0L, if (direction == "credit") parsedAmount else 0L)
                        amount = ""; reference = ""; description = ""; localError = ""
                    }
                }, modifier = Modifier.fillMaxWidth()
            ) { Text("حفظ حركة كشف الحساب") }
            if (!periodOpen) Text("الفترة المختارة مغلقة؛ لا يمكن إضافة حركات إليها قبل إعادة فتحها.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
    }
}

private fun formatDate(timestamp: Long): String =
    Instant.ofEpochMilli(timestamp).atZone(ZoneId.systemDefault()).toLocalDate().toString()
