package com.tahseel.students.util

import android.content.Context
import android.content.Intent
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import com.tahseel.students.vm.MonthlyReport
import java.time.format.DateTimeFormatter
import java.util.Locale

object MonthlyReportPrinter {
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    private fun html(context: Context, r: MonthlyReport): String {
        val profile = context.getSharedPreferences("receipt_profile", Context.MODE_PRIVATE)
        val profileComplete = AcademyProfileStore.isSetupComplete(context)
        val academyName = esc(AcademyProfileStore.getName(context))
        val academyAddress = if (profileComplete) esc(profile.getString("address", "") ?: "") else ""
        val academyPhone = if (profileComplete) esc(profile.getString("phone", "") ?: "") else ""
        val profileLine = listOf(academyAddress, academyPhone.takeIf { it.isNotBlank() }?.let { "هاتف: $it" }).filterNotNull().filter { it.isNotBlank() }.joinToString(" | ")
        val month = esc(r.month.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)))
        val payments = r.payments.joinToString("") { "<tr><td>${esc(it.studentName)}</td><td>${esc(it.receiptNo)}</td><td>${Money.format(it.amountPiasters)}</td><td>${TimeUtil.fmt(it.createdAt)}</td></tr>" }
        val expenses = r.expenses.joinToString("") { "<tr><td>${esc(it.title)}</td><td>${Money.format(it.amountPiasters)}</td><td>${Money.format(it.paidAmountPiasters)}</td><td>${Money.format((it.amountPiasters-it.paidAmountPiasters).coerceAtLeast(0))}</td></tr>" }
        return """<!doctype html><html lang='ar' dir='rtl'><head><meta charset='utf-8'><style>
        @page{size:A4;margin:14mm}*{box-sizing:border-box}body{font-family:'Noto Naskh Arabic','Arial',sans-serif;color:#222;font-size:12pt;direction:rtl}
        h1{text-align:center;color:#263f68;font-size:22pt;margin:0}h2{text-align:center;font-size:16pt;margin:6px 0 16px}
        .meta{text-align:center;color:#555;border-bottom:2px solid #263f68;padding-bottom:10px;margin-bottom:14px}
        table{width:100%;border-collapse:collapse;margin:8px 0 18px;page-break-inside:auto}thead{display:table-header-group}tr{page-break-inside:avoid}
        th,td{border:1px solid #777;padding:7px;text-align:right}th{background:#e9edf3} .cards{display:grid;grid-template-columns:1fr 1fr;gap:8px}
        .card{border:1px solid #888;padding:9px;border-radius:5px}.label{font-size:10pt;color:#555}.value{font-size:14pt;font-weight:bold;margin-top:4px}
        h3{background:#263f68;color:white;padding:7px;font-size:14pt;margin:16px 0 6px}.foot{margin-top:28px;border-top:1px solid #777;padding-top:10px;display:flex;justify-content:space-between}
        </style></head><body><h1>$academyName</h1>${if (profileLine.isNotBlank()) "<div class='meta'>$profileLine</div>" else ""}<h2>التقرير المالي الشهري</h2><div class='meta'>الفترة: $month<br>تاريخ الطباعة: ${TimeUtil.fmt(System.currentTimeMillis())}</div>
        <div class='cards'>
        <div class='card'><div class='label'>الاشتراكات المستحقة</div><div class='value'>${Money.format(r.due)}</div></div>
        <div class='card'><div class='label'>إجمالي المقبوضات (بعد استبعاد الملغي)</div><div class='value'>${Money.format(r.collected)}</div></div>
        <div class='card'><div class='label'>تحصيل الاشتراكات</div><div class='value'>${Money.format(r.subscriptionCollected)}</div></div>
        <div class='card'><div class='label'>المصروفات المدفوعة</div><div class='value'>${Money.format(r.expensesPaid)}</div></div>
        <div class='card'><div class='label'>صافي الحركة النقدية</div><div class='value'>${Money.format(r.net)}</div></div>
        <div class='card'><div class='label'>إجمالي المصروفات</div><div class='value'>${Money.format(r.expensesTotal)}</div></div>
        <div class='card'><div class='label'>المتبقي من المصروفات</div><div class='value'>${Money.format(r.expensesRemaining)}</div></div>
        <div class='card'><div class='label'>متأخرات الاشتراكات</div><div class='value'>${Money.format(r.arrears)}</div></div></div>
        <h3>سجل التحصيل</h3><table><thead><tr><th>اسم الطالب</th><th>رقم الإيصال</th><th>المبلغ</th><th>التاريخ</th></tr></thead><tbody>$payments</tbody></table>
        <h3>سجل المصروفات</h3><table><thead><tr><th>بند المصروف</th><th>المستحق</th><th>المدفوع</th><th>المتبقي</th></tr></thead><tbody>$expenses</tbody></table>
        <div class='foot'><span>إعداد الإدارة</span><span>التوقيع: __________________</span></div></body></html>"""
    }
    fun print(context: Context, report: MonthlyReport) {
        val web = WebView(context)
        web.settings.javaScriptEnabled = false
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                val manager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
                val name = "Noury_Financial_Report_${report.month}"
                manager.print(name, view.createPrintDocumentAdapter(name), PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setMinMargins(PrintAttributes.Margins(360, 360, 360, 360)).build())
            }
        }
        web.loadDataWithBaseURL(null, html(context, report), "text/html", "UTF-8", null)
    }
    fun shareCsv(context: Context, report: MonthlyReport) {
        val rows = buildString {
            val profile = context.getSharedPreferences("receipt_profile", Context.MODE_PRIVATE)
            val profileComplete = AcademyProfileStore.isSetupComplete(context)
            val academyName = AcademyProfileStore.getName(context).replace("\"", "\"\"")
            val academyAddress = (if (profileComplete) profile.getString("address", "") ?: "" else "").replace("\"", "\"\"")
            val academyPhone = (if (profileComplete) profile.getString("phone", "") ?: "" else "").replace("\"", "\"\"")
            append("﻿القسم,البيان,القيمة\n")
            append("بيانات الأكاديمية,الاسم,\"$academyName\"\n")
            append("بيانات الأكاديمية,العنوان,\"$academyAddress\"\n")
            append("بيانات الأكاديمية,الهاتف,\"$academyPhone\"\n")
            append("ملخص,الاشتراكات المستحقة,${Money.plain(report.due)}\n")
            append("ملخص,إجمالي المقبوضات,${Money.plain(report.collected)}\n")
            append("ملخص,تحصيل الاشتراكات,${Money.plain(report.subscriptionCollected)}\n")
            append("ملخص,المصروفات المستحقة,${Money.plain(report.expensesTotal)}\n")
            append("ملخص,المصروفات المدفوعة,${Money.plain(report.expensesPaid)}\n")
            append("ملخص,صافي الحركة النقدية,${Money.plain(report.net)}\n")
            append("ملخص,المتبقي من المصروفات,${Money.plain(report.expensesRemaining)}\n")
            append("ملخص,متأخرات الاشتراكات,${Money.plain(report.arrears)}\n")
            append("ملخص,عدد الطلاب المستحق عليهم,${report.studentDueCount}\n")
            append("التحصيل,اسم الطالب - رقم الإيصال - المبلغ - التاريخ,\n")
            report.payments.forEach { val name = it.studentName.replace("\"", "\"\""); append("تحصيل,\"$name / ${it.receiptNo}\",${Money.plain(it.amountPiasters)},${TimeUtil.csvTime(it.createdAt)}\n") }
            report.expenses.forEach { val title = it.title.replace("\"", "\"\""); append("مصروفات,\"$title\",${Money.plain(it.amountPiasters)},${Money.plain(it.paidAmountPiasters)}\n") }
        }
        val file = java.io.File(context.cacheDir, "Noury_Report_${report.month}.csv")
        file.writeText(rows, Charsets.UTF_8)
        val uri = androidx.core.content.FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply { type = "text/csv"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        context.startActivity(Intent.createChooser(intent, "تصدير التقرير"))
    }
}
