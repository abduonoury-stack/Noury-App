package com.tahseel.students.data

import androidx.room.*
import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId
import kotlin.math.abs

/** كشف حركة خارجية واردة من كشف البنك/المحفظة. القيم بالقروش؛ المدين إيداع والدائن سحب. */
@Entity(
    tableName = "cash_statement_lines",
    foreignKeys = [
        ForeignKey(entity = CashAccount::class, parentColumns = ["id"], childColumns = ["cashAccountId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = JournalLine::class, parentColumns = ["id"], childColumns = ["matchedJournalLineId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index("cashAccountId"), Index("periodKey"), Index(value = ["matchedJournalLineId"], unique = true)]
)
data class CashStatementLine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cashAccountId: String,
    val periodKey: String,
    val statementDate: Long,
    val reference: String = "",
    val description: String,
    val debitPiasters: Long = 0L,
    val creditPiasters: Long = 0L,
    val matchedJournalLineId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

/** أرصدة أول وآخر الفترة كما وردت في كشف البنك/المحفظة؛ مستقلة عن دفتر الأستاذ. */
@Entity(
    tableName = "cash_statement_balances",
    foreignKeys = [ForeignKey(entity = CashAccount::class, parentColumns = ["id"], childColumns = ["cashAccountId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index(value = ["cashAccountId", "periodKey"], unique = true), Index("periodKey")]
)
data class CashStatementBalance(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cashAccountId: String,
    val periodKey: String,
    val openingBalancePiasters: Long,
    val closingBalancePiasters: Long,
    val note: String = "",
    val savedAt: Long = System.currentTimeMillis()
)

/** لقطة تدقيقية محفوظة عند إقفال الفترة؛ لا تستبدل سجلات الإقفال السابقة عند إعادة الفتح. */
@Entity(tableName = "financial_period_close_audits", indices = [Index("periodKey"), Index("closedAt")])
data class FinancialPeriodCloseAudit(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val periodKey: String,
    val closedAt: Long,
    val note: String,
    val vendorSubledgerPiasters: Long,
    val vendorControlPiasters: Long,
    val vendorDifferencePiasters: Long,
    val unbalancedEntries: Int,
    val duplicateSources: Int,
    val missingSourceLinks: Int,
    val invalidInvoices: Int,
    val invalidPayments: Int,
    val missingVendorLinks: Int,
    val unmatchedStatementLines: Int,
    val unmatchedBankBookLines: Int,
    val bankAccountsWithoutStatements: Int,
    @ColumnInfo(defaultValue = "0") val bankStatementBalanceDifferences: Int = 0,
    @ColumnInfo(defaultValue = "0") val bankStatementMovementDifferences: Int = 0,
    @ColumnInfo(defaultValue = "0") val possibleDuplicateInvoices: Int = 0,
    @ColumnInfo(defaultValue = "0") val duplicateStatementReferences: Int = 0,
    val unmappedCashAccounts: Int,
    val cashAccountsWithoutCounts: Int,
    val cashCountDifferences: Int,
    @ColumnInfo(defaultValue = "0") val missingOperationalPosts: Int = 0
)

data class CashStatementJournalCandidate(
    val journalLineId: Long,
    val entryId: Long,
    val entryDate: Long,
    val periodKey: String,
    val entryNo: String,
    val description: String,
    val debitPiasters: Long,
    val creditPiasters: Long,
    val memo: String,
    val sourceType: String,
    val entryStatus: String
)

data class VendorBalanceRow(
    val vendorId: Long?,
    val vendorName: String,
    val invoiceCount: Int,
    val invoicesPiasters: Long,
    val paidPiasters: Long,
    val balancePiasters: Long,
    val unassignedInvoices: Int = 0
)

data class VendorReconciliationSnapshot(
    val asOf: Long,
    val rows: List<VendorBalanceRow>,
    val subledgerBalancePiasters: Long,
    val controlAccountBalancePiasters: Long,
    val differencePiasters: Long,
    val unassignedInvoiceCount: Int
) {
    val isMatched: Boolean get() = differencePiasters == 0L && unassignedInvoiceCount == 0
}

data class FinancialCloseIssue(val code: String, val title: String, val count: Int, val detail: String)

data class FinancialCloseReadiness(
    val periodKey: String,
    val vendorSubledgerPiasters: Long,
    val vendorControlPiasters: Long,
    val vendorDifferencePiasters: Long,
    val issues: List<FinancialCloseIssue>
) {
    val canClose: Boolean get() = issues.isEmpty()
}

@Dao
interface FinancialControlDao {
    @Query("SELECT * FROM cash_statement_lines WHERE (:accountId = '' OR cashAccountId = :accountId) ORDER BY statementDate DESC, id DESC")
    fun observeStatementLines(accountId: String): Flow<List<CashStatementLine>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertStatementLine(line: CashStatementLine): Long

    @Query("SELECT * FROM cash_statement_balances WHERE cashAccountId=:cashAccountId AND periodKey=:periodKey LIMIT 1")
    fun observeStatementBalance(cashAccountId: String, periodKey: String): Flow<CashStatementBalance?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveStatementBalance(balance: CashStatementBalance): Long

    @Query("SELECT * FROM cash_statement_lines WHERE id=:id LIMIT 1")
    suspend fun statementLineById(id: Long): CashStatementLine?

    @Query("UPDATE cash_statement_lines SET matchedJournalLineId=:journalLineId WHERE id=:id AND matchedJournalLineId IS NULL")
    suspend fun setStatementMatch(id: Long, journalLineId: Long): Int

    @Query("UPDATE cash_statement_lines SET matchedJournalLineId=NULL WHERE id=:id AND matchedJournalLineId=:journalLineId")
    suspend fun clearStatementMatch(id: Long, journalLineId: Long): Int

    @Query("""
        SELECT l.id AS journalLineId, e.id AS entryId, e.entryDate AS entryDate, e.periodKey AS periodKey,
               e.entryNo AS entryNo, e.description AS description, l.debitPiasters AS debitPiasters,
               l.creditPiasters AS creditPiasters, l.memo AS memo, e.sourceType AS sourceType, e.status AS entryStatus
          FROM journal_lines l
          INNER JOIN journal_entries e ON e.id=l.entryId
          INNER JOIN cash_account_ledger_mappings m ON m.ledgerAccountId=l.accountId
         WHERE m.cashAccountId=:cashAccountId
           AND e.periodKey=:periodKey
           AND e.status='posted'
           AND e.entryDate BETWEEN :fromDate AND :toDate
           AND NOT EXISTS (SELECT 1 FROM cash_statement_lines s WHERE s.matchedJournalLineId=l.id)
         ORDER BY e.entryDate DESC, e.id DESC, l.id DESC
    """)
    fun observeCandidates(cashAccountId: String, periodKey: String, fromDate: Long, toDate: Long): Flow<List<CashStatementJournalCandidate>>

    @Query("""
        SELECT l.id AS journalLineId, e.id AS entryId, e.entryDate AS entryDate, e.periodKey AS periodKey,
               e.entryNo AS entryNo, e.description AS description, l.debitPiasters AS debitPiasters,
               l.creditPiasters AS creditPiasters, l.memo AS memo, e.sourceType AS sourceType, e.status AS entryStatus
          FROM journal_lines l
          INNER JOIN journal_entries e ON e.id=l.entryId
          INNER JOIN cash_account_ledger_mappings m ON m.ledgerAccountId=l.accountId
         WHERE m.cashAccountId=:cashAccountId AND l.id=:journalLineId AND e.status='posted'
         LIMIT 1
    """)
    suspend fun candidateById(cashAccountId: String, journalLineId: Long): CashStatementJournalCandidate?

    @Query("""
        SELECT l.id AS journalLineId, e.id AS entryId, e.entryDate AS entryDate, e.periodKey AS periodKey,
               e.entryNo AS entryNo, e.description AS description, l.debitPiasters AS debitPiasters,
               l.creditPiasters AS creditPiasters, l.memo AS memo, e.sourceType AS sourceType, e.status AS entryStatus
          FROM journal_lines l
          INNER JOIN journal_entries e ON e.id=l.entryId
          INNER JOIN cash_account_ledger_mappings m ON m.ledgerAccountId=l.accountId
         WHERE m.cashAccountId=:cashAccountId AND e.periodKey=:periodKey AND e.status IN ('posted','reversed')
         ORDER BY e.entryDate, e.id, l.id
    """)
    fun observeBookLines(cashAccountId: String, periodKey: String): Flow<List<CashStatementJournalCandidate>>

    @Query("SELECT * FROM financial_period_close_audits ORDER BY closedAt DESC LIMIT 20")
    fun observeCloseAudits(): Flow<List<FinancialPeriodCloseAudit>>
}

/**
 * عمليات المطابقة لا تنشئ قيود تسوية تلقائية. إدخال كشف البنك منفصل عن الدفاتر،
 * والمطابقة لا تتم إلا عند تطابق الحساب والقيمة والاتجاه وبعدها الزمني.
 */
class FinancialControlRepository(private val db: AppDatabase) {
    private val accounting get() = db.accountingDao()
    private val control get() = db.financialControlDao()

    suspend fun vendorReconciliation(asOf: Long): VendorReconciliationSnapshot {
        val invoices = accounting.expenseSnapshot().filter {
            it.documentDate <= asOf && it.status !in setOf("void", "deleted")
        }
        val invoiceIds = invoices.map { it.id }.toSet()
        val paidByInvoice = accounting.expensePaymentSnapshot()
            .filter { it.paidAt <= asOf && it.expenseId in invoiceIds }
            .groupBy { it.expenseId }
            .mapValues { (_, rows) -> rows.fold(0L) { total, row -> Math.addExact(total, row.amountPiasters) } }
        val vendors = accounting.vendorSnapshot().associateBy { it.id }
        val rows = invoices.groupBy { it.vendorId }.map { (vendorId, vendorInvoices) ->
            val invoiceTotal = vendorInvoices.fold(0L) { total, invoice -> Math.addExact(total, invoice.amountPiasters) }
            val paidTotal = vendorInvoices.fold(0L) { total, invoice -> Math.addExact(total, paidByInvoice[invoice.id] ?: 0L) }
            val missing = if (vendorId == null || vendors[vendorId] == null) vendorInvoices.size else 0
            VendorBalanceRow(
                vendorId = vendorId,
                vendorName = vendorId?.let { vendors[it]?.name } ?: "فواتير غير منسوبة لمورد",
                invoiceCount = vendorInvoices.size,
                invoicesPiasters = invoiceTotal,
                paidPiasters = paidTotal,
                balancePiasters = Math.subtractExact(invoiceTotal, paidTotal),
                unassignedInvoices = missing
            )
        }.sortedWith(compareByDescending<VendorBalanceRow> { it.balancePiasters }.thenBy { it.vendorName })
        val subledger = rows.fold(0L) { total, row -> Math.addExact(total, row.balancePiasters) }
        val controlBalance = accounting.supplierControlBalanceAsOf(asOf)
        return VendorReconciliationSnapshot(
            asOf = asOf, rows = rows, subledgerBalancePiasters = subledger,
            controlAccountBalancePiasters = controlBalance,
            differencePiasters = Math.subtractExact(subledger, controlBalance),
            unassignedInvoiceCount = rows.sumOf { it.unassignedInvoices }
        )
    }

    suspend fun addStatementLine(
        cashAccountId: String, statementDate: Long, reference: String, description: String,
        debitPiasters: Long, creditPiasters: Long
    ): Long = db.withTransaction {
        require(description.isNotBlank()) { "بيان حركة كشف الحساب مطلوب" }
        require(debitPiasters >= 0L && creditPiasters >= 0L && (debitPiasters > 0L) != (creditPiasters > 0L)) {
            "أدخل إيداعًا أو سحبًا بقيمة موجبة، وليس الاثنين معًا"
        }
        val account = db.cashAccountDao().find(cashAccountId) ?: error("الحساب المالي غير موجود")
        require(account.isActive) { "الحساب المالي غير نشط" }
        require(db.cashAccountDao().ledgerMapping(cashAccountId) != null) { "الحساب غير مربوط بحساب أستاذ مستقل" }
        val date = Instant.ofEpochMilli(statementDate).atZone(ZoneId.systemDefault()).toLocalDate()
        val periodKey = YearMonth.from(date).toString()
        require(accounting.isPeriodOpen(periodKey)) { "الفترة $periodKey مغلقة؛ أعد فتحها قبل إدخال كشف الحساب" }
        control.insertStatementLine(CashStatementLine(
            cashAccountId = cashAccountId, periodKey = periodKey, statementDate = statementDate,
            reference = reference.trim(), description = description.trim(),
            debitPiasters = debitPiasters, creditPiasters = creditPiasters
        ))
    }

    suspend fun saveStatementBalance(
        cashAccountId: String, periodKey: String, openingBalancePiasters: Long,
        closingBalancePiasters: Long, note: String
    ): Long = db.withTransaction {
        require(openingBalancePiasters >= 0L && closingBalancePiasters >= 0L) { "أرصدة كشف البنك لا يمكن أن تكون سالبة" }
        val account = db.cashAccountDao().find(cashAccountId) ?: error("الحساب المالي غير موجود")
        require(account.isActive && account.type != "cash") { "اختر بنكًا أو محفظة نشطة" }
        require(db.cashAccountDao().ledgerMapping(cashAccountId) != null) { "الحساب غير مربوط بحساب أستاذ مستقل" }
        require(accounting.isPeriodOpen(periodKey)) { "الفترة $periodKey مغلقة؛ أعد فتحها قبل تعديل أرصدة كشف البنك" }
        require(accounting.periodByKey(periodKey) != null) { "الفترة المحاسبية غير موجودة" }
        control.saveStatementBalance(CashStatementBalance(
            cashAccountId = cashAccountId, periodKey = periodKey,
            openingBalancePiasters = openingBalancePiasters,
            closingBalancePiasters = closingBalancePiasters, note = note.trim()
        ))
    }

    suspend fun matchStatementLine(statementLineId: Long, journalLineId: Long): Unit = db.withTransaction {
        val statement = control.statementLineById(statementLineId) ?: error("بند كشف الحساب غير موجود")
        require(statement.matchedJournalLineId == null) { "بند كشف الحساب تمت مطابقته بالفعل" }
        require(accounting.isPeriodOpen(statement.periodKey)) { "فترة كشف الحساب مغلقة؛ أعد فتحها قبل تعديل المطابقة" }
        val candidate = control.candidateById(statement.cashAccountId, journalLineId)
            ?: error("سطر الأستاذ غير متاح لهذا الحساب أو ليس قيدًا مرحلًا")
        require(accounting.isPeriodOpen(candidate.periodKey)) { "فترة القيد المحاسبي مغلقة؛ أعد فتحها قبل المطابقة" }
        require(abs(candidate.entryDate - statement.statementDate) <= 7L * 24L * 60L * 60L * 1000L) {
            "تاريخ القيد يبعد أكثر من 7 أيام عن حركة كشف الحساب"
        }
        require(candidate.periodKey == statement.periodKey) { "لا تتم مطابقة حركة بين فترتين ماليتين مختلفتين" }
        require(candidate.debitPiasters == statement.debitPiasters && candidate.creditPiasters == statement.creditPiasters) {
            "قيمة أو اتجاه الحركة لا يطابق سطر الأستاذ"
        }
        require(control.setStatementMatch(statementLineId, journalLineId) == 1) { "تعذر حفظ المطابقة؛ ربما تمت مطابقة الحركة في عملية أخرى" }
    }

    suspend fun unmatchStatementLine(statementLineId: Long): Unit = db.withTransaction {
        val statement = control.statementLineById(statementLineId) ?: error("بند كشف الحساب غير موجود")
        val matched = statement.matchedJournalLineId ?: return@withTransaction
        require(accounting.isPeriodOpen(statement.periodKey)) { "لا يمكن تعديل مطابقة فترة مغلقة؛ أعد فتح الفترة أولًا" }
        require(control.clearStatementMatch(statementLineId, matched) == 1) { "تعذر إلغاء المطابقة" }
    }

    suspend fun recordCashCount(cashAccountId: String, periodKey: String, actualAmountPiasters: Long, note: String): Long = db.withTransaction {
        require(PermissionGuard.allow(Permission.STOCKTAKE_SAVE)) { PermissionGuard.DENIED_MESSAGE }
        require(actualAmountPiasters >= 0L) { "قيمة الجرد لا يمكن أن تكون سالبة" }
        require(accounting.isPeriodOpen(periodKey)) { "الفترة مغلقة؛ أعد فتحها قبل تسجيل الجرد" }
        val account = db.cashAccountDao().find(cashAccountId) ?: error("الخزينة غير موجودة")
        require(account.isActive && account.type == "cash") { "اختر خزينة نقدية نشطة" }
        val period = accounting.periodByKey(periodKey) ?: error("الفترة غير موجودة")
        db.cashControlDao().insertCount(CashCount(
            countedAt = period.endDate, actualAmountPiasters = actualAmountPiasters,
            note = note.trim(), accountId = cashAccountId
        )).toLong()
    }

    suspend fun closeReadiness(periodKey: String): FinancialCloseReadiness {
        val period = accounting.periodByKey(periodKey) ?: error("الفترة المحاسبية غير موجودة")
        val asOf = period.endDate
        val vendor = vendorReconciliation(asOf)
        val issues = mutableListOf<FinancialCloseIssue>()
        fun add(code: String, title: String, count: Int, detail: String) {
            if (count > 0) issues += FinancialCloseIssue(code, title, count, detail)
        }
        add("unbalanced", "قيود غير متوازنة", accounting.periodUnbalancedEntries(periodKey), "راجع إجمالي المدين والدائن لكل قيد قبل الإقفال")
        add("duplicate_sources", "مصادر مالية مكررة", accounting.periodDuplicateSources(periodKey), "يوجد أكثر من قيد مرتبط بمصدر العملية نفسه")
        add("missing_sources", "قيود بلا مرجع ترحيل", accounting.periodMissingSourceLinks(periodKey), "راجع سجل الترحيل والقيود المرتبطة بمصادرها")
        add("missing_operational_posts", "عمليات مالية بلا قيود محاسبية", accounting.periodMissingOperationalPosts(periodKey), "راجع التحصيل والاشتراكات والمرتبات والسلف والاستردادات والتحويلات؛ كل عملية مالية فعلية يجب أن يكون لها قيد مصدر مرتبط")
        add("orphan_posts", "مراجع ترحيل يتيمة", accounting.orphanSourcePostCount(), "يوجد مرجع ترحيل لا يشير إلى قيد صحيح")
        add("invalid_invoices", "فواتير بلا قيد استحقاق سليم", accounting.periodInvalidInvoices(periodKey), "تحقق من قيد المصروف وحساب الموردين 2100")
        add("duplicate_invoices", "أرقام فواتير مكررة لدى الموردين", accounting.periodPossibleDuplicateInvoices(periodKey), "راجع رقم المستند والمورد؛ قد تكون فاتورة واحدة مسجلة مرتين")
        add("invalid_payments", "دفعات بلا قيد سداد سليم", accounting.periodInvalidPayments(periodKey), "تحقق من حساب الموردين والبنك/الخزينة ومقدار الدفعة")
        add("missing_vendor", "فواتير بلا مورد محدد", accounting.periodMissingVendorLinks(periodKey), "اربط كل فاتورة بمورد قبل اعتماد دفتر الموردين")
        add("unmatched_statement", "بنود كشف بنك غير مطابقة", accounting.periodUnmatchedStatementLines(periodKey), "طابق كل سطر كشف مع سطر الأستاذ الموافق")
        add("duplicate_statement_refs", "مراجع كشف بنك مكررة محتملة", accounting.periodDuplicateStatementReferences(periodKey), "راجع المرجع والتاريخ والقيمة؛ لا تحذف بندًا قبل التحقق من كشف البنك")
        add("unmatched_book", "حركات بنك بالأستاذ بلا كشف مطابق", accounting.periodUnmatchedBankBookLines(periodKey), "أدخل سطور كشف البنك ثم طابقها مع الحركات المرحلة")
        add("no_bank_statement", "حسابات بنكية بلا كشف للفترة", accounting.periodBankAccountsWithoutStatements(periodKey), "أدخل أرصدة أول وآخر الفترة من كشف كل بنك/محفظة نشطة لها حركة")
        add("bank_balance_difference", "فرق رصيد كشف البنك عن الأستاذ", accounting.periodBankStatementBalanceDifferences(periodKey), "راجع رصيد الإقفال في كشف البنك مع رصيد حساب الأستاذ حتى نهاية الفترة")
        add("bank_movement_difference", "حركة كشف البنك لا تساوي فرق رصيدي أول وآخر الفترة", accounting.periodBankStatementMovementDifferences(periodKey), "راجع جميع حركات الكشف بين رصيد البداية ورصيد النهاية")
        add("unmapped_cash", "حسابات خزائن/بنوك بلا ربط أستاذ", accounting.activeCashAccountsWithoutMapping(), "أكمل الربط المحاسبي لكل الحسابات النشطة")
        add("cash_count_missing", "خزائن لم تسجل جردًا فعليًا", accounting.periodCashAccountsWithoutCounts(periodKey), "سجل جردًا فعليًا لكل خزينة لها حركة خلال الفترة")
        add("cash_count_difference", "فروق جرد الخزائن عن الأستاذ", accounting.periodCashCountDifferences(periodKey), "راجع الرصيد الفعلي والرصيد الدفتري ولا تنشئ تسوية دون مستند")
        if (vendor.differencePiasters != 0L) {
            issues += FinancialCloseIssue("vendor_control", "فرق بين دفتر الموردين وحساب الرقابة 2100", 1,
                "فرق المطابقة: ${vendor.differencePiasters} قرش. لا تُنشئ قيد تسوية تلقائيًا؛ راجع مصدر الفرق.")
        }
        return FinancialCloseReadiness(periodKey, vendor.subledgerBalancePiasters,
            vendor.controlAccountBalancePiasters, vendor.differencePiasters, issues)
    }
}
