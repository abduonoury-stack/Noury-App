package com.tahseel.students.ui

import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.tahseel.students.util.AcademyProfileStore

@Composable
fun AcademySetupScreen(onComplete: () -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Box(Modifier.fillMaxSize().imePadding()) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(Modifier.height(8.dp))
            Image(painterResource(com.tahseel.students.R.drawable.canaria_logo), contentDescription = "Noury App", modifier = Modifier.size(82.dp))
            Text("مرحبًا بك في Noury App", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text("سجّل بيانات الأكاديمية مرة واحدة لتظهر تلقائيًا في جميع الشاشات والإيصالات والتقارير والطباعة.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("بيانات الأكاديمية", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = name, onValueChange = { name = it; error = null },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        label = { Text("اسم الأكاديمية") }, leadingIcon = { Icon(Icons.Default.Business, null) },
                        placeholder = { Text("اكتب اسم الأكاديمية") }
                    )
                    OutlinedTextField(
                        value = phone, onValueChange = { phone = it; error = null },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        label = { Text("رقم التواصل") }, leadingIcon = { Icon(Icons.Default.PhoneAndroid, null) },
                        placeholder = { Text("01xxxxxxxxx") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                    )
                    OutlinedTextField(
                        value = address, onValueChange = { address = it; error = null },
                        modifier = Modifier.fillMaxWidth(), minLines = 2,
                        label = { Text("عنوان الأكاديمية") }, leadingIcon = { Icon(Icons.Default.LocationOn, null) },
                        placeholder = { Text("المحافظة – المنطقة – العنوان بالتفصيل") }
                    )
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                    Button(
                        onClick = {
                            when {
                                name.isBlank() -> error = "من فضلك اكتب اسم الأكاديمية."
                                phone.filter(Char::isDigit).length < 8 -> error = "من فضلك اكتب رقم موبايل صحيحًا."
                                address.isBlank() -> error = "من فضلك اكتب عنوان الأكاديمية."
                                else -> {
                                    AcademyProfileStore.save(context, name, address, phone)
                                    onComplete()
                                }
                            }
                        }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) { Text("حفظ البيانات وبدء الاستخدام", fontWeight = FontWeight.Bold) }
                }
            }
            Text("يمكنك تعديل هذه البيانات لاحقًا من الإعدادات، وسيتم تحديثها في البرنامج كله.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
