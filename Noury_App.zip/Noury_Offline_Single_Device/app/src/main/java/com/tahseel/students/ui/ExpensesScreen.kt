package com.tahseel.students.ui

import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tahseel.students.data.Expense
import com.tahseel.students.data.ExpenseDao
import com.tahseel.students.data.CashAccountDao
import com.tahseel.students.data.expensesForMonth
import com.tahseel.students.data.expenseMonthTotals
import com.tahseel.students.data.auditExpenseRegister
import com.tahseel.students.data.ExpenseAuditSeverity
import com.tahseel.students.util.Money
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale

private val recurringExpenseNames = listOf("الإيجار", "المرتبات", "فاتورة المياه", "فاتورة الكهرباء", "قرض البنك", "عامل النظافة")

class ExpensesViewModel(private val dao: ExpenseDao, cashAccountDao: CashAccountDao) : ViewModel() {
    val accounts = cashAccountDao.observeActive().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val items = dao.observeAll().map { all -> all.filter { it.deletedAt == null } }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val monthLocks = dao.observeMonthLocks().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val auditHistory = dao.observeExpenseAudit().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val payments = dao.observeAllPayments().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun ensureMonth(month: YearMonth) = viewModelScope.launch {
        val zone = ZoneId.systemDefault()
        val monthStart = month.atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
        val nextMonthStart = month.plusMonths(1).atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
        if (dao.isMonthLocked(month.toString())) return@launch
        recurringExpenseNames.forEach { name ->
            if (dao.findMonthly(month.toString(), name, name, monthStart, nextMonthStart) == null) {
                val due = month.atDay(5).atStartOfDay(zone).toInstant().toEpochMilli()
                dao.insertIfMissing(Expense(title = name, category = name, amountPiasters = 0L,
                    spentAt = monthStart, note = "", paidAmountPiasters = 0L, dueAt = due, monthKey = month.toString()))
            }
        }
    }

    fun save(id: Long?, title: String, category: String, amount: Long, paid: Long, note: String, dueAt: Long, month: YearMonth) = viewModelScope.launch {
        val old = id?.let { items.value.firstOrNull { e -> e.id == it } }
        val normalizedTitle = title.trim()
        val isSalaryEntry = category == "المرتبات" || normalizedTitle.contains("المرتبات") || normalizedTitle.contains("مرتبات") || normalizedTitle.contains("رواتب")
        if (isSalaryEntry || old?.note?.startsWith("HR_SYNC:") == true) return@launch
        val now = System.currentTimeMillis()
        val monthStart = month.atDay(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val item = Expense(id = id ?: 0, title = normalizedTitle, category = category,
            amountPiasters = amount.coerceAtLeast(0), spentAt = old?.spentAt ?: monthStart, note = note.trim(),
            createdAt = old?.createdAt ?: now, updatedAt = now,
            paidAmountPiasters = old?.paidAmountPiasters ?: 0L, dueAt = dueAt, monthKey = month.toString())
        dao.saveEditable(item)
    }
    fun closeMonth(month: YearMonth) = viewModelScope.launch { if (!com.tahseel.students.data.PermissionGuard.allow(com.tahseel.students.data.Permission.PERIOD_CLOSE)) return@launch; dao.closeMonth(month.toString(), "إغلاق يدوي من شاشة المصروفات") }
    fun reopenMonth(month: YearMonth) = viewModelScope.launch { if (!com.tahseel.students.data.PermissionGuard.allow(com.tahseel.students.data.Permission.PERIOD_CLOSE)) return@launch; dao.reopenMonth(month.toString()) }
    fun recordPayment(expenseId: Long, amount: Long, date: LocalDate, method: String, note: String, accountId: String) = viewModelScope.launch {
        val timestamp = date.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        dao.recordPayment(expenseId, amount, timestamp, method, note, accountId)
    }
    fun delete(id: Long) = viewModelScope.launch { dao.softDeleteExpense(id) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpensesScreen(vm: ExpensesViewModel, onBack: () -> Unit) {
    val rows by vm.items.collectAsState()
    val paymentRows by vm.payments.collectAsState()
    val cashAccounts by vm.accounts.collectAsState()
    val monthLocks by vm.monthLocks.collectAsState()
    val auditHistory by vm.auditHistory.collectAsState()
    var showAuditHistory by remember { mutableStateOf(false) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    val monthIsLocked = monthLocks.any { it.monthKey == month.toString() }
    LaunchedEffect(month) { vm.ensureMonth(month) }
    val monthRows = expensesForMonth(rows, month).filterNot { it.category == "أرشيف مزامنة المرتبات" }
    val expenseTotals = expenseMonthTotals(monthRows)
    val total = expenseTotals.committed
    val paidTotal = expenseTotals.paid
    val remaining = expenseTotals.remaining
    val auditIssues = auditExpenseRegister(monthRows, paymentRows, System.currentTimeMillis(), month)
    val errorCount = auditIssues.count { it.severity == ExpenseAuditSeverity.ERROR }
    val warningCount = auditIssues.count { it.severity == ExpenseAuditSeverity.WARNING }
    var searchQuery by remember { mutableStateOf("") }
    var categoryFilter by remember { mutableStateOf("الكل") }
    val visibleRows = monthRows.filter { item ->
        (searchQuery.isBlank() || item.title.contains(searchQuery.trim(), ignoreCase = true) ||
            item.category.contains(searchQuery.trim(), ignoreCase = true)) &&
            (categoryFilter == "الكل" || item.category == categoryFilter)
    }
    val categories = listOf("الكل") + monthRows.map { it.category }.distinct().sorted()
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var paid by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var dueAt by remember { mutableLongStateOf(month.atDay(5).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()) }
    var editing by remember { mutableStateOf<Long?>(null) }
    var showDatePicker by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<Long?>(null) }
    var paymentTarget by remember { mutableStateOf<Expense?>(null) }
    var paymentAmount by remember { mutableStateOf("") }
    var paymentDate by remember { mutableStateOf(LocalDate.now().toString()) }
    var paymentMethod by remember { mutableStateOf("نقدي") }
    var paymentAccountId by remember { mutableStateOf("cash") }
    var paymentNote by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("أخرى") }
    val moneyInput: (String) -> Long = { Money.parseNonNegative(it) ?: 0L }
    AppScaffold(title = "المصروفات الشهرية", onBack = onBack) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(shape = MaterialTheme.shapes.large) { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { month = month.minusMonths(1) }) { Text("‹ السابق") }
                    Text(month.format(DateTimeFormatter.ofPattern("yyyy / MM")), style = MaterialTheme.typography.titleLarge)
                    TextButton(onClick = { month = month.plusMonths(1) }) { Text("التالي ›") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(if (monthIsLocked) "الشهر مغلق — عرض فقط" else "الشهر مفتوح — التعديل متاح", color = if (monthIsLocked) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                    TextButton(onClick = { if (monthIsLocked) vm.reopenMonth(month) else vm.closeMonth(month) }) { Text(if (monthIsLocked) "إعادة فتح الشهر" else "إغلاق الشهر يدويًا") }
                }
                SummaryLine("إجمالي الالتزامات", total)
                SummaryLine("المدفوع فعليًا", paidTotal)
                SummaryLine("المتبقي", remaining, true)
                val paidRatio = if (total > 0L) (paidTotal.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
                LinearProgressIndicator(progress = paidRatio, modifier = Modifier.fillMaxWidth())
                Text("نسبة السداد: ${if (total > 0L) "%.1f".format(Locale.US, paidRatio * 100f) else "0.0"}%", style = MaterialTheme.typography.labelMedium)
            } }
            Card(shape = MaterialTheme.shapes.large, colors = CardDefaults.cardColors(
                containerColor = if (errorCount > 0) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant
            )) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🔎", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.width(8.dp))
                        Text("مراقب سلامة المصروفات", style = MaterialTheme.typography.titleMedium)
                    }
                    if (auditIssues.isEmpty()) {
                        Text("لا توجد ملاحظات محاسبية آلية على البنود الظاهرة لهذا الشهر.", style = MaterialTheme.typography.bodySmall)
                    } else {
                        Text("أخطاء: $errorCount  •  تنبيهات: $warningCount  •  معلومات: ${auditIssues.size - errorCount - warningCount}",
                            style = MaterialTheme.typography.labelMedium)
                        auditIssues.take(5).forEach { issue ->
                            val marker = when (issue.severity) {
                                ExpenseAuditSeverity.ERROR -> "🔴"
                                ExpenseAuditSeverity.WARNING -> "🟠"
                                ExpenseAuditSeverity.INFO -> "ℹ️"
                            }
                            Text("$marker ${issue.title}: ${issue.detail}", style = MaterialTheme.typography.bodySmall)
                        }
                        if (auditIssues.size > 5) Text("توجد ${auditIssues.size - 5} ملاحظات أخرى.", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            Card(shape = MaterialTheme.shapes.medium) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("سجل التعديلات والإجراءات", style = MaterialTheme.typography.titleSmall)
                        TextButton(onClick = { showAuditHistory = !showAuditHistory }) { Text(if (showAuditHistory) "إخفاء" else "عرض السجل") }
                    }
                    if (showAuditHistory) {
                        if (auditHistory.isEmpty()) Text("لا توجد تعديلات مسجلة بعد.", style = MaterialTheme.typography.bodySmall)
                        auditHistory.take(15).forEach { log ->
                            val date = Instant.ofEpochMilli(log.createdAt).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm"))
                            val action = when (log.action) {
                                "created" -> "إضافة مصروف"
                                "updated" -> "تعديل مصروف"
                                "soft_deleted" -> "حذف آمن لمصروف"
                                "payment_recorded" -> "تسجيل دفعة"
                                "closed" -> "إغلاق شهر"
                                "reopened" -> "إعادة فتح شهر"
                                else -> log.action
                            }
                            Text("$date • $action • ${log.details.substringAfter(';', log.details).take(120)}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            Text("سجل المصروفات", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = searchQuery, onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("بحث باسم المصروف أو التصنيف") }
            )
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                categories.forEach { category ->
                    FilterChip(selected = categoryFilter == category, onClick = { categoryFilter = category }, label = { Text(category) })
                }
            }
            Text("البنود الشهرية الثابتة", style = MaterialTheme.typography.titleMedium)
            Text("تُنشأ البنود تلقائيًا لكل شهر. سجّل كل دفعة بتاريخها وطريقة دفعها؛ والمتبقي يُحسب تلقائيًا.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            visibleRows.forEach { item ->
                Card(shape = MaterialTheme.shapes.medium) { Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(item.title, style = MaterialTheme.typography.titleMedium)
                            Text(when { item.amountPiasters == 0L -> "لم يتم تحديد القيمة"; item.paidAmountPiasters >= item.amountPiasters -> "مدفوع بالكامل"; item.paidAmountPiasters > 0 -> "مدفوع جزئيًا"; else -> "لم يُدفع" }, style = MaterialTheme.typography.bodySmall, color = if (item.amountPiasters > item.paidAmountPiasters) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                        }
                        if (item.note.startsWith("HR_SYNC:")) {
                            Text("مُدار تلقائيًا من شؤون العاملين", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        } else {
                            IconButton(enabled = !monthIsLocked, onClick = { editing = item.id; title = item.title; selectedCategory = item.category; amount = "%.2f".format(Locale.US, item.amountPiasters / 100.0); paid = "%.2f".format(Locale.US, item.paidAmountPiasters / 100.0); note = item.note; dueAt = item.dueAt }) { Icon(Icons.Default.Edit, contentDescription = "تعديل") }
                            IconButton(enabled = !monthIsLocked, onClick = { deleteTarget = item.id }) { Icon(Icons.Default.Delete, contentDescription = "حذف آمن", tint = MaterialTheme.colorScheme.error) }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("القيمة: ${Money.format(item.amountPiasters)}")
                        Text("المدفوع: ${Money.format(item.paidAmountPiasters)}")
                    }
                    Text("المتبقي: ${Money.format((item.amountPiasters - item.paidAmountPiasters).coerceAtLeast(0))}", color = MaterialTheme.colorScheme.error)
                    if (!monthIsLocked && !item.note.startsWith("HR_SYNC:") && item.paidAmountPiasters < item.amountPiasters) {
                        OutlinedButton(onClick = { paymentTarget = item; paymentAmount = ""; paymentDate = LocalDate.now().toString(); paymentMethod = "نقدي"; paymentAccountId = "cash"; paymentNote = "" }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل دفعة جديدة") }
                    }
                    paymentRows.filter { it.expenseId == item.id }.sortedByDescending { it.paidAt }.forEach { payment ->
                        Text("دفعة ${Money.format(payment.amountPiasters)} • ${Instant.ofEpochMilli(payment.paidAt).atZone(ZoneId.systemDefault()).toLocalDate()} • ${payment.paymentMethod}", style = MaterialTheme.typography.bodySmall)
                    }
                    Text("الاستحقاق: ${Instant.ofEpochMilli(item.dueAt).atZone(ZoneId.systemDefault()).toLocalDate()}", style = MaterialTheme.typography.bodySmall)
                } }
            }
            if (visibleRows.isEmpty()) {
                Text("لا توجد مصروفات تطابق البحث أو التصنيف المحدد.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            HorizontalDivider()
            Text(if (editing == null) "إضافة مصروف آخر" else "تعديل بند المصروف", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(title, { title = it }, label = { Text("اسم المصروف") }, modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !monthIsLocked)
            Text("البند")
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                recurringExpenseNames.filterNot { it == "المرتبات" }.chunked(2).forEach { group -> Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { group.forEach { c -> FilterChip(selected = selectedCategory == c, onClick = { selectedCategory = c; if (editing == null) title = c }, label = { Text(c) }) } } }
                FilterChip(selected = selectedCategory == "أخرى", onClick = { selectedCategory = "أخرى" }, label = { Text("أخرى") })
            }
            OutlinedTextField(amount, { amount = it.filter { c -> c.isDigit() || c == '.' || c == ',' } }, label = { Text("إجمالي المصروف بالجنيه") }, modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !monthIsLocked, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            Text("يُسجّل المدفوع من خلال دفعات منفصلة بتاريخ وطريقة دفع محددين.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = { showDatePicker = true }, enabled = !monthIsLocked, modifier = Modifier.fillMaxWidth()) { Text("تاريخ الاستحقاق: ${Instant.ofEpochMilli(dueAt).atZone(ZoneId.systemDefault()).toLocalDate()}") }
            OutlinedTextField(note, { note = it }, label = { Text("ملاحظات (اختياري)") }, modifier = Modifier.fillMaxWidth(), enabled = !monthIsLocked)
            Button(onClick = {
                val totalP = moneyInput(amount)
                if (title.isNotBlank() && totalP > 0) {
                    vm.save(editing, title, selectedCategory, totalP, 0L, note, dueAt, month)
                    editing = null; title = ""; amount = ""; paid = ""; note = ""; selectedCategory = "أخرى"
                }
            }, modifier = Modifier.fillMaxWidth(), enabled = !monthIsLocked && title.isNotBlank() && moneyInput(amount) > 0 && moneyInput(amount) >= (rows.firstOrNull { it.id == editing }?.paidAmountPiasters ?: 0L)) { Text(if (editing == null) "حفظ المصروف" else "حفظ التعديلات") }
            if (editing != null) TextButton(onClick = { editing = null; title = ""; amount = ""; paid = ""; note = ""; selectedCategory = "أخرى" }) { Text("إلغاء التعديل") }
        }
    }
    if (showDatePicker) {
        val pickerState = rememberDatePickerState(initialSelectedDateMillis = dueAt)
        DatePickerDialog(onDismissRequest = { showDatePicker = false }, confirmButton = { TextButton(onClick = { dueAt = pickerState.selectedDateMillis ?: dueAt; showDatePicker = false }) { Text("تأكيد") } }, dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("إلغاء") } }) { DatePicker(state = pickerState) }
    }
    if (paymentTarget != null) AlertDialog(
        onDismissRequest = { paymentTarget = null },
        title = { Text("تسجيل دفعة مصروف") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(paymentTarget?.title.orEmpty())
            OutlinedTextField(paymentAmount, { paymentAmount = it.filter { c -> c.isDigit() || c == '.' || c == ',' } }, label = { Text("قيمة الدفعة بالجنيه") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            OutlinedTextField(paymentDate, { paymentDate = it }, label = { Text("تاريخ الدفع (YYYY-MM-DD)") }, singleLine = true)
            CashAccountDropdown(accounts = cashAccounts, selectedId = paymentAccountId, onSelected = { paymentAccountId = it }, label = "حساب الصرف")
            OutlinedTextField(paymentMethod, { paymentMethod = it }, label = { Text("تفصيل وسيلة الدفع") }, singleLine = true)
            OutlinedTextField(paymentNote, { paymentNote = it }, label = { Text("ملاحظات") })
        } },
        confirmButton = { TextButton(onClick = {
            val date = runCatching { LocalDate.parse(paymentDate) }.getOrNull()
            val amountValue = moneyInput(paymentAmount)
            val target = paymentTarget
            if (target != null && date != null && amountValue > 0L && paymentMethod.isNotBlank() && amountValue <= (target.amountPiasters - target.paidAmountPiasters).coerceAtLeast(0L)) {
                vm.recordPayment(target.id, amountValue, date, paymentMethod, paymentNote, paymentAccountId)
                paymentTarget = null
            }
        }, enabled = moneyInput(paymentAmount) > 0 && runCatching { LocalDate.parse(paymentDate) }.isSuccess && paymentMethod.isNotBlank()) { Text("تسجيل") } },
        dismissButton = { TextButton(onClick = { paymentTarget = null }) { Text("إلغاء") } }
    )
    if (deleteTarget != null) AlertDialog(onDismissRequest = { deleteTarget = null }, title = { Text("حذف المصروف؟") }, text = { Text("سيتم إخفاء المصروف من السجل النشط مع الاحتفاظ بسجل العملية والدفعات السابقة وحركات الخزينة للمراجعة. هذا حذف آمن وليس حذفًا نهائيًا.") }, confirmButton = { TextButton(onClick = { vm.delete(deleteTarget!!); deleteTarget = null }) { Text("حذف") } }, dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("إلغاء") } })
}

@Composable
private fun SummaryLine(label: String, value: Long, warning: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Text(Money.format(value), color = if (warning && value > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
    }
}
