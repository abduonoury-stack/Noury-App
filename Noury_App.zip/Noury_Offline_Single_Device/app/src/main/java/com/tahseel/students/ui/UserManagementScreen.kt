package com.tahseel.students.ui

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.tahseel.students.data.*
import kotlinx.coroutines.launch

@Composable
fun UserLoginScreen(dao: UserDao, onAuthenticated: (AppUser) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var setupMode by remember { mutableStateOf(false) }
    var checked by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { setupMode = dao.countUsers() == 0; checked = true }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            if (!checked) CircularProgressIndicator()
            else Card(Modifier.fillMaxWidth().padding(22.dp), shape = RoundedCornerShape(30.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)) {
                Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    Surface(shape = RoundedCornerShape(18.dp), color = LdaPalette.BlueContainer) {
                        Text("NOURY", modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp), style = MaterialTheme.typography.labelLarge, color = LdaPalette.RoyalDeep, fontWeight = FontWeight.ExtraBold)
                    }
                    Text(if (setupMode) "إنشاء حساب مدير النظام" else "مرحبًا بعودتك", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = LdaPalette.RoyalDeep)
                    Text(if (setupMode) "هذه أول مرة يتم فيها تشغيل نظام المستخدمين. أنشئ حساب المدير الرئيسي." else "سجّل الدخول بحسابك للمتابعة على هذا الجهاز.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedTextField(username, { username = it.trim().lowercase() }, Modifier.fillMaxWidth(), label = { Text("اسم المستخدم") }, singleLine = true)
                    if (setupMode) OutlinedTextField(displayName, { displayName = it }, Modifier.fillMaxWidth(), label = { Text("الاسم الظاهر") }, singleLine = true)
                    OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(), label = { Text("كلمة المرور") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                    if (setupMode) OutlinedTextField(confirm, { confirm = it }, Modifier.fillMaxWidth(), label = { Text("تأكيد كلمة المرور") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                    Button(
                        onClick = {
                            if (username.length < 3 || password.length < 8 || (setupMode && displayName.isBlank())) {
                                Toast.makeText(context, "اسم المستخدم 3 أحرف على الأقل وكلمة المرور 8 أحرف على الأقل", Toast.LENGTH_LONG).show()
                                return@Button
                            }
                            if (setupMode && password != confirm) {
                                Toast.makeText(context, "كلمتا المرور غير متطابقتين", Toast.LENGTH_LONG).show()
                                return@Button
                            }
                            loading = true
                            scope.launch {
                                try {
                                    if (setupMode) {
                                        val (salt, hash) = PasswordSecurity.hash(password)
                                        val id = dao.insert(AppUser(username = username, displayName = displayName.trim(), role = UserRoles.ADMIN, passwordSalt = salt, passwordHash = hash))
                                        dao.log(UserActivityLog(userId = id, username = username, action = "INITIAL_ADMIN_CREATED", details = "إنشاء حساب مدير النظام"))
                                        val user = dao.findById(id)
                                        if (user != null) onAuthenticated(user)
                                    } else {
                                        val user = dao.findByUsername(username)
                                        if (user == null || !user.isActive || !PasswordSecurity.verify(password, user.passwordSalt, user.passwordHash)) {
                                            Toast.makeText(context, "بيانات الدخول غير صحيحة أو الحساب موقوف", Toast.LENGTH_LONG).show()
                                        } else {
                                            dao.updateLastLogin(user.id, System.currentTimeMillis())
                                            dao.log(UserActivityLog(userId = user.id, username = user.username, action = "LOGIN", details = "تسجيل دخول ناجح"))
                                            onAuthenticated(user.copy(lastLoginAt = System.currentTimeMillis()))
                                        }
                                    }
                                } catch (_: Exception) {
                                    Toast.makeText(context, "تعذر إتمام العملية. تحقق من اسم المستخدم وحاول مرة أخرى.", Toast.LENGTH_LONG).show()
                                } finally { loading = false }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
                        enabled = !loading,
                        shape = RoundedCornerShape(17.dp)
                    ) { if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text(if (setupMode) "إنشاء المدير والدخول" else "تسجيل الدخول") }
                    if (!setupMode) Text("إذا نسيت كلمة المرور، اطلب من مدير النظام إعادة تعيينها.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserManagementScreen(dao: UserDao, currentUser: AppUser, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var users by remember { mutableStateOf(emptyList<AppUser>()) }
    var username by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var role by remember { mutableStateOf(UserRoles.RECEPTION) }
    var expanded by remember { mutableStateOf(false) }
    var resetTarget by remember { mutableStateOf<AppUser?>(null) }
    var resetPassword by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    suspend fun refresh() { users = dao.allUsers() }
    LaunchedEffect(Unit) { refresh() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("إدارة المستخدمين", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onBack) { Text("رجوع") }
        }
        Text("إنشاء حساب مستقل لكل موظف. لا تشارك حساب المدير بين الموظفين.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("إضافة مستخدم", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                OutlinedTextField(displayName, { displayName = it }, Modifier.fillMaxWidth(), label = { Text("اسم الموظف") }, singleLine = true)
                OutlinedTextField(username, { username = it.trim().lowercase() }, Modifier.fillMaxWidth(), label = { Text("اسم المستخدم") }, singleLine = true)
                OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(), label = { Text("كلمة مرور مؤقتة (8 أحرف على الأقل)") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                    OutlinedTextField(value = UserRoles.labels[role] ?: role, onValueChange = {}, readOnly = true, label = { Text("الدور الوظيفي") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        UserRoles.labels.filterKeys { it != UserRoles.ADMIN }.forEach { (key, label) ->
                            DropdownMenuItem(text = { Text(label) }, onClick = { role = key; expanded = false })
                        }
                    }
                }
                Button(onClick = {
                    if (displayName.isBlank() || username.length < 3 || password.length < 8) {
                        Toast.makeText(context, "أكمل البيانات وتأكد من طول اسم المستخدم وكلمة المرور", Toast.LENGTH_LONG).show()
                        return@Button
                    }
                    busy = true
                    scope.launch {
                        try {
                            if (dao.findByUsername(username) != null) {
                                Toast.makeText(context, "اسم المستخدم مستخدم بالفعل", Toast.LENGTH_LONG).show()
                            } else {
                                val (salt, hash) = PasswordSecurity.hash(password)
                                val id = dao.insert(AppUser(username = username, displayName = displayName.trim(), role = role, passwordSalt = salt, passwordHash = hash))
                                dao.log(UserActivityLog(userId = currentUser.id, username = currentUser.username, action = "USER_CREATED", details = "إنشاء المستخدم $username بالدور ${UserRoles.labels[role]}"))
                                username = ""; displayName = ""; password = ""; role = UserRoles.RECEPTION
                                refresh()
                                Toast.makeText(context, "تم إنشاء المستخدم", Toast.LENGTH_SHORT).show()
                            }
                        } catch (_: Exception) { Toast.makeText(context, "تعذر إنشاء المستخدم", Toast.LENGTH_LONG).show() }
                        finally { busy = false }
                    }
                }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("إنشاء الحساب") }
            }
        }
        Text("الحسابات المسجلة (${users.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        users.forEach { user ->
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(user.displayName, fontWeight = FontWeight.Bold)
                            Text("@${user.username} • ${UserRoles.labels[user.role] ?: user.role}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        AssistChip(onClick = {}, label = { Text(if (user.isActive) "نشط" else "موقوف") })
                    }
                    Text("آخر دخول: ${user.lastLoginAt?.let { java.text.DateFormat.getDateTimeInstance().format(java.util.Date(it)) } ?: "لم يسجل الدخول بعد"}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            scope.launch {
                                if (user.id == currentUser.id) {
                                    Toast.makeText(context, "لا يمكن إيقاف حسابك أثناء استخدامه", Toast.LENGTH_LONG).show()
                                } else if (user.isActive && user.role == UserRoles.ADMIN && dao.activeAdminCount() <= 1) {
                                    Toast.makeText(context, "يجب الاحتفاظ بمدير نظام نشط واحد على الأقل", Toast.LENGTH_LONG).show()
                                } else {
                                    dao.update(user.copy(isActive = !user.isActive))
                                    dao.log(UserActivityLog(userId = currentUser.id, username = currentUser.username, action = if (user.isActive) "USER_DISABLED" else "USER_ENABLED", details = "تغيير حالة ${user.username}"))
                                    refresh()
                                }
                            }
                        }) { Text(if (user.isActive) "إيقاف الحساب" else "تفعيل الحساب") }
                        OutlinedButton(onClick = { resetTarget = user; resetPassword = "" }) { Text("إعادة كلمة المرور") }
                    }
                }
            }
        }
    }

    resetTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { resetTarget = null },
            title = { Text("إعادة تعيين كلمة المرور") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("حساب ${target.displayName} (@${target.username})")
                    OutlinedTextField(resetPassword, { resetPassword = it }, label = { Text("كلمة المرور الجديدة") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (resetPassword.length < 8) Toast.makeText(context, "كلمة المرور يجب ألا تقل عن 8 أحرف", Toast.LENGTH_LONG).show()
                    else {
                        scope.launch {
                            val (salt, hash) = PasswordSecurity.hash(resetPassword)
                            dao.update(target.copy(passwordSalt = salt, passwordHash = hash))
                            dao.log(UserActivityLog(userId = currentUser.id, username = currentUser.username, action = "PASSWORD_RESET", details = "إعادة تعيين كلمة مرور ${target.username}"))
                            resetTarget = null
                            Toast.makeText(context, "تم تحديث كلمة المرور", Toast.LENGTH_SHORT).show()
                        }
                    }
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { resetTarget = null }) { Text("إلغاء") } }
        )
    }
}
