package com.tahseel.students.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tahseel.students.data.Classroom
import com.tahseel.students.data.ClassroomDao
import com.tahseel.students.data.AttendanceDao
import com.tahseel.students.data.Student
import com.tahseel.students.data.StudentDao
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ClassroomsViewModel(private val classes: ClassroomDao, private val students: StudentDao, private val attendance: AttendanceDao) : ViewModel() {
    val classrooms = classes.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allStudents = students.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun create(name: String, level: String, capacity: Int, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                if (name.isBlank()) { onResult("اكتب اسم الفصل"); return@launch }
                if (capacity < 1) { onResult("السعة لازم تكون أكبر من صفر"); return@launch }
                classes.insert(Classroom(name = name.trim(), level = level.trim(), capacity = capacity))
                onResult(null)
            } catch (_: Exception) { onResult("اسم الفصل مستخدم بالفعل") }
        }
    }

    fun updateClassroom(classroom: Classroom, name: String, level: String, capacity: Int, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                val cleanName = name.trim()
                if (cleanName.isBlank()) { onResult("اكتب اسم الفصل"); return@launch }
                if (capacity < 1) { onResult("السعة لازم تكون أكبر من صفر"); return@launch }
                val oldName = classroom.name
                val updated = classroom.copy(name = cleanName, level = level.trim(), capacity = capacity)
                classes.update(updated)
                if (oldName != cleanName) {
                    classes.renameStudentsClass(oldName, cleanName, System.currentTimeMillis())
                    attendance.renameClassHistory(oldName, cleanName)
                }
                onResult(null)
            } catch (_: Exception) { onResult("تعذر تعديل الفصل. تأكد أن اسم الفصل غير مستخدم في فصل آخر") }
        }
    }

    fun assign(student: Student, classroom: Classroom, currentCount: Int, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            if (student.className == classroom.name) { onResult("الطالب موجود بالفعل في الفصل"); return@launch }
            if (currentCount >= classroom.capacity) { onResult("الفصل وصل للسعة المحددة"); return@launch }
            students.update(student.copy(className = classroom.name, updatedAt = System.currentTimeMillis()))
            onResult(null)
        }
    }

    fun unassign(student: Student) {
        viewModelScope.launch { students.update(student.copy(className = "", updatedAt = System.currentTimeMillis())) }
    }
}
