package com.tahseel.students.util

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import com.tahseel.students.data.Student
import java.time.Instant
import java.time.LocalDate
import java.time.Period
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** A4 Arabic student roster printer for one classroom or all active students. */
object StudentRosterPrinter {
    private fun esc(value: String): String = value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&#39;")

    private fun ageLabel(birthDate: Long?): String {
        if (birthDate == null) return "غير مسجل"
        return try {
            val birth = Instant.ofEpochMilli(birthDate).atZone(ZoneId.systemDefault()).toLocalDate()
            val today = LocalDate.now()
            if (birth.isAfter(today)) return "غير صحيح"
            val age = Period.between(birth, today)
            // Always show both units, including zero months/years (e.g. 4 سنة و0 شهر).
            "${age.years} سنة و${age.months} شهر"
        } catch (_: Exception) { "غير مسجل" }
    }

    private fun html(context: Context, students: List<Student>, title: String, subtitle: String): String {
        val profile = context.getSharedPreferences("receipt_profile", Context.MODE_PRIVATE)
        val profileComplete = AcademyProfileStore.isSetupComplete(context)
        val academyName = esc(AcademyProfileStore.getName(context))
        val academyAddress = if (profileComplete) esc(profile.getString("address", "") ?: "") else ""
        val academyPhone = if (profileComplete) esc(profile.getString("phone", "") ?: "") else ""
        val profileDetails = listOf(academyAddress, academyPhone.takeIf { it.isNotBlank() }?.let { "هاتف: $it" }).filterNotNull().filter { it.isNotBlank() }.joinToString(" | ")
        val logoTag = AcademyProfileStore.logoDataUri(context)?.let { "<img class='academy-logo' src='$it' alt='شعار الأكاديمية'>" }.orEmpty()
        // Always print the complete active roster; missing optional fields never remove a student.
        // Birth dates are ascending chronologically for descending age (oldest first).
        // Students without a birth date are retained at the end; alphabetical tie-breaker.
        val activeStudents = students.filter { it.status == "active" }
            .sortedWith(compareBy<Student> { it.birthDate ?: Long.MAX_VALUE }.thenBy { it.fullName.trim() })
        val rows = activeStudents.mapIndexed { index, student ->
            val motherPhone = student.motherWhatsapp.trim().ifBlank { "غير مسجل" }
            """<tr><td class="num">${index + 1}</td><td>${esc(student.fullName.ifBlank { "غير مسجل" })}</td><td class="age">${esc(ageLabel(student.birthDate))}</td><td class="phone">${esc(motherPhone)}</td></tr>"""
        }.joinToString("\n")
        val date = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd", Locale("ar")))
        return """<!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<style>
@page { size: A4 portrait; margin: 13mm 12mm 15mm; }
* { box-sizing: border-box; }
body { font-family: 'Noto Naskh Arabic','Noto Sans Arabic',Tahoma,Arial,sans-serif; color:#202938; direction:rtl; font-size:11pt; line-height:1.55; margin:0; }
.header { text-align:center; border-bottom:3px solid #263f68; padding:0 0 12px; margin-bottom:14px; page-break-inside:avoid; }
.brand { color:#263f68; font-size:20pt; font-weight:800; letter-spacing:.2px; }
.brand-header { display:flex; align-items:center; justify-content:center; gap:14px; margin-bottom:5px; }
.academy-logo { width:68px; height:68px; object-fit:contain; background:#fff; border:1px solid #d8dce4; border-radius:8px; padding:4px; }
h1 { font-size:16pt; margin:5px 0 4px; color:#182c4d; }
.meta { display:flex; justify-content:space-between; gap:12px; color:#4b5563; font-size:10pt; margin-top:7px; }
.summary { display:flex; gap:8px; margin:12px 0; }
.pill { border:1px solid #cbd5e1; background:#f4f7fb; border-radius:6px; padding:6px 10px; font-weight:700; }
table { width:100%; border-collapse:collapse; table-layout:fixed; }
thead { display:table-header-group; }
tr { page-break-inside:avoid; }
th,td { border:1px solid #8b97a8; padding:9px 8px; text-align:right; vertical-align:middle; overflow-wrap:anywhere; }
th { background:#e8edf4 !important; color:#172b4d; font-weight:800; }
tbody tr:nth-child(even) { background:#f7f9fc; }
tbody tr { page-break-inside:avoid; break-inside:avoid; }
thead { display:table-header-group; }
.num { width:8%; text-align:center; }
th:nth-child(2) { width:42%; }
.age { width:22%; text-align:center; }
.phone { width:28%; direction:ltr; text-align:center; unicode-bidi:plaintext; font-family:Arial,sans-serif; }
.footer { margin-top:22px; padding-top:9px; border-top:1px solid #cbd5e1; display:flex; justify-content:space-between; color:#4b5563; font-size:9pt; }
.empty { text-align:center; padding:28px; color:#64748b; }
@media print {
  body { -webkit-print-color-adjust:exact; print-color-adjust:exact; }
  thead { display:table-header-group !important; }
  tfoot { display:table-footer-group; }
  tr { page-break-inside:avoid; break-inside:avoid; }
}
</style></head><body>
<div class="header"><div class="brand-header">$logoTag<div class="brand">$academyName</div></div>${if (profileDetails.isNotBlank()) "<div>${profileDetails}</div>" else ""}<h1>${esc(title)}</h1><div>${esc(subtitle)}</div>
<div class="meta"><span>تاريخ الطباعة: ${esc(date)}</span><span>عدد الطلاب: ${activeStudents.size}</span></div></div>
<div class="summary"><div class="pill">إجمالي الطلاب النشطين: ${activeStudents.size}</div><div class="pill">كشف بيانات الطلاب</div></div>
<table><thead><tr><th class="num">م</th><th>اسم الطالب</th><th class="age">العمر</th><th class="phone">رقم تليفون الأم</th></tr></thead>
<tbody>${rows.ifBlank { "<tr><td colspan='4' class='empty'>لا يوجد طلاب نشطون لعرضهم</td></tr>" }}</tbody></table>
<div class="footer"><span>$academyName</span><span>توقيع الإدارة: __________________</span></div>
</body></html>"""
    }

    fun print(context: Context, students: List<Student>, title: String, subtitle: String) {
        val webView = WebView(context)
        webView.settings.javaScriptEnabled = false
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
                val jobName = "Noury_Student_Roster_${System.currentTimeMillis()}"
                printManager.print(
                    jobName,
                    view.createPrintDocumentAdapter(jobName),
                    PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                        .setMinMargins(PrintAttributes.Margins(360, 360, 360, 360))
                        .build()
                )
            }
        }
        webView.loadDataWithBaseURL(null, html(context, students, title, subtitle), "text/html", "UTF-8", null)
    }
}
