package com.tahseel.students.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection

/** NOURY — Playful Professional: sky blue, turquoise, warm yellow, coral and mint over calm light surfaces. */
object LdaPalette {
    // Brand foundation
    val Royal = Color(0xFF1779B0)
    val RoyalDeep = Color(0xFF0F4C6E)
    val RoyalMid = Color(0xFF2E9BD6)
    val Peach = Color(0xFFE2553F)
    val PeachContainer = Color(0xFFFFE4DF)
    val Gold = Color(0xFFFFC94D)
    val Lilac = Color(0xFFE3F4FB)
    val Canvas = Color(0xFFF3FAFD)
    val Surface = Color(0xFFFFFFFF)
    val SurfaceSoft = Color(0xFFEAF5F9)
    val Border = Color(0xFFD5E7EF)
    val MutedText = Color(0xFF55707F)

    // Functional colors
    val Success = Color(0xFF12906F)
    val SuccessContainer = Color(0xFFDDF7EC)
    val Warning = Color(0xFFB96A12)
    val WarningContainer = Color(0xFFFFF1D9)
    val Error = Color(0xFFCB4355)
    val ErrorContainer = Color(0xFFFFE6E9)

    // Colorful module accents
    val Blue = Color(0xFF1779B0)
    val BlueContainer = Color(0xFFDDF1FB)
    val Orange = Color(0xFFD98A00)
    val OrangeContainer = Color(0xFFFFF1C9)
    val Green = Color(0xFF12906F)
    val GreenContainer = Color(0xFFDDF6EE)
    val Pink = Color(0xFFE2553F)
    val PinkContainer = Color(0xFFFFE4DF)
    val Purple = Color(0xFF5E6CC9)
    val PurpleContainer = Color(0xFFE8EBFF)
    val Teal = Color(0xFF0C9A9A)
    val TealContainer = Color(0xFFD6F3F2)
}

private val ldaColors = lightColorScheme(
    primary = LdaPalette.Royal,
    onPrimary = Color.White,
    primaryContainer = LdaPalette.BlueContainer,
    onPrimaryContainer = LdaPalette.RoyalDeep,
    secondary = LdaPalette.Peach,
    onSecondary = Color.White,
    secondaryContainer = LdaPalette.OrangeContainer,
    onSecondaryContainer = Color(0xFF7A2A1D),
    tertiary = LdaPalette.Purple,
    onTertiary = Color.White,
    tertiaryContainer = LdaPalette.PurpleContainer,
    onTertiaryContainer = Color(0xFF38206E),
    background = LdaPalette.Canvas,
    onBackground = Color(0xFF12303F),
    surface = LdaPalette.Surface,
    onSurface = Color(0xFF12303F),
    surfaceVariant = LdaPalette.SurfaceSoft,
    onSurfaceVariant = LdaPalette.MutedText,
    outline = LdaPalette.Border,
    outlineVariant = Color(0xFFE6F1F6),
    error = LdaPalette.Error,
    errorContainer = LdaPalette.ErrorContainer,
    onErrorContainer = Color(0xFF641B2A)
)

private val ldaShapes = Shapes(
    extraSmall = RoundedCornerShape(9.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(23.dp),
    extraLarge = RoundedCornerShape(29.dp)
)

private fun ldaText(
    size: androidx.compose.ui.unit.TextUnit,
    weight: FontWeight = FontWeight.Normal,
    lineHeight: androidx.compose.ui.unit.TextUnit = (size.value * 1.38f).sp
) = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = size, lineHeight = lineHeight, fontWeight = weight)

private val ldaTypography = Typography(
    displayLarge = ldaText(38.sp, FontWeight.ExtraBold, 48.sp),
    displayMedium = ldaText(34.sp, FontWeight.ExtraBold, 43.sp),
    displaySmall = ldaText(30.sp, FontWeight.Bold, 39.sp),
    headlineLarge = ldaText(28.sp, FontWeight.Bold, 37.sp),
    headlineMedium = ldaText(25.sp, FontWeight.Bold, 34.sp),
    headlineSmall = ldaText(23.sp, FontWeight.Bold, 32.sp),
    titleLarge = ldaText(21.sp, FontWeight.Bold, 30.sp),
    titleMedium = ldaText(18.sp, FontWeight.SemiBold, 27.sp),
    titleSmall = ldaText(16.sp, FontWeight.SemiBold, 24.sp),
    bodyLarge = ldaText(16.sp, FontWeight.Normal, 26.sp),
    bodyMedium = ldaText(15.sp, FontWeight.Normal, 24.sp),
    bodySmall = ldaText(14.sp, FontWeight.Normal, 22.sp),
    labelLarge = ldaText(15.sp, FontWeight.Bold, 22.sp),
    labelMedium = ldaText(14.sp, FontWeight.SemiBold, 21.sp),
    labelSmall = ldaText(13.sp, FontWeight.Medium, 19.sp)
)

@Composable
fun TahseelTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = ldaColors, typography = ldaTypography, shapes = ldaShapes, content = content)
    }
}
