package com.tahseel.students.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection

/** NOURY — Nubian Heritage × Modern Premium: royal purple, warm peach, soft gold and ivory. */
object LdaPalette {
    // Brand foundation
    val Royal = Color(0xFF4B3475)
    val RoyalDeep = Color(0xFF302147)
    val RoyalMid = Color(0xFF7055A0)
    val Peach = Color(0xFFE58B68)
    val PeachContainer = Color(0xFFFBE7DC)
    val Gold = Color(0xFFD7B36A)
    val Lilac = Color(0xFFEEE8F5)
    val Canvas = Color(0xFFF7F3EC)
    val Surface = Color(0xFFFFFEFC)
    val SurfaceSoft = Color(0xFFF1EBE2)
    val Border = Color(0xFFE5DACC)
    val MutedText = Color(0xFF756B78)

    // Functional colors
    val Success = Color(0xFF12906F)
    val SuccessContainer = Color(0xFFDDF7EC)
    val Warning = Color(0xFFB96A12)
    val WarningContainer = Color(0xFFFFF1D9)
    val Error = Color(0xFFCB4355)
    val ErrorContainer = Color(0xFFFFE6E9)

    // Colorful module accents
    val Blue = Color(0xFF5B477F)
    val BlueContainer = Color(0xFFEDE7F4)
    val Orange = Color(0xFFC47A4F)
    val OrangeContainer = Color(0xFFF8EBDD)
    val Green = Color(0xFF12906F)
    val GreenContainer = Color(0xFFDDF6EE)
    val Pink = Color(0xFFB96E5B)
    val PinkContainer = Color(0xFFF6E5DF)
    val Purple = Color(0xFF7055A0)
    val PurpleContainer = Color(0xFFEEE8F5)
    val Teal = Color(0xFF568C83)
    val TealContainer = Color(0xFFE3EFEB)
}

private val ldaColors = lightColorScheme(
    primary = LdaPalette.Royal,
    onPrimary = Color.White,
    primaryContainer = LdaPalette.BlueContainer,
    onPrimaryContainer = LdaPalette.RoyalDeep,
    secondary = LdaPalette.Peach,
    onSecondary = LdaPalette.RoyalDeep,
    secondaryContainer = LdaPalette.OrangeContainer,
    onSecondaryContainer = Color(0xFF7A2A1D),
    tertiary = LdaPalette.Purple,
    onTertiary = Color.White,
    tertiaryContainer = LdaPalette.PurpleContainer,
    onTertiaryContainer = Color(0xFF38206E),
    background = LdaPalette.Canvas,
    onBackground = Color(0xFF12303F),
    surface = LdaPalette.Surface,
    onSurface = Color(0xFF12303F),
    surfaceVariant = LdaPalette.SurfaceSoft,
    onSurfaceVariant = LdaPalette.MutedText,
    outline = LdaPalette.Border,
    outlineVariant = Color(0xFFE6F1F6),
    error = LdaPalette.Error,
    errorContainer = LdaPalette.ErrorContainer,
    onErrorContainer = Color(0xFF641B2A)
)

private val ldaShapes = Shapes(
    extraSmall = RoundedCornerShape(9.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(23.dp),
    extraLarge = RoundedCornerShape(29.dp)
)

private fun ldaText(
    size: androidx.compose.ui.unit.TextUnit,
    weight: FontWeight = FontWeight.Normal,
    lineHeight: androidx.compose.ui.unit.TextUnit = (size.value * 1.38f).sp
) = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = size, lineHeight = lineHeight, fontWeight = weight)

private val ldaTypography = Typography(
    displayLarge = ldaText(38.sp, FontWeight.ExtraBold, 48.sp),
    displayMedium = ldaText(34.sp, FontWeight.ExtraBold, 43.sp),
    displaySmall = ldaText(30.sp, FontWeight.Bold, 39.sp),
    headlineLarge = ldaText(28.sp, FontWeight.Bold, 37.sp),
    headlineMedium = ldaText(25.sp, FontWeight.Bold, 34.sp),
    headlineSmall = ldaText(23.sp, FontWeight.Bold, 32.sp),
    titleLarge = ldaText(21.sp, FontWeight.Bold, 30.sp),
    titleMedium = ldaText(18.sp, FontWeight.SemiBold, 27.sp),
    titleSmall = ldaText(16.sp, FontWeight.SemiBold, 24.sp),
    bodyLarge = ldaText(16.sp, FontWeight.Normal, 26.sp),
    bodyMedium = ldaText(15.sp, FontWeight.Normal, 24.sp),
    bodySmall = ldaText(14.sp, FontWeight.Normal, 22.sp),
    labelLarge = ldaText(15.sp, FontWeight.Bold, 22.sp),
    labelMedium = ldaText(14.sp, FontWeight.SemiBold, 21.sp),
    labelSmall = ldaText(13.sp, FontWeight.Medium, 19.sp)
)

@Composable
fun TahseelTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = ldaColors, typography = ldaTypography, shapes = ldaShapes, content = content)
    }
}
