package com.tahseel.students.data

import androidx.room.withTransaction
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.YearMonth

/** Returns the monthly net due (including zero for a full exemption), or null when invalid. */
internal fun calculateSubscriptionNetDuePiasters(grossDuePiasters: Long, discountPiasters: Long): Long? {
    if (grossDuePiasters <= 0L || discountPiasters < 0L || discountPiasters > grossDuePiasters) return null
    return grossDuePiasters - discountPiasters
}

sealed class SubscriptionResult {
    data class Success(val paymentId: Long, val receiptNo: String, val duePiasters: Long) : SubscriptionResult()
    data class Rejected(val reason: String) : SubscriptionResult()
}

/** قواعد الاشتراك: سداد صافي المستحق كاملًا، أو إثبات إعفاء كامل دون حركة نقدية. */
class SubscriptionRepository(private val db: AppDatabase) {
    private val students = db.studentDao()
    private val payments = db.dao()
    private val finance = db.financeDao()
    private val periods = db.periodDao()

    /** السعر حسب الفترة وتاريخ سريان السعر؛ السعر الخاص بالطالب له الأولوية. */
    suspend fun monthlyAmountPiasters(student: Student, period: YearMonth): Long? {
        student.monthlyFeeOverridePiasters?.let { return it }
        val periodId = student.periodId ?: if (student.attendanceEndHour == 16) 2L else 1L
        val start = period.atDay(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        return periods.priceAt(periodId, start)
    }

    fun firstMonthAmountPiasters(amountPounds: Long): Long {
        require(amountPounds > 0) { "قيمة شهر الالتحاق يجب أن تكون أكبر من صفر" }
        return Math.multiplyExact(amountPounds, 100L)
    }

    suspend fun collectMonthly(
        studentId: Long,
        period: YearMonth,
        receiptNo: String,
        paidAmountPiasters: Long,
        discountPiasters: Long = 0L,
        discountNote: String = "",
        accountId: String = "cash",
        now: Long = System.currentTimeMillis()
    ): SubscriptionResult = db.withTransaction {
        val student = students.getById(studentId)
            ?: return@withTransaction SubscriptionResult.Rejected("الطالب غير موجود")
        if (student.status != "active") return@withTransaction SubscriptionResult.Rejected("لا يمكن تحصيل اشتراك طالب غير نشط")
        if (receiptNo.isBlank()) return@withTransaction SubscriptionResult.Rejected("رقم الإيصال مطلوب")
        if (paidAmountPiasters < 0) return@withTransaction SubscriptionResult.Rejected("المبلغ غير صالح")
        if (discountPiasters < 0) return@withTransaction SubscriptionResult.Rejected("قيمة الخصم غير صالحة")

        val periodKey = period.toString()
        if (finance.subscriptionForPeriod(studentId, periodKey) != null)
            return@withTransaction SubscriptionResult.Rejected("اشتراك هذا الشهر مسجل بالفعل")

        val enrollment = Instant.ofEpochMilli(student.enrollmentDate).atZone(ZoneId.systemDefault()).toLocalDate()
        val enrollmentMonth = YearMonth.from(enrollment)
        if (period.isBefore(enrollmentMonth))
            return@withTransaction SubscriptionResult.Rejected("لا يمكن تحصيل شهر يسبق تاريخ التحاق الطفل")
        val isFirstMonth = enrollmentMonth == period
        val grossDue = if (isFirstMonth && student.firstMonthAmountPiasters != null) {
            student.firstMonthAmountPiasters
        } else {
            monthlyAmountPiasters(student, period)
                ?: return@withTransaction SubscriptionResult.Rejected("لا يوجد سعر موثق وساري لهذه الفترة في الشهر المحدد. راجع سجل أسعار الفترة قبل التحصيل")
        }
        val due = calculateSubscriptionNetDuePiasters(grossDue, discountPiasters)
            ?: return@withTransaction SubscriptionResult.Rejected("الخصم لا يمكن أن يتجاوز قيمة الاشتراك الأصلية")
        if (discountPiasters > 0L && discountNote.isBlank())
            return@withTransaction SubscriptionResult.Rejected("حدد سبب الخصم: منحة أو حالة خاصة أو إعفاء كامل")
        if (discountPiasters == grossDue && !discountNote.contains("إعفاء كامل"))
            return@withTransaction SubscriptionResult.Rejected("يجب تسجيل سبب الخصم الكامل باعتباره إعفاءً كاملًا")
        if (paidAmountPiasters != due)
            return@withTransaction SubscriptionResult.Rejected(if (due == 0L)
                "هذا الشهر معفى بالكامل؛ يجب أن يكون المبلغ المدفوع صفرًا"
            else "يجب تحصيل المستحق بعد الخصم كاملًا: ${due / 100} جنيه، دون زيادة أو نقص")
        if (due > 0L) {
            val cashAccount = db.cashAccountDao().find(accountId)
                ?: return@withTransaction SubscriptionResult.Rejected("حساب الاستلام غير موجود")
            if (!cashAccount.isActive) return@withTransaction SubscriptionResult.Rejected("حساب الاستلام غير نشط")
        }

        val paymentId = try {
            payments.insert(Payment(
                studentName = student.fullName,
                receiptNo = receiptNo.trim(),
                amountPiasters = paidAmountPiasters,
                createdAt = now,
                studentId = student.id,
                // Full exemption is a non-cash administrative record; it must never enter a cash account.
                accountId = accountId.takeIf { paidAmountPiasters > 0L }
            ))
        } catch (_: Exception) {
            return@withTransaction SubscriptionResult.Rejected("رقم الإيصال مستخدم من قبل أو تعذر حفظ الدفعة")
        }
        finance.insertReceipt(Receipt(paymentId = paymentId, receiptNo = receiptNo.trim(), issuedAt = now))
        finance.insertSubscriptionPayment(SubscriptionPayment(
            studentId = student.id,
            periodKey = periodKey,
            dueAmountPiasters = due,
            paidAmountPiasters = paidAmountPiasters,
            paymentId = paymentId,
            isPartialEnrollmentMonth = isFirstMonth && student.firstMonthAmountPiasters != null,
            createdAt = now,
            discountPiasters = discountPiasters,
            discountNote = discountNote.trim()
        ))
        // الترحيل المحاسبي جزء من نفس معاملة التحصيل؛ فشل القيد يلغي الإيصال والاشتراك معًا.
        if (paidAmountPiasters > 0L) {
            FinancialTransactionEngine(db).postSubscriptionReceipt(
                paymentId = paymentId,
                amountPiasters = paidAmountPiasters,
                accountId = accountId,
                paidAt = now,
                studentName = student.fullName,
                periodLabel = periodKey
            )
        }
        finance.insertAudit(AuditLog(
            entityType = "subscription", entityId = paymentId,
            action = if (due == 0L) "full_exemption" else "collect",
            details = "actor=owner;student=${student.id};period=$periodKey;grossDue=$grossDue;discount=$discountPiasters;netDue=$due;paid=$paidAmountPiasters;discountNote=${discountNote.trim()};cashMovement=${paidAmountPiasters > 0L}",
            createdAt = now
        ))
        SubscriptionResult.Success(paymentId, receiptNo.trim(), due)
    }
}
