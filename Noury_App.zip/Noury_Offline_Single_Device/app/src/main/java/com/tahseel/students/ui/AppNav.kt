package com.tahseel.students.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.tahseel.students.App
import com.tahseel.students.util.AcademyProfileStore
import com.tahseel.students.data.AppUser
import com.tahseel.students.data.UserRoles
import com.tahseel.students.vm.*

@Composable
fun AppNav(app: App) {
    val context = LocalContext.current
    val authScope = rememberCoroutineScope()
    var currentUser by remember { mutableStateOf<AppUser?>(null) }
    var authReady by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { authReady = true }
    if (!authReady) {
        androidx.compose.foundation.layout.Box(androidx.compose.ui.Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) { androidx.compose.material3.CircularProgressIndicator() }
        return
    }
    if (currentUser == null) {
        UserLoginScreen(app.db.userDao()) { currentUser = it }
        return
    }
    val profileReady = remember(context) { AcademyProfileStore.isSetupComplete(context) }
    val nav = rememberNavController()
    val repo = app.repo
    val back: () -> Unit = { nav.popBackStack() }
    val entry by nav.currentBackStackEntryAsState()
    val currentRoute = entry?.destination?.route ?: "dashboard"
    val user = currentUser!!
    val denied = currentRoute != "access-denied" && !UserRoles.canOpen(user.role, currentRoute)
    if (denied) {
        androidx.compose.foundation.layout.Box(androidx.compose.ui.Modifier.fillMaxSize().padding(24.dp), contentAlignment = androidx.compose.ui.Alignment.Center) {
            androidx.compose.material3.Card {
                androidx.compose.foundation.layout.Column(androidx.compose.ui.Modifier.padding(24.dp), verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)) {
                    androidx.compose.material3.Text("غير مصرح", style = androidx.compose.material3.MaterialTheme.typography.headlineSmall)
                    androidx.compose.material3.Text("حسابك لا يملك صلاحية الوصول إلى هذه الشاشة.")
                    androidx.compose.material3.Button(onClick = back) { androidx.compose.material3.Text("رجوع") }
                }
            }
        }
        return
    }
    NavHost(navController = nav, startDestination = if (profileReady) "dashboard" else "academy-setup") {
        composable("academy-setup") {
            AcademySetupScreen(onComplete = {
                nav.navigate("dashboard") {
                    popUpTo("academy-setup") { inclusive = true }
                    launchSingleTop = true
                }
            })
        }
        composable("dashboard") {
            DashboardScreen(
                vm = viewModel<DashboardViewModel>(factory = vmFactory { DashboardViewModel(repo, app.db.studentDao(), app.db.financeDao(), app.db.expenseDao(), app.db.periodDao()) }),
                onAdd = { nav.navigate("add") },
                onReports = { nav.navigate("reports") },
                onStudents = { nav.navigate("students") },
                onSubscription = { nav.navigate("subscription") },
                onCollectionStatus = { nav.navigate("collection-status") },
                onHr = { nav.navigate("hr") }, onAddStudent = { nav.navigate("add-student") },
                onHub = { nav.navigate("hub/$it") }, onStudentProfile = { nav.navigate("student-profile/$it") },
                currentUserName = user.displayName, onLogout = {
                    authScope.launch { app.db.userDao().log(com.tahseel.students.data.UserActivityLog(user.id, user.username, "LOGOUT", "تسجيل خروج")) }
                    currentUser = null
                }
            )
        }
        composable("hub/{section}", arguments = listOf(navArgument("section") { type = NavType.StringType })) { entry ->
            val section = entry.arguments?.getString("section") ?: "students"
            ModuleHubScreen(section = section, onBack = back) { destination -> nav.navigate(destination) }
        }
        composable("student-exit") {
            StudentExitScreen(viewModel<StudentExitViewModel>(factory = vmFactory { StudentExitViewModel(app.db.studentDao(), app.db.financeDao(), app.db.cashAccountDao(), app.db) }), back) { nav.navigate("student-profile/$it") }
        }
        composable("hr") {
            HrScreen(viewModel<HrViewModel>(factory = vmFactory { HrViewModel(app.db.hrDao(), app.db.expenseDao(), app.db) }), back)
        }
        composable("expenses") {
            AccountingScreen(app.db.accountingDao(), back, onFinancialControl = { nav.navigate("financial-control") })
        }
        composable("financial-control") {
            FinancialControlScreen(app.db, back)
        }
        composable("finance-payroll") {
            FinancePayrollScreen(app.db.hrDao(), back)
        }
        composable("attendance") {
            AttendanceScreen(viewModel<AttendanceViewModel>(factory = vmFactory { AttendanceViewModel(app.db.attendanceDao(), app.db.classroomDao(), app.db.studentDao(), app.db.financeDao()) }), back) { nav.navigate("student-profile/$it") }
        }
        composable("classrooms") {
            ClassroomsScreen(viewModel<ClassroomsViewModel>(factory = vmFactory { ClassroomsViewModel(app.db.classroomDao(), app.db.studentDao(), app.db.attendanceDao()) }), back) { nav.navigate("student-profile/$it") }
        }
        composable("birthdays") {
            BirthdaysScreen(app.db.studentDao(), back) { nav.navigate("student-profile/$it") }
        }
        composable("students") {
            StudentsScreen(
                viewModel<StudentsViewModel>(factory = vmFactory { StudentsViewModel(app.db.studentDao(), app.db.classroomDao(), app.db.periodDao()) }),
                back, onProfile = { nav.navigate("student-profile/$it") },
                onFinance = { nav.navigate("student-finance/$it") }
            )
        }
        composable("add-student") {
            StudentsScreen(
                viewModel<StudentsViewModel>(factory = vmFactory { StudentsViewModel(app.db.studentDao(), app.db.classroomDao(), app.db.periodDao()) }),
                back, onProfile = { nav.navigate("student-profile/$it") },
                onFinance = { nav.navigate("student-finance/$it") }, openAddInitially = true
            )
        }
        composable("student-profile/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
            val id = e.arguments?.getLong("id") ?: 0L
            StudentProfileScreen(id, app.db.studentDao(), app.db.dao(), app.db.financeDao(), app.db.feeDao(), app.db.attendanceDao(), back, onFinance = { nav.navigate("student-finance/$id") })
        }
        composable("student-finance/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
            val id = e.arguments?.getLong("id") ?: 0L
            StudentFinanceScreen(id, app.db.studentDao(), app.db.financeDao(), app.db.dao(), app.db.periodDao(), back, onAddPayment = { nav.navigate("add") }, onProfile = { nav.navigate("student-profile/$id") })
        }
        composable("collection-status") {
            CollectionStatusScreen(
                viewModel<CollectionStatusViewModel>(factory = vmFactory { CollectionStatusViewModel(app.db.studentDao(), app.db.financeDao(), app.db.periodDao()) }),
                back
            ) { nav.navigate("student-profile/$it") }
        }
        composable("periods") {
            PeriodManagementScreen(app.db.periodDao(), back)
        }
        composable("subscription") {
            SubscriptionScreen(
                viewModel<SubscriptionViewModel>(factory = vmFactory { SubscriptionViewModel(app.db.studentDao(), app.subscriptionRepo, app.db.cashAccountDao()) }),
                back
            )
        }
        composable("add") {
            PaymentFormScreen(
                vm = viewModel<PaymentFormViewModel>(factory = vmFactory { PaymentFormViewModel(repo, app.db.studentDao(), app.db.cashAccountDao(), null) }),
                title = "تسجيل دفعة جديدة", buttonText = "حفظ عملية الدفع", onBack = back, onDone = back
            )
        }
        composable("edit/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
            val id = e.arguments?.getLong("id") ?: 0L
            PaymentFormScreen(
                vm = viewModel<PaymentFormViewModel>(factory = vmFactory { PaymentFormViewModel(repo, app.db.studentDao(), app.db.cashAccountDao(), id) }),
                title = "تعديل عملية دفع", buttonText = "حفظ التعديلات", onBack = back, onDone = back
            )
        }
        composable("ledger") {
            LedgerScreen(viewModel<LedgerViewModel>(factory = vmFactory { LedgerViewModel(repo) }), back, onOpen = { nav.navigate("details/$it") }, onStudentProfile = { nav.navigate("student-profile/$it") })
        }
        composable("details/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
            val id = e.arguments?.getLong("id") ?: 0L
            DetailsScreen(viewModel<DetailsViewModel>(factory = vmFactory { DetailsViewModel(repo, id) }), back, onEdit = { nav.navigate("edit/$it") }, onStudentProfile = { nav.navigate("student-profile/$it") })
        }
        composable("search") {
            SearchScreen(viewModel<SearchViewModel>(factory = vmFactory { SearchViewModel(app.db.studentDao()) }), back) { nav.navigate("student-profile/$it") }
        }
        composable("reports") {
            ReportsScreen(
                vm = viewModel<ReportsViewModel>(factory = vmFactory { ReportsViewModel(repo, app.db.studentDao(), app.db.financeDao(), app.db.expenseDao(), app.db.periodDao(), app.db.hrDao(), app.db.cashControlDao(), app.db.cashAccountDao(), app.db.cashTransferDao(), app.db) }),
                performanceVm = viewModel<DashboardViewModel>(factory = vmFactory { DashboardViewModel(repo, app.db.studentDao(), app.db.financeDao(), app.db.expenseDao(), app.db.periodDao()) }),
                onBack = back,
                onOpen = { nav.navigate("details/$it") },
                onStudentProfile = { nav.navigate("student-profile/$it") }
            )
        }
        composable("cash-accounts") {
            CashAccountsScreen(app.db, back)
        }
        composable("refunds") {
            RefundScreen(viewModel<RefundViewModel>(factory = vmFactory { RefundViewModel(app.db.financeDao(), app.db.studentDao(), app.refundRepo, app.db.cashAccountDao(), app.db.dao()) }), back)
        }
        composable("backup") {
            BackupScreen(viewModel<BackupViewModel>(factory = vmFactory { BackupViewModel(repo, app.db, app) }), back)
        }
        composable("academy-profile") {
            AcademyProfileScreen(onBack = back)
        }
        composable("users") {
            UserManagementScreen(app.db.userDao(), user, back)
        }
        composable("access-denied") {
            androidx.compose.foundation.layout.Column(androidx.compose.ui.Modifier.fillMaxSize().padding(24.dp), verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center) {
                androidx.compose.material3.Text("غير مصرح لك بالوصول")
                androidx.compose.material3.Button(onClick = back) { androidx.compose.material3.Text("رجوع") }
            }
        }
        composable("system-settings") {
            SystemSettingsScreen(
                settingsDao = app.db.financeDao(),
                onBack = back,
                onAcademyProfile = { nav.navigate("academy-profile") },
                onManagePeriods = { nav.navigate("periods") },
                onBackup = { nav.navigate("backup") },
                onManageUsers = { nav.navigate("users") },
                onLogout = { currentUser = null }
            )
        }
    }
}
