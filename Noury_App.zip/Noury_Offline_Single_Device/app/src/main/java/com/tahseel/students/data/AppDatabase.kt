package com.tahseel.students.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [Payment::class, Student::class, FeePlan::class, StudentFee::class,
        RefundCredit::class, Receipt::class, AuditLog::class, AppSetting::class, SubscriptionPayment::class, RefundTransaction::class, Classroom::class, Attendance::class, Expense::class, Employee::class, EmployeeAttendance::class, EmployeeLeave::class, EmployeePayroll::class, EmployeePayrollPayment::class, EmployeePayrollReversal::class, EmployeePayrollRecoveryTransaction::class, EmployeeLoan::class, EmployeeAdjustment::class, StudentExitSettlement::class, StudentExitSettlementEvent::class, AttendancePeriod::class, PeriodPriceHistory::class, CashOpeningBalance::class, CashCount::class, ExpensePayment::class, CashAccount::class, CashTransfer::class, ExpenseMonthLock::class, AccountingAccount::class, AccountingPeriod::class, JournalEntry::class, JournalLine::class, AccountingVendor::class, AccountingExpense::class, AccountingExpensePayment::class, AccountingSourcePost::class],
    version = 27,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): PaymentDao
    abstract fun studentDao(): StudentDao
    abstract fun feeDao(): FeeDao
    abstract fun financeDao(): FinanceDao
    abstract fun classroomDao(): ClassroomDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun hrDao(): HrDao
    abstract fun periodDao(): PeriodDao
    abstract fun cashControlDao(): CashControlDao
    abstract fun cashAccountDao(): CashAccountDao
    abstract fun cashTransferDao(): CashTransferDao
    abstract fun accountingDao(): AccountingDao

    companion object {
        /** ترقية غير مدمرة: جدول payments وسجلاته الحالية لا تُحذف ولا يعاد إنشاؤها. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE payments ADD COLUMN studentId INTEGER")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_payments_studentId ON payments(studentId)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS students (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, fullName TEXT NOT NULL,
                    birthDate INTEGER, enrollmentDate INTEGER NOT NULL, className TEXT NOT NULL,
                    motherName TEXT NOT NULL, motherWhatsapp TEXT NOT NULL, fatherName TEXT NOT NULL,
                    fatherPhone TEXT NOT NULL, address TEXT NOT NULL, photoUri TEXT, status TEXT NOT NULL,
                    notes TEXT NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_students_fullName ON students(fullName)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_students_status ON students(status)")
                // إنشاء ملف أولي لكل اسم تاريخي وربط دفعاته به دون تغيير أي مبلغ أو إيصال.
                db.execSQL("""INSERT INTO students (fullName, enrollmentDate, className, motherName, motherWhatsapp, fatherName, fatherPhone, address, status, notes, createdAt, updatedAt)
                    SELECT studentName, MIN(createdAt), '', '', '', '', '', '', 'active', 'ملف تم إنشاؤه تلقائياً من سجل الإصدار الأول', MIN(createdAt), MAX(createdAt)
                    FROM payments GROUP BY studentName""")
                db.execSQL("""UPDATE payments SET studentId = (
                    SELECT students.id FROM students WHERE students.fullName = payments.studentName LIMIT 1
                ) WHERE studentId IS NULL""")
                db.execSQL("""CREATE TABLE IF NOT EXISTS fee_plans (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, title TEXT NOT NULL,
                    amountPiasters INTEGER NOT NULL, studentId INTEGER, billingType TEXT NOT NULL,
                    isActive INTEGER NOT NULL, createdAt INTEGER NOT NULL)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_fee_plans_studentId ON fee_plans(studentId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_fee_plans_isActive ON fee_plans(isActive)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS student_fees (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, studentId INTEGER NOT NULL,
                    feePlanId INTEGER NOT NULL, periodKey TEXT NOT NULL, description TEXT NOT NULL,
                    amountPiasters INTEGER NOT NULL, dueAt INTEGER NOT NULL, discountPiasters INTEGER NOT NULL,
                    createdAt INTEGER NOT NULL, FOREIGN KEY(studentId) REFERENCES students(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_student_fees_studentId ON student_fees(studentId)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_student_fees_studentId_periodKey_feePlanId ON student_fees(studentId, periodKey, feePlanId)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS refund_credits (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, studentId INTEGER NOT NULL,
                    paymentId INTEGER NOT NULL, originalAmountPiasters INTEGER NOT NULL,
                    remainingAmountPiasters INTEGER NOT NULL, createdAt INTEGER NOT NULL, note TEXT NOT NULL,
                    FOREIGN KEY(studentId) REFERENCES students(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_refund_credits_studentId ON refund_credits(studentId)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_refund_credits_paymentId ON refund_credits(paymentId)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS receipts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, paymentId INTEGER NOT NULL,
                    receiptNo TEXT NOT NULL, issuedAt INTEGER NOT NULL,
                    FOREIGN KEY(paymentId) REFERENCES payments(id) ON UPDATE NO ACTION ON DELETE CASCADE)""")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_receipts_paymentId ON receipts(paymentId)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_receipts_receiptNo ON receipts(receiptNo)")
                // إنشاء سجل إيصال لكل دفعة قديمة باستخدام رقمها وتاريخها الأصليين.
                db.execSQL("""INSERT INTO receipts (paymentId, receiptNo, issuedAt)
                    SELECT id, receiptNo, createdAt FROM payments""")
                db.execSQL("""CREATE TABLE IF NOT EXISTS audit_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, entityType TEXT NOT NULL,
                    entityId INTEGER NOT NULL, action TEXT NOT NULL, details TEXT NOT NULL, createdAt INTEGER NOT NULL)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_audit_logs_createdAt ON audit_logs(createdAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_audit_logs_entityType ON audit_logs(entityType)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_audit_logs_entityId ON audit_logs(entityId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS app_settings (`key` TEXT NOT NULL PRIMARY KEY, value TEXT NOT NULL)")
                db.execSQL("INSERT OR IGNORE INTO app_settings (`key`, value) VALUES ('monthly_due_day', '1')")
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE students ADD COLUMN attendanceEndHour INTEGER NOT NULL DEFAULT 15")
                db.execSQL("ALTER TABLE students ADD COLUMN firstMonthAmountPiasters INTEGER")
                db.execSQL("""CREATE TABLE IF NOT EXISTS subscription_payments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    studentId INTEGER NOT NULL, periodKey TEXT NOT NULL,
                    dueAmountPiasters INTEGER NOT NULL, paidAmountPiasters INTEGER NOT NULL,
                    paymentId INTEGER NOT NULL, isPartialEnrollmentMonth INTEGER NOT NULL,
                    createdAt INTEGER NOT NULL,
                    FOREIGN KEY(studentId) REFERENCES students(id) ON UPDATE NO ACTION ON DELETE RESTRICT,
                    FOREIGN KEY(paymentId) REFERENCES payments(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_subscription_payments_studentId_periodKey ON subscription_payments(studentId, periodKey)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_subscription_payments_paymentId ON subscription_payments(paymentId)")
                db.execSQL("INSERT OR IGNORE INTO app_settings (`key`, value) VALUES ('monthly_due_day', '1')")
                db.execSQL("INSERT OR IGNORE INTO app_settings (`key`, value) VALUES ('subscription_morning_piasters', '70000')")
                db.execSQL("INSERT OR IGNORE INTO app_settings (`key`, value) VALUES ('subscription_evening_piasters', '70000')")
            }
        }

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS refund_transactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    refundCreditId INTEGER NOT NULL, amountPiasters INTEGER NOT NULL,
                    refundedAt INTEGER NOT NULL, method TEXT NOT NULL, note TEXT NOT NULL,
                    FOREIGN KEY(refundCreditId) REFERENCES refund_credits(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_refund_transactions_refundCreditId ON refund_transactions(refundCreditId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_refund_transactions_refundedAt ON refund_transactions(refundedAt)")
            }
        }

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE payments ADD COLUMN isCancelled INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE payments ADD COLUMN cancelledAt INTEGER")
                db.execSQL("ALTER TABLE payments ADD COLUMN cancellationReason TEXT NOT NULL DEFAULT ''")
            }
        }

        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS classrooms (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    name TEXT NOT NULL, level TEXT NOT NULL,
                    capacity INTEGER NOT NULL, createdAt INTEGER NOT NULL)""")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_classrooms_name ON classrooms(name)")
                // Preserve any class names already stored on student profiles.
                db.execSQL("""INSERT OR IGNORE INTO classrooms (name, level, capacity, createdAt)
                    SELECT DISTINCT className, '', 20, MIN(createdAt) FROM students
                    WHERE TRIM(className) <> '' GROUP BY className""")
            }
        }

        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS attendance (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    studentId INTEGER NOT NULL, studentName TEXT NOT NULL,
                    className TEXT NOT NULL, attendanceDate TEXT NOT NULL,
                    status TEXT NOT NULL, createdAt INTEGER NOT NULL)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_attendance_className_attendanceDate ON attendance(className, attendanceDate)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_attendance_studentId_attendanceDate ON attendance(studentId, attendanceDate)")
            }
        }

        val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS expenses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    title TEXT NOT NULL, category TEXT NOT NULL,
                    amountPiasters INTEGER NOT NULL, spentAt INTEGER NOT NULL,
                    note TEXT NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_expenses_spentAt ON expenses(spentAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_expenses_category ON expenses(category)")
            }
        }

        val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE expenses ADD COLUMN paidAmountPiasters INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE expenses ADD COLUMN dueAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE expenses ADD COLUMN monthKey TEXT NOT NULL DEFAULT ''")
                // Existing expense records represent completed historical expenses.
                db.execSQL("UPDATE expenses SET paidAmountPiasters = amountPiasters, dueAt = spentAt")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_expenses_monthKey ON expenses(monthKey)")
            }
        }

        /** يضيف بيانات الخصم دون المساس بأي إيصال أو اشتراك تاريخي. */
        val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE subscription_payments ADD COLUMN discountPiasters INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE subscription_payments ADD COLUMN discountNote TEXT NOT NULL DEFAULT ''")
            }
        }

        /** إضافة نظام شؤون العاملين مع الحفاظ على جميع بيانات الإصدارات السابقة. */
        val MIGRATION_10_11 = object : Migration(10, 11) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS employees (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, employeeCode TEXT NOT NULL, fullName TEXT NOT NULL,
                    jobTitle TEXT NOT NULL, phone TEXT NOT NULL, whatsapp TEXT NOT NULL, address TEXT NOT NULL,
                    nationalId TEXT NOT NULL, birthDate TEXT NOT NULL, hireDate TEXT NOT NULL, contractType TEXT NOT NULL,
                    contractEndDate TEXT NOT NULL, department TEXT NOT NULL, workStart TEXT NOT NULL, workEnd TEXT NOT NULL,
                    weeklyDays TEXT NOT NULL, baseSalaryPiasters INTEGER NOT NULL, emergencyName TEXT NOT NULL,
                    emergencyPhone TEXT NOT NULL, notes TEXT NOT NULL, status TEXT NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employees_fullName ON employees(fullName)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employees_status ON employees(status)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employees_jobTitle ON employees(jobTitle)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS employee_attendance (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, employeeId INTEGER NOT NULL, workDate TEXT NOT NULL,
                    checkIn TEXT NOT NULL, checkOut TEXT NOT NULL, status TEXT NOT NULL, lateMinutes INTEGER NOT NULL,
                    note TEXT NOT NULL, createdAt INTEGER NOT NULL,
                    FOREIGN KEY(employeeId) REFERENCES employees(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_employee_attendance_employeeId_workDate ON employee_attendance(employeeId, workDate)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_attendance_workDate ON employee_attendance(workDate)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS employee_leaves (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, employeeId INTEGER NOT NULL, leaveType TEXT NOT NULL,
                    startDate TEXT NOT NULL, endDate TEXT NOT NULL, days REAL NOT NULL, reason TEXT NOT NULL,
                    status TEXT NOT NULL, decisionNote TEXT NOT NULL, createdAt INTEGER NOT NULL,
                    FOREIGN KEY(employeeId) REFERENCES employees(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_leaves_employeeId ON employee_leaves(employeeId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_leaves_startDate ON employee_leaves(startDate)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS employee_payroll (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, employeeId INTEGER NOT NULL, monthKey TEXT NOT NULL,
                    basePiasters INTEGER NOT NULL, allowancesPiasters INTEGER NOT NULL, bonusesPiasters INTEGER NOT NULL,
                    deductionsPiasters INTEGER NOT NULL, loanDeductionPiasters INTEGER NOT NULL, netPiasters INTEGER NOT NULL,
                    paidPiasters INTEGER NOT NULL, paidAt INTEGER, note TEXT NOT NULL, createdAt INTEGER NOT NULL,
                    FOREIGN KEY(employeeId) REFERENCES employees(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_employee_payroll_employeeId_monthKey ON employee_payroll(employeeId, monthKey)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_payroll_monthKey ON employee_payroll(monthKey)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS employee_loans (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, employeeId INTEGER NOT NULL, amountPiasters INTEGER NOT NULL,
                    monthlyInstallmentPiasters INTEGER NOT NULL, remainingPiasters INTEGER NOT NULL, startMonth TEXT NOT NULL,
                    note TEXT NOT NULL, status TEXT NOT NULL, createdAt INTEGER NOT NULL,
                    FOREIGN KEY(employeeId) REFERENCES employees(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_loans_employeeId ON employee_loans(employeeId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_loans_status ON employee_loans(status)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS employee_adjustments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, employeeId INTEGER NOT NULL, monthKey TEXT NOT NULL,
                    type TEXT NOT NULL, amountPiasters INTEGER NOT NULL, reason TEXT NOT NULL, createdAt INTEGER NOT NULL,
                    FOREIGN KEY(employeeId) REFERENCES employees(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_adjustments_employeeId ON employee_adjustments(employeeId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_adjustments_monthKey ON employee_adjustments(monthKey)")
            }
        }

        /** إضافة سجل تسويات انسحاب الطلاب دون تعديل سجلات التحصيل والحضور السابقة. */
        val MIGRATION_11_12 = object : Migration(11, 12) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS student_exit_settlements (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, studentId INTEGER NOT NULL,
                    periodKey TEXT NOT NULL, withdrawalDate TEXT NOT NULL, attendedDays INTEGER NOT NULL,
                    monthlyFeePiasters INTEGER NOT NULL, paidAmountPiasters INTEGER NOT NULL,
                    earnedAmountPiasters INTEGER NOT NULL, refundAmountPiasters INTEGER NOT NULL,
                    amountDuePiasters INTEGER NOT NULL, createdAt INTEGER NOT NULL,
                    FOREIGN KEY(studentId) REFERENCES students(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_student_exit_settlements_studentId ON student_exit_settlements(studentId)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_student_exit_settlements_studentId_periodKey ON student_exit_settlements(studentId, periodKey)")
            }
        }

        /** يضيف تتبع الصرف والتصحيح دون تعديل أي تسوية أو حركة مالية سابقة. */
        val MIGRATION_12_13 = object : Migration(12, 13) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE student_exit_settlements ADD COLUMN refundedAmountPiasters INTEGER NOT NULL DEFAULT 0")
                db.execSQL("""CREATE TABLE IF NOT EXISTS student_exit_settlement_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    settlementId INTEGER NOT NULL, eventType TEXT NOT NULL,
                    amountPiasters INTEGER NOT NULL, details TEXT NOT NULL, createdAt INTEGER NOT NULL,
                    FOREIGN KEY(settlementId) REFERENCES student_exit_settlements(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_student_exit_settlement_events_settlementId ON student_exit_settlement_events(settlementId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_student_exit_settlement_events_createdAt ON student_exit_settlement_events(createdAt)")
            }
        }

        /** إضافة تعديل إداري قابل للاختيار وحالة إلغاء محفوظة دون حذف السجلات السابقة. */
        val MIGRATION_13_14 = object : Migration(13, 14) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE student_exit_settlements ADD COLUMN manualAdjustmentType TEXT NOT NULL DEFAULT 'none'")
                db.execSQL("ALTER TABLE student_exit_settlements ADD COLUMN manualAdjustmentAmountPiasters INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE student_exit_settlements ADD COLUMN manualAdjustmentReason TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE student_exit_settlements ADD COLUMN settlementStatus TEXT NOT NULL DEFAULT 'active'")
                db.execSQL("ALTER TABLE student_exit_settlements ADD COLUMN cancelledAt INTEGER")
                db.execSQL("ALTER TABLE student_exit_settlements ADD COLUMN cancellationReason TEXT NOT NULL DEFAULT ''")
            }
        }


        /** إدارة الفترات والأسعار مع ترحيل آمن للطلاب الحاليين. */
        val MIGRATION_14_15 = object : Migration(14, 15) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS attendance_periods (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, startTime TEXT NOT NULL, endTime TEXT NOT NULL, monthlyFeePiasters INTEGER NOT NULL, isActive INTEGER NOT NULL, createdAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_attendance_periods_isActive ON attendance_periods(isActive)")
                db.execSQL("CREATE TABLE IF NOT EXISTS period_price_history (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, periodId INTEGER NOT NULL, amountPiasters INTEGER NOT NULL, effectiveFrom INTEGER NOT NULL, recordedAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_period_price_history_periodId ON period_price_history(periodId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_period_price_history_effectiveFrom ON period_price_history(effectiveFrom)")
                db.execSQL("ALTER TABLE students ADD COLUMN periodId INTEGER")
                db.execSQL("ALTER TABLE students ADD COLUMN monthlyFeeOverridePiasters INTEGER")
                val now = System.currentTimeMillis()
                db.execSQL("INSERT INTO attendance_periods (id,name,startTime,endTime,monthlyFeePiasters,isActive,createdAt) VALUES (1,'صباحية','08:00','13:00',70000,1,$now)")
                db.execSQL("INSERT INTO attendance_periods (id,name,startTime,endTime,monthlyFeePiasters,isActive,createdAt) VALUES (2,'مسائية','10:00','15:00',70000,1,$now)")
                db.execSQL("INSERT INTO period_price_history (periodId,amountPiasters,effectiveFrom,recordedAt) VALUES (1,70000,0,$now)")
                db.execSQL("INSERT INTO period_price_history (periodId,amountPiasters,effectiveFrom,recordedAt) VALUES (2,70000,0,$now)")
                db.execSQL("UPDATE students SET periodId = CASE WHEN attendanceEndHour = 16 THEN 2 ELSE 1 END")
                db.execSQL("UPDATE students SET monthlyFeeOverridePiasters = 70000")
            }
        }

        /** سجل مستقل لكل دفعة مرتب مع ترحيل المدفوع التاريخي دون فقد قيمته. */
        val MIGRATION_15_16 = object : Migration(15, 16) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS employee_payroll_payments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    payrollId INTEGER NOT NULL,
                    amountPiasters INTEGER NOT NULL,
                    paymentDate TEXT NOT NULL,
                    paymentMethod TEXT NOT NULL,
                    note TEXT NOT NULL,
                    createdAt INTEGER NOT NULL,
                    FOREIGN KEY(payrollId) REFERENCES employee_payroll(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_payroll_payments_payrollId ON employee_payroll_payments(payrollId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_payroll_payments_paymentDate ON employee_payroll_payments(paymentDate)")
                // تحويل إجمالي المدفوع القديم إلى حركة افتتاحية واحدة حتى لا تضيع الأرصدة السابقة.
                db.execSQL("""INSERT INTO employee_payroll_payments (payrollId,amountPiasters,paymentDate,paymentMethod,note,createdAt)
                    SELECT id,paidPiasters,
                    strftime('%Y-%m-%d', COALESCE(paidAt,createdAt)/1000, 'unixepoch','localtime'),
                    'رصيد سابق - وسيلة غير محددة',
                    'حركة افتتاحية مُرحّلة من إجمالي المدفوع قبل تفعيل سجل الدفعات؛ التاريخ تقديري من بيانات الكشف',
                    COALESCE(paidAt,createdAt)
                    FROM employee_payroll WHERE paidPiasters > 0""")
            }
        }

        /** إلغاء/تصحيح دفعات المرتبات دون حذف الحركة الأصلية أو فقد سبب التعديل. */
        val MIGRATION_16_17 = object : Migration(16, 17) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE employee_payroll_payments ADD COLUMN status TEXT NOT NULL DEFAULT 'active'")
                db.execSQL("ALTER TABLE employee_payroll_payments ADD COLUMN voidedAt INTEGER")
                db.execSQL("ALTER TABLE employee_payroll_payments ADD COLUMN voidReason TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE employee_payroll_payments ADD COLUMN correctionOfPaymentId INTEGER")
                db.execSQL("ALTER TABLE employee_payroll_payments ADD COLUMN correctedByPaymentId INTEGER")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_payroll_payments_correctionOfPaymentId ON employee_payroll_payments(correctionOfPaymentId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_payroll_payments_correctedByPaymentId ON employee_payroll_payments(correctedByPaymentId)")
            }
        }

        /** يضيف بيانات ضبط الخزينة دون تعديل أي حركة مالية تاريخية. */
        val MIGRATION_17_18 = object : Migration(17, 18) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS cash_opening_balance (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, amountPiasters INTEGER NOT NULL,
                    effectiveAt INTEGER NOT NULL, note TEXT NOT NULL, updatedAt INTEGER NOT NULL)""")
                db.execSQL("""CREATE TABLE IF NOT EXISTS cash_counts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, countedAt INTEGER NOT NULL,
                    actualAmountPiasters INTEGER NOT NULL, note TEXT NOT NULL, createdAt INTEGER NOT NULL)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_cash_counts_countedAt ON cash_counts(countedAt)")
            }
        }

        /** سجل تفصيلي مستقل لكل دفعة مصروف؛ السجلات القديمة تظل محفوظة كما هي. */
        val MIGRATION_18_19 = object : Migration(18, 19) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS expense_payments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, expenseId INTEGER NOT NULL,
                    amountPiasters INTEGER NOT NULL, paidAt INTEGER NOT NULL, paymentMethod TEXT NOT NULL,
                    note TEXT NOT NULL, createdAt INTEGER NOT NULL,
                    FOREIGN KEY(expenseId) REFERENCES expenses(id) ON UPDATE NO ACTION ON DELETE CASCADE)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_expense_payments_expenseId ON expense_payments(expenseId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_expense_payments_paidAt ON expense_payments(paidAt)")
            }
        }

        /** حسابات مستقلة دون إعادة تصنيف أي حركة تاريخية؛ accountId يظل NULL للسجلات القديمة. */
        val MIGRATION_19_20 = object : Migration(19, 20) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS cash_accounts (
                    id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL, type TEXT NOT NULL,
                    isActive INTEGER NOT NULL, createdAt INTEGER NOT NULL)""")
                db.execSQL("INSERT OR IGNORE INTO cash_accounts (id,name,type,isActive,createdAt) VALUES ('cash','الخزينة النقدية','cash',1,0)")
                db.execSQL("ALTER TABLE payments ADD COLUMN accountId TEXT")
                db.execSQL("ALTER TABLE expense_payments ADD COLUMN accountId TEXT")
                db.execSQL("ALTER TABLE refund_transactions ADD COLUMN accountId TEXT")
                db.execSQL("ALTER TABLE student_exit_settlement_events ADD COLUMN accountId TEXT")
                db.execSQL("ALTER TABLE employee_payroll_payments ADD COLUMN accountId TEXT")
                db.execSQL("ALTER TABLE employee_loans ADD COLUMN accountId TEXT")
                db.execSQL("ALTER TABLE employee_loans ADD COLUMN issuedAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE cash_opening_balance ADD COLUMN accountId TEXT NOT NULL DEFAULT 'cash'")
                db.execSQL("ALTER TABLE cash_counts ADD COLUMN accountId TEXT NOT NULL DEFAULT 'cash'")
                db.execSQL("""CREATE TABLE IF NOT EXISTS cash_transfers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    fromAccountId TEXT NOT NULL, toAccountId TEXT NOT NULL,
                    amountPiasters INTEGER NOT NULL, transferredAt INTEGER NOT NULL,
                    note TEXT NOT NULL, createdAt INTEGER NOT NULL,
                    FOREIGN KEY(fromAccountId) REFERENCES cash_accounts(id) ON UPDATE NO ACTION ON DELETE RESTRICT,
                    FOREIGN KEY(toAccountId) REFERENCES cash_accounts(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_cash_transfers_transferredAt ON cash_transfers(transferredAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_cash_transfers_fromAccountId ON cash_transfers(fromAccountId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_cash_transfers_toAccountId ON cash_transfers(toAccountId)")
            }
        }

        /** سجل عكس دفعات المرتبات والتحصيل الفعلي من الموظف دون افتراض عودة النقد. */
        val MIGRATION_20_21 = object : Migration(20, 21) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // حفظ حركات الرد مؤقتًا قبل إعادة بناء جدول الأرصدة حتى تظل مفاتيحها الأجنبية صحيحة.
                db.execSQL("""CREATE TABLE refund_transactions_v20 (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, refundCreditId INTEGER NOT NULL,
                    amountPiasters INTEGER NOT NULL, refundedAt INTEGER NOT NULL, method TEXT NOT NULL,
                    note TEXT NOT NULL, accountId TEXT)""")
                db.execSQL("INSERT INTO refund_transactions_v20 SELECT id,refundCreditId,amountPiasters,refundedAt,method,note,accountId FROM refund_transactions")
                db.execSQL("DROP TABLE refund_transactions")
                // جعل مرجع التحصيل اختياريًا حتى ترتبط أرصدة الاسترداد أيضًا بتسوية الانسحاب المعتمدة.
                db.execSQL("DROP INDEX IF EXISTS index_refund_credits_studentId")
                db.execSQL("DROP INDEX IF EXISTS index_refund_credits_paymentId")
                db.execSQL("ALTER TABLE refund_credits RENAME TO refund_credits_v20")
                db.execSQL("""CREATE TABLE refund_credits (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    studentId INTEGER NOT NULL,
                    paymentId INTEGER,
                    originalAmountPiasters INTEGER NOT NULL,
                    remainingAmountPiasters INTEGER NOT NULL,
                    createdAt INTEGER NOT NULL,
                    note TEXT NOT NULL,
                    sourceType TEXT NOT NULL DEFAULT 'payment',
                    sourceId INTEGER,
                    approvalStatus TEXT NOT NULL DEFAULT 'approved',
                    reason TEXT NOT NULL DEFAULT '',
                    documentReference TEXT NOT NULL DEFAULT '',
                    approvedAt INTEGER,
                    FOREIGN KEY(studentId) REFERENCES students(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
                db.execSQL("""INSERT INTO refund_credits (id,studentId,paymentId,originalAmountPiasters,remainingAmountPiasters,createdAt,note,sourceType,sourceId,approvalStatus,reason,documentReference,approvedAt)
                    SELECT id,studentId,paymentId,originalAmountPiasters,remainingAmountPiasters,createdAt,note,'payment',paymentId,'approved',note,'',createdAt FROM refund_credits_v20""")
                db.execSQL("DROP TABLE refund_credits_v20")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_refund_credits_studentId ON refund_credits(studentId)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_refund_credits_paymentId ON refund_credits(paymentId)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_refund_credits_sourceType_sourceId ON refund_credits(sourceType,sourceId)")
                db.execSQL("""CREATE TABLE refund_transactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, refundCreditId INTEGER NOT NULL,
                    amountPiasters INTEGER NOT NULL, refundedAt INTEGER NOT NULL, method TEXT NOT NULL,
                    note TEXT NOT NULL, accountId TEXT,
                    FOREIGN KEY(refundCreditId) REFERENCES refund_credits(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
                db.execSQL("INSERT INTO refund_transactions SELECT id,refundCreditId,amountPiasters,refundedAt,method,note,accountId FROM refund_transactions_v20")
                db.execSQL("DROP TABLE refund_transactions_v20")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_refund_transactions_refundCreditId ON refund_transactions(refundCreditId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_refund_transactions_refundedAt ON refund_transactions(refundedAt)")
                // ترحيل تسويات الانسحاب القديمة إلى أرصدة موحدة، مع تحويل أحداث الصرف السابقة إلى معاملات مرتبطة.
                db.execSQL("""INSERT INTO refund_credits (studentId,paymentId,originalAmountPiasters,remainingAmountPiasters,createdAt,note,sourceType,sourceId,approvalStatus,reason,documentReference,approvedAt)
                    SELECT s.studentId,NULL,s.refundAmountPiasters,
                        CASE WHEN s.settlementStatus='active' THEN MAX(0,s.refundAmountPiasters-COALESCE(SUM(CASE WHEN e.eventType='refund_paid' THEN e.amountPiasters ELSE 0 END),0)) ELSE 0 END,
                        s.createdAt,'ترحيل رصيد من تسوية انسحاب #' || s.id,'exit_settlement',s.id,
                        CASE WHEN s.settlementStatus='active' THEN 'approved' ELSE 'cancelled' END,
                        'رصيد مرحّل من تسوية انسحاب محفوظة','تسوية انسحاب #' || s.id,s.createdAt
                    FROM student_exit_settlements s
                    LEFT JOIN student_exit_settlement_events e ON e.settlementId=s.id
                    WHERE s.refundAmountPiasters>0
                    GROUP BY s.id""")
                db.execSQL("""INSERT INTO refund_transactions (refundCreditId,amountPiasters,refundedAt,method,note,accountId)
                    SELECT c.id,e.amountPiasters,e.createdAt,'exit_settlement',e.details || ' [exit_event=' || e.id || ']',e.accountId
                    FROM student_exit_settlement_events e
                    INNER JOIN refund_credits c ON c.sourceType='exit_settlement' AND c.sourceId=e.settlementId
                    WHERE e.eventType='refund_paid' AND e.amountPiasters>0""")

                db.execSQL("""CREATE TABLE IF NOT EXISTS employee_payroll_reversals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    originalPaymentId INTEGER NOT NULL,
                    amountPiasters INTEGER NOT NULL,
                    reason TEXT NOT NULL,
                    note TEXT NOT NULL,
                    createdAt INTEGER NOT NULL,
                    FOREIGN KEY(originalPaymentId) REFERENCES employee_payroll_payments(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_employee_payroll_reversals_originalPaymentId ON employee_payroll_reversals(originalPaymentId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_payroll_reversals_createdAt ON employee_payroll_reversals(createdAt)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS employee_payroll_recovery_transactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    reversalId INTEGER NOT NULL,
                    amountPiasters INTEGER NOT NULL,
                    receivedAt INTEGER NOT NULL,
                    accountId TEXT NOT NULL,
                    note TEXT NOT NULL,
                    FOREIGN KEY(reversalId) REFERENCES employee_payroll_reversals(id) ON UPDATE NO ACTION ON DELETE RESTRICT,
                    FOREIGN KEY(accountId) REFERENCES cash_accounts(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_payroll_recovery_transactions_reversalId ON employee_payroll_recovery_transactions(reversalId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_payroll_recovery_transactions_receivedAt ON employee_payroll_recovery_transactions(receivedAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_payroll_recovery_transactions_accountId ON employee_payroll_recovery_transactions(accountId)")
            }
        }

        /** Soft delete, audit-safe expense month locking; existing expense/payment rows remain intact. */
        val MIGRATION_21_22 = object : Migration(21, 22) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE expenses ADD COLUMN deletedAt INTEGER DEFAULT NULL")
                db.execSQL("CREATE TABLE IF NOT EXISTS expense_month_locks (monthKey TEXT NOT NULL PRIMARY KEY, closedAt INTEGER NOT NULL, closedBy TEXT NOT NULL, note TEXT NOT NULL)")
            }
        }

        /** Accounting foundation v1: remove legacy expense data and create double-entry tables.
         * Payroll source tables and cash accounts are intentionally preserved. */
        val MIGRATION_22_23 = object : Migration(22, 23) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // User-approved removal of old expense register data. Payroll is stored elsewhere.
                db.execSQL("DELETE FROM expense_payments")
                db.execSQL("DELETE FROM expenses")
                db.execSQL("DELETE FROM expense_month_locks")
                db.execSQL("""CREATE TABLE IF NOT EXISTS accounting_accounts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, code TEXT NOT NULL, name TEXT NOT NULL,
                    type TEXT NOT NULL, parentId INTEGER, isPosting INTEGER NOT NULL, isActive INTEGER NOT NULL,
                    createdAt INTEGER NOT NULL)""")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_accounting_accounts_code ON accounting_accounts(code)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_accounting_accounts_parentId ON accounting_accounts(parentId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_accounting_accounts_type ON accounting_accounts(type)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS accounting_periods (
                    periodKey TEXT NOT NULL PRIMARY KEY, startDate INTEGER NOT NULL, endDate INTEGER NOT NULL,
                    status TEXT NOT NULL, closedAt INTEGER, note TEXT NOT NULL)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_accounting_periods_startDate_endDate ON accounting_periods(startDate,endDate)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS journal_entries (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, entryNo TEXT NOT NULL, entryDate INTEGER NOT NULL,
                    periodKey TEXT NOT NULL, description TEXT NOT NULL, sourceType TEXT NOT NULL, sourceId TEXT NOT NULL,
                    status TEXT NOT NULL, reversedEntryId INTEGER, createdAt INTEGER NOT NULL)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_journal_entries_entryDate ON journal_entries(entryDate)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_journal_entries_periodKey ON journal_entries(periodKey)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_journal_entries_sourceType_sourceId ON journal_entries(sourceType,sourceId)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS journal_lines (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, entryId INTEGER NOT NULL, accountId INTEGER NOT NULL,
                    debitPiasters INTEGER NOT NULL, creditPiasters INTEGER NOT NULL, memo TEXT NOT NULL,
                    FOREIGN KEY(entryId) REFERENCES journal_entries(id) ON UPDATE NO ACTION ON DELETE CASCADE,
                    FOREIGN KEY(accountId) REFERENCES accounting_accounts(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_journal_lines_entryId ON journal_lines(entryId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_journal_lines_accountId ON journal_lines(accountId)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS accounting_vendors (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, phone TEXT NOT NULL,
                    taxNumber TEXT NOT NULL, address TEXT NOT NULL, notes TEXT NOT NULL, isActive INTEGER NOT NULL,
                    createdAt INTEGER NOT NULL)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_accounting_vendors_name ON accounting_vendors(name)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS accounting_expenses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, documentNo TEXT NOT NULL, title TEXT NOT NULL,
                    categoryAccountId INTEGER NOT NULL, vendorId INTEGER, documentDate INTEGER NOT NULL, dueDate INTEGER NOT NULL,
                    amountPiasters INTEGER NOT NULL, paidPiasters INTEGER NOT NULL, periodKey TEXT NOT NULL,
                    status TEXT NOT NULL, note TEXT NOT NULL, journalEntryId INTEGER, createdAt INTEGER NOT NULL)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_accounting_expenses_documentDate ON accounting_expenses(documentDate)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_accounting_expenses_dueDate ON accounting_expenses(dueDate)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_accounting_expenses_vendorId ON accounting_expenses(vendorId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_accounting_expenses_periodKey ON accounting_expenses(periodKey)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS accounting_expense_payments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, expenseId INTEGER NOT NULL, amountPiasters INTEGER NOT NULL,
                    paidAt INTEGER NOT NULL, cashAccountId TEXT NOT NULL, method TEXT NOT NULL, note TEXT NOT NULL,
                    journalEntryId INTEGER, createdAt INTEGER NOT NULL,
                    FOREIGN KEY(expenseId) REFERENCES accounting_expenses(id) ON UPDATE NO ACTION ON DELETE RESTRICT,
                    FOREIGN KEY(cashAccountId) REFERENCES cash_accounts(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_accounting_expense_payments_expenseId ON accounting_expense_payments(expenseId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_accounting_expense_payments_paidAt ON accounting_expense_payments(paidAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_accounting_expense_payments_cashAccountId ON accounting_expense_payments(cashAccountId)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS accounting_source_posts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, sourceType TEXT NOT NULL, sourceId TEXT NOT NULL,
                    journalEntryId INTEGER NOT NULL, createdAt INTEGER NOT NULL)""")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_accounting_source_posts_sourceType_sourceId ON accounting_source_posts(sourceType,sourceId)")
                // Seed a usable chart of accounts; no historical opening balances are fabricated.
                val now = System.currentTimeMillis()
                val seeds = listOf(
                    arrayOf("1000","الأصول","asset","0"), arrayOf("1100","الخزينة","asset","1"),
                    arrayOf("1110","البنوك والمحافظ","asset","1"), arrayOf("1200","ذمم أولياء الأمور","asset","1"),
                    arrayOf("2000","الالتزامات","liability","0"), arrayOf("2100","الموردون والمصروفات المستحقة","liability","1"),
                    arrayOf("2200","مرتبات مستحقة","liability","1"), arrayOf("3000","حقوق الملكية","equity","0"),
                    arrayOf("3100","رأس المال والأرصدة الافتتاحية","equity","1"), arrayOf("4000","الإيرادات","revenue","0"),
                    arrayOf("4100","إيرادات الاشتراكات","revenue","1"), arrayOf("5000","المصروفات","expense","0"),
                    arrayOf("5100","مصروفات تشغيلية","expense","1"), arrayOf("5200","مصروف المرتبات","expense","1")
                )
                seeds.forEach { row -> db.execSQL("INSERT OR IGNORE INTO accounting_accounts(code,name,type,isPosting,isActive,createdAt) VALUES(?,?,?,?,1,?)", arrayOf(row[0],row[1],row[2],row[3].toInt(),now)) }
            }
        }

        /** Payroll accounting extension: employee advances are distinct from parent receivables. */
        val MIGRATION_23_24 = object : Migration(23, 24) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("INSERT OR IGNORE INTO accounting_accounts(code,name,type,parentId,isPosting,isActive,createdAt) VALUES('1210','سلف وعهد الموظفين','asset',NULL,1,1,${System.currentTimeMillis()})")
            }
        }

        /** Idempotently seed the operational chart for fresh installs and repair missing posting accounts.
         * Existing account IDs, journal lines, payments and balances are preserved. */
        private fun ensureAccountingChart(db: SupportSQLiteDatabase) {
            val now = System.currentTimeMillis()
            val seeds = listOf(
                arrayOf("1000", "الأصول", "asset", "0"),
                arrayOf("1100", "الخزينة", "asset", "1"),
                arrayOf("1110", "البنوك والمحافظ", "asset", "1"),
                arrayOf("1200", "ذمم أولياء الأمور", "asset", "1"),
                arrayOf("1210", "سلف وعهد الموظفين", "asset", "1"),
                arrayOf("2000", "الالتزامات", "liability", "0"),
                arrayOf("2100", "الموردون والمصروفات المستحقة", "liability", "1"),
                arrayOf("2200", "مرتبات مستحقة", "liability", "1"),
                arrayOf("3000", "حقوق الملكية", "equity", "0"),
                arrayOf("3100", "رأس المال والأرصدة الافتتاحية", "equity", "1"),
                arrayOf("4000", "الإيرادات", "revenue", "0"),
                arrayOf("4100", "إيرادات الاشتراكات", "revenue", "1"),
                arrayOf("5000", "المصروفات", "expense", "0"),
                arrayOf("5100", "مصروفات تشغيلية", "expense", "1"),
                arrayOf("5200", "مصروف المرتبات", "expense", "1")
            )
            seeds.forEach { row ->
                db.execSQL(
                    "INSERT OR IGNORE INTO accounting_accounts(code,name,type,parentId,isPosting,isActive,createdAt) VALUES(?,?,?,NULL,?,1,?)",
                    arrayOf(row[0], row[1], row[2], row[3].toInt(), now)
                )
            }
            // Required operational posting accounts must remain usable. No balances are altered.
            db.execSQL("UPDATE accounting_accounts SET type='revenue', isPosting=1, isActive=1 WHERE code='4100'")
            db.execSQL("UPDATE accounting_accounts SET type='asset', isPosting=1, isActive=1 WHERE code IN ('1100','1110')")
        }

        /** Repair old installations through the normal Room migration path. */
        val MIGRATION_24_25 = object : Migration(24, 25) {
            override fun migrate(db: SupportSQLiteDatabase) = ensureAccountingChart(db)
        }

        val MIGRATION_25_26 = object : Migration(25, 26) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE students ADD COLUMN gender TEXT NOT NULL DEFAULT 'boy'")
            }
        }

        /** Local-only schema marker. No cloud IDs or teacher-sync tables are added in this edition. */
        val MIGRATION_26_27 = object : Migration(26, 27) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Intentionally empty: local records already use their Room primary keys.
            }
        }


        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "tahseel.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10, MIGRATION_10_11, MIGRATION_11_12, MIGRATION_12_13, MIGRATION_13_14, MIGRATION_14_15, MIGRATION_15_16, MIGRATION_16_17, MIGRATION_17_18, MIGRATION_18_19, MIGRATION_19_20, MIGRATION_20_21, MIGRATION_21_22, MIGRATION_22_23, MIGRATION_23_24, MIGRATION_24_25, MIGRATION_25_26, MIGRATION_26_27)
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        db.execSQL("INSERT OR IGNORE INTO cash_accounts (id,name,type,isActive,createdAt) VALUES ('cash','الخزينة النقدية','cash',1,0)")
                        ensureAccountingChart(db)
                    }

                    override fun onOpen(db: SupportSQLiteDatabase) {
                        super.onOpen(db)
                        // Repair installations where the accounting chart was never initialized completely.
                        ensureAccountingChart(db)
                    }


                })
                .build()
    }
}
