package com.tahseel.students.util

import com.tahseel.students.data.AppDatabase
import com.tahseel.students.data.Payment

/**
 * Rebuilds the data of a receipt exactly as it was issued to the guardian, from the saved payment,
 * its subscription record (period, net due, discount) and the student file (class, guardian).
 * Read-only: nothing is written to the database.
 */
object ReceiptLoader {
    suspend fun load(db: AppDatabase, p: Payment): ReceiptData {
        val sub = db.financeDao().subscriptionForPayment(p.id)
        val studentId = p.studentId ?: sub?.studentId
        val student = studentId?.let { db.studentDao().getById(it) }
        return ReceiptData(
            nurseryName = AcademyProfileStore.name.value,
            nurseryAddress = AcademyProfileStore.address.value,
            nurseryPhone = AcademyProfileStore.phone.value,
            studentName = p.studentName,
            period = sub?.periodKey.orEmpty(),
            receiptNo = p.receiptNo,
            duePiasters = sub?.dueAmountPiasters ?: p.amountPiasters,
            paidPiasters = sub?.paidAmountPiasters ?: p.amountPiasters,
            createdAt = p.createdAt,
            guardianName = student?.let { it.motherName.ifBlank { it.fatherName } }.orEmpty(),
            className = student?.className.orEmpty(),
            discountPiasters = sub?.discountPiasters ?: 0L,
            discountNote = sub?.discountNote.orEmpty(),
            statement = if (sub == null) "دفعة نقدية" else null,
            isCancelled = p.isCancelled
        )
    }

    suspend fun loadAll(db: AppDatabase, payments: List<Payment>): List<ReceiptData> = payments.map { load(db, it) }
}
