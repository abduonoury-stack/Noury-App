package com.tahseel.students.data

/** تطابق محتمل بين حركتين تاريخيتين؛ لا يعني أنهما مكررتان بشكل مؤكد. */
data class FinancialDuplicateCandidate(
    val firstMovementId: String,
    val secondMovementId: String,
    val amountPiasters: Long,
    val accountId: String?,
    val direction: CashDirection,
    val distanceMillis: Long,
    val reason: String
)

/**
 * يرصد المرشحين للمراجعة اليدوية فقط. لا يحذف سجلات ولا يغيّر إجماليات الدفاتر؛
 * فالتشابه في القيمة والحساب والتاريخ قد يكون عمليتين حقيقيتين مستقلتين.
 */
fun findHistoricalDuplicateCandidates(
    movements: List<CashMovement>,
    windowMillis: Long = 24L * 60L * 60L * 1000L
): List<FinancialDuplicateCandidate> {
    require(windowMillis >= 0L) { "نطاق المراجعة الزمنية غير صحيح" }
    val rows = movements.filter { it.amountPiasters > 0L }
        .sortedWith(compareBy<CashMovement> { it.timestamp }.thenBy { it.id })
    val result = mutableListOf<FinancialDuplicateCandidate>()
    for (i in rows.indices) {
        val a = rows[i]
        for (j in i + 1 until rows.size) {
            val b = rows[j]
            val distance = b.timestamp - a.timestamp
            if (distance > windowMillis) break
            if (a.id == b.id || a.sourceReference == b.sourceReference) continue
            if (a.direction != b.direction || a.amountPiasters != b.amountPiasters) continue
            if (a.accountId != b.accountId) continue
            result += FinancialDuplicateCandidate(
                firstMovementId = a.id, secondMovementId = b.id,
                amountPiasters = a.amountPiasters, accountId = a.accountId,
                direction = a.direction, distanceMillis = distance,
                reason = "حركتان بالقيمة والاتجاه والحساب نفسيهما داخل نطاق المراجعة؛ يلزم فحص المستندين قبل أي معالجة"
            )
        }
    }
    return result
}
