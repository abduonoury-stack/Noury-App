package com.tahseel.students.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tahseel.students.data.*
import com.tahseel.students.util.TextUtil
import com.tahseel.students.util.TimeUtil
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.*

data class Summary(val today: Long = 0, val month: Long = 0, val total: Long = 0, val count: Int = 0)

private data class CashLedgerBaseRows(val payments: List<Payment>, val expenses: List<Expense>, val credits: List<RefundCredit>, val refunds: List<RefundTransaction>, val expensePayments: List<ExpensePayment>, val transfers: List<CashTransfer>, val accounts: List<CashAccount>, val accountingExpenses: List<AccountingExpense>, val accountingExpensePayments: List<AccountingExpensePayment>)
private data class CashLedgerLifecycleRows(val settlements: List<StudentExitSettlement>, val events: List<StudentExitSettlementEvent>, val payroll: List<EmployeePayroll>, val payrollPayments: List<EmployeePayrollPayment>, val payrollRecoveries: List<EmployeePayrollRecoveryTransaction>)


private fun appAccountingExpensesFlow(db: AppDatabase) = db.accountingDao().observeExpenses()
private fun appAccountingExpensePaymentsFlow(db: AppDatabase) = db.accountingDao().observeExpensePayments()

/** Paid subscriptions for the same student population used to calculate historical dues. */
internal fun sumPaidForStudents(rows: List<SubscriptionPayment>, studentIds: Set<Long>): Long =
    rows.filter { it.studentId in studentIds }.sumOf { it.paidAmountPiasters.coerceAtLeast(0) }

data class MonthlyReport(
    val month: YearMonth,
    val due: Long = 0,
    val collected: Long = 0,
    val subscriptionCollected: Long = 0,
    val expensesTotal: Long = 0,
    val expensesPaid: Long = 0,
    val expensesRemaining: Long = 0,
    val arrears: Long = 0,
    val payments: List<Payment> = emptyList(),
    val expenses: List<Expense> = emptyList(),
    val studentDueCount: Int = 0
) { val net: Long get() = netCashMovement(collected, expensesPaid) }

@OptIn(ExperimentalCoroutinesApi::class)
class ReportsViewModel(
    repo: PaymentRepository,
    private val studentsDao: StudentDao,
    private val financeDao: FinanceDao,
    private val expenseDao: ExpenseDao,
    private val periodDao: PeriodDao,
    hrDao: HrDao,
    private val cashControlDao: CashControlDao,
    private val cashAccountDao: com.tahseel.students.data.CashAccountDao,
    private val cashTransferDao: CashTransferDao,
    private val db: AppDatabase
) : ViewModel() {
    private val reportDate = MutableStateFlow(LocalDate.now())
    val summary: StateFlow<Summary> = reportDate.flatMapLatest { date ->
        val month = YearMonth.from(date)
        combine(
            repo.dao.observeSumBetween(TimeUtil.startOf(date), TimeUtil.startOf(date.plusDays(1))),
            repo.dao.observeSumBetween(TimeUtil.startOfMonth(month), TimeUtil.startOfNextMonth(month)),
            repo.dao.observeTotal(), repo.dao.observeCount()
        ) { d, m, t, c -> Summary(d, m, t, c) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Summary())
    fun refreshDate() { reportDate.value = LocalDate.now() }

    private val cashLedgerBaseRows = combine(
        combine(repo.dao.observeAll(), expenseDao.observeAll(), financeDao.observeAllRefundCredits(), financeDao.observeRefundTransactions(), expenseDao.observeAllPayments()) { payments, expenses, credits, refunds, expensePayments ->
            CashLedgerBaseRows(payments, expenses, credits, refunds, expensePayments, emptyList(), emptyList(), emptyList(), emptyList())
        }.combine(
            appAccountingExpensesFlow(db).combine(appAccountingExpensePaymentsFlow(db)) { invoices, payments -> invoices to payments }
        ) { base, accountingRows ->
            base.copy(accountingExpenses = accountingRows.first, accountingExpensePayments = accountingRows.second)
        }.combine(cashTransferDao.observeAll().combine(cashAccountDao.observeAll()) { transfers, accounts -> transfers to accounts }) { base, transferData ->
            base.copy(transfers = transferData.first, accounts = transferData.second)
        },
        combine(studentsDao.observeExitSettlements(), studentsDao.observeAllExitSettlementEvents(), hrDao.observeAllPayroll(), hrDao.observeAllPayrollPayments()) { settlements, events, payroll, payrollPayments ->
            CashLedgerLifecycleRows(settlements, events, payroll, payrollPayments, emptyList())
        }.combine(hrDao.observeAllPayrollRecoveries()) { rows, recoveries -> rows.copy(payrollRecoveries = recoveries) },
        combine(hrDao.observeEmployees(), hrDao.observeLoans()) { employees, loans -> employees to loans }
    ) { base, lifecycle, hr ->
        buildCashMovements(
            payments = base.payments, expenses = base.expenses,
            refundCredits = base.credits, refundTransactions = base.refunds,
            settlements = lifecycle.settlements, settlementEvents = lifecycle.events,
            payrollRows = lifecycle.payroll, payrollPayments = lifecycle.payrollPayments,
            employees = hr.first, loans = hr.second, expensePayments = base.expensePayments, transfers = base.transfers, cashAccounts = base.accounts,
            payrollRecoveries = lifecycle.payrollRecoveries, accountingExpenses = base.accountingExpenses,
            accountingExpensePayments = base.accountingExpensePayments
        )
    }

    val cashGeneralLedgerReconciliation: StateFlow<List<CashGeneralLedgerReconciliation>> = cashLedgerBaseRows
        .map { movements -> FinancialTransactionEngine(db).reconcileCashAccounts(movements, System.currentTimeMillis()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val historicalDuplicateCandidates: StateFlow<List<FinancialDuplicateCandidate>> = cashLedgerBaseRows
        .map { findHistoricalDuplicateCandidates(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val refundAuditRows = financeDao.observeAllRefundCredits()
        .combine(financeDao.observeRefundTransactions()) { credits, transactions -> credits to transactions }
    private val exitAuditRows = studentsDao.observeExitSettlements()
        .combine(studentsDao.observeAllExitSettlementEvents()) { settlements, events -> settlements to events }
    private data class PayrollAuditRows(
        val payroll: List<EmployeePayroll>, val payments: List<EmployeePayrollPayment>,
        val reversals: List<EmployeePayrollReversal>, val recoveries: List<EmployeePayrollRecoveryTransaction>
    )
    private val payrollAuditRows = combine(
        hrDao.observeAllPayroll(), hrDao.observeAllPayrollPayments(),
        hrDao.observeAllPayrollReversals(), hrDao.observeAllPayrollRecoveries()
    ) { payroll, payments, reversals, recoveries -> PayrollAuditRows(payroll, payments, reversals, recoveries) }
    val cashLifecycleAudit: StateFlow<CashLifecycleAudit> = combine(
        refundAuditRows, exitAuditRows, payrollAuditRows, hrDao.observeLoans(), expenseDao.observeAll()
    ) { refunds, exits, payroll, loans, expenses ->
        auditCashLifecycle(
            refundCredits = refunds.first,
            refundTransactions = refunds.second,
            settlements = exits.first,
            settlementEvents = exits.second,
            payrollRows = payroll.payroll,
            payrollPayments = payroll.payments,
            loans = loans,
            expenses = expenses,
            payrollReversals = payroll.reversals,
            payrollRecoveries = payroll.recoveries
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CashLifecycleAudit())

    val studentQuery = MutableStateFlow("")
    val studentResults: StateFlow<List<Payment>> = combine(repo.dao.observeAll(), studentQuery) { all, q ->
        val n = TextUtil.normalize(q)
        if (n.isEmpty()) emptyList() else all.filter { !it.isCancelled && TextUtil.normalize(it.studentName).contains(n) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val range = MutableStateFlow(Pair(LocalDate.now().withDayOfMonth(1), LocalDate.now()))
    val rangeResults: StateFlow<List<Payment>> = range.flatMapLatest { (from, to) ->
        if (to.isBefore(from)) flowOf(emptyList()) else repo.dao.observeBetween(TimeUtil.startOf(from), TimeUtil.startOf(to.plusDays(1)))
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun setFrom(d: LocalDate) = range.update { it.copy(first = d) }
    fun setTo(d: LocalDate) = range.update { it.copy(second = d) }

    val selectedMonth = MutableStateFlow(YearMonth.now())
    val cashAccounts: StateFlow<List<CashAccount>> = cashAccountDao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val selectedCashAccountId = MutableStateFlow("cash")
    val cashLedger: StateFlow<CashLedgerSummary> = combine(selectedMonth, selectedCashAccountId, cashLedgerBaseRows) { month, accountId, rows ->
        summarizeCashMovements(rows, month, accountId = accountId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), summarizeCashMovements(emptyList(), YearMonth.now(), accountId = "cash"))
    fun selectCashAccount(id: String) { selectedCashAccountId.value = id }
    val unassignedCashMovements: StateFlow<List<CashMovement>> = combine(selectedMonth, cashLedgerBaseRows) { month, rows ->
        summarizeCashMovements(rows, month, accountId = "__unassigned__").movements
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    data class CashControlState(
        val opening: CashOpeningBalance? = null,
        val openingHistory: List<CashOpeningBalance> = emptyList(),
        val counts: List<CashCount> = emptyList(),
        val expectedNow: Long? = null,
        val latestExpected: Long? = null,
        val latestDifference: Long? = null,
        val unassignedSinceOpening: Int = 0
    )
    private val cashOpeningData = selectedCashAccountId.flatMapLatest { id ->
        combine(cashControlDao.observeOpeningBalance(id), cashControlDao.observeOpeningHistory(id)) { opening, history -> opening to history }
    }
    private val cashCounts = selectedCashAccountId.flatMapLatest { id -> cashControlDao.observeCounts(id) }
    val cashControl: StateFlow<CashControlState> = combine(cashOpeningData, cashCounts, cashLedgerBaseRows) { openingData, counts, movements ->
        val opening = openingData.first
        val latest = counts.firstOrNull()
        val expectedAtCount = latest?.let { expectedCashBalance(movements, opening, it.countedAt, selectedCashAccountId.value) }
        CashControlState(
            opening = opening, openingHistory = openingData.second, counts = counts,
            expectedNow = expectedCashBalance(movements, opening, System.currentTimeMillis(), selectedCashAccountId.value),
            latestExpected = expectedAtCount,
            latestDifference = if (latest != null && expectedAtCount != null) latest.actualAmountPiasters - expectedAtCount else null,
            unassignedSinceOpening = opening?.let { start -> movements.count { it.accountId == null && it.timestamp >= start.effectiveAt } } ?: 0
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CashControlState())

    fun saveCashOpening(amountPiasters: Long, effectiveAt: Long, note: String) {
        require(amountPiasters >= 0L)
        viewModelScope.launch {
            cashControlDao.saveOpeningBalance(CashOpeningBalance(
                amountPiasters = amountPiasters, effectiveAt = effectiveAt,
                note = note.trim(), updatedAt = System.currentTimeMillis(), accountId = selectedCashAccountId.value
            ))
        }
    }

    fun recordCashCount(actualAmountPiasters: Long, countedAt: Long, note: String) {
        require(actualAmountPiasters >= 0L)
        viewModelScope.launch {
            cashControlDao.insertCount(CashCount(
                countedAt = countedAt, actualAmountPiasters = actualAmountPiasters,
                note = note.trim(), accountId = selectedCashAccountId.value
            ))
        }
    }
    val monthlyReport: StateFlow<MonthlyReport> = selectedMonth.flatMapLatest { month ->
        val from = TimeUtil.startOfMonth(month); val until = TimeUtil.startOfNextMonth(month)
        combine(
            studentsDao.observeAll()
                .combine(repo.dao.observeBetween(from, until)) { students, payments -> students to payments }
                .combine(expenseDao.observeAll()) { studentPayments, allExpenses ->
                    Triple(studentPayments.first, studentPayments.second, allExpenses)
                },
            financeDao.observeValidSubscriptionPayments(month.toString())
                .combine(periodDao.observeAll()) { subscriptionRows, allPeriods -> subscriptionRows to allPeriods }
                .combine(periodDao.observeAllPriceHistory()) { subscriptionPeriods, priceHistory ->
                    Triple(subscriptionPeriods.first, subscriptionPeriods.second, priceHistory)
                }
        ) { studentExpenseData, subscriptionPeriodData ->
            val (students, payments, allExpenses) = studentExpenseData
            val (subscriptionRows, allPeriods, priceHistory) = subscriptionPeriodData
            val eligible = students.filter { s ->
                val enrolled = Instant.ofEpochMilli(s.enrollmentDate).atZone(ZoneId.systemDefault()).toLocalDate()
                s.status == "active" && !YearMonth.from(enrolled).isAfter(month)
            }
            val dueByStudent = eligible.sumOf { s ->
                val enrolled = YearMonth.from(Instant.ofEpochMilli(s.enrollmentDate).atZone(ZoneId.systemDefault()).toLocalDate())
                val sub = subscriptionRows.firstOrNull { it.studentId == s.id }
                when {
                    sub != null -> sub.dueAmountPiasters
                    enrolled == month && s.firstMonthAmountPiasters != null -> s.firstMonthAmountPiasters
                    else -> {
                        val pid = s.periodId ?: if (s.attendanceEndHour == 16 || s.attendanceEndHour == 17) 2L else 1L
                        val at = month.atDay(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                        s.monthlyFeeOverridePiasters ?: resolvePeriodPricePiasters(priceHistory, pid, at) ?: 0L
                    }
                }
            }
            val monthExpenses = expensesForMonth(allExpenses, month)
            val expenseTotals = expenseMonthTotals(monthExpenses)
            val expenseTotal = expenseTotals.committed
            val expensePaid = expenseTotals.paid
            // Total cash collected from all valid receipts; subscription arrears below
            // are calculated only from subscription records to avoid mixing categories.
            val collected = sumValidReceiptAmounts(payments)
            // Keep subscription collections distinct from total receipts so one-time/other receipts
            // are not silently mixed into the subscription collection KPI.
            val eligibleIdsForCollection = eligible.map { it.id }.toSet()
            val subscriptionCollected = subscriptionRows.asSequence()
                .filter { it.studentId in eligibleIdsForCollection }
                .sumOf { row -> row.paidAmountPiasters.coerceIn(0L, row.dueAmountPiasters.coerceAtLeast(0L)) }
            // Do not let payments belonging to currently inactive/withdrawn students
            // reduce the arrears of the active students shown in this report.
            val eligibleIds = eligible.map { it.id }.toSet()
            val subPaid = sumPaidForStudents(subscriptionRows, eligibleIds)
            val arrears = (dueByStudent - subPaid).coerceAtLeast(0L)
            MonthlyReport(month = month, due = dueByStudent, collected = collected,
                subscriptionCollected = subscriptionCollected, expensesTotal = expenseTotal, expensesPaid = expensePaid,
                expensesRemaining = expenseTotals.remaining, arrears = arrears,
                payments = payments.filter { payment -> !payment.isCancelled && payment.amountPiasters > 0L }, expenses = monthExpenses, studentDueCount = eligible.size)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MonthlyReport(YearMonth.now()))
    fun previousMonth() { selectedMonth.update { it.minusMonths(1) } }
    fun nextMonth() { selectedMonth.update { it.plusMonths(1) } }
}
