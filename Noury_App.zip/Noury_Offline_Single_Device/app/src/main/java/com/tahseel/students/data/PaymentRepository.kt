package com.tahseel.students.data

import android.database.sqlite.SQLiteConstraintException
import androidx.room.withTransaction
import java.time.YearMonth

sealed class CancelResult {
    object Success : CancelResult()
    object NotFound : CancelResult()
    object AlreadyCancelled : CancelResult()
    object HasRefunds : CancelResult()
    data class Error(val message: String) : CancelResult()
}

sealed class SaveResult {
    object Success : SaveResult()
    object DuplicateReceipt : SaveResult()
    data class Error(val message: String) : SaveResult()
}

class PaymentRepository(private val db: AppDatabase) {
    val dao: PaymentDao = db.dao()

    suspend fun add(name: String, receipt: String, piasters: Long, accountId: String = "cash"): SaveResult = try {
        db.withTransaction {
            require(name.isNotBlank()) { "اسم صاحب التحصيل مطلوب" }
            require(receipt.isNotBlank()) { "رقم الإيصال مطلوب" }
            require(piasters > 0L) { "مبلغ التحصيل يجب أن يكون أكبر من صفر" }
            val account = db.cashAccountDao().find(accountId) ?: error("حساب الاستلام غير موجود")
            require(account.isActive) { "حساب الاستلام غير نشط" }
            val now = System.currentTimeMillis()
            val id = dao.insert(Payment(studentName = name.trim(), receiptNo = receipt.trim(), amountPiasters = piasters, createdAt = now, accountId = accountId))
            db.financeDao().insertReceipt(Receipt(paymentId = id, receiptNo = receipt.trim(), issuedAt = now))
            FinancialTransactionEngine(db).postManualReceipt(id, piasters, accountId, now, name.trim())
            db.financeDao().insertAudit(AuditLog(entityType = "payment", entityId = id, action = "manual_receipt_created", details = "receipt=${receipt.trim()};amount=$piasters;account=$accountId", createdAt = now))
            SaveResult.Success
        }
    } catch (e: SQLiteConstraintException) {
        SaveResult.DuplicateReceipt
    } catch (e: Exception) {
        SaveResult.Error(e.message ?: "تعذر تسجيل التحصيل")
    }

    /** تسجيل دفعة الاشتراك وربطها بالشهر الحالي حتى تتحدث شاشة متابعة السداد فوراً. */
    suspend fun addCurrentMonthSubscription(studentId: Long, receipt: String, piasters: Long, accountId: String = "cash"): SaveResult {
        return when (val result = SubscriptionRepository(db).collectMonthly(
            studentId = studentId,
            period = YearMonth.now(),
            receiptNo = receipt,
            paidAmountPiasters = piasters,
            accountId = accountId
        )) {
            is SubscriptionResult.Success -> SaveResult.Success
            is SubscriptionResult.Rejected -> SaveResult.Error(result.reason)
        }
    }

    /**
     * تحديث الدفعة والإيصال والتحقق من ثبات سجل الاشتراك كوحدة واحدة.
     *
     * الاشتراكات الشهرية لا تسمح بتغيير الطالب أو مبلغ الاستحقاق من شاشة تعديل
     * الإيصال؛ يجب إلغاء العملية وفق ضوابط الإلغاء ثم إعادة تسجيلها حتى لا
     * تتغير حقيقة الاستحقاق التاريخي بصمت.
     */
    suspend fun update(p: Payment): SaveResult = try {
        db.withTransaction {
            val current = dao.getById(p.id)
                ?: return@withTransaction SaveResult.Error("عملية التحصيل غير موجودة")
            if (current.isCancelled) {
                return@withTransaction SaveResult.Error("لا يمكن تعديل عملية ملغاة")
            }
            if (p.receiptNo.isBlank()) {
                return@withTransaction SaveResult.Error("رقم الإيصال مطلوب")
            }
            if (p.studentName.isBlank()) {
                return@withTransaction SaveResult.Error("اسم الطالب مطلوب")
            }
            if (p.amountPiasters <= 0L) {
                return@withTransaction SaveResult.Error("مبلغ التحصيل يجب أن يكون أكبر من صفر")
            }

            val finance = db.financeDao()
            val refundCredit = finance.refundCreditForPayment(p.id)
            if (refundCredit != null) {
                return@withTransaction SaveResult.Error(
                    "لا يمكن تعديل دفعة لها رصيد استرداد. راجع سجل الاسترداد أولاً"
                )
            }

            val subscription = finance.subscriptionForPayment(p.id)
            val updatedPayment = if (subscription != null) {
                val targetStudent = db.studentDao().getByExactName(p.studentName)
                    ?: return@withTransaction SaveResult.Error("الطالب المرتبط بالاشتراك غير موجود")
                if (targetStudent.id != subscription.studentId) {
                    return@withTransaction SaveResult.Error(
                        "لا يمكن نقل اشتراك مسجل إلى طالب آخر. ألغِ العملية وفق الإجراءات ثم أعد تسجيلها"
                    )
                }
                if (p.amountPiasters != subscription.paidAmountPiasters ||
                    p.amountPiasters != subscription.dueAmountPiasters) {
                    return@withTransaction SaveResult.Error(
                        "لا يمكن تغيير مبلغ اشتراك شهري مسجل من شاشة تعديل الإيصال. استخدم الإلغاء وإعادة التسجيل"
                    )
                }
                p.copy(
                    studentId = subscription.studentId,
                    studentName = targetStudent.fullName,
                    receiptNo = p.receiptNo.trim(),
                    accountId = current.accountId
                )
            } else {
                val manualPost = db.accountingDao().sourcePost("manual_receipt", p.id.toString())
                if (manualPost != null && (p.amountPiasters != current.amountPiasters || p.studentName.trim() != current.studentName.trim())) {
                    return@withTransaction SaveResult.Error(
                        "لا يمكن تغيير قيمة أو صاحب تحصيل مرحّل محاسبيًا. ألغِ الإيصال بعكس قيده ثم أعد تسجيله بالبيانات الصحيحة"
                    )
                }
                val targetStudent = db.studentDao().getByExactName(p.studentName)
                if (current.studentId != null && targetStudent == null) {
                    return@withTransaction SaveResult.Error(
                        "الدفعة مرتبطة بملف طالب؛ اختر اسم طالب موجودًا للحفاظ على الربط"
                    )
                }
                p.copy(
                    studentId = targetStudent?.id,
                    studentName = targetStudent?.fullName ?: p.studentName.trim(),
                    receiptNo = p.receiptNo.trim(),
                    accountId = current.accountId
                )
            }

            val changed = dao.update(updatedPayment)
            if (changed == 0) {
                return@withTransaction SaveResult.Error("لم يتم العثور على الدفعة لتحديثها")
            }

            val oldReceipt = finance.receiptForPayment(p.id)
            if (oldReceipt != null) {
                if (finance.updateReceipt(oldReceipt.copy(receiptNo = updatedPayment.receiptNo)) == 0) {
                    error("تعذر تحديث سجل الإيصال المرتبط")
                }
            } else {
                finance.insertReceipt(Receipt(
                    paymentId = p.id,
                    receiptNo = updatedPayment.receiptNo,
                    issuedAt = updatedPayment.createdAt
                ))
            }

            finance.insertAudit(AuditLog(
                entityType = "payment",
                entityId = p.id,
                action = "update",
                details = "oldStudent=${current.studentName};newStudent=${updatedPayment.studentName};" +
                    "oldReceipt=${current.receiptNo};newReceipt=${updatedPayment.receiptNo};" +
                    "oldAmount=${current.amountPiasters};newAmount=${updatedPayment.amountPiasters}",
                createdAt = System.currentTimeMillis()
            ))
            SaveResult.Success
        }
    } catch (e: SQLiteConstraintException) {
        SaveResult.DuplicateReceipt
    } catch (e: Exception) {
        SaveResult.Error(e.message ?: "تعذر تحديث عملية التحصيل")
    }

    suspend fun cancel(id: Long, reason: String): CancelResult = try {
        db.withTransaction {
            val payment = dao.getById(id) ?: return@withTransaction CancelResult.NotFound
            if (payment.isCancelled) return@withTransaction CancelResult.AlreadyCancelled

            val finance = db.financeDao()
            val credit = finance.refundCreditForPayment(id)
            if (credit != null && finance.countRefundTransactions(credit.id) > 0) {
                return@withTransaction CancelResult.HasRefunds
            }

            // إلغاء رصيد الزيادة غير المصروف مع الاحتفاظ بسجل الرصيد الأصلي.
            if (credit != null) finance.updateRefundCredit(credit.copy(
                remainingAmountPiasters = 0L, approvalStatus = "cancelled",
                reason = "تم إلغاء الدفعة المرتبطة", approvedAt = System.currentTimeMillis(),
                note = (credit.note + " | تم إلغاء الدفعة المرتبطة").trim()
            ))

            val now = System.currentTimeMillis()
            val subscription = finance.subscriptionForPayment(id)
            var journalReversed = false
            if (payment.amountPiasters > 0L) {
                val accounting = db.accountingDao()
                val sourceType = if (subscription != null) "subscription_receipt" else "manual_receipt"
                val sourcePost = accounting.sourcePost(sourceType, id.toString())
                if (subscription != null && sourcePost == null) {
                    return@withTransaction CancelResult.Error(
                        "لا يوجد قيد محاسبي مرتبط بهذا الإيصال. أوقفنا الإلغاء لحماية تطابق الخزينة والأستاذ العام، ويلزم فحص العملية التاريخية أولاً"
                    )
                }
                if (sourcePost != null) {
                    accounting.reverseJournal(
                        entryId = sourcePost.journalEntryId,
                        reversalDate = now,
                        reason = "إلغاء إيصال ${if (subscription != null) "اشتراك" else "تحصيل عام"} ${payment.receiptNo}: ${reason.trim()}"
                    )
                    journalReversed = true
                }
            }

            // إزالة رابط الاشتراك النشط للسماح بإعادة تسجيل الشهر بعد الإلغاء.
            finance.deleteSubscriptionPayment(id)
            val changed = dao.markCancelled(id, now, reason.trim())
            if (changed == 0) return@withTransaction CancelResult.AlreadyCancelled
            finance.insertAudit(AuditLog(
                entityType = "payment", entityId = id, action = "cancel",
                details = "receipt=${payment.receiptNo};student=${payment.studentName};amount=${payment.amountPiasters};reason=${reason.trim()};journalReversed=$journalReversed",
                createdAt = now
            ))
            CancelResult.Success
        }
    } catch (e: Exception) {
        CancelResult.Error(e.message ?: "تعذر إلغاء العملية")
    }

    /** استبدال كل البيانات داخل Transaction واحدة؛ أي فشل يُلغي التغيير بالكامل ويبقى القديم سليمًا. */
    suspend fun replaceAll(list: List<Payment>) {
        db.withTransaction {
            dao.deleteAll()
            dao.insertAll(list)
        }
    }

    private suspend fun guard(block: suspend () -> Unit): SaveResult = try {
        block()
        SaveResult.Success
    } catch (e: SQLiteConstraintException) {
        SaveResult.DuplicateReceipt
    } catch (e: Exception) {
        SaveResult.Error(e.message ?: "خطأ غير معروف")
    }
}
