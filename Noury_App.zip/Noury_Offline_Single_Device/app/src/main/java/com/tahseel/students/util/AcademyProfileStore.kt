package com.tahseel.students.util

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Single source of truth for academy identity across screens, receipts and reports. */
object AcademyProfileStore {
    const val DEFAULT_NAME = ""
    private const val PREFS_NAME = "receipt_profile"

    private val mutableName = MutableStateFlow(DEFAULT_NAME)
    private val mutableAddress = MutableStateFlow("")
    private val mutablePhone = MutableStateFlow("")
    val name: StateFlow<String> = mutableName.asStateFlow()
    val address: StateFlow<String> = mutableAddress.asStateFlow()
    val phone: StateFlow<String> = mutablePhone.asStateFlow()

    private fun preferences(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private fun isComplete(name: String, address: String, phone: String): Boolean =
        name.isNotBlank() && address.isNotBlank() && phone.filter(Char::isDigit).length >= 8

    /** Setup is complete only when academy name, address and contact phone are all saved. */
    fun isSetupComplete(context: Context): Boolean {
        val prefs = preferences(context)
        return isComplete(
            prefs.getString("name", "")?.trim().orEmpty(),
            prefs.getString("address", "")?.trim().orEmpty(),
            prefs.getString("phone", "")?.trim().orEmpty()
        )
    }

    /** Load persisted profile at app start or after a backup restore. Partial profiles stay hidden. */
    fun refresh(context: Context): String {
        val prefs = preferences(context)
        val savedName = prefs.getString("name", "")?.trim().orEmpty()
        val savedAddress = prefs.getString("address", "")?.trim().orEmpty()
        val savedPhone = prefs.getString("phone", "")?.trim().orEmpty()
        val complete = isComplete(savedName, savedAddress, savedPhone)
        mutableName.value = if (complete) savedName else ""
        mutableAddress.value = if (complete) savedAddress else ""
        mutablePhone.value = if (complete) savedPhone else ""
        return mutableName.value
    }

    /** إعدادات الأكاديمية المكتملة فقط كما تُحفظ داخل النسخ الاحتياطية المحلية. */
    fun exportJson(context: Context): org.json.JSONObject {
        refresh(context)
        return org.json.JSONObject().put("name", mutableName.value)
            .put("phone", mutablePhone.value)
            .put("address", mutableAddress.value)
    }

    fun getName(context: Context): String = refresh(context)
    fun getAddress(context: Context): String { refresh(context); return mutableAddress.value }
    fun getPhone(context: Context): String { refresh(context); return mutablePhone.value }

    /** Save once and publish all fields only when the full academy profile is valid. */
    fun save(context: Context, name: String, address: String, phone: String): String {
        val normalizedName = name.trim()
        val normalizedAddress = address.trim()
        val normalizedPhone = phone.trim()
        val complete = isComplete(normalizedName, normalizedAddress, normalizedPhone)
        preferences(context).edit()
            .putString("name", normalizedName)
            .putString("address", normalizedAddress)
            .putString("phone", normalizedPhone)
            .putBoolean("setup_completed", complete)
            .apply()
        mutableName.value = if (complete) normalizedName else ""
        mutableAddress.value = if (complete) normalizedAddress else ""
        mutablePhone.value = if (complete) normalizedPhone else ""
        return mutableName.value
    }
}
