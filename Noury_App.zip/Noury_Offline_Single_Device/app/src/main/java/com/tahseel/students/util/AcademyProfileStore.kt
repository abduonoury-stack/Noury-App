package com.tahseel.students.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Base64
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Single source of truth for academy identity across screens, receipts and reports. */
object AcademyProfileStore {
    const val DEFAULT_NAME = ""
    const val MAX_LOGO_BYTES = 8 * 1024 * 1024
    const val BACKUP_LOGO_FIELD = "logoBase64"
    private const val PREFS_NAME = "receipt_profile"

    data class BackupRestoreResult(
        val logoFieldPresent: Boolean,
        val logoRestored: Boolean = false,
        val logoRemoved: Boolean = false,
        val logoFailed: Boolean = false
    )

    private val mutableName = MutableStateFlow(DEFAULT_NAME)
    private val mutableAddress = MutableStateFlow("")
    private val mutablePhone = MutableStateFlow("")
    private val mutableLogoPath = MutableStateFlow("")
    val name: StateFlow<String> = mutableName.asStateFlow()
    val address: StateFlow<String> = mutableAddress.asStateFlow()
    val phone: StateFlow<String> = mutablePhone.asStateFlow()
    val logoPath: StateFlow<String> = mutableLogoPath.asStateFlow()

    private fun preferences(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private fun isComplete(name: String, address: String, phone: String): Boolean =
        name.isNotBlank() && address.isNotBlank() && phone.filter(Char::isDigit).length >= 8

    /** Setup is complete only when academy name, address and contact phone are all saved. */
    fun isSetupComplete(context: Context): Boolean {
        val prefs = preferences(context)
        return isComplete(
            prefs.getString("name", "")?.trim().orEmpty(),
            prefs.getString("address", "")?.trim().orEmpty(),
            prefs.getString("phone", "")?.trim().orEmpty()
        )
    }

    /** Load persisted profile at app start or after a backup restore. Partial profiles stay hidden. */
    fun refresh(context: Context): String {
        val prefs = preferences(context)
        val savedName = prefs.getString("name", "")?.trim().orEmpty()
        val savedAddress = prefs.getString("address", "")?.trim().orEmpty()
        val savedPhone = prefs.getString("phone", "")?.trim().orEmpty()
        val complete = isComplete(savedName, savedAddress, savedPhone)
        mutableName.value = if (complete) savedName else ""
        mutableAddress.value = if (complete) savedAddress else ""
        mutablePhone.value = if (complete) savedPhone else ""
        mutableLogoPath.value = prefs.getString("logo_path", "")
            ?.takeIf { it.isNotBlank() && File(it).isFile }.orEmpty()
        return mutableName.value
    }

    /** بيانات الأكاديمية والشعار الفعلي داخل النسخ الاحتياطية المحلية ونسخ الأمان. */
    fun exportJson(context: Context): org.json.JSONObject {
        refresh(context)
        val result = org.json.JSONObject()
            .put("name", mutableName.value)
            .put("phone", mutablePhone.value)
            .put("address", mutableAddress.value)
        val path = mutableLogoPath.value
        val encodedLogo = if (path.isBlank()) {
            ""
        } else {
            val file = File(path)
            require(file.isFile && file.length() <= MAX_LOGO_BYTES) {
                "تعذر تضمين شعار الأكاديمية: حجم ملف الشعار يتجاوز الحد المسموح أو أن الملف غير متاح. أعد اختيار صورة الشعار من بيانات الأكاديمية."
            }
            Base64.getEncoder().encodeToString(file.readBytes())
        }
        // الحقل موجود دائمًا في النسخ الجديدة؛ القيمة الفارغة تعني أن النسخة أُنشئت بلا شعار مخصص.
        return result.put(BACKUP_LOGO_FIELD, encodedLogo)
    }

    fun getName(context: Context): String = refresh(context)
    fun getAddress(context: Context): String { refresh(context); return mutableAddress.value }
    fun getPhone(context: Context): String { refresh(context); return mutablePhone.value }

    /** Copy selected logo into a unique app-private file so image changes always emit a new UI state. */
    fun saveLogo(context: Context, source: Uri): Boolean = runCatching {
        val temp = File(context.filesDir, "academy_logo_${UUID.randomUUID()}.tmp")
        try {
            val input = context.contentResolver.openInputStream(source) ?: run {
                temp.delete()
                return false
            }
            input.use { ins ->
                temp.outputStream().use { out ->
                    val buffer = ByteArray(16 * 1024)
                    var total = 0L
                    while (true) {
                        val count = ins.read(buffer)
                        if (count < 0) break
                        total += count
                        require(total <= MAX_LOGO_BYTES) { "حجم صورة الشعار أكبر من 8 ميجابايت" }
                        out.write(buffer, 0, count)
                    }
                    out.flush()
                }
            }
            persistLogoFile(context, temp)
        } catch (e: Throwable) {
            temp.delete()
            throw e
        }
    }.getOrDefault(false)

    private fun persistLogoFile(context: Context, preparedFile: File): Boolean {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(preparedFile.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0 || preparedFile.length() !in 1..MAX_LOGO_BYTES.toLong()) {
            preparedFile.delete()
            return false
        }
        val target = File(context.filesDir, "academy_logo_${UUID.randomUUID()}.img")
        if (!preparedFile.renameTo(target)) {
            preparedFile.copyTo(target, overwrite = false)
            preparedFile.delete()
        }
        val prefs = preferences(context)
        val oldPath = prefs.getString("logo_path", null)
        prefs.edit().putString("logo_path", target.absolutePath).apply()
        mutableLogoPath.value = target.absolutePath
        if (!oldPath.isNullOrBlank() && oldPath != target.absolutePath) runCatching { File(oldPath).delete() }
        return true
    }

    fun removeLogo(context: Context) {
        val prefs = preferences(context)
        prefs.getString("logo_path", null)?.let { runCatching { File(it).delete() } }
        prefs.edit().remove("logo_path").apply()
        mutableLogoPath.value = ""
    }

    /** Restores academy details and, when present, its logo. A legacy backup without the field preserves the current logo. */
    fun restoreFromBackup(context: Context, profile: org.json.JSONObject?): BackupRestoreResult {
        if (profile == null) return BackupRestoreResult(logoFieldPresent = false)

        val restoredName = profile.optString("name", "").trim()
        val restoredAddress = profile.optString("address", "").trim()
        val restoredPhone = profile.optString("phone", "").trim()
        if (isComplete(restoredName, restoredAddress, restoredPhone)) {
            save(context, restoredName, restoredAddress, restoredPhone)
        }

        if (!profile.has(BACKUP_LOGO_FIELD)) {
            refresh(context)
            return BackupRestoreResult(logoFieldPresent = false)
        }

        val encoded = profile.optString(BACKUP_LOGO_FIELD, "")
        if (encoded.isBlank()) {
            removeLogo(context)
            refresh(context)
            return BackupRestoreResult(logoFieldPresent = true, logoRemoved = true)
        }

        val restored = runCatching {
            val bytes = Base64.getDecoder().decode(encoded)
            require(bytes.isNotEmpty() && bytes.size <= MAX_LOGO_BYTES) { "بيانات شعار الأكاديمية غير صالحة" }
            val temp = File(context.filesDir, "academy_logo_${UUID.randomUUID()}.tmp")
            temp.writeBytes(bytes)
            val saved = persistLogoFile(context, temp)
            if (!saved) temp.delete()
            saved
        }.getOrDefault(false)
        refresh(context)
        return BackupRestoreResult(logoFieldPresent = true, logoRestored = restored, logoFailed = !restored)
    }

    /** Small, bounded bitmap for vector-like use in Android PDF output. Caller owns and recycles it. */
    fun loadLogoBitmap(context: Context, maxDimension: Int = 512): Bitmap? {
        refresh(context)
        val path = mutableLogoPath.value
        if (path.isBlank()) return null
        return runCatching {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            val limit = maxDimension.coerceAtLeast(64)
            while (maxOf(bounds.outWidth / sample, bounds.outHeight / sample) > limit) sample *= 2
            BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
        }.getOrNull()
    }

    /** Inline PNG data URI for offline HTML reports rendered by WebView. */
    fun logoDataUri(context: Context): String? {
        val bitmap = loadLogoBitmap(context, 384) ?: return null
        return try {
            val bytes = ByteArrayOutputStream().use { output ->
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) return null
                output.toByteArray()
            }
            "data:image/png;base64," + Base64.getEncoder().encodeToString(bytes)
        } finally {
            bitmap.recycle()
        }
    }

    /** Save once and publish all fields only when the full academy profile is valid. */
    fun save(context: Context, name: String, address: String, phone: String): String {
        val normalizedName = name.trim()
        val normalizedAddress = address.trim()
        val normalizedPhone = phone.trim()
        val complete = isComplete(normalizedName, normalizedAddress, normalizedPhone)
        preferences(context).edit()
            .putString("name", normalizedName)
            .putString("address", normalizedAddress)
            .putString("phone", normalizedPhone)
            .putBoolean("setup_completed", complete)
            .apply()
        mutableName.value = if (complete) normalizedName else ""
        mutableAddress.value = if (complete) normalizedAddress else ""
        mutablePhone.value = if (complete) normalizedPhone else ""
        return mutableName.value
    }
}
