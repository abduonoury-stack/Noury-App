package com.tahseel.students.ui

import android.content.ActivityNotFoundException
import android.graphics.BitmapFactory
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Message
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.data.*
import com.tahseel.students.util.AcademyProfileStore
import com.tahseel.students.util.Money
import java.net.URLEncoder
import java.time.Instant
import java.time.LocalDate
import java.time.Period
import java.time.ZoneId

@Composable
fun StudentProfileScreen(
    studentId: Long,
    students: StudentDao,
    payments: PaymentDao,
    finance: FinanceDao,
    fees: FeeDao,
    attendance: AttendanceDao,
    onBack: () -> Unit,
    onFinance: () -> Unit
) {
    val student by students.observeById(studentId).collectAsStateWithLifecycle(initialValue = null)
    val child = student
    val paymentRows by remember(child?.id, child?.fullName) {
        if (child == null) kotlinx.coroutines.flow.flowOf(emptyList<Payment>()) else payments.observeForStudent(child.id, child.fullName)
    }.collectAsStateWithLifecycle(initialValue = emptyList())
    val subscriptionRows by finance.observeSubscriptionHistory(studentId).collectAsStateWithLifecycle(initialValue = emptyList())
    val feeRows by fees.observeStudentFees(studentId).collectAsStateWithLifecycle(initialValue = emptyList())
    val attendanceRows by attendance.observeStudentHistory(studentId).collectAsStateWithLifecycle(initialValue = emptyList())
    val context = LocalContext.current
    AppScaffold("ملف الطالب", onBack) { pad ->
        if (child == null) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) { CircularProgressIndicator() }
        } else {
            val zone = ZoneId.systemDefault()
            val birth = child.birthDate?.let { Instant.ofEpochMilli(it).atZone(zone).toLocalDate() }
            val age = birth?.let { Period.between(it, LocalDate.now()) }
            val enrollment = Instant.ofEpochMilli(child.enrollmentDate).atZone(zone).toLocalDate()
            val photoBitmap by produceState<android.graphics.Bitmap?>(initialValue = null, child.photoUri) {
                value = withContext(Dispatchers.IO) {
                    runCatching {
                        child.photoUri?.takeIf { it.isNotBlank() }?.let { saved ->
                            com.tahseel.students.util.PhotoDecoder.decode(context, Uri.parse(saved), 1024)
                        }
                    }.getOrNull()
                }
            }
            // البيانات المالية لا تظهر إلا لمدير النظام والمدير المالي.
            val canSeeFinance = SessionContext.role.let { it == UserRoles.ADMIN || it == UserRoles.FINANCE_MANAGER }
            val validPayments = paymentRows.filter { !it.isCancelled }
            val paidTotal = validPayments.sumOf { it.amountPiasters }
            val present = attendanceRows.count { it.status == "present" }
            val absent = attendanceRows.count { it.status != "present" }
            LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            StudentAvatar(child.photoUri, 104.dp, child.id, child.gender)
                            Text(child.fullName, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
                            Text("${if (child.status == "active") "منتظم" else "منقطع"} • ${child.className.ifBlank { "غير موزع على فصل" }}", style = MaterialTheme.typography.bodyMedium)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                Button(onClick = { launchMotherWhatsApp(context, child) }, enabled = child.motherWhatsapp.isNotBlank(), modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Default.Message, null); Spacer(Modifier.width(5.dp)); Text("واتساب الأعمال")
                                }
                                OutlinedButton(onClick = { launchMotherCall(context, child) }, enabled = child.motherWhatsapp.isNotBlank(), modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Default.Call, null); Spacer(Modifier.width(5.dp)); Text("اتصال")
                                }
                            }
                            if (child.motherWhatsapp.isBlank()) Text("رقم الأم غير مسجل؛ أضفه من تعديل بيانات الطالب لتفعيل التواصل.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                            if (canSeeFinance) OutlinedButton(onClick = onFinance, modifier = Modifier.fillMaxWidth()) { Text("فتح الحساب المالي التفصيلي") }
                        }
                    }
                }
                item { ProfileSection("البيانات الأساسية") {
                    ProfileValue("اسم الطالب", child.fullName)
                    ProfileValue("تاريخ الميلاد", birth?.toString() ?: "غير مسجل")
                    ProfileValue("العمر الحالي", age?.let { "${it.years} سنة و${it.months} شهر" } ?: "غير مسجل")
                    ProfileValue("تاريخ الالتحاق", enrollment.toString())
                    ProfileValue("الفترة", if (child.attendanceEndHour == 15) "صباحية 8 ص – 1 م" else "مسائية 10 ص – 3 م")
                    ProfileValue("الصورة الشخصية", if (child.photoUri.isNullOrBlank()) "لا توجد صورة مسجلة" else "الصورة معروضة أعلى الملف إن أمكن تحميلها")
                } }
                item { ProfileSection("بيانات الأسرة والتواصل") {
                    ProfileValue("اسم الأم", child.motherName)
                    ProfileValue("رقم الأم (واتساب واتصال)", child.motherWhatsapp)
                    ProfileValue("اسم الأب", child.fatherName)
                    ProfileValue("هاتف الأب", child.fatherPhone)
                    ProfileValue("العنوان", child.address)
                    ProfileValue("ملاحظات", child.notes)
                } }
                if (canSeeFinance) item { ProfileSection("ملخص مالي مسجل") {
                    ProfileValue("إجمالي الدفعات غير الملغاة", Money.format(paidTotal))
                    ProfileValue("عدد التحصيلات النقدية", validPayments.count { it.amountPiasters > 0L }.toString())
                    ProfileValue("سجلات الاشتراك", subscriptionRows.size.toString())
                    ProfileValue("بنود المستحقات المسجلة", feeRows.size.toString())
                    ProfileValue("إجمالي المستحقات المسجلة", Money.format(feeRows.sumOf { it.amountPiasters - it.discountPiasters }))
                } }
                item { ProfileSection("ملخص الحضور والغياب") {
                    ProfileValue("أيام الحضور المسجلة", present.toString())
                    ProfileValue("أيام الغياب المسجلة", absent.toString())
                    ProfileValue("إجمالي الأيام المسجلة", attendanceRows.size.toString())
                } }
                if (canSeeFinance) {
                item { Text("سجل الاشتراكات الشهرية", style = MaterialTheme.typography.titleMedium) }
                if (subscriptionRows.isEmpty()) item { Text("لا توجد اشتراكات شهرية مسجلة", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                items(subscriptionRows, key = { "subscription-${it.id}" }) { subscription ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("اشتراك شهر ${subscription.periodKey}", style = MaterialTheme.typography.titleSmall)
                            Text("قيمة الاشتراك الأصلية: ${Money.format(subscription.dueAmountPiasters + subscription.discountPiasters)}")
                            Text("الخصم: ${Money.format(subscription.discountPiasters)}")
                            Text("صافي المستحق: ${Money.format(subscription.dueAmountPiasters)}")
                            if (subscription.dueAmountPiasters == 0L && subscription.discountPiasters > 0L) {
                                Text("تمت التسوية بالإعفاء الكامل", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleSmall)
                            } else {
                                Text("المحصل: ${Money.format(subscription.paidAmountPiasters)}")
                            }
                            if (subscription.discountNote.isNotBlank()) Text("سبب الخصم: ${subscription.discountNote}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                item { Text("آخر عمليات التحصيل النقدي", style = MaterialTheme.typography.titleMedium) }
                val cashPayments = validPayments.filter { it.amountPiasters > 0L }
                if (cashPayments.isEmpty()) item { Text("لا توجد تحصيلات نقدية مسجلة لهذا الطالب", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                items(cashPayments.take(30), key = { "payment-${it.id}" }) { payment ->
                    Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) { Text("إيصال ${payment.receiptNo}"); Text(Instant.ofEpochMilli(payment.createdAt).atZone(zone).toLocalDate().toString(), style = MaterialTheme.typography.bodySmall) }
                        Text(Money.format(payment.amountPiasters), style = MaterialTheme.typography.titleMedium)
                    } }
                }
                }
                item { Text("آخر سجلات الحضور", style = MaterialTheme.typography.titleMedium) }
                if (attendanceRows.isEmpty()) item { Text("لا يوجد سجل حضور مسجل", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                items(attendanceRows.take(30), key = { "attendance-${it.id}" }) { row ->
                    Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column { Text(row.attendanceDate); Text(row.className, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        Text(if (row.status == "present") "حاضر" else "غائب", color = if (row.status == "present") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                    } }
                }
            }
        }
    }
}

@Composable private fun ProfileSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) { Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary); HorizontalDivider(); content() } }
}
@Composable private fun ProfileValue(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) { Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(value.ifBlank { "غير مسجل" }, style = MaterialTheme.typography.bodyMedium) }
}

private fun normalizeMotherNumber(raw: String): String {
    val digits = raw.filter(Char::isDigit)
    return when { raw.trim().startsWith("+") -> digits; digits.startsWith("00") -> digits.drop(2); digits.startsWith("0") -> "20${digits.drop(1)}"; digits.startsWith("20") -> digits; else -> digits }
}
private fun launchMotherWhatsApp(context: android.content.Context, student: Student) {
    val phone = normalizeMotherNumber(student.motherWhatsapp)
    if (phone.length < 10) { Toast.makeText(context, "رقم الأم غير صحيح", Toast.LENGTH_LONG).show(); return }
    val message = "أهلًا بحضرتك 🌷\nبخصوص الطالب/ة ${student.fullName}، نتواصل مع حضرتك من ${AcademyProfileStore.getName(context)}."
    val uri = Uri.parse("https://wa.me/$phone?text=${URLEncoder.encode(message, "UTF-8")}")
    for (pkg in listOf("com.whatsapp.w4b", "com.whatsapp")) try { context.startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg)); return } catch (_: ActivityNotFoundException) { }
    try { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: ActivityNotFoundException) { Toast.makeText(context, "واتساب غير مثبت على الجهاز", Toast.LENGTH_LONG).show() }
}
private fun launchMotherCall(context: android.content.Context, student: Student) {
    val phone = normalizeMotherNumber(student.motherWhatsapp)
    if (phone.length < 10) { Toast.makeText(context, "رقم الأم غير صحيح", Toast.LENGTH_LONG).show(); return }
    try { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))) } catch (_: ActivityNotFoundException) { Toast.makeText(context, "تعذر فتح تطبيق الاتصال", Toast.LENGTH_LONG).show() }
}
