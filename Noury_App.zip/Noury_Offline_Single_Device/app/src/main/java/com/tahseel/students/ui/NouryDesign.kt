package com.tahseel.students.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import android.graphics.BitmapFactory
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.dp

/**
 * NOURY Design System (2.3.0) — طبقة العرض فقط. لا تلمس البيانات أو الصلاحيات.
 * الألوان والخطوط والأشكال الأساسية تأتي من Theme.kt (LdaPalette + MaterialTheme).
 */

/** علامة NOURY هندسية مستوحاة من تكرارات الأشكال النوبية؛ علامة المنتج وليست شعار الأكاديمية. */
@Composable
fun NouryBrandMark(modifier: Modifier = Modifier, size: Dp = 48.dp) {
    Surface(
        modifier = modifier.size(size),
        shape = RoundedCornerShape(17.dp),
        color = LdaPalette.RoyalDeep,
        border = BorderStroke(1.dp, LdaPalette.Gold.copy(alpha = 0.72f)),
        tonalElevation = 0.dp
    ) {
        Canvas(Modifier.fillMaxSize().padding(size * 0.20f)) {
            val cx = this.size.width / 2f
            val cy = this.size.height / 2f
            val r = this.size.minDimension * 0.34f
            val gold = LdaPalette.Gold
            val peach = LdaPalette.Peach
            val diamond = Path().apply {
                moveTo(cx, cy - r)
                lineTo(cx + r * 0.72f, cy)
                lineTo(cx, cy + r)
                lineTo(cx - r * 0.72f, cy)
                close()
            }
            drawPath(diamond, gold)
            drawCircle(LdaPalette.RoyalDeep, radius = r * 0.48f, center = Offset(cx, cy))
            drawLine(peach, Offset(cx, cy - r * 0.70f), Offset(cx, cy - r * 1.42f), strokeWidth = 2.2.dp.toPx())
            drawLine(peach, Offset(cx, cy + r * 0.70f), Offset(cx, cy + r * 1.42f), strokeWidth = 2.2.dp.toPx())
            drawLine(peach, Offset(cx - r * 0.70f, cy), Offset(cx - r * 1.42f, cy), strokeWidth = 2.2.dp.toPx())
            drawLine(peach, Offset(cx + r * 0.70f, cy), Offset(cx + r * 1.42f, cy), strokeWidth = 2.2.dp.toPx())
        }
    }
}

/** شعار الأكاديمية المسجل؛ يعرض علامة NOURY فقط عند عدم وجود شعار مخصص. */
@Composable
fun AcademyLogo(path: String, modifier: Modifier = Modifier, size: Dp = 54.dp) {
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, path) {
        value = if (path.isBlank()) null else withContext(Dispatchers.IO) { runCatching {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) null else {
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= 256 && bounds.outHeight / (sample * 2) >= 256) sample *= 2
                BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
            }
        }.getOrNull() }
    }
    if (bitmap != null) {
        Surface(modifier = modifier.size(size), shape = RoundedCornerShape(16.dp), color = Color.White, border = BorderStroke(1.dp, LdaPalette.Border)) {
            Image(bitmap!!.asImageBitmap(), contentDescription = "شعار الأكاديمية", modifier = Modifier.fillMaxSize().padding(4.dp), contentScale = ContentScale.Fit)
        }
    } else {
        NouryBrandMark(modifier = modifier, size = size)
    }
}

object NourySpacing {
    val xs: Dp = 4.dp
    val sm: Dp = 8.dp
    val md: Dp = 12.dp
    val lg: Dp = 16.dp
    val xl: Dp = 24.dp
    val screenPadding: Dp = 16.dp
}

object NouryRadius {
    val chip: Dp = 12.dp
    val field: Dp = 16.dp
    val button: Dp = 20.dp
    val card: Dp = 24.dp
    val sheet: Dp = 28.dp
}

/** نغمة الحالة لشارات الحالة. */
enum class NouryTone { Success, Warning, Danger, Info, Neutral }

@Composable
fun NouryStatusBadge(text: String, tone: NouryTone = NouryTone.Neutral, modifier: Modifier = Modifier) {
    val (bg, fg) = when (tone) {
        NouryTone.Success -> LdaPalette.SuccessContainer to LdaPalette.Success
        NouryTone.Warning -> LdaPalette.WarningContainer to LdaPalette.Warning
        NouryTone.Danger -> LdaPalette.ErrorContainer to LdaPalette.Error
        NouryTone.Info -> LdaPalette.BlueContainer to LdaPalette.RoyalDeep
        NouryTone.Neutral -> LdaPalette.SurfaceSoft to LdaPalette.MutedText
    }
    Surface(modifier = modifier, shape = RoundedCornerShape(NouryRadius.chip), color = bg) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = fg,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/** بطاقة مؤشر رقمي موحدة: أيقونة ملونة + رقم كبير + عنوان. */
@Composable
fun NouryMetricCard(
    title: String,
    value: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    accent: Color = LdaPalette.Blue,
    container: Color = LdaPalette.BlueContainer,
    subtitle: String? = null
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(NouryRadius.card),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().heightIn(min = 118.dp).padding(NouryCardInnerPadding),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            DuotoneIcon(icon, tint = accent, containerColor = container, tileSize = 40.dp, iconSize = 22.dp)
            Text(
                value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = LdaPalette.RoyalDeep,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = accent, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

private val NouryCardInnerPadding = 14.dp

@Composable
fun NouryEmptyState(
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    icon: ImageVector = Icons.Default.Inbox,
    actionText: String? = null,
    onAction: (() -> Unit)? = null
) {
    Column(
        modifier.fillMaxWidth().padding(NourySpacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(NourySpacing.md)
    ) {
        DuotoneIcon(icon, tint = LdaPalette.Teal, containerColor = LdaPalette.TealContainer, tileSize = 72.dp, iconSize = 36.dp)
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = LdaPalette.RoyalDeep, textAlign = TextAlign.Center)
        Text(message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        if (actionText != null && onAction != null) {
            Button(onClick = onAction, shape = RoundedCornerShape(NouryRadius.button), modifier = Modifier.heightIn(min = 52.dp)) { Text(actionText) }
        }
    }
}

@Composable
fun NouryLoadingState(message: String = "جارٍ التحميل…", modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth().padding(NourySpacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(NourySpacing.md)
    ) {
        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
        Text(message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun NouryErrorState(message: String, modifier: Modifier = Modifier, onRetry: (() -> Unit)? = null) {
    Column(
        modifier.fillMaxWidth().padding(NourySpacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(NourySpacing.md)
    ) {
        DuotoneIcon(Icons.Default.ErrorOutline, tint = LdaPalette.Error, containerColor = LdaPalette.ErrorContainer, tileSize = 72.dp, iconSize = 36.dp)
        Text(message, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface, textAlign = TextAlign.Center)
        if (onRetry != null) {
            FilledTonalButton(onClick = onRetry, shape = RoundedCornerShape(NouryRadius.button), modifier = Modifier.heightIn(min = 52.dp)) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("إعادة المحاولة")
            }
        }
    }
}

/** عنوان قسم موحد مع أيقونة وعنوان فرعي. */
@Composable
fun NourySectionHeader(title: String, subtitle: String? = null, icon: ImageVector? = null, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) {
            DuotoneIcon(icon, tint = LdaPalette.Royal, containerColor = LdaPalette.Lilac, tileSize = 39.dp, iconSize = 21.dp)
            Spacer(Modifier.width(10.dp))
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = LdaPalette.RoyalDeep)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** حقل نص موحد. */
@Composable
fun NouryTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
    enabled: Boolean = true,
    isError: Boolean = false,
    supportingText: String? = null
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth(),
        label = { Text(label) },
        singleLine = singleLine,
        enabled = enabled,
        isError = isError,
        supportingText = supportingText?.let { { Text(it) } },
        shape = RoundedCornerShape(NouryRadius.field)
    )
}

/** حوار تأكيد موحد للعمليات الحساسة. */
@Composable
fun NouryConfirmDialog(
    title: String,
    message: String,
    confirmText: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    dismissText: String = "إلغاء",
    destructive: Boolean = false
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(NouryRadius.sheet),
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(title, fontWeight = FontWeight.Bold, color = LdaPalette.RoyalDeep) },
        text = { Text(message, style = MaterialTheme.typography.bodyMedium) },
        confirmButton = {
            Button(
                onClick = onConfirm,
                shape = RoundedCornerShape(NouryRadius.button),
                colors = if (destructive) ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error) else ButtonDefaults.buttonColors()
            ) { Text(confirmText) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(dismissText) } }
    )
}

/** ورقة سفلية موحدة. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NourySheet(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(topStart = NouryRadius.sheet, topEnd = NouryRadius.sheet),
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = NourySpacing.lg).padding(bottom = NourySpacing.xl), verticalArrangement = Arrangement.spacedBy(NourySpacing.md), content = content)
    }
}
