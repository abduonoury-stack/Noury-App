package com.tahseel.students.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Transaction
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/** Independent cash, bank and electronic-wallet balances. Legacy movements remain unassigned. */
@Entity(tableName = "cash_accounts")
data class CashAccount(
    @PrimaryKey val id: String,
    val name: String,
    /** cash, bank, wallet, electronic */
    val type: String,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)


@Entity(
    tableName = "cash_account_ledger_mappings",
    foreignKeys = [
        androidx.room.ForeignKey(entity = CashAccount::class, parentColumns = ["id"], childColumns = ["cashAccountId"], onDelete = androidx.room.ForeignKey.RESTRICT),
        androidx.room.ForeignKey(entity = AccountingAccount::class, parentColumns = ["id"], childColumns = ["ledgerAccountId"], onDelete = androidx.room.ForeignKey.RESTRICT)
    ],
    indices = [androidx.room.Index(value = ["cashAccountId"], unique = true), androidx.room.Index(value = ["ledgerAccountId"], unique = true)]
)
data class CashAccountLedgerMapping(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cashAccountId: String,
    val ledgerAccountId: Long,
    val effectiveFrom: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val note: String = ""
)

data class CashAccountStatementRow(
    val journalLineId: Long,
    val entryId: Long,
    val entryDate: Long,
    val entryNo: String,
    val description: String,
    val debitPiasters: Long,
    val creditPiasters: Long,
    val memo: String,
    val sourceType: String,
    val sourceId: String
)

@Dao
interface CashAccountDao {
    @Query("SELECT * FROM cash_accounts ORDER BY CASE WHEN id='cash' THEN 0 ELSE 1 END, name COLLATE NOCASE")
    fun observeAll(): Flow<List<CashAccount>>

    @Query("SELECT * FROM cash_accounts WHERE isActive=1 ORDER BY CASE WHEN id='cash' THEN 0 ELSE 1 END, name COLLATE NOCASE")
    fun observeActive(): Flow<List<CashAccount>>

    @Query("SELECT * FROM cash_accounts WHERE id=:id LIMIT 1")
    suspend fun find(id: String): CashAccount?

    @Query("SELECT * FROM cash_accounts ORDER BY id")
    suspend fun snapshotAll(): List<CashAccount>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertRaw(account: CashAccount)

    @Transaction
    suspend fun insert(account: CashAccount) {
        insertRaw(account)
        val parentCode = if (account.type == "cash") "1100" else "1110"
        val suffix = account.id.hashCode().toUInt().toString(16).uppercase().take(8)
        val childCode = "$parentCode-$suffix"
        val parentId = ledgerAccountIdByCode(parentCode) ?: error("حساب الأستاذ التجميعي $parentCode غير موجود")
        createLedgerSubaccount(childCode, account.name, parentId, account.createdAt)
        val childId = ledgerAccountIdByCode(childCode) ?: error("تعذر إنشاء حساب الأستاذ الفرعي")
        insertLedgerMapping(CashAccountLedgerMapping(cashAccountId = account.id, ledgerAccountId = childId, effectiveFrom = account.createdAt, note = "ربط تلقائي لحساب مالي جديد"))
    }

    @Query("SELECT * FROM cash_account_ledger_mappings WHERE cashAccountId=:cashAccountId LIMIT 1")
    suspend fun ledgerMapping(cashAccountId: String): CashAccountLedgerMapping?

    @Query("SELECT * FROM cash_account_ledger_mappings ORDER BY cashAccountId")
    fun observeLedgerMappings(): Flow<List<CashAccountLedgerMapping>>

    @Query("SELECT a.* FROM accounting_accounts a INNER JOIN cash_account_ledger_mappings m ON m.ledgerAccountId=a.id WHERE m.cashAccountId=:cashAccountId LIMIT 1")
    suspend fun mappedLedgerAccount(cashAccountId: String): AccountingAccount?

    @Query("SELECT l.id AS journalLineId, e.id AS entryId, e.entryDate AS entryDate, e.entryNo AS entryNo, e.description AS description, l.debitPiasters AS debitPiasters, l.creditPiasters AS creditPiasters, l.memo AS memo, e.sourceType AS sourceType, e.sourceId AS sourceId FROM cash_account_ledger_mappings m INNER JOIN journal_lines l ON l.accountId=m.ledgerAccountId INNER JOIN journal_entries e ON e.id=l.entryId WHERE m.cashAccountId=:cashAccountId AND e.status IN ('posted','reversed') AND e.entryDate BETWEEN :fromDate AND :toDate ORDER BY e.entryDate,e.id,l.id")
    fun observeStatement(cashAccountId: String, fromDate: Long, toDate: Long): Flow<List<CashAccountStatementRow>>

    @Query("SELECT id FROM accounting_accounts WHERE code=:code LIMIT 1")
    suspend fun ledgerAccountIdByCode(code: String): Long?

    @Query("SELECT * FROM cash_account_ledger_mappings WHERE ledgerAccountId=:ledgerAccountId LIMIT 1")
    suspend fun mappingByLedgerAccount(ledgerAccountId: Long): CashAccountLedgerMapping?

    @Query("SELECT COUNT(*) FROM cash_accounts c LEFT JOIN cash_account_ledger_mappings m ON m.cashAccountId=c.id WHERE c.isActive=1 AND m.id IS NULL")
    suspend fun activeAccountsWithoutMapping(): Int

    @Transaction
    suspend fun insertWithLedgerMapping(account: CashAccount) = insert(account)

    @Query("INSERT OR IGNORE INTO accounting_accounts(code,name,type,parentId,isPosting,isActive,createdAt) VALUES(:code,:name,'asset',:parentId,1,1,:createdAt)")
    suspend fun createLedgerSubaccount(code: String, name: String, parentId: Long, createdAt: Long)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertLedgerMapping(mapping: CashAccountLedgerMapping)

    @Query("UPDATE cash_accounts SET isActive=:active WHERE id=:id AND id!='cash'")
    suspend fun setActive(id: String, active: Boolean): Int
}

@Entity(
    tableName = "cash_transfers",
    foreignKeys = [
        androidx.room.ForeignKey(entity = CashAccount::class, parentColumns = ["id"], childColumns = ["fromAccountId"], onDelete = androidx.room.ForeignKey.RESTRICT),
        androidx.room.ForeignKey(entity = CashAccount::class, parentColumns = ["id"], childColumns = ["toAccountId"], onDelete = androidx.room.ForeignKey.RESTRICT)
    ],
    indices = [androidx.room.Index("transferredAt"), androidx.room.Index("fromAccountId"), androidx.room.Index("toAccountId")]
)
data class CashTransfer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fromAccountId: String,
    val toAccountId: String,
    val amountPiasters: Long,
    val transferredAt: Long,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface CashTransferDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(transfer: CashTransfer): Long

    @Query("SELECT isActive FROM cash_accounts WHERE id=:id LIMIT 1")
    suspend fun accountIsActive(id: String): Boolean?

    @Transaction
    suspend fun record(transfer: CashTransfer): Long {
        require(transfer.amountPiasters > 0L) { "قيمة التحويل يجب أن تكون أكبر من صفر" }
        require(transfer.fromAccountId != transfer.toAccountId) { "لا يمكن التحويل إلى الحساب نفسه" }
        require(accountIsActive(transfer.fromAccountId) == true) { "حساب التحويل المصدر غير موجود أو غير نشط" }
        require(accountIsActive(transfer.toAccountId) == true) { "حساب التحويل المستقبِل غير موجود أو غير نشط" }
        return insert(transfer)
    }

    @Query("SELECT * FROM cash_transfers ORDER BY transferredAt DESC, id DESC")
    fun observeAll(): Flow<List<CashTransfer>>
}
