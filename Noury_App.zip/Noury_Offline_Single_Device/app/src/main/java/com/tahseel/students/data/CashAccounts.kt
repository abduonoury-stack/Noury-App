package com.tahseel.students.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Transaction
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/** Independent cash, bank and electronic-wallet balances. Legacy movements remain unassigned. */
@Entity(tableName = "cash_accounts")
data class CashAccount(
    @PrimaryKey val id: String,
    val name: String,
    /** cash, bank, wallet, electronic */
    val type: String,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface CashAccountDao {
    @Query("SELECT * FROM cash_accounts ORDER BY CASE WHEN id='cash' THEN 0 ELSE 1 END, name COLLATE NOCASE")
    fun observeAll(): Flow<List<CashAccount>>

    @Query("SELECT * FROM cash_accounts WHERE isActive=1 ORDER BY CASE WHEN id='cash' THEN 0 ELSE 1 END, name COLLATE NOCASE")
    fun observeActive(): Flow<List<CashAccount>>

    @Query("SELECT * FROM cash_accounts WHERE id=:id LIMIT 1")
    suspend fun find(id: String): CashAccount?

    @Query("SELECT * FROM cash_accounts ORDER BY id")
    suspend fun snapshotAll(): List<CashAccount>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(account: CashAccount)

    @Query("UPDATE cash_accounts SET isActive=:active WHERE id=:id AND id!='cash'")
    suspend fun setActive(id: String, active: Boolean): Int
}

@Entity(
    tableName = "cash_transfers",
    foreignKeys = [
        androidx.room.ForeignKey(entity = CashAccount::class, parentColumns = ["id"], childColumns = ["fromAccountId"], onDelete = androidx.room.ForeignKey.RESTRICT),
        androidx.room.ForeignKey(entity = CashAccount::class, parentColumns = ["id"], childColumns = ["toAccountId"], onDelete = androidx.room.ForeignKey.RESTRICT)
    ],
    indices = [androidx.room.Index("transferredAt"), androidx.room.Index("fromAccountId"), androidx.room.Index("toAccountId")]
)
data class CashTransfer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fromAccountId: String,
    val toAccountId: String,
    val amountPiasters: Long,
    val transferredAt: Long,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface CashTransferDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(transfer: CashTransfer): Long

    @Query("SELECT isActive FROM cash_accounts WHERE id=:id LIMIT 1")
    suspend fun accountIsActive(id: String): Boolean?

    @Transaction
    suspend fun record(transfer: CashTransfer): Long {
        require(transfer.amountPiasters > 0L) { "قيمة التحويل يجب أن تكون أكبر من صفر" }
        require(transfer.fromAccountId != transfer.toAccountId) { "لا يمكن التحويل إلى الحساب نفسه" }
        require(accountIsActive(transfer.fromAccountId) == true) { "حساب التحويل المصدر غير موجود أو غير نشط" }
        require(accountIsActive(transfer.toAccountId) == true) { "حساب التحويل المستقبِل غير موجود أو غير نشط" }
        return insert(transfer)
    }

    @Query("SELECT * FROM cash_transfers ORDER BY transferredAt DESC, id DESC")
    fun observeAll(): Flow<List<CashTransfer>>
}
