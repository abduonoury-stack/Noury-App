package com.tahseel.students.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import com.tahseel.students.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.DayOfWeek
import com.tahseel.students.util.WorkdaySettings

class HrViewModel(private val dao: HrDao, private val expenseDao: ExpenseDao, private val db: AppDatabase) : ViewModel() {
    val cashAccounts = db.cashAccountDao().observeActive().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private val _workdays = MutableStateFlow(WorkdaySettings.defaultDays)
    val workdays = _workdays.asStateFlow()

    val employees = dao.observeEmployees().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val selectedDate = MutableStateFlow(LocalDate.now())
    init { refreshWorkdays() }
    fun refreshWorkdays() { viewModelScope.launch { _workdays.value = WorkdaySettings.load(db.financeDao()); selectedDate.value = WorkdaySettings.nearestWorkdayInMonth(selectedDate.value, _workdays.value) } }
    val attendance = selectedDate.flatMapLatest { date -> dao.observeAttendance(date.toString()) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val leaves = dao.observeLeaves().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val loans = dao.observeLoans().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val month = MutableStateFlow(YearMonth.now())
    val monthlyAttendance = month.flatMapLatest { m -> dao.observeAttendanceRange(m.atDay(1).toString(), m.atEndOfMonth().toString()) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val payroll = month.flatMapLatest { dao.observePayroll(it.toString()) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val payrollPayments = month.flatMapLatest { dao.observePayrollPayments(it.toString()) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val payrollReversals = dao.observeAllPayrollReversals().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val payrollRecoveries = dao.observeAllPayrollRecoveries().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private val _payrollMessage = MutableStateFlow("")
    val payrollMessage = _payrollMessage.asStateFlow()
    val adjustments = month.flatMapLatest { dao.observeAdjustments(it.toString()) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val absenceCount = month.flatMapLatest { m -> dao.observeAbsenceCount(m.atDay(1).toString(), m.atEndOfMonth().toString()) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun changeMonth(next: YearMonth) {
        month.value = next
        val today = LocalDate.now()
        val preferredDay = if (next == YearMonth.from(selectedDate.value)) selectedDate.value.dayOfMonth else if (next == YearMonth.from(today)) today.dayOfMonth else 1
        val candidate = next.atDay(preferredDay.coerceAtMost(next.lengthOfMonth()))
        selectedDate.value = WorkdaySettings.nearestWorkdayInMonth(candidate, workdays.value)
    }
    fun selectDate(date: LocalDate) { if (WorkdaySettings.isWorkday(date, workdays.value)) selectedDate.value = date }
    fun saveEmployee(old: Employee?, name: String, role: String, phone: String, whatsapp: String, address: String, nationalId: String, birth: String, hire: String, contract: String, end: String, department: String, start: String, finish: String, days: String, salary: Long, emergency: String, emergencyPhone: String, notes: String) = viewModelScope.launch {
        val now = System.currentTimeMillis()
        val item = Employee(id = old?.id ?: 0, employeeCode = old?.employeeCode ?: "NRY-${(employees.value.size + 1).toString().padStart(4, '0')}", fullName = name.trim(), jobTitle = role, phone = phone.trim(), whatsapp = whatsapp.trim(), address = address.trim(), nationalId = nationalId.trim(), birthDate = birth.trim(), hireDate = hire.trim(), contractType = contract, contractEndDate = end.trim(), department = department.trim(), workStart = start, workEnd = finish, weeklyDays = WorkdaySettings.serialize(workdays.value), baseSalaryPiasters = salary, emergencyName = emergency.trim(), emergencyPhone = emergencyPhone.trim(), notes = notes.trim(), status = old?.status ?: "active", createdAt = old?.createdAt ?: now, updatedAt = now)
        if (old == null) dao.insertEmployee(item) else dao.updateEmployee(item)
    }
    fun toggleEmployeeStatus(e: Employee) = viewModelScope.launch { dao.updateEmployee(e.copy(status = if (e.status == "active") "inactive" else "active", updatedAt = System.currentTimeMillis())) }
    // أرشفة بدل الحذف النهائي حتى لا تضيع سجلات المرتبات والحضور والسلف المرتبطة بالموظف.
    fun archiveEmployee(e: Employee) = viewModelScope.launch { dao.updateEmployee(e.copy(status = "deleted", updatedAt = System.currentTimeMillis())) }
    fun setAttendance(e: Employee, status: String, date: LocalDate = selectedDate.value) = viewModelScope.launch {
        if (!WorkdaySettings.isWorkday(date, workdays.value)) return@launch
        val dateKey = date.toString()
        val old = dao.attendance(e.id, dateKey)
        dao.saveAttendance(EmployeeAttendance(id = old?.id ?: 0, employeeId = e.id, workDate = dateKey, checkIn = old?.checkIn ?: "", checkOut = old?.checkOut ?: "", status = status, lateMinutes = old?.lateMinutes ?: 0, note = old?.note ?: "", createdAt = old?.createdAt ?: System.currentTimeMillis()))
    }
    fun setAttendanceTimes(e: Employee, checkIn: String, checkOut: String, lateMinutes: Int, date: LocalDate = selectedDate.value) = viewModelScope.launch {
        if (!WorkdaySettings.isWorkday(date, workdays.value)) return@launch
        val dateKey = date.toString()
        val old = dao.attendance(e.id, dateKey)
        dao.saveAttendance(EmployeeAttendance(id = old?.id ?: 0, employeeId = e.id, workDate = dateKey, checkIn = checkIn, checkOut = checkOut, status = old?.status ?: "present", lateMinutes = lateMinutes.coerceAtLeast(0), note = old?.note ?: "", createdAt = old?.createdAt ?: System.currentTimeMillis()))
    }
    fun saveLeave(employeeId: Long, type: String, from: String, until: String, days: Double, reason: String) = viewModelScope.launch { dao.insertLeave(EmployeeLeave(employeeId = employeeId, leaveType = type, startDate = from, endDate = until, days = days, reason = reason)) }
    fun decideLeave(id: Long, approved: Boolean) = viewModelScope.launch { dao.decideLeave(id, if (approved) "approved" else "rejected") }
    fun addLoan(employeeId: Long, amount: Long, installment: Long, monthKey: String, note: String, accountId: String, issuedAt: Long) = viewModelScope.launch {
        _payrollMessage.value = ""
        runCatching { db.withTransaction {
            require(amount > 0L && installment > 0L) { "قيمة السلفة والقسط يجب أن يكونا أكبر من صفر" }
            val employee = dao.employee(employeeId) ?: error("الموظف غير موجود")
            val cash = db.cashAccountDao().find(accountId)?.takeIf { it.isActive } ?: error("حساب صرف السلفة غير نشط")
            val date = if (issuedAt > 0L) issuedAt else System.currentTimeMillis()
            val loanId = dao.insertLoan(EmployeeLoan(employeeId = employeeId, amountPiasters = amount, monthlyInstallmentPiasters = installment, remainingPiasters = amount, startMonth = monthKey, note = note, accountId = accountId, issuedAt = date))
            val accounting = db.accountingDao()
            val period = accountingPeriodFor(date)
            accounting.ensurePeriod(period.first, period.second.first, period.second.second)
            val advance = accounting.accountByCode("1210") ?: error("حساب سلف الموظفين غير موجود")
            val cashAccount = accounting.accountByCode(if (cash.type == "cash") "1100" else "1110") ?: error("حساب الأستاذ المقابل للخزينة غير موجود")
            accounting.postJournal(JournalEntry(entryNo = "LOAN-$loanId", entryDate = date, periodKey = period.first, description = "صرف سلفة للموظف ${employee.fullName}", sourceType = "employee_loan_issue", sourceId = loanId.toString()), listOf(
                JournalLineDraft(advance.id, debitPiasters = amount, memo = "سلفة ${employee.fullName}"),
                JournalLineDraft(cashAccount.id, creditPiasters = amount, memo = "صرف سلفة من ${cash.name}")
            ))
        } }.onFailure { _payrollMessage.value = it.message ?: "تعذر تسجيل السلفة محاسبيًا" }
            .onSuccess { _payrollMessage.value = "تم تسجيل السلفة وربطها محاسبيًا" }
    }
    fun addAdjustment(employeeId: Long, type: String, amount: Long, reason: String) = viewModelScope.launch { if (amount > 0) dao.insertAdjustment(EmployeeAdjustment(employeeId = employeeId, monthKey = month.value.toString(), type = type, amountPiasters = amount, reason = reason)) }

    // كل شيء في معاملة واحدة: الكشف وخصم السلف ومزامنة بند المرتبات؛ أي فشل يُرجع الجميع.
    fun generatePayroll() = viewModelScope.launch {
        _payrollMessage.value = ""
        runCatching { db.withTransaction { generatePayrollInTransaction() } }
            .onFailure { _payrollMessage.value = it.message ?: "تعذر إنشاء كشف المرتبات" }
            .onSuccess { _payrollMessage.value = "تم تحديث كشف المرتبات بنجاح" }
    }
    private suspend fun generatePayrollInTransaction() {
        val m = month.value.toString()
        employees.value.filter { it.status == "active" }.forEach { e ->
            val old = dao.payroll(e.id, m)
            val bonus = dao.bonuses(e.id, m)
            val allowance = dao.allowances(e.id, m)
            val penalty = dao.penalties(e.id, m)
            val absentDays = dao.absenceDates(e.id, m + "-01", YearMonth.parse(m).atEndOfMonth().toString()).count { key -> runCatching { WorkdaySettings.isWorkday(LocalDate.parse(key), workdays.value) }.getOrDefault(false) }
            val absenceDeduction = (e.baseSalaryPiasters * absentDays / 30L).coerceAtMost(e.baseSalaryPiasters)
            val totalDeductions = penalty + absenceDeduction
            // لا نخصم قسط السلفة مرة ثانية عند إعادة حساب كشف الشهر.
            val loanRows = if (old == null) dao.activeLoans(e.id).filter { it.startMonth <= m } else emptyList()
            val availableBeforeLoan = (e.baseSalaryPiasters + allowance + bonus - totalDeductions).coerceAtLeast(0)
            // لا نخصم من السلفة أكثر مما يسمح به صافي المستحق قبل قسط السلفة.
            val requestedLoanDeduction = old?.loanDeductionPiasters ?: loanRows.sumOf { minOf(it.monthlyInstallmentPiasters, it.remainingPiasters) }
            val loanDeduction = minOf(requestedLoanDeduction, availableBeforeLoan)
            val net = (availableBeforeLoan - loanDeduction).coerceAtLeast(0)
            val paid = if (old == null) 0L else dao.payrollPaymentsTotal(old.id)
            check(paid <= net) { "لا يمكن إعادة حساب مرتب ${e.fullName}: إجمالي ما تم صرفه (${paid}) أكبر من صافي المستحق الجديد (${net}). راجع الخصومات أو التسويات قبل إعادة الحساب." }
            dao.savePayroll(EmployeePayroll(id = old?.id ?: 0, employeeId = e.id, monthKey = m, basePiasters = e.baseSalaryPiasters, allowancesPiasters = allowance, bonusesPiasters = bonus, deductionsPiasters = totalDeductions, loanDeductionPiasters = loanDeduction, netPiasters = net, paidPiasters = paid, paidAt = if (paid >= net && net > 0) old?.paidAt ?: System.currentTimeMillis() else null, note = old?.note ?: "", createdAt = old?.createdAt ?: System.currentTimeMillis()))
            if (old == null) {
                var remainingToApply = loanDeduction
                loanRows.forEach { loan ->
                    val cut = minOf(remainingToApply, loan.monthlyInstallmentPiasters, loan.remainingPiasters)
                    if (cut > 0) { dao.updateLoan(loan.copy(remainingPiasters = loan.remainingPiasters - cut, status = if (loan.remainingPiasters - cut <= 0) "closed" else "active")); remainingToApply -= cut }
                }
            }
        }
    }
    fun recordPayrollPayment(row: EmployeePayroll, amount: Long, paymentDate: String, paymentMethod: String, note: String, accountId: String) = viewModelScope.launch {
        _payrollMessage.value = ""
        runCatching { db.withTransaction {
            val current = dao.payroll(row.employeeId, row.monthKey) ?: error("كشف المرتب غير موجود")
            require(runCatching { LocalDate.parse(paymentDate) }.isSuccess) { "تاريخ الصرف غير صحيح" }
            require(amount > 0) { "قيمة الدفعة يجب أن تكون أكبر من صفر" }
            require(db.cashAccountDao().find(accountId)?.isActive == true) { "حساب الصرف غير موجود أو غير نشط" }
            val paidSoFar = dao.payrollPaymentsTotal(current.id)
            val remaining = (current.netPiasters - paidSoFar).coerceAtLeast(0L)
            require(amount <= remaining) { "قيمة الدفعة أكبر من المتبقي (${remaining / 100.0} جنيه)" }
            val accounting = db.accountingDao()
            postPayrollAccrualIfNeeded(current, accounting)
            val paymentId = dao.insertPayrollPayment(EmployeePayrollPayment(
                payrollId = current.id, amountPiasters = amount, paymentDate = paymentDate,
                paymentMethod = paymentMethod, note = note.trim(), accountId = accountId
            ))
            val paidDate = LocalDate.parse(paymentDate).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
            val period = accountingPeriodFor(paidDate)
            accounting.ensurePeriod(period.first, period.second.first, period.second.second)
            val cash = db.cashAccountDao().find(accountId) ?: error("حساب الصرف غير موجود")
            val payable = accounting.accountByCode("2200") ?: error("حساب المرتبات المستحقة غير موجود")
            val cashLedger = accounting.accountByCode(if (cash.type == "cash") "1100" else "1110") ?: error("حساب الأستاذ المقابل للخزينة غير موجود")
            accounting.postJournal(JournalEntry(entryNo = "PAYROLL-PAY-$paymentId", entryDate = paidDate, periodKey = period.first, description = "صرف مرتب ${current.monthKey}", sourceType = "employee_payroll_payment", sourceId = paymentId.toString()), listOf(
                JournalLineDraft(payable.id, debitPiasters = amount, memo = "صرف مرتب الموظف"),
                JournalLineDraft(cashLedger.id, creditPiasters = amount, memo = "صرف من ${cash.name}")
            ))
            val newPaid = paidSoFar + amount
            dao.savePayroll(current.copy(paidPiasters = newPaid, paidAt = if (newPaid >= current.netPiasters) System.currentTimeMillis() else null))
        } }.onFailure { _payrollMessage.value = it.message ?: "تعذر تسجيل دفعة المرتب" }
            .onSuccess { _payrollMessage.value = "تم تسجيل دفعة المرتب وتحديث المتبقي" }
    }

    fun voidOrCorrectPayrollPayment(
        payment: EmployeePayrollPayment,
        replacementAmount: Long?,
        paymentDate: String,
        paymentMethod: String,
        note: String,
        reason: String
    ) = viewModelScope.launch {
        _payrollMessage.value = ""
        runCatching { db.withTransaction {
            val original = dao.payrollPayment(payment.id) ?: error("الدفعة الأصلية غير موجودة")
            require(original.status == "active") { "هذه الدفعة ملغاة بالفعل ولا يمكن إلغاؤها مرة أخرى" }
            require(reason.trim().isNotBlank()) { "سبب الإلغاء أو التصحيح إلزامي" }
            val monthKey = dao.payrollMonthForId(original.payrollId)
                ?: error("كشف المرتب المرتبط بالدفعة غير موجود")
            val current = dao.payrollSnapshot(monthKey).firstOrNull { it.id == original.payrollId }
                ?: error("كشف المرتب المرتبط بالدفعة غير موجود")
            val paidWithoutOriginal = (dao.payrollPaymentsTotal(current.id) - original.amountPiasters).coerceAtLeast(0L)
            val replacement = replacementAmount ?: 0L
            require(replacement >= 0L) { "قيمة الدفعة المصححة غير صحيحة" }
            if (replacement > 0L) {
                require(runCatching { LocalDate.parse(paymentDate) }.isSuccess) { "تاريخ الدفعة المصححة غير صحيح" }
                require(paymentMethod.isNotBlank()) { "حدد طريقة الدفع" }
                val remaining = (current.netPiasters - paidWithoutOriginal).coerceAtLeast(0L)
                require(replacement <= remaining) { "قيمة الدفعة المصححة أكبر من المتبقي بعد استبعاد الدفعة الأصلية (${remaining / 100.0} جنيه)" }
            }
            val now = System.currentTimeMillis()
            dao.updatePayrollPayment(original.copy(status = "voided", voidedAt = now, voidReason = reason.trim()))
            if (replacement > 0L) {
                val replacementId = dao.insertPayrollPayment(EmployeePayrollPayment(
                    payrollId = original.payrollId,
                    amountPiasters = replacement,
                    paymentDate = paymentDate,
                    paymentMethod = paymentMethod,
                    note = note.trim(),
                    createdAt = now,
                    correctionOfPaymentId = original.id,
                    accountId = original.accountId
                ))
                dao.updatePayrollPayment(original.copy(
                    status = "voided", voidedAt = now, voidReason = reason.trim(),
                    correctedByPaymentId = replacementId
                ))
            }
            val newPaid = paidWithoutOriginal + replacement
            dao.savePayroll(current.copy(
                paidPiasters = newPaid,
                paidAt = if (newPaid >= current.netPiasters && current.netPiasters > 0) now else null
            ))
            db.financeDao().insertAudit(AuditLog(
                entityType = "payroll_payment", entityId = original.id, action = "void_unpaid_entry",
                details = "actor=owner;originalAmount=${original.amountPiasters};replacementAmount=$replacement;reason=${reason.trim()}",
                createdAt = now
            ))
        } }.onFailure { _payrollMessage.value = it.message ?: "تعذر إلغاء أو تصحيح الدفعة" }
            .onSuccess { _payrollMessage.value = if ((replacementAmount ?: 0L) > 0L) "تم إلغاء الدفعة الأصلية وتسجيل الدفعة المصححة مع الاحتفاظ بالسبب" else "تم إلغاء الدفعة مع الاحتفاظ بالحركة الأصلية وسبب الإلغاء" }
    }

    /** عكس دفعة خرجت فعليًا: تستبعد من صافي مستحق المرتب، وتبقى حركة الصرف الأصلية في دفتر النقدية. */
    fun reversePaidPayrollPayment(payment: EmployeePayrollPayment, amountActuallyReturned: Long, accountId: String?, reason: String, note: String = "") = viewModelScope.launch {
        _payrollMessage.value = ""
        runCatching { db.withTransaction {
            val original = dao.payrollPayment(payment.id) ?: error("الدفعة الأصلية غير موجودة")
            require(original.status == "active") { "الدفعة ليست سارية أو سبق عكسها" }
            require(reason.trim().isNotBlank()) { "سبب عكس المرتب إلزامي" }
            require(amountActuallyReturned in 0L..original.amountPiasters) { "المبلغ المسترد فعليًا يجب أن يكون بين صفر وقيمة الدفعة الأصلية" }
            if (amountActuallyReturned > 0L) {
                require(!accountId.isNullOrBlank() && db.cashAccountDao().find(accountId)?.isActive == true) { "حدد حسابًا نشطًا استقبل المبلغ فعليًا" }
            }
            require(dao.payrollReversalForPayment(original.id) == null) { "سبق تسجيل عكس لهذه الدفعة" }
            val now = System.currentTimeMillis()
            val reversalId = dao.insertPayrollReversal(EmployeePayrollReversal(
                originalPaymentId = original.id, amountPiasters = original.amountPiasters,
                reason = reason.trim(), note = note.trim(), createdAt = now
            ))
            dao.updatePayrollPayment(original.copy(status = "reversed", voidedAt = now, voidReason = reason.trim()))
            if (amountActuallyReturned > 0L) {
                dao.insertPayrollRecovery(EmployeePayrollRecoveryTransaction(
                    reversalId = reversalId, amountPiasters = amountActuallyReturned,
                    receivedAt = now, accountId = accountId!!, note = note.trim()
                ))
            }
            val monthKey = dao.payrollMonthForId(original.payrollId) ?: error("كشف المرتب غير موجود")
            val current = dao.payrollSnapshot(monthKey).firstOrNull { it.id == original.payrollId } ?: error("كشف المرتب غير موجود")
            val activePaid = dao.payrollPaymentsTotal(current.id)
            dao.savePayroll(current.copy(paidPiasters = activePaid, paidAt = if (activePaid >= current.netPiasters && current.netPiasters > 0L) now else null))
            db.financeDao().insertAudit(AuditLog(
                entityType = "payroll_reversal", entityId = reversalId, action = "reverse_paid",
                details = "actor=owner;originalPayment=${original.id};amount=${original.amountPiasters};returned=${amountActuallyReturned};receivable=${original.amountPiasters - amountActuallyReturned};account=${accountId ?: "none"};reason=${reason.trim()}",
                createdAt = now
            ))
        } }.onFailure { _payrollMessage.value = it.message ?: "تعذر عكس دفعة المرتب" }
            .onSuccess { _payrollMessage.value = "تم عكس الدفعة. المسترد فعليًا: ${amountActuallyReturned / 100.0} جنيه، والمديونية المتبقية على الموظف: ${(payment.amountPiasters - amountActuallyReturned) / 100.0} جنيه" }
    }

    private fun accountingPeriodFor(epochMillis: Long): Pair<String, Pair<Long, Long>> {
        val date = java.time.Instant.ofEpochMilli(epochMillis).atZone(ZoneId.systemDefault()).toLocalDate()
        val ym = YearMonth.from(date)
        val start = ym.atDay(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val end = ym.atEndOfMonth().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() - 1L
        return ym.toString() to (start to end)
    }

    /** يثبت استحقاق المرتب مرة واحدة فقط قبل أول صرف؛ السلف المستقطعة تخفض أصل سلف الموظف. */
    private suspend fun postPayrollAccrualIfNeeded(row: EmployeePayroll, accounting: AccountingDao) {
        if (accounting.alreadyPosted("employee_payroll_accrual", row.id.toString())) return
        val firstDay = YearMonth.parse(row.monthKey).atDay(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val period = accountingPeriodFor(firstDay)
        accounting.ensurePeriod(period.first, period.second.first, period.second.second)
        val salary = accounting.accountByCode("5200") ?: error("حساب مصروف المرتبات غير موجود")
        val payable = accounting.accountByCode("2200") ?: error("حساب المرتبات المستحقة غير موجود")
        val advance = accounting.accountByCode("1210") ?: error("حساب سلف الموظفين غير موجود")
        val drafts = payrollAccrualDrafts(row, salary.id, payable.id, advance.id)
        accounting.postJournal(JournalEntry(entryNo = "PAYROLL-ACC-${row.id}", entryDate = firstDay, periodKey = period.first, description = "إثبات استحقاق مرتبات ${row.monthKey}", sourceType = "employee_payroll_accrual", sourceId = row.id.toString()), drafts)
    }

    /** تسجيل تحصيل لاحق من مديونية موظف؛ لا يزيد الحساب إلا بقيمة التحصيل الفعلي. */
    fun recordPayrollRecovery(reversalId: Long, amountPiasters: Long, accountId: String, note: String = "") = viewModelScope.launch {
        _payrollMessage.value = ""
        runCatching { db.withTransaction {
            require(amountPiasters > 0L) { "قيمة التحصيل يجب أن تكون أكبر من صفر" }
            val reversal = dao.payrollReversalById(reversalId) ?: error("سجل عكس المرتب غير موجود")
            require(db.cashAccountDao().find(accountId)?.isActive == true) { "حساب التحصيل غير موجود أو غير نشط" }
            val collected = dao.payrollRecoveryTotal(reversalId)
            val remaining = (reversal.amountPiasters - collected).coerceAtLeast(0L)
            require(amountPiasters <= remaining) { "المبلغ أكبر من المديونية المتبقية (${remaining / 100.0} جنيه)" }
            val now = System.currentTimeMillis()
            val id = dao.insertPayrollRecovery(EmployeePayrollRecoveryTransaction(
                reversalId = reversalId, amountPiasters = amountPiasters, receivedAt = now,
                accountId = accountId, note = note.trim()
            ))
            db.financeDao().insertAudit(AuditLog(
                entityType = "payroll_reversal", entityId = reversalId, action = "recover_debt",
                details = "actor=owner;recoveryTransaction=$id;amount=$amountPiasters;account=$accountId;remaining=${remaining - amountPiasters};note=${note.trim()}",
                createdAt = now
            ))
        } }.onFailure { _payrollMessage.value = it.message ?: "تعذر تسجيل تحصيل المديونية" }
            .onSuccess { _payrollMessage.value = "تم تسجيل التحصيل الفعلي من الموظف" }
    }

}
