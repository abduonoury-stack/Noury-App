package com.tahseel.students.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.R
import com.tahseel.students.util.AcademyProfileStore
import com.tahseel.students.util.Money
import com.tahseel.students.util.TimeUtil
import com.tahseel.students.vm.DashboardViewModel
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val DashPurple = LdaPalette.Royal
private val DashDeep = LdaPalette.RoyalDeep
private val DashLilac = LdaPalette.Lilac
private val DashMint = LdaPalette.SuccessContainer
private val DashPeach = LdaPalette.PeachContainer

@Composable
fun DashboardScreen(
    vm: DashboardViewModel,
    onAdd: () -> Unit, onReports: () -> Unit,
    onStudents: () -> Unit, onSubscription: () -> Unit, onCollectionStatus: () -> Unit,
    onHr: () -> Unit, onAddStudent: () -> Unit,
    onHub: (String) -> Unit, onStudentProfile: (Long) -> Unit
) {
    val s by vm.state.collectAsStateWithLifecycle()
    val academyName by AcademyProfileStore.name.collectAsStateWithLifecycle()
    val academyAddress by AcademyProfileStore.address.collectAsStateWithLifecycle()
    val academyPhone by AcademyProfileStore.phone.collectAsStateWithLifecycle()
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refreshDay() }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(30_000) } }
    val locale = remember { Locale("ar", "EG") }
    val dateText = remember(now) { now.format(DateTimeFormatter.ofPattern("EEEE، d MMMM yyyy", locale)) }

    AppScaffold(title = "الرئيسية", onBack = null, showTopBar = false) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).background(Brush.verticalGradient(listOf(Color(0xFFF8F3FF), Color(0xFFF0E8FF), Color(0xFFFFFBFF))))
                .verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp)
        ) {
            // Academy identity header
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Image(painter = androidx.compose.ui.res.painterResource(R.drawable.noury_wordmark), contentDescription = "Noury App", modifier = Modifier.width(142.dp).height(44.dp), contentScale = ContentScale.Fit)
                    if (academyName.isNotBlank()) {
                        Text(academyName, color = DashPurple, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(listOf(academyAddress, academyPhone).filter { it.isNotBlank() }.joinToString(" • "), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    Text(dateText, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                }
                Surface(shape = CircleShape, color = Color.White, border = BorderStroke(2.dp, DashLilac), shadowElevation = 3.dp) {
                    Image(painter = androidx.compose.ui.res.painterResource(R.drawable.canaria_logo), contentDescription = "شعار الأكاديمية", modifier = Modifier.size(58.dp).padding(5.dp))
                }
            }

            // البانر الترحيبي (home_banner.jpg، نسبة 1440×524): يُعرض كاملًا بدون قص حتى لا تُقطع كلمة "مرحبًا بك".
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(26.dp),
                elevation = CardDefaults.cardElevation(4.dp),
                border = BorderStroke(1.dp, Color.White)
            ) {
                Image(
                    painter = androidx.compose.ui.res.painterResource(R.drawable.home_banner),
                    contentDescription = "مرحبًا بك – هنا تبدأ رحلة التعلم والمرح",
                    modifier = Modifier.fillMaxWidth().aspectRatio(1440f / 524f),
                    contentScale = ContentScale.Crop
                )
            }

            DashboardSectionTitle("لوحة التحكم الرئيسية", "إدارة الأكاديمية من مكان واحد", Icons.Default.Home)

            // المراكز الرئيسية فقط؛ الخدمات التفصيلية موجودة داخل كل مركز.
            DashboardSectionTitle("المراكز الرئيسية", "اختر المركز للوصول إلى خدماته", Icons.Default.Groups)
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DashboardAction("إدارة الطلاب", Icons.Default.Groups, Color(0xFFECE4FF), DashPurple, { onHub("students") }, Modifier.weight(1f))
                    DashboardAction("الإدارة المالية", Icons.Default.AccountBalance, Color(0xFFFFF0DF), Color(0xFFB66A00), { onHub("finance") }, Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DashboardAction("التقارير والتحليلات", Icons.Default.Assessment, Color(0xFFE7F0FF), Color(0xFF2867B2), onReports, Modifier.weight(1f))
                    DashboardAction("الموارد البشرية", Icons.Default.Groups, Color(0xFFDDF8E9), Color(0xFF128A57), onHr, Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DashboardAction("إعدادات النظام", Icons.Default.Settings, Color(0xFFEDEFF3), Color(0xFF596579), { onHub("system") }, Modifier.fillMaxWidth())
                }
            }

            val last = s.last
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White), border = BorderStroke(1.dp, LdaPalette.Border)) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("آخر عملية تحصيل", color = DashDeep, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (last == null) Text("لا توجد عمليات مسجلة حتى الآن", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else {
                        Text(last.studentName, style = MaterialTheme.typography.titleMedium, color = DashPurple, modifier = last.studentId?.let { id -> Modifier.clickable { onStudentProfile(id) } } ?: Modifier)
                        Text("إيصال ${last.receiptNo}  •  ${Money.format(last.amountPiasters)}", fontWeight = FontWeight.SemiBold, color = DashDeep)
                        Text(TimeUtil.fmt(last.createdAt), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            if (academyName.isNotBlank()) Text("NOURY APP  •  ${academyName.uppercase(Locale.ROOT)}", modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun DashboardMetricCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, bg: Color, accent: Color, modifier: Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = bg), border = BorderStroke(1.dp, Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(27.dp))
            Text(value, color = DashDeep, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(title, color = accent, fontWeight = FontWeight.Bold, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2, lineHeight = 15.sp)
        }
    }
}

@Composable
private fun DashboardValueLine(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
        Text(value, color = color, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleSmall, maxLines = 1)
    }
}

@Composable
private fun DashboardSectionTitle(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(Modifier.fillMaxWidth().padding(top = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        DuotoneIcon(icon, tint = DashPurple, containerColor = Color(0xFFECE4FF), tileSize = 39.dp, iconSize = 21.dp)
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text(title, color = DashDeep, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun DashboardAction(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, bg: Color, accent: Color, onClick: () -> Unit, modifier: Modifier) {
    Card(onClick = onClick, modifier = modifier.heightIn(min = 96.dp), shape = RoundedCornerShape(21.dp), colors = CardDefaults.cardColors(containerColor = bg), border = BorderStroke(1.dp, Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 7.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Surface(shape = RoundedCornerShape(14.dp), color = Color.White.copy(alpha = .78f)) {
                Icon(icon, contentDescription = title, tint = accent, modifier = Modifier.padding(9.dp).size(27.dp))
            }
            Text(title, color = DashDeep, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge, textAlign = TextAlign.Center, maxLines = 2)
        }
    }
}

@Composable
private fun DashboardStat(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White), border = BorderStroke(1.dp, LdaPalette.Border)) {
        Column(Modifier.fillMaxWidth().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(icon, null, tint = DashPurple, modifier = Modifier.size(23.dp))
            Text(value, color = DashDeep, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
            Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, maxLines = 2)
        }
    }
}

@Composable
private fun DashboardBottomBar(onHome: () -> Unit, onReports: () -> Unit, onStudents: () -> Unit, onSubscriptions: () -> Unit, onMore: () -> Unit) {
    Surface(color = Color.White, shadowElevation = 10.dp, tonalElevation = 2.dp) {
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 5.dp, vertical = 7.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            DashboardNavItem("الرئيسية", Icons.Default.Home, true, onHome)
            DashboardNavItem("التقارير", Icons.Default.Assessment, false, onReports)
            DashboardNavItem("الأطفال", Icons.Default.Groups, false, onStudents)
            DashboardNavItem("الاشتراكات", Icons.Default.ReceiptLong, false, onSubscriptions)
            DashboardNavItem("المزيد", Icons.Default.MoreHoriz, false, onMore)
        }
    }
}

@Composable
private fun DashboardNavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) DashPurple else Color.Transparent
    val fg = if (selected) Color.White else DashDeep
    Column(Modifier.clip(RoundedCornerShape(18.dp)).background(bg).clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Icon(icon, contentDescription = label, tint = fg, modifier = Modifier.size(22.dp))
        Text(label, color = fg, fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.SemiBold, fontSize = 10.sp, maxLines = 2, textAlign = TextAlign.Center, lineHeight = 12.sp)
    }
}
