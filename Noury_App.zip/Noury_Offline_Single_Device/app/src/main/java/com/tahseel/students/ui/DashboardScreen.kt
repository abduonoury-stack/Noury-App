package com.tahseel.students.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.R
import com.tahseel.students.data.SessionContext
import com.tahseel.students.data.UserRoles
import com.tahseel.students.util.AcademyProfileStore
import com.tahseel.students.util.Money
import com.tahseel.students.util.TimeUtil
import com.tahseel.students.vm.DashboardViewModel
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val DashPurple = LdaPalette.Royal
private val DashDeep = LdaPalette.RoyalDeep
private val DashLilac = LdaPalette.Lilac
private val DashMint = LdaPalette.SuccessContainer
private val DashPeach = LdaPalette.PeachContainer

@Composable
fun DashboardScreen(
    vm: DashboardViewModel,
    onAdd: () -> Unit, onReports: () -> Unit,
    onStudents: () -> Unit, onSubscription: () -> Unit, onCollectionStatus: () -> Unit,
    onHr: () -> Unit, onAddStudent: () -> Unit,
    onHub: (String) -> Unit, onStudentProfile: (Long) -> Unit,
    currentUserName: String, onLogout: () -> Unit
) {
    val s by vm.state.collectAsStateWithLifecycle()
    val academyName by AcademyProfileStore.name.collectAsStateWithLifecycle()
    val academyAddress by AcademyProfileStore.address.collectAsStateWithLifecycle()
    val academyPhone by AcademyProfileStore.phone.collectAsStateWithLifecycle()
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refreshDay() }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(30_000) } }
    val locale = remember { Locale("ar", "EG") }
    val dateText = remember(now) { now.format(DateTimeFormatter.ofPattern("EEEE، d MMMM yyyy", locale)) }

    AppScaffold(title = "الرئيسية", onBack = null, showTopBar = false) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).background(Brush.verticalGradient(listOf(LdaPalette.Canvas, Color(0xFFF3EDE3), LdaPalette.Canvas)))
                .verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp)
        ) {
            // Academy identity header
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Image(painter = androidx.compose.ui.res.painterResource(R.drawable.noury_wordmark), contentDescription = "Noury App", modifier = Modifier.width(142.dp).height(44.dp), contentScale = ContentScale.Fit)
                    if (academyName.isNotBlank()) {
                        Text(academyName, color = DashPurple, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(listOf(academyAddress, academyPhone).filter { it.isNotBlank() }.joinToString(" • "), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    Text(dateText, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    NouryBrandMark(size = 58.dp)
                    Text(currentUserName, style = MaterialTheme.typography.labelSmall, color = DashPurple, maxLines = 1)
                    TextButton(onClick = onLogout, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) {
                        Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(3.dp))
                        Text("خروج", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            // Welcome hero: branded, data-aware, and free of a fixed academy name or sample artwork.
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = LdaPalette.RoyalDeep),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                border = BorderStroke(1.dp, LdaPalette.Gold.copy(alpha = 0.55f))
            ) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(Brush.linearGradient(listOf(LdaPalette.RoyalDeep, LdaPalette.Royal, Color(0xFF70558F))))
                        .padding(horizontal = 20.dp, vertical = 21.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                if (academyName.isNotBlank()) "مرحبًا بك في $academyName" else "مرحبًا بك في NOURY",
                                color = Color.White,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                "إدارة يومك الأكاديمي تبدأ من هنا",
                                color = Color.White.copy(alpha = 0.86f),
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(dateText, color = LdaPalette.Gold, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                        }
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color.White.copy(alpha = 0.12f),
                            border = BorderStroke(1.dp, LdaPalette.Gold.copy(alpha = 0.7f))
                        ) {
                            Icon(Icons.Default.ChildCare, contentDescription = null, tint = LdaPalette.Gold, modifier = Modifier.padding(15.dp).size(34.dp))
                        }
                    }
                }
            }

            // مؤشرات حقيقية من DashboardViewModel، تُعرض حسب صلاحيات الدور الحالي فقط.
            val role = SessionContext.role ?: ""
            val canStudents = UserRoles.canOpen(role, "students")
            val canCollect = UserRoles.canOpen(role, "collection-status")
            val canExpenses = UserRoles.canOpen(role, "expenses")
            val kpiCards = mutableListOf<@Composable (Modifier) -> Unit>()
            if (canStudents) kpiCards.add { m -> NouryMetricCard("الأطفال النشطون", s.activeStudents.toString(), Icons.Default.ChildCare, m, LdaPalette.Teal, LdaPalette.TealContainer, "شهر ${s.month}") }
            if (canCollect) {
                kpiCards.add { m -> NouryMetricCard("مدفوعات اليوم", Money.format(s.todayTotal), Icons.Default.Payments, m, LdaPalette.Green, LdaPalette.GreenContainer, "${s.todayCount} إيصال") }
                kpiCards.add { m -> NouryMetricCard("المتوقع هذا الشهر", Money.format(s.expected), Icons.Default.AccountBalanceWallet, m, LdaPalette.Blue, LdaPalette.BlueContainer) }
                kpiCards.add { m -> NouryMetricCard("المحصّل هذا الشهر", Money.format(s.collected), Icons.Default.AddCard, m, LdaPalette.Green, LdaPalette.GreenContainer, "ملتزمون: ${s.paidStudents}") }
                kpiCards.add { m -> NouryMetricCard("المتبقي للتحصيل", Money.format(s.remaining), Icons.Default.ReceiptLong, m, LdaPalette.Orange, LdaPalette.OrangeContainer, "غير مسددين: ${s.unpaidStudents}") }
            }
            if (canExpenses) {
                kpiCards.add { m -> NouryMetricCard("مصروفات الشهر", Money.format(s.expenses), Icons.Default.Wallet, m, LdaPalette.Pink, LdaPalette.PinkContainer) }
                kpiCards.add { m -> NouryMetricCard("صافي الحركة النقدية", Money.format(s.net), Icons.Default.TrendingUp, m, LdaPalette.Purple, LdaPalette.PurpleContainer) }
            }
            if (kpiCards.isNotEmpty()) {
                NourySectionHeader("ملخص الأكاديمية", "أرقام حقيقية من بيانات الجهاز", Icons.Default.TrendingUp)
                kpiCards.chunked(2).forEach { rowCards ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        rowCards.forEach { card -> card(Modifier.weight(1f)) }
                        if (rowCards.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }

            DashboardSectionTitle("لوحة التحكم الرئيسية", "إدارة الأكاديمية من مكان واحد", Icons.Default.Home)

            // المراكز المعتمدة: بطاقات وصول مباشرة دون عنوان إضافي أو أقسام مكررة.
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    DashboardAction("إدارة الطلاب", Icons.Default.Groups, LdaPalette.PurpleContainer, LdaPalette.Purple, { onHub("students") }, Modifier.weight(1f))
                    DashboardAction("الإدارة المالية", Icons.Default.AccountBalance, LdaPalette.OrangeContainer, LdaPalette.Orange, { onHub("finance") }, Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    DashboardAction("التقارير والتحليلات", Icons.Default.Assessment, LdaPalette.BlueContainer, LdaPalette.Blue, onReports, Modifier.weight(1f))
                    DashboardAction("الموارد البشرية", Icons.Default.Groups, LdaPalette.GreenContainer, LdaPalette.Green, onHr, Modifier.weight(1f))
                }
                DashboardAction("إعدادات النظام", Icons.Default.Settings, LdaPalette.TealContainer, LdaPalette.Teal, { onHub("system") }, Modifier.fillMaxWidth(), wide = true)
            }

            if (academyName.isNotBlank()) Text("NOURY APP  •  ${academyName.uppercase(Locale.ROOT)}", modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun DashboardMetricCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, bg: Color, accent: Color, modifier: Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = bg), border = BorderStroke(1.dp, Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(27.dp))
            Text(value, color = DashDeep, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(title, color = accent, fontWeight = FontWeight.Bold, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2, lineHeight = 15.sp)
        }
    }
}

@Composable
private fun DashboardValueLine(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
        Text(value, color = color, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleSmall, maxLines = 1)
    }
}

@Composable
private fun DashboardSectionTitle(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(Modifier.fillMaxWidth().padding(top = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        DuotoneIcon(icon, tint = DashPurple, containerColor = Color(0xFFECE4FF), tileSize = 39.dp, iconSize = 21.dp)
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text(title, color = DashDeep, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun DashboardAction(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    bg: Color,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier,
    wide: Boolean = false
) {
    Card(
        onClick = onClick,
        modifier = modifier.height(if (wide) 82.dp else 122.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = bg),
        border = BorderStroke(1.dp, Color.White.copy(alpha = .95f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp, pressedElevation = 1.dp)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.linearGradient(listOf(Color.White.copy(alpha = .62f), bg, bg.copy(alpha = .88f))))
                .padding(horizontal = 15.dp, vertical = if (wide) 12.dp else 14.dp)
        ) {
            if (wide) {
                Row(
                    Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(13.dp)
                ) {
                    Surface(shape = RoundedCornerShape(17.dp), color = Color.White.copy(alpha = .88f), shadowElevation = 1.dp) {
                        Icon(icon, contentDescription = title, tint = accent, modifier = Modifier.padding(12.dp).size(27.dp))
                    }
                    Text(title, color = DashDeep, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.weight(1f))
                    Surface(shape = CircleShape, color = Color.White.copy(alpha = .78f)) {
                        Text("‹", color = accent, fontWeight = FontWeight.ExtraBold, fontSize = 25.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 1.dp))
                    }
                }
            } else {
                Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.SpaceBetween) {
                        Surface(shape = RoundedCornerShape(16.dp), color = Color.White.copy(alpha = .88f), shadowElevation = 1.dp) {
                            Icon(icon, contentDescription = title, tint = accent, modifier = Modifier.padding(11.dp).size(26.dp))
                        }
                        Surface(shape = CircleShape, color = Color.White.copy(alpha = .68f)) {
                            Text("‹", color = accent, fontWeight = FontWeight.ExtraBold, fontSize = 21.sp, modifier = Modifier.padding(horizontal = 9.dp, vertical = 0.dp))
                        }
                    }
                    Text(
                        title,
                        color = DashDeep,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall,
                        textAlign = TextAlign.Start,
                        maxLines = 2
                    )
                }
            }
        }
    }
}

@Composable
private fun DashboardStat(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White), border = BorderStroke(1.dp, LdaPalette.Border)) {
        Column(Modifier.fillMaxWidth().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(icon, null, tint = DashPurple, modifier = Modifier.size(23.dp))
            Text(value, color = DashDeep, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
            Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, maxLines = 2)
        }
    }
}

@Composable
private fun DashboardBottomBar(onHome: () -> Unit, onReports: () -> Unit, onStudents: () -> Unit, onSubscriptions: () -> Unit, onMore: () -> Unit) {
    Surface(color = Color.White, shadowElevation = 10.dp, tonalElevation = 2.dp) {
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 5.dp, vertical = 7.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            DashboardNavItem("الرئيسية", Icons.Default.Home, true, onHome)
            DashboardNavItem("التقارير", Icons.Default.Assessment, false, onReports)
            DashboardNavItem("الأطفال", Icons.Default.Groups, false, onStudents)
            DashboardNavItem("الاشتراكات", Icons.Default.ReceiptLong, false, onSubscriptions)
            DashboardNavItem("المزيد", Icons.Default.MoreHoriz, false, onMore)
        }
    }
}

@Composable
private fun DashboardNavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) DashPurple else Color.Transparent
    val fg = if (selected) Color.White else DashDeep
    Column(Modifier.clip(RoundedCornerShape(18.dp)).background(bg).clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Icon(icon, contentDescription = label, tint = fg, modifier = Modifier.size(22.dp))
        Text(label, color = fg, fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.SemiBold, fontSize = 10.sp, maxLines = 2, textAlign = TextAlign.Center, lineHeight = 12.sp)
    }
}
