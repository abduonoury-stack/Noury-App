package com.tahseel.students.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tahseel.students.data.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class RefundViewModel(
    private val financeDao: FinanceDao,
    studentDao: StudentDao,
    private val repository: RefundRepository,
    cashAccountDao: CashAccountDao,
    paymentDao: PaymentDao
) : ViewModel() {
    val credits = financeDao.observeOpenRefundCredits().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val students = studentDao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val allCredits = financeDao.observeAllRefundCredits().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val history = financeDao.observeRefundTransactions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val accounts = cashAccountDao.observeActive().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val payments = combine(paymentDao.observeAll(), financeDao.observeSubscriptionPaymentIds()) { all, subscriptionIds ->
        all.filter { !it.isCancelled && it.id !in subscriptionIds }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun createManualCredit(paymentId: Long, pounds: String, reason: String, documentReference: String, onResult: (String) -> Unit) = viewModelScope.launch {
        if (!PermissionGuard.allow(Permission.REFUND_REQUEST)) { onResult(PermissionGuard.DENIED_MESSAGE); return@launch }
        val amount = com.tahseel.students.util.Money.parse(pounds)
        if (amount == null) { onResult("اكتب مبلغًا صحيحًا أكبر من صفر") ; return@launch }
        when (val result = repository.createManualCredit(paymentId, amount, reason, documentReference)) {
            is RefundCreditCreateResult.Rejected -> onResult(result.reason)
            is RefundCreditCreateResult.Success -> onResult("تم إنشاء واعتماد رصيد الاسترداد رقم ${result.creditId}. لم يتم خصم أي مبلغ من الحسابات حتى الصرف الفعلي.")
        }
    }

    fun refund(creditId: Long, pounds: String, method: String, note: String, accountId: String, onResult: (String) -> Unit) = viewModelScope.launch {
        if (!PermissionGuard.allow(Permission.REFUND_PAY)) { onResult(PermissionGuard.DENIED_MESSAGE); return@launch }
        val amount = com.tahseel.students.util.Money.parse(pounds)
        if (amount == null) { onResult("اكتب مبلغ استرداد صحيحًا أكبر من صفر"); return@launch }
        when (val result = repository.refund(creditId, amount, method, note, accountId)) {
            is RefundResult.Rejected -> onResult(result.reason)
            is RefundResult.Success -> onResult("تم تسجيل الاسترداد بنجاح\nرقم العملية: ${result.transactionId}\nالرصيد المتبقي: ${result.remainingPiasters / 100} جنيه")
        }
    }
}
