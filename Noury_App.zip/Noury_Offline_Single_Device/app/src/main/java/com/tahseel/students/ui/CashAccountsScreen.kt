package com.tahseel.students.ui

import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.data.CashAccount
import com.tahseel.students.data.CashAccountDao
import com.tahseel.students.data.AppDatabase
import com.tahseel.students.data.CashTransferRepository
import com.tahseel.students.data.CashTransfer
import com.tahseel.students.util.Money
import java.time.LocalDate
import java.time.ZoneId
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
fun CashAccountsScreen(db: AppDatabase, onBack: () -> Unit) {
    val dao = db.cashAccountDao()
    val accounts by dao.observeAll().collectAsStateWithLifecycle(emptyList())
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("bank") }
    var fromId by remember { mutableStateOf("cash") }
    var toId by remember { mutableStateOf("") }
    var transferAmount by remember { mutableStateOf("") }
    var transferDate by remember { mutableStateOf(LocalDate.now().toString()) }
    var transferNote by remember { mutableStateOf("") }
    var transferMessage by remember { mutableStateOf("") }
    var selectedStatementAccount by remember { mutableStateOf("") }
    val nowMonth = remember { java.time.YearMonth.now() }
    val statementStart = remember { nowMonth.atDay(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() }
    val statementEnd = remember { nowMonth.atEndOfMonth().atTime(23,59,59).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli() }
    val statementRows by remember(selectedStatementAccount) { dao.observeStatement(selectedStatementAccount, statementStart, statementEnd) }.collectAsStateWithLifecycle(emptyList())
    val mappings by dao.observeLedgerMappings().collectAsStateWithLifecycle(emptyList())
    val scope = rememberCoroutineScope()
    AppScaffold("حسابات النقدية والبنوك", onBack) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Text("كل حساب له رصيد مستقل. التحصيل أو الصرف يُسجل على الحساب المختار فقط، والتحويل بين الحسابات لا يُعد إيرادًا أو مصروفًا.", style = MaterialTheme.typography.bodyMedium) }
            item { Card { Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("إضافة حساب", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(name, { name = it.take(60) }, label = { Text("اسم الحساب") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = type == "bank", onClick = { type = "bank" }, label = { Text("بنك") })
                    FilterChip(selected = type == "wallet", onClick = { type = "wallet" }, label = { Text("محفظة") })
                    FilterChip(selected = type == "electronic", onClick = { type = "electronic" }, label = { Text("إلكتروني") })
                }
                Button(onClick = {
                    val clean = name.trim()
                    if (clean.isNotBlank()) scope.launch {
                        dao.insert(CashAccount(id = "${type}_${UUID.randomUUID()}", name = clean, type = type))
                        name = ""
                    }
                }, enabled = name.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("إضافة الحساب") }
            } } }
            item { Card { Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("تحويل بين الحسابات", style = MaterialTheme.typography.titleMedium)
                CashAccountDropdown(accounts = accounts.filter { it.isActive }, selectedId = fromId, onSelected = { fromId = it }, label = "من حساب")
                CashAccountDropdown(accounts = accounts.filter { it.isActive }, selectedId = toId, onSelected = { toId = it }, label = "إلى حساب")
                OutlinedTextField(transferAmount, { transferAmount = it }, label = { Text("المبلغ بالجنيه") }, singleLine = true, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(transferDate, { transferDate = it }, label = { Text("تاريخ التحويل YYYY-MM-DD") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(transferNote, { transferNote = it }, label = { Text("رقم مرجعي / ملاحظات") }, modifier = Modifier.fillMaxWidth())
                if (transferMessage.isNotBlank()) Text(transferMessage, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Button(onClick = {
                    val amount = Money.parse(transferAmount)
                    val date = runCatching { LocalDate.parse(transferDate) }.getOrNull()
                    val from = accounts.firstOrNull { it.id == fromId && it.isActive }
                    val to = accounts.firstOrNull { it.id == toId && it.isActive }
                    when {
                        from == null || to == null -> transferMessage = "اختر حسابين نشطين"
                        fromId == toId -> transferMessage = "لا يمكن التحويل إلى الحساب نفسه"
                        amount == null || amount <= 0L -> transferMessage = "أدخل مبلغًا صحيحًا أكبر من صفر"
                        date == null -> transferMessage = "تاريخ التحويل غير صحيح"
                        else -> scope.launch {
                            runCatching { CashTransferRepository(db).record(CashTransfer(fromAccountId = fromId, toAccountId = toId, amountPiasters = amount, transferredAt = date.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli(), note = transferNote.trim())) }
                                .onSuccess { transferAmount = ""; transferNote = ""; transferMessage = "" }
                                .onFailure { transferMessage = it.message ?: "تعذر تسجيل التحويل" }
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل التحويل") }
                Text("التحويل يسجل خصمًا من الحساب الأول وإضافة للحساب الثاني بالقيمة نفسها، ولا يدخل ضمن الإيرادات أو المصروفات التشغيلية.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } } }
            item { Text("الحسابات المسجلة", style = MaterialTheme.typography.titleMedium) }
            items(accounts, key = { it.id }) { account ->
                Card {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(account.name, style = MaterialTheme.typography.titleSmall)
                            Text(
                                when (account.type) { "cash" -> "نقدية"; "bank" -> "حساب بنكي"; "wallet" -> "محفظة إلكترونية"; else -> "وسيلة إلكترونية" },
                                style = MaterialTheme.typography.bodySmall
                            )
                            val mapping = mappings.firstOrNull { it.cashAccountId == account.id }
                            Text(if (mapping == null) "غير مربوط بحساب أستاذ" else "حساب أستاذ مستقل #${mapping.ledgerAccountId}", style = MaterialTheme.typography.bodySmall, color = if (mapping == null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                            TextButton(onClick = { selectedStatementAccount = if (selectedStatementAccount == account.id) "" else account.id }) { Text(if (selectedStatementAccount == account.id) "إخفاء الكشف" else "كشف الحساب — الشهر الحالي") }
                        }
                        if (account.id != "cash") {
                            TextButton(onClick = { scope.launch { dao.setActive(account.id, !account.isActive) } }) {
                                Text(if (account.isActive) "تعطيل" else "تفعيل")
                            }
                        } else Text("أساسي", color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
            if (selectedStatementAccount.isNotBlank()) {
                item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("كشف حساب: ${accounts.firstOrNull { it.id == selectedStatementAccount }?.name.orEmpty()}", style = MaterialTheme.typography.titleMedium)
                    Text("الفترة: ${nowMonth}", style = MaterialTheme.typography.bodySmall)
                    val periodNet = statementRows.fold(0L) { total, row -> Math.addExact(total, row.debitPiasters - row.creditPiasters) }
                    Text("صافي حركة الفترة: ${Money.format(periodNet)}", style = MaterialTheme.typography.titleSmall)
                    Text("الكشف يعرض القيود المرحلة على الحساب الفرعي منذ تاريخ ربطه. الأرصدة والحركات التاريخية السابقة ما زالت في الحساب التجميعي ولم يُعاد توزيعها تلقائيًا.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (statementRows.isEmpty()) Text("لا توجد حركات مرحلة على هذا الحساب خلال الفترة المحددة.")
                    statementRows.forEach { row ->
                        HorizontalDivider()
                        Text("${row.entryNo} • ${row.description}", style = MaterialTheme.typography.titleSmall)
                        Text("${java.time.Instant.ofEpochMilli(row.entryDate).atZone(ZoneId.systemDefault()).toLocalDate()} • ${row.sourceType} / ${row.sourceId}", style = MaterialTheme.typography.bodySmall)
                        Text("مدين: ${Money.format(row.debitPiasters)}  |  دائن: ${Money.format(row.creditPiasters)}")
                    }
                } } }
            }
    }
}
}