package com.tahseel.students.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** دليل الحسابات المحاسبي — كل المبالغ بالقروش. */
@Entity(tableName = "accounting_accounts", indices = [Index(value = ["code"], unique = true), Index("parentId"), Index("type")])
data class AccountingAccount(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val name: String,
    val type: String, // asset, liability, equity, revenue, expense
    val parentId: Long? = null,
    val isPosting: Boolean = true,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "accounting_periods", indices = [Index(value = ["startDate", "endDate"])])
data class AccountingPeriod(
    @PrimaryKey val periodKey: String,
    val startDate: Long,
    val endDate: Long,
    val status: String = "open", // open, closed
    val closedAt: Long? = null,
    val note: String = ""
)

@Entity(tableName = "journal_entries", indices = [Index("entryDate"), Index("periodKey"), Index(value = ["sourceType", "sourceId"])])
data class JournalEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val entryNo: String,
    val entryDate: Long,
    val periodKey: String,
    val description: String,
    val sourceType: String = "manual",
    val sourceId: String = "",
    val status: String = "posted", // posted, reversed
    val reversedEntryId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "journal_lines", foreignKeys = [ForeignKey(entity = JournalEntry::class, parentColumns = ["id"], childColumns = ["entryId"], onDelete = ForeignKey.CASCADE), ForeignKey(entity = AccountingAccount::class, parentColumns = ["id"], childColumns = ["accountId"], onDelete = ForeignKey.RESTRICT)], indices = [Index("entryId"), Index("accountId")])
data class JournalLine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val entryId: Long,
    val accountId: Long,
    val debitPiasters: Long = 0,
    val creditPiasters: Long = 0,
    val memo: String = ""
)

@Entity(tableName = "accounting_vendors", indices = [Index("name")])
data class AccountingVendor(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val taxNumber: String = "",
    val address: String = "",
    val notes: String = "",
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "accounting_expenses", indices = [Index("documentDate"), Index("dueDate"), Index("vendorId"), Index("periodKey")])
data class AccountingExpense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val documentNo: String = "",
    val title: String,
    val categoryAccountId: Long,
    val vendorId: Long? = null,
    val documentDate: Long,
    val dueDate: Long,
    val amountPiasters: Long,
    val paidPiasters: Long = 0,
    val periodKey: String,
    val status: String = "unpaid", // unpaid, partial, paid, void, deleted
    val note: String = "",
    val journalEntryId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "accounting_expense_payments", foreignKeys = [ForeignKey(entity = AccountingExpense::class, parentColumns = ["id"], childColumns = ["expenseId"], onDelete = ForeignKey.RESTRICT), ForeignKey(entity = CashAccount::class, parentColumns = ["id"], childColumns = ["cashAccountId"], onDelete = ForeignKey.RESTRICT)], indices = [Index("expenseId"), Index("paidAt"), Index("cashAccountId")])
data class AccountingExpensePayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val expenseId: Long,
    val amountPiasters: Long,
    val paidAt: Long,
    val cashAccountId: String,
    val method: String,
    val note: String = "",
    val journalEntryId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "accounting_source_posts", indices = [Index(value = ["sourceType", "sourceId"], unique = true)])
data class AccountingSourcePost(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sourceType: String,
    val sourceId: String,
    val journalEntryId: Long,
    val createdAt: Long = System.currentTimeMillis()
)

data class JournalLineDraft(val accountId: Long, val debitPiasters: Long = 0, val creditPiasters: Long = 0, val memo: String = "")

data class AccountLedgerRow(
    val id: Long,
    val entryId: Long,
    val accountId: Long,
    val debitPiasters: Long,
    val creditPiasters: Long,
    val memo: String,
    val accountCode: String,
    val accountName: String,
    val entryDate: Long,
    val entryNo: String,
    val description: String
)

data class TrialBalanceRow(
    val accountId: Long,
    val code: String,
    val name: String,
    val type: String,
    val debitPiasters: Long,
    val creditPiasters: Long
)

/** Builds the balanced payroll accrual using gross salary, net payable, employee-loan recovery and deductions. */
fun payrollAccrualDrafts(row: EmployeePayroll, salaryAccountId: Long, payableAccountId: Long, employeeAdvanceAccountId: Long): List<JournalLineDraft> {
    val gross = row.basePiasters + row.allowancesPiasters + row.bonusesPiasters
    require(gross > 0L) { "إجمالي استحقاق المرتب غير صحيح" }
    require(row.netPiasters >= 0L && row.loanDeductionPiasters >= 0L && row.deductionsPiasters >= 0L) { "مكونات المرتب لا يمكن أن تكون سالبة" }
    require(gross == row.netPiasters + row.loanDeductionPiasters + row.deductionsPiasters) {
        "مكونات كشف المرتب غير متوازنة محاسبيًا؛ راجع الاستحقاق والخصومات والسلفة قبل الصرف"
    }
    val drafts = mutableListOf(JournalLineDraft(salaryAccountId, debitPiasters = gross, memo = "إجمالي استحقاق ${row.monthKey}"))
    if (row.netPiasters > 0L) drafts += JournalLineDraft(payableAccountId, creditPiasters = row.netPiasters, memo = "صافي المرتب المستحق")
    if (row.loanDeductionPiasters > 0L) drafts += JournalLineDraft(employeeAdvanceAccountId, creditPiasters = row.loanDeductionPiasters, memo = "استقطاع قسط سلفة الموظف")
    if (row.deductionsPiasters > 0L) drafts += JournalLineDraft(salaryAccountId, creditPiasters = row.deductionsPiasters, memo = "خصومات وغياب الشهر")
    return drafts
}

@Dao
abstract class AccountingDao {
    @Query("SELECT * FROM accounting_accounts ORDER BY code, id") abstract fun observeAccounts(): Flow<List<AccountingAccount>>
    @Query("SELECT * FROM accounting_accounts WHERE isActive = 1 AND isPosting = 1 ORDER BY code") abstract suspend fun postingAccounts(): List<AccountingAccount>
    @Insert(onConflict = OnConflictStrategy.ABORT) abstract suspend fun insertAccount(account: AccountingAccount): Long
    @Query("SELECT * FROM accounting_periods ORDER BY startDate DESC") abstract fun observePeriods(): Flow<List<AccountingPeriod>>
    @Query("SELECT * FROM accounting_expenses ORDER BY documentDate DESC, id DESC") abstract fun observeExpenses(): Flow<List<AccountingExpense>>
    @Query("SELECT * FROM accounting_expense_payments ORDER BY paidAt DESC, id DESC") abstract fun observeExpensePayments(): Flow<List<AccountingExpensePayment>>
    @Query("""
        SELECT COUNT(*) FROM accounting_expense_payments p
        LEFT JOIN journal_entries j ON j.id = p.journalEntryId
        LEFT JOIN cash_account_ledger_mappings m ON m.cashAccountId = p.cashAccountId
        LEFT JOIN accounting_source_posts sp
          ON sp.sourceType = 'accounting_expense_payment'
         AND sp.sourceId = CAST(p.id AS TEXT)
         AND sp.journalEntryId = j.id
        WHERE p.journalEntryId IS NULL
           OR j.id IS NULL
           OR j.status != 'posted'
           OR sp.id IS NULL
           OR m.ledgerAccountId IS NULL
           OR (SELECT COALESCE(SUM(l.creditPiasters), 0)
                 FROM journal_lines l
                WHERE l.entryId = j.id AND l.accountId = m.ledgerAccountId) != p.amountPiasters
           OR (SELECT COALESCE(SUM(l.debitPiasters), 0)
                 FROM journal_lines l
                WHERE l.entryId = j.id
                  AND l.accountId = (SELECT id FROM accounting_accounts WHERE code = '2100' LIMIT 1)) != p.amountPiasters
    """) abstract fun observeExpensePaymentCashMismatchCount(): Flow<Int>
    @Query("SELECT * FROM accounting_vendors ORDER BY name") abstract fun observeVendors(): Flow<List<AccountingVendor>>
    @Query("SELECT * FROM journal_entries ORDER BY entryDate DESC, id DESC LIMIT 200") abstract fun observeJournal(): Flow<List<JournalEntry>>
    @Query("SELECT * FROM accounting_accounts WHERE code=:code AND isActive=1 AND isPosting=1 LIMIT 1") abstract suspend fun accountByCode(code: String): AccountingAccount?
    @Query("SELECT * FROM accounting_accounts WHERE id=:id AND isActive=1 AND isPosting=1 LIMIT 1") abstract suspend fun journalPostingAccountById(id: Long): AccountingAccount?
    @Query("SELECT * FROM accounting_expenses WHERE id=:id LIMIT 1") abstract suspend fun expenseById(id: Long): AccountingExpense?
    @Query("SELECT * FROM cash_accounts WHERE id=:id AND isActive=1 LIMIT 1") abstract suspend fun activeCashAccount(id: String): CashAccount?
    @Query("SELECT * FROM cash_account_ledger_mappings WHERE cashAccountId=:id LIMIT 1") abstract suspend fun dbCashMapping(id: String): CashAccountLedgerMapping?
    @Query("SELECT * FROM accounting_periods WHERE periodKey=:key LIMIT 1") abstract suspend fun periodByKey(key: String): AccountingPeriod?
    @Query("SELECT COALESCE(SUM(debitPiasters),0) FROM journal_lines WHERE accountId=:accountId") abstract suspend fun accountDebitTotal(accountId: Long): Long
    @Query("SELECT COALESCE(SUM(creditPiasters),0) FROM journal_lines WHERE accountId=:accountId") abstract suspend fun accountCreditTotal(accountId: Long): Long
    @Query("SELECT COALESCE(SUM(l.debitPiasters),0) FROM journal_lines l INNER JOIN accounting_accounts a ON a.id=l.accountId WHERE a.code=:rootCode OR a.parentId=(SELECT id FROM accounting_accounts WHERE code=:rootCode LIMIT 1)") abstract suspend fun cashRootDebitTotal(rootCode: String): Long
    @Query("SELECT COALESCE(SUM(l.creditPiasters),0) FROM journal_lines l INNER JOIN accounting_accounts a ON a.id=l.accountId WHERE a.code=:rootCode OR a.parentId=(SELECT id FROM accounting_accounts WHERE code=:rootCode LIMIT 1)") abstract suspend fun cashRootCreditTotal(rootCode: String): Long
    @Query("SELECT COUNT(*) FROM journal_entries e WHERE e.status='posted' AND (SELECT COALESCE(SUM(l.debitPiasters),0) FROM journal_lines l WHERE l.entryId=e.id) != (SELECT COALESCE(SUM(l.creditPiasters),0) FROM journal_lines l WHERE l.entryId=e.id)") abstract fun observeUnbalancedJournalCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM (SELECT sourceType,sourceId FROM journal_entries WHERE sourceType!='manual' AND sourceId!='' GROUP BY sourceType,sourceId HAVING COUNT(*)>1)") abstract fun observeDuplicateJournalSourceCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM journal_entries e WHERE e.status='posted' AND e.sourceType!='manual' AND e.sourceId!='' AND NOT EXISTS(SELECT 1 FROM accounting_source_posts p WHERE p.sourceType=e.sourceType AND p.sourceId=e.sourceId AND p.journalEntryId=e.id)") abstract fun observeJournalWithoutSourceCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM accounting_source_posts p LEFT JOIN journal_entries e ON e.id=p.journalEntryId WHERE e.id IS NULL") abstract fun observeOrphanSourcePostCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM accounting_expenses WHERE status NOT IN ('void','deleted') AND journalEntryId IS NULL") abstract fun observeExpensesWithoutJournalCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM accounting_expense_payments WHERE journalEntryId IS NULL") abstract fun observeExpensePaymentsWithoutJournalCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM cash_accounts c LEFT JOIN cash_account_ledger_mappings m ON m.cashAccountId=c.id WHERE c.isActive=1 AND m.id IS NULL") abstract fun observeActiveCashAccountsWithoutMappingCount(): Flow<Int>
    @Query("SELECT a.id AS accountId, a.code AS code, a.name AS name, a.type AS type, COALESCE(SUM(CASE WHEN e.status IN ('posted','reversed') THEN l.debitPiasters ELSE 0 END),0) AS debitPiasters, COALESCE(SUM(CASE WHEN e.status IN ('posted','reversed') THEN l.creditPiasters ELSE 0 END),0) AS creditPiasters FROM accounting_accounts a LEFT JOIN journal_lines l ON l.accountId=a.id LEFT JOIN journal_entries e ON e.id=l.entryId GROUP BY a.id,a.code,a.name,a.type ORDER BY a.code") abstract fun observeTrialBalance(): Flow<List<TrialBalanceRow>>
    @Query("SELECT * FROM journal_lines WHERE entryId = :entryId ORDER BY id") abstract suspend fun linesForEntry(entryId: Long): List<JournalLine>
    @Query("SELECT COALESCE(SUM(debitPiasters),0) FROM journal_lines WHERE entryId = :entryId") abstract suspend fun debitTotal(entryId: Long): Long
    @Query("SELECT COALESCE(SUM(creditPiasters),0) FROM journal_lines WHERE entryId = :entryId") abstract suspend fun creditTotal(entryId: Long): Long
    @Query("SELECT EXISTS(SELECT 1 FROM accounting_source_posts WHERE sourceType=:type AND sourceId=:sourceId)") abstract suspend fun alreadyPosted(type: String, sourceId: String): Boolean
    @Query("SELECT * FROM accounting_source_posts WHERE sourceType=:type AND sourceId=:sourceId LIMIT 1") abstract suspend fun sourcePost(type: String, sourceId: String): AccountingSourcePost?
    @Query("SELECT EXISTS(SELECT 1 FROM accounting_periods WHERE periodKey=:periodKey AND status='open')") abstract suspend fun isPeriodOpen(periodKey: String): Boolean
    @Query("SELECT EXISTS(SELECT 1 FROM accounting_accounts WHERE id=:accountId AND isActive=1 AND isPosting=1)") abstract suspend fun isPostingAccount(accountId: Long): Boolean
    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun insertPeriod(period: AccountingPeriod)
    @Insert abstract suspend fun insertVendor(vendor: AccountingVendor): Long
    @Update abstract suspend fun updateVendor(vendor: AccountingVendor)
    @Insert abstract suspend fun insertExpense(expense: AccountingExpense): Long
    @Insert abstract suspend fun insertExpensePayment(payment: AccountingExpensePayment): Long
    @Insert abstract suspend fun insertJournal(entry: JournalEntry): Long
    @Insert abstract suspend fun insertLines(lines: List<JournalLine>)
    @Insert abstract suspend fun insertSourcePost(post: AccountingSourcePost)
    @Query("UPDATE accounting_expenses SET paidPiasters=:paid, status=:status WHERE id=:id") abstract suspend fun updateExpensePaymentState(id: Long, paid: Long, status: String)
    @Update abstract suspend fun updateAccountingExpense(expense: AccountingExpense)
    @Query("UPDATE accounting_expenses SET journalEntryId=:entryId WHERE id=:id") abstract suspend fun setExpenseJournal(id: Long, entryId: Long)
    @Query("UPDATE accounting_expense_payments SET journalEntryId=:entryId WHERE id=:id") abstract suspend fun setExpensePaymentJournal(id: Long, entryId: Long)
    @Query("SELECT * FROM cash_accounts WHERE isActive=1 ORDER BY CASE WHEN id='cash' THEN 0 ELSE 1 END, name") abstract fun observeActiveCashAccounts(): Flow<List<CashAccount>>
    @Query("SELECT * FROM accounting_expenses WHERE status IN ('unpaid','partial') ORDER BY dueDate,id") abstract fun observeOutstandingExpenses(): Flow<List<AccountingExpense>>
    @Query("SELECT * FROM accounting_vendors WHERE id=:id LIMIT 1") abstract suspend fun vendorById(id: Long): AccountingVendor?
    @Query("SELECT * FROM accounting_vendors ORDER BY name") abstract suspend fun vendorSnapshot(): List<AccountingVendor>
    @Query("SELECT * FROM accounting_expenses ORDER BY documentDate,id") abstract suspend fun expenseSnapshot(): List<AccountingExpense>
    @Query("SELECT * FROM accounting_expense_payments ORDER BY paidAt,id") abstract suspend fun expensePaymentSnapshot(): List<AccountingExpensePayment>

    @Query("""
        SELECT COALESCE(SUM(e.amountPiasters),0) - COALESCE((
            SELECT SUM(p.amountPiasters) FROM accounting_expense_payments p
            INNER JOIN accounting_expenses pe ON pe.id=p.expenseId
            WHERE p.paidAt <= :asOf AND pe.documentDate <= :asOf AND pe.status NOT IN ('void','deleted')
        ),0)
        FROM accounting_expenses e
        WHERE e.documentDate <= :asOf AND e.status NOT IN ('void','deleted')
    """) abstract suspend fun supplierSubledgerBalanceAsOf(asOf: Long): Long

    @Query("""
        SELECT COALESCE(SUM(l.creditPiasters-l.debitPiasters),0)
        FROM journal_lines l INNER JOIN journal_entries e ON e.id=l.entryId
        WHERE l.accountId=(SELECT id FROM accounting_accounts WHERE code='2100' LIMIT 1)
          AND e.entryDate <= :asOf AND e.status IN ('posted','reversed')
    """) abstract suspend fun supplierControlBalanceAsOf(asOf: Long): Long

    @Query("""SELECT COUNT(*) FROM journal_entries e WHERE e.periodKey=:periodKey
        AND e.status IN ('posted','reversed')
        AND ((SELECT COUNT(*) FROM journal_lines l WHERE l.entryId=e.id)<2
          OR (SELECT COALESCE(SUM(l.debitPiasters),0) FROM journal_lines l WHERE l.entryId=e.id)<=0
          OR (SELECT COALESCE(SUM(l.debitPiasters),0) FROM journal_lines l WHERE l.entryId=e.id)
          != (SELECT COALESCE(SUM(l.creditPiasters),0) FROM journal_lines l WHERE l.entryId=e.id))""") abstract suspend fun periodUnbalancedEntries(periodKey: String): Int

    @Query("""SELECT COUNT(*) FROM journal_entries e WHERE e.periodKey=:periodKey AND e.sourceType!='manual' AND e.sourceId!=''
        AND (SELECT COUNT(*) FROM journal_entries x WHERE x.sourceType=e.sourceType AND x.sourceId=e.sourceId)>1""") abstract suspend fun periodDuplicateSources(periodKey: String): Int

    @Query("""SELECT COUNT(*) FROM journal_entries e WHERE e.periodKey=:periodKey AND e.status IN ('posted','reversed')
        AND e.sourceType!='manual' AND e.sourceId!=''
        AND NOT EXISTS(SELECT 1 FROM accounting_source_posts p WHERE p.sourceType=e.sourceType AND p.sourceId=e.sourceId AND p.journalEntryId=e.id)""") abstract suspend fun periodMissingSourceLinks(periodKey: String): Int

    /** Detects operational records that have no matching journal/source-post link in this month. */
    @Query("""
        SELECT
        (SELECT COUNT(*) FROM payments p
          WHERE p.isCancelled=0 AND p.amountPiasters>0
            AND p.createdAt BETWEEN (SELECT startDate FROM accounting_periods WHERE periodKey=:periodKey)
                                AND (SELECT endDate FROM accounting_periods WHERE periodKey=:periodKey)
            AND NOT EXISTS(SELECT 1 FROM accounting_source_posts sp
              WHERE sp.sourceType=CASE WHEN EXISTS(SELECT 1 FROM subscription_payments s WHERE s.paymentId=p.id)
                                       THEN 'subscription_receipt' ELSE 'manual_receipt' END
                AND sp.sourceId=CAST(p.id AS TEXT)))
        + (SELECT COUNT(*) FROM employee_payroll ep
          WHERE ep.monthKey=:periodKey AND ep.netPiasters>0
            AND NOT EXISTS(SELECT 1 FROM accounting_source_posts sp WHERE sp.sourceType='employee_payroll_accrual' AND sp.sourceId=CAST(ep.id AS TEXT)))
        + (SELECT COUNT(*) FROM employee_payroll_payments pp
          WHERE pp.status='active' AND substr(pp.paymentDate,1,7)=:periodKey AND pp.amountPiasters>0
            AND NOT EXISTS(SELECT 1 FROM accounting_source_posts sp WHERE sp.sourceType='employee_payroll_payment' AND sp.sourceId=CAST(pp.id AS TEXT)))
        + (SELECT COUNT(*) FROM employee_loans loan
          WHERE loan.issuedAt BETWEEN (SELECT startDate FROM accounting_periods WHERE periodKey=:periodKey)
                                  AND (SELECT endDate FROM accounting_periods WHERE periodKey=:periodKey)
            AND loan.issuedAt>0 AND loan.amountPiasters>0
            AND NOT EXISTS(SELECT 1 FROM accounting_source_posts sp WHERE sp.sourceType='employee_loan_issue' AND sp.sourceId=CAST(loan.id AS TEXT)))
        + (SELECT COUNT(*) FROM refund_transactions rt INNER JOIN refund_credits rc ON rc.id=rt.refundCreditId
          WHERE rt.refundedAt BETWEEN (SELECT startDate FROM accounting_periods WHERE periodKey=:periodKey)
                                 AND (SELECT endDate FROM accounting_periods WHERE periodKey=:periodKey)
            AND rt.amountPiasters>0
            AND NOT EXISTS(SELECT 1 FROM accounting_source_posts sp
              WHERE sp.sourceType=CASE WHEN rc.sourceType='exit_settlement' THEN 'exit_settlement_refund'
                                       WHEN rc.sourceType='manual_payment' THEN 'manual_refund' ELSE '' END
                AND sp.sourceId=CAST(rt.id AS TEXT)))
        + (SELECT COUNT(*) FROM cash_transfers ct
          WHERE ct.transferredAt BETWEEN (SELECT startDate FROM accounting_periods WHERE periodKey=:periodKey)
                                     AND (SELECT endDate FROM accounting_periods WHERE periodKey=:periodKey)
            AND ct.amountPiasters>0
            AND NOT EXISTS(SELECT 1 FROM accounting_source_posts sp WHERE sp.sourceType='cash_transfer' AND sp.sourceId=CAST(ct.id AS TEXT)))
        + (SELECT COUNT(*) FROM employee_payroll_reversals pr
          WHERE pr.createdAt BETWEEN (SELECT startDate FROM accounting_periods WHERE periodKey=:periodKey)
                                  AND (SELECT endDate FROM accounting_periods WHERE periodKey=:periodKey)
            AND pr.amountPiasters>0
            AND NOT EXISTS(SELECT 1 FROM accounting_source_posts sp WHERE sp.sourceType='employee_payroll_reversal' AND sp.sourceId=CAST(pr.id AS TEXT)))
        + (SELECT COUNT(*) FROM employee_payroll_recovery_transactions rr
          WHERE rr.receivedAt BETWEEN (SELECT startDate FROM accounting_periods WHERE periodKey=:periodKey)
                                   AND (SELECT endDate FROM accounting_periods WHERE periodKey=:periodKey)
            AND rr.amountPiasters>0
            AND NOT EXISTS(SELECT 1 FROM accounting_source_posts sp WHERE sp.sourceType='employee_payroll_recovery' AND sp.sourceId=CAST(rr.id AS TEXT)))
    """) abstract suspend fun periodMissingOperationalPosts(periodKey: String): Int

    @Query("SELECT COUNT(*) FROM accounting_source_posts p LEFT JOIN journal_entries e ON e.id=p.journalEntryId WHERE e.id IS NULL OR e.sourceType!=p.sourceType OR e.sourceId!=p.sourceId") abstract suspend fun orphanSourcePostCount(): Int

    @Query("""SELECT COUNT(*) FROM accounting_expenses x WHERE x.periodKey=:periodKey AND x.status NOT IN ('void','deleted')
        AND (x.amountPiasters<=0 OR x.journalEntryId IS NULL OR NOT EXISTS(
            SELECT 1 FROM journal_entries j WHERE j.id=x.journalEntryId AND j.status='posted'
            AND j.periodKey=x.periodKey AND j.sourceType='accounting_expense' AND j.sourceId=CAST(x.id AS TEXT)
            AND EXISTS(SELECT 1 FROM accounting_accounts a WHERE a.id=x.categoryAccountId AND a.type='expense' AND a.isActive=1 AND a.isPosting=1)
            AND (SELECT COALESCE(SUM(l.debitPiasters),0) FROM journal_lines l WHERE l.entryId=j.id AND l.accountId=x.categoryAccountId)=x.amountPiasters
            AND (SELECT COALESCE(SUM(l.creditPiasters),0) FROM journal_lines l WHERE l.entryId=j.id AND l.accountId=(SELECT id FROM accounting_accounts WHERE code='2100' LIMIT 1))=x.amountPiasters
            AND EXISTS(SELECT 1 FROM accounting_source_posts p WHERE p.journalEntryId=j.id AND p.sourceType=j.sourceType AND p.sourceId=j.sourceId)
        ))""") abstract suspend fun periodInvalidInvoices(periodKey: String): Int

    @Query("""SELECT COUNT(*) FROM accounting_expenses x
        WHERE x.periodKey=:periodKey AND x.status NOT IN ('void','deleted')
          AND TRIM(x.documentNo)!=''
          AND EXISTS(SELECT 1 FROM accounting_expenses y
              WHERE y.id<x.id AND y.status NOT IN ('void','deleted')
                AND y.vendorId IS x.vendorId
                AND LOWER(TRIM(y.documentNo))=LOWER(TRIM(x.documentNo)))""") abstract suspend fun periodPossibleDuplicateInvoices(periodKey: String): Int

    @Query("""SELECT COUNT(*) FROM accounting_expense_payments p
        INNER JOIN accounting_expenses x ON x.id=p.expenseId
        LEFT JOIN journal_entries j ON j.id=p.journalEntryId
        LEFT JOIN cash_account_ledger_mappings m ON m.cashAccountId=p.cashAccountId
        WHERE p.paidAt BETWEEN (SELECT startDate FROM accounting_periods WHERE periodKey=:periodKey)
                           AND (SELECT endDate FROM accounting_periods WHERE periodKey=:periodKey)
          AND (
            p.amountPiasters<=0 OR x.status IN ('void','deleted') OR p.journalEntryId IS NULL OR j.id IS NULL OR j.status!='posted'
            OR j.periodKey!=:periodKey OR m.ledgerAccountId IS NULL
            OR j.sourceType!='accounting_expense_payment' OR j.sourceId!=CAST(p.id AS TEXT)
            OR NOT EXISTS(SELECT 1 FROM accounting_source_posts sp WHERE sp.sourceType=j.sourceType AND sp.sourceId=j.sourceId AND sp.journalEntryId=j.id)
            OR (SELECT COALESCE(SUM(l.debitPiasters),0) FROM journal_lines l WHERE l.entryId=j.id AND l.accountId=(SELECT id FROM accounting_accounts WHERE code='2100' LIMIT 1))!=p.amountPiasters
            OR (SELECT COALESCE(SUM(l.creditPiasters),0) FROM journal_lines l WHERE l.entryId=j.id AND l.accountId=m.ledgerAccountId)!=p.amountPiasters
            OR (SELECT COALESCE(SUM(px.amountPiasters),0) FROM accounting_expense_payments px WHERE px.expenseId=x.id)>x.amountPiasters
          )""") abstract suspend fun periodInvalidPayments(periodKey: String): Int

    @Query("""SELECT COUNT(*) FROM accounting_expenses x LEFT JOIN accounting_vendors v ON v.id=x.vendorId
        WHERE x.periodKey=:periodKey AND x.status NOT IN ('void','deleted') AND (x.vendorId IS NULL OR v.id IS NULL)""") abstract suspend fun periodMissingVendorLinks(periodKey: String): Int

    @Query("SELECT COUNT(*) FROM cash_statement_lines WHERE periodKey=:periodKey AND matchedJournalLineId IS NULL") abstract suspend fun periodUnmatchedStatementLines(periodKey: String): Int

    @Query("""SELECT COUNT(*) FROM cash_statement_lines s
        WHERE s.periodKey=:periodKey AND TRIM(s.reference)!=''
          AND EXISTS(SELECT 1 FROM cash_statement_lines x WHERE x.id<s.id
            AND x.cashAccountId=s.cashAccountId AND x.periodKey=s.periodKey
            AND LOWER(TRIM(x.reference))=LOWER(TRIM(s.reference))
            AND x.statementDate=s.statementDate
            AND x.debitPiasters=s.debitPiasters AND x.creditPiasters=s.creditPiasters)""") abstract suspend fun periodDuplicateStatementReferences(periodKey: String): Int

    @Query("""SELECT COUNT(*) FROM cash_accounts c INNER JOIN cash_account_ledger_mappings m ON m.cashAccountId=c.id
        INNER JOIN journal_lines l ON l.accountId=m.ledgerAccountId INNER JOIN journal_entries e ON e.id=l.entryId
        WHERE c.isActive=1 AND c.type!='cash' AND e.periodKey=:periodKey AND e.status='posted'
        AND NOT EXISTS(SELECT 1 FROM cash_statement_lines s WHERE s.matchedJournalLineId=l.id)""") abstract suspend fun periodUnmatchedBankBookLines(periodKey: String): Int

    @Query("""SELECT COUNT(*) FROM cash_accounts c INNER JOIN cash_account_ledger_mappings m ON m.cashAccountId=c.id
        WHERE c.isActive=1 AND c.type!='cash'
        AND EXISTS(SELECT 1 FROM journal_lines l INNER JOIN journal_entries e ON e.id=l.entryId WHERE l.accountId=m.ledgerAccountId AND e.periodKey=:periodKey AND e.status='posted')
        AND NOT EXISTS(SELECT 1 FROM cash_statement_balances b WHERE b.cashAccountId=c.id AND b.periodKey=:periodKey)""") abstract suspend fun periodBankAccountsWithoutStatements(periodKey: String): Int

    @Query("""SELECT COUNT(*) FROM cash_statement_balances b
        INNER JOIN cash_accounts c ON c.id=b.cashAccountId
        INNER JOIN cash_account_ledger_mappings m ON m.cashAccountId=c.id
        WHERE b.periodKey=:periodKey AND c.isActive=1 AND c.type!='cash'
          AND b.closingBalancePiasters != (SELECT COALESCE(SUM(l.debitPiasters-l.creditPiasters),0)
              FROM journal_lines l INNER JOIN journal_entries e ON e.id=l.entryId
              WHERE l.accountId=m.ledgerAccountId
                AND e.entryDate <= (SELECT endDate FROM accounting_periods WHERE periodKey=:periodKey)
                AND e.status IN ('posted','reversed'))""") abstract suspend fun periodBankStatementBalanceDifferences(periodKey: String): Int

    @Query("""SELECT COUNT(*) FROM cash_statement_balances b
        INNER JOIN cash_accounts c ON c.id=b.cashAccountId
        WHERE b.periodKey=:periodKey AND c.isActive=1 AND c.type!='cash'
          AND (b.closingBalancePiasters-b.openingBalancePiasters) !=
              (SELECT COALESCE(SUM(s.debitPiasters-s.creditPiasters),0)
                 FROM cash_statement_lines s WHERE s.cashAccountId=b.cashAccountId AND s.periodKey=b.periodKey)""") abstract suspend fun periodBankStatementMovementDifferences(periodKey: String): Int

    @Query("SELECT COUNT(*) FROM cash_accounts c LEFT JOIN cash_account_ledger_mappings m ON m.cashAccountId=c.id WHERE c.isActive=1 AND m.id IS NULL") abstract suspend fun activeCashAccountsWithoutMapping(): Int

    @Query("""SELECT COUNT(*) FROM cash_accounts c INNER JOIN cash_account_ledger_mappings m ON m.cashAccountId=c.id
        WHERE c.isActive=1 AND c.type='cash'
        AND EXISTS(SELECT 1 FROM journal_lines l INNER JOIN journal_entries e ON e.id=l.entryId WHERE l.accountId=m.ledgerAccountId AND e.periodKey=:periodKey AND e.status='posted')
        AND NOT EXISTS(SELECT 1 FROM cash_counts cc WHERE cc.accountId=c.id AND cc.countedAt BETWEEN
            (SELECT startDate FROM accounting_periods WHERE periodKey=:periodKey) AND
            (SELECT endDate FROM accounting_periods WHERE periodKey=:periodKey))""") abstract suspend fun periodCashAccountsWithoutCounts(periodKey: String): Int

    @Query("""SELECT COUNT(*) FROM cash_accounts c INNER JOIN cash_account_ledger_mappings m ON m.cashAccountId=c.id
        INNER JOIN cash_counts cc ON cc.accountId=c.id
        WHERE c.isActive=1 AND c.type='cash'
          AND cc.countedAt BETWEEN (SELECT startDate FROM accounting_periods WHERE periodKey=:periodKey)
                               AND (SELECT endDate FROM accounting_periods WHERE periodKey=:periodKey)
          AND cc.id=(SELECT cc2.id FROM cash_counts cc2 WHERE cc2.accountId=c.id
              AND cc2.countedAt BETWEEN (SELECT startDate FROM accounting_periods WHERE periodKey=:periodKey)
                                    AND (SELECT endDate FROM accounting_periods WHERE periodKey=:periodKey)
              ORDER BY cc2.countedAt DESC, cc2.id DESC LIMIT 1)
          AND cc.actualAmountPiasters != (SELECT COALESCE(SUM(l.debitPiasters-l.creditPiasters),0)
              FROM journal_lines l INNER JOIN journal_entries e ON e.id=l.entryId
              WHERE l.accountId=m.ledgerAccountId AND e.entryDate<=cc.countedAt AND e.status IN ('posted','reversed'))""") abstract suspend fun periodCashCountDifferences(periodKey: String): Int

    @Insert abstract suspend fun insertCloseAudit(audit: FinancialPeriodCloseAudit): Long
    @Query("UPDATE accounting_periods SET status='closed', closedAt=:closedAt, note=:note WHERE periodKey=:periodKey AND status='open'") abstract suspend fun closePeriodRow(periodKey: String, closedAt: Long, note: String): Int
    @Query("UPDATE accounting_periods SET status='open', closedAt=NULL, note=:note WHERE periodKey=:periodKey AND status='closed'") abstract suspend fun reopenPeriodRow(periodKey: String, note: String): Int
    @Query("UPDATE journal_entries SET status='reversed', reversedEntryId=:reversalId WHERE id=:entryId AND status='posted'") abstract suspend fun markEntryReversed(entryId: Long, reversalId: Long): Int
    @Query("SELECT * FROM journal_entries WHERE id=:id LIMIT 1") abstract suspend fun journalById(id: Long): JournalEntry?
    @Query("SELECT * FROM accounting_periods WHERE status='open' ORDER BY startDate") abstract fun observeOpenPeriods(): Flow<List<AccountingPeriod>>
    @Query("SELECT l.*, a.code AS accountCode, a.name AS accountName, e.entryDate AS entryDate, e.entryNo AS entryNo, e.description AS description FROM journal_lines l INNER JOIN journal_entries e ON e.id=l.entryId INNER JOIN accounting_accounts a ON a.id=l.accountId WHERE l.accountId=:accountId AND e.status IN ('posted','reversed') ORDER BY e.entryDate,e.id,l.id") abstract fun observeAccountLedger(accountId: Long): Flow<List<AccountLedgerRow>>
    @Query("SELECT COUNT(*) FROM journal_entries WHERE periodKey=:periodKey AND status='posted'") abstract suspend fun postedEntriesInPeriod(periodKey: String): Int
    @Query("SELECT COUNT(*) FROM accounting_expenses WHERE periodKey=:periodKey AND status IN ('unpaid','partial')") abstract suspend fun outstandingInvoicesInPeriod(periodKey: String): Int

    @Transaction
    open suspend fun postJournal(entry: JournalEntry, drafts: List<JournalLineDraft>): Long {
        require(drafts.size >= 2) { "القيد يجب أن يحتوي على سطرين على الأقل" }
        require(isPeriodOpen(entry.periodKey)) { "الفترة المحاسبية غير موجودة أو مغلقة" }
        require(drafts.all { isPostingAccount(it.accountId) }) { "يحتوي القيد على حساب غير نشط أو غير قابل للترحيل" }
        require(drafts.all { it.debitPiasters >= 0 && it.creditPiasters >= 0 && (it.debitPiasters == 0L) != (it.creditPiasters == 0L) }) { "كل سطر يجب أن يكون مدينًا أو دائنًا فقط وبقيمة موجبة" }
        val debit = drafts.fold(0L) { total, line -> Math.addExact(total, line.debitPiasters) }
        val credit = drafts.fold(0L) { total, line -> Math.addExact(total, line.creditPiasters) }
        require(debit > 0 && debit == credit) { "القيد غير متوازن: إجمالي المدين يجب أن يساوي إجمالي الدائن" }
        if (entry.sourceType != "manual" && entry.sourceId.isNotBlank()) require(!alreadyPosted(entry.sourceType, entry.sourceId)) { "تم ترحيل هذه العملية من قبل" }
        val id = insertJournal(entry)
        insertLines(drafts.map { JournalLine(entryId = id, accountId = it.accountId, debitPiasters = it.debitPiasters, creditPiasters = it.creditPiasters, memo = it.memo) })
        if (entry.sourceType != "manual" && entry.sourceId.isNotBlank()) insertSourcePost(AccountingSourcePost(sourceType = entry.sourceType, sourceId = entry.sourceId, journalEntryId = id))
        return id
    }

    /** Record a real partial/full settlement. The cash credit is posted only for the amount actually paid. */
    @Transaction
    open suspend fun recordExpensePayment(expenseId: Long, amountPiasters: Long, cashAccountId: String, method: String, paidAt: Long = System.currentTimeMillis(), note: String = ""): Long {
        require(amountPiasters > 0L) { "قيمة الدفعة يجب أن تكون أكبر من صفر" }
        val expense = expenseById(expenseId) ?: throw IllegalArgumentException("الفاتورة غير موجودة")
        require(expense.status == "unpaid" || expense.status == "partial") { "الفاتورة غير قابلة للسداد" }
        val remaining = expense.amountPiasters - expense.paidPiasters
        require(amountPiasters <= remaining) { "قيمة الدفعة أكبر من المتبقي" }
        val cash = activeCashAccount(cashAccountId) ?: throw IllegalArgumentException("حساب الخزينة غير موجود أو غير نشط")
        val periodKey = java.time.Instant.ofEpochMilli(paidAt).atZone(java.time.ZoneId.systemDefault()).toLocalDate().let { java.time.YearMonth.from(it).toString() }
        require(isPeriodOpen(periodKey)) { "فترة السداد غير مفتوحة" }
        val paymentId = insertExpensePayment(AccountingExpensePayment(expenseId=expenseId, amountPiasters=amountPiasters, paidAt=paidAt, cashAccountId=cashAccountId, method=method, note=note))
        val entryId = FinancialTransactionEngine(db).postAccountingExpensePayment(paymentId, expense, amountPiasters, cashAccountId, paidAt)
        setExpensePaymentJournal(paymentId, entryId)
        val newPaid = expense.paidPiasters + amountPiasters
        updateExpensePaymentState(expenseId, newPaid, if (newPaid == expense.amountPiasters) "paid" else "partial")
        return paymentId
    }

    /** Edit an accrued invoice without erasing its original posting or any settled payment.
     * The old accrual is reversed and a fresh balanced accrual is posted in the same open period.
     */
    @Transaction
    open suspend fun reviseAccruedExpense(expenseId: Long, newTitle: String, newAmountPiasters: Long, newCategoryAccountId: Long, reason: String): Long {
        require(newTitle.isNotBlank()) { "بيان المصروف مطلوب" }
        require(newAmountPiasters > 0L) { "قيمة الفاتورة يجب أن تكون أكبر من صفر" }
        require(reason.isNotBlank()) { "سبب التعديل مطلوب" }
        val old = expenseById(expenseId) ?: throw IllegalArgumentException("الفاتورة غير موجودة")
        require(old.status !in listOf("void", "deleted")) { "لا يمكن تعديل فاتورة ملغاة أو محذوفة" }
        require(newAmountPiasters >= old.paidPiasters) { "لا يمكن جعل قيمة الفاتورة أقل من إجمالي ما تم دفعه" }
        require(isPeriodOpen(old.periodKey)) { "فترة الفاتورة مغلقة؛ أعد فتحها أولًا" }
        val expenseAccount = accountByIdForPosting(newCategoryAccountId)
            ?: throw IllegalArgumentException("حساب المصروف غير نشط أو غير قابل للترحيل")
        require(expenseAccount.type == "expense") { "يجب اختيار حساب من نوع المصروفات" }
        val originalEntryId = old.journalEntryId ?: throw IllegalStateException("القيد الأصلي للفاتورة غير موجود")
        val payable = accountByCode("2100") ?: throw IllegalStateException("حساب الموردين والمصروفات المستحقة غير موجود")
        val now = System.currentTimeMillis()
        reverseJournal(originalEntryId, old.documentDate, "تعديل الفاتورة #$expenseId: $reason")
        val revised = old.copy(title = newTitle.trim(), amountPiasters = newAmountPiasters,
            categoryAccountId = newCategoryAccountId,
            status = when { old.paidPiasters == 0L -> "unpaid"; old.paidPiasters >= newAmountPiasters -> "paid"; else -> "partial" })
        updateAccountingExpense(revised)
        val newEntryId = postJournal(
            JournalEntry(entryNo="EXP-EDIT-$expenseId-$now", entryDate=old.documentDate, periodKey=old.periodKey,
                description="إعادة إثبات فاتورة بعد التعديل #$expenseId — $reason", sourceType="accounting_expense_revision", sourceId="$expenseId-$now"),
            listOf(
                JournalLineDraft(newCategoryAccountId, debitPiasters=newAmountPiasters, memo="مصروف معدل: ${newTitle.trim()}"),
                JournalLineDraft(payable.id, creditPiasters=newAmountPiasters, memo="استحقاق الفاتورة المعدلة")
            )
        )
        updateAccountingExpense(revised.copy(journalEntryId=newEntryId))
        return newEntryId
    }

    /** Cancel an unpaid invoice through a full reversing journal; never erase history. */
    @Transaction
    open suspend fun voidAccruedExpense(expenseId: Long, reason: String): Long {
        require(reason.isNotBlank()) { "سبب الإلغاء مطلوب" }
        val expense = expenseById(expenseId) ?: throw IllegalArgumentException("الفاتورة غير موجودة")
        require(expense.status !in listOf("void", "deleted")) { "الفاتورة ملغاة أو محذوفة بالفعل" }
        require(expense.paidPiasters == 0L) { "لا يمكن إلغاء فاتورة سُدد منها مبلغ؛ سجّل استرداد المبلغ أولًا" }
        require(isPeriodOpen(expense.periodKey)) { "فترة الفاتورة مغلقة؛ أعد فتحها أولًا" }
        val entryId = expense.journalEntryId ?: throw IllegalStateException("القيد الأصلي للفاتورة غير موجود")
        val reversalId = reverseJournal(entryId, expense.documentDate, "إلغاء الفاتورة #$expenseId: $reason")
        updateAccountingExpense(expense.copy(status="void"))
        return reversalId
    }

    /** Logical deletion is allowed only for an unpaid invoice; the invoice and reversal remain auditable. */
    @Transaction
    open suspend fun deleteAccruedExpense(expenseId: Long, reason: String): Long {
        require(reason.isNotBlank()) { "سبب الحذف مطلوب" }
        val expense = expenseById(expenseId) ?: throw IllegalArgumentException("الفاتورة غير موجودة")
        require(expense.status !in listOf("void", "deleted")) { "الفاتورة ملغاة أو محذوفة بالفعل" }
        require(expense.paidPiasters == 0L) { "لا يمكن حذف فاتورة سُدد منها مبلغ؛ استخدم الإلغاء بعد تسوية المبلغ" }
        require(isPeriodOpen(expense.periodKey)) { "فترة الفاتورة مغلقة؛ أعد فتحها أولًا" }
        val entryId = expense.journalEntryId ?: throw IllegalStateException("القيد الأصلي للفاتورة غير موجود")
        val reversalId = reverseJournal(entryId, expense.documentDate, "حذف آمن للفاتورة #$expenseId: $reason")
        updateAccountingExpense(expense.copy(status="deleted"))
        return reversalId
    }

    /** Creates the current calendar month only when it does not already exist. */
    @Transaction
    open suspend fun ensurePeriod(periodKey: String, startDate: Long, endDate: Long) {
        if (periodByKey(periodKey) == null) insertPeriod(AccountingPeriod(periodKey, startDate, endDate))
    }

    /** Record an accrued expense: Dr expense / Cr supplier payable. No cash movement is fabricated. */
    @Transaction
    open suspend fun recordAccruedExpense(expense: AccountingExpense): Long {
        require(expense.amountPiasters > 0L) { "قيمة الفاتورة يجب أن تكون أكبر من صفر" }
        require(expense.paidPiasters == 0L) { "تسجيل الفاتورة يتم أولاً كاستحقاق، ثم تسجل الدفعات منفصلة" }
        require(expense.status == "unpaid") { "حالة الفاتورة الأولية غير صحيحة" }
        require(isPeriodOpen(expense.periodKey)) { "الفترة المحاسبية غير موجودة أو مغلقة" }
        val expenseAccount = accountByIdForPosting(expense.categoryAccountId)
            ?: throw IllegalArgumentException("حساب المصروف غير نشط أو غير قابل للترحيل")
        require(expenseAccount.type == "expense") { "يجب اختيار حساب من نوع المصروفات" }
        val id = insertExpense(expense)
        val entryId = FinancialTransactionEngine(db).postAccruedExpense(id, expense.copy(id = id))
        setExpenseJournal(id, entryId)
        return id
    }

    @Query("SELECT * FROM accounting_accounts WHERE id=:id AND isActive=1 AND isPosting=1 LIMIT 1")
    public abstract suspend fun accountByIdForPosting(id: Long): AccountingAccount?

    /** Financial close is blocked by unreconciled control balances or incomplete posting trails. */
    @Transaction
    open suspend fun closePeriod(periodKey: String, note: String = ""): Boolean {
        val period = periodByKey(periodKey) ?: error("الفترة المحاسبية غير موجودة")
        require(period.status == "open") { "الفترة مغلقة بالفعل" }
        val asOf = period.endDate
        val vendorSubledger = supplierSubledgerBalanceAsOf(asOf)
        val vendorControl = supplierControlBalanceAsOf(asOf)
        val unbalanced = periodUnbalancedEntries(periodKey)
        val duplicates = periodDuplicateSources(periodKey)
        val missingSources = periodMissingSourceLinks(periodKey)
        val missingOperationalPosts = periodMissingOperationalPosts(periodKey)
        val orphanPosts = orphanSourcePostCount()
        val invalidInvoices = periodInvalidInvoices(periodKey)
        val duplicateInvoices = periodPossibleDuplicateInvoices(periodKey)
        val invalidPayments = periodInvalidPayments(periodKey)
        val missingVendors = periodMissingVendorLinks(periodKey)
        val unmatchedStatements = periodUnmatchedStatementLines(periodKey)
        val duplicateStatementReferences = periodDuplicateStatementReferences(periodKey)
        val unmatchedBook = periodUnmatchedBankBookLines(periodKey)
        val bankAccountsWithoutStatements = periodBankAccountsWithoutStatements(periodKey)
        val bankBalanceDifferences = periodBankStatementBalanceDifferences(periodKey)
        val bankMovementDifferences = periodBankStatementMovementDifferences(periodKey)
        val unmappedCash = activeCashAccountsWithoutMapping()
        val cashAccountsWithoutCounts = periodCashAccountsWithoutCounts(periodKey)
        val cashCountDifferences = periodCashCountDifferences(periodKey)
        val vendorDifference = Math.subtractExact(vendorSubledger, vendorControl)
        val blockers = mutableListOf<String>()
        if (unbalanced > 0) blockers += "قيود غير متوازنة: $unbalanced"
        if (duplicates > 0) blockers += "مصادر مالية مكررة: $duplicates"
        if (missingSources > 0) blockers += "قيود بلا مرجع ترحيل: $missingSources"
        if (missingOperationalPosts > 0) blockers += "عمليات مالية بلا قيود محاسبية: $missingOperationalPosts"
        if (orphanPosts > 0) blockers += "مراجع ترحيل يتيمة: $orphanPosts"
        if (invalidInvoices > 0) blockers += "فواتير بلا قيد استحقاق سليم: $invalidInvoices"
        if (duplicateInvoices > 0) blockers += "أرقام فواتير مكررة لدى الموردين: $duplicateInvoices"
        if (invalidPayments > 0) blockers += "دفعات بلا قيد سداد سليم: $invalidPayments"
        if (missingVendors > 0) blockers += "فواتير بلا مورد محدد: $missingVendors"
        if (unmatchedStatements > 0) blockers += "بنود كشف بنك غير مطابقة: $unmatchedStatements"
        if (duplicateStatementReferences > 0) blockers += "مراجع كشف بنك مكررة محتملة: $duplicateStatementReferences"
        if (unmatchedBook > 0) blockers += "حركات بنك بلا كشف مطابق: $unmatchedBook"
        if (bankAccountsWithoutStatements > 0) blockers += "حسابات بنكية بلا كشف للفترة: $bankAccountsWithoutStatements"
        if (bankBalanceDifferences > 0) blockers += "فروق أرصدة كشف البنك عن الأستاذ: $bankBalanceDifferences"
        if (bankMovementDifferences > 0) blockers += "حركة كشف البنك لا تطابق رصيدي أول وآخر الفترة: $bankMovementDifferences"
        if (unmappedCash > 0) blockers += "حسابات نقدية بلا ربط أستاذ: $unmappedCash"
        if (cashAccountsWithoutCounts > 0) blockers += "خزائن لم تسجل جردًا فعليًا: $cashAccountsWithoutCounts"
        if (cashCountDifferences > 0) blockers += "فروق جرد الخزائن عن الأستاذ: $cashCountDifferences"
        if (vendorDifference != 0L) blockers += "فرق دفتر الموردين عن حساب 2100: $vendorDifference قرش"
        require(blockers.isEmpty()) { "تعذر إقفال $periodKey:\n${blockers.joinToString("\n")}" }
        val now = System.currentTimeMillis()
        val closed = closePeriodRow(periodKey, now, note.trim()) == 1
        if (closed) insertCloseAudit(FinancialPeriodCloseAudit(
            periodKey = periodKey, closedAt = now, note = note.trim(),
            vendorSubledgerPiasters = vendorSubledger, vendorControlPiasters = vendorControl,
            vendorDifferencePiasters = vendorDifference, unbalancedEntries = unbalanced,
            duplicateSources = duplicates, missingSourceLinks = missingSources,
            invalidInvoices = invalidInvoices, invalidPayments = invalidPayments,
            possibleDuplicateInvoices = duplicateInvoices,
            missingVendorLinks = missingVendors, unmatchedStatementLines = unmatchedStatements,
            duplicateStatementReferences = duplicateStatementReferences,
            unmatchedBankBookLines = unmatchedBook, bankAccountsWithoutStatements = bankAccountsWithoutStatements,
            bankStatementBalanceDifferences = bankBalanceDifferences,
            bankStatementMovementDifferences = bankMovementDifferences, unmappedCashAccounts = unmappedCash, cashAccountsWithoutCounts = cashAccountsWithoutCounts,
            cashCountDifferences = cashCountDifferences, missingOperationalPosts = missingOperationalPosts
        ))
        return closed
    }

    @Transaction
    open suspend fun reopenPeriod(periodKey: String, note: String): Boolean {
        require(note.isNotBlank()) { "اكتب سبب إعادة فتح الفترة" }
        require(periodByKey(periodKey)?.status == "closed") { "الفترة غير مغلقة" }
        return reopenPeriodRow(periodKey, note) == 1
    }

    /** Reverse a posted journal by creating a separate equal-and-opposite entry. */
    /** Opening balances are posted once as a balanced journal at the approved cut-off date. */
    @Transaction
    open suspend fun postOpeningBalances(cutoffDate: Long, drafts: List<JournalLineDraft>, approvalNote: String): Long {
        require(approvalNote.isNotBlank()) { "اعتماد الأرصدة الافتتاحية ومصدرها مطلوب" }
        val periodKey = java.time.Instant.ofEpochMilli(cutoffDate).atZone(java.time.ZoneId.systemDefault()).toLocalDate().let { java.time.YearMonth.from(it).toString() }
        require(!alreadyPosted("opening_balances", periodKey)) { "تم تسجيل الأرصدة الافتتاحية لهذه الفترة من قبل" }
        return postJournal(
            JournalEntry(entryNo="OPEN-$periodKey", entryDate=cutoffDate, periodKey=periodKey,
                description="الأرصدة الافتتاحية المعتمدة: $approvalNote", sourceType="opening_balances", sourceId=periodKey),
            drafts
        )
    }

    @Transaction
    open suspend fun reverseJournal(entryId: Long, reversalDate: Long, reason: String): Long {
        require(reason.isNotBlank()) { "سبب العكس مطلوب" }
        val original = journalById(entryId) ?: throw IllegalArgumentException("القيد غير موجود")
        require(original.status == "posted") { "القيد ليس مرحلاً أو سبق عكسه" }
        val periodKey = java.time.Instant.ofEpochMilli(reversalDate).atZone(java.time.ZoneId.systemDefault()).toLocalDate().let { java.time.YearMonth.from(it).toString() }
        require(isPeriodOpen(periodKey)) { "فترة العكس غير مفتوحة" }
        val lines = linesForEntry(entryId)
        require(lines.size >= 2) { "القيد الأصلي غير مكتمل" }
        val reversalId = postJournal(
            JournalEntry(entryNo="REV-$entryId-${System.currentTimeMillis()}", entryDate=reversalDate, periodKey=periodKey,
                description="عكس القيد ${original.entryNo}: $reason", sourceType="reversal", sourceId=entryId.toString()),
            lines.map { JournalLineDraft(it.accountId, debitPiasters=it.creditPiasters, creditPiasters=it.debitPiasters, memo="عكس: ${it.memo}") }
        )
        check(markEntryReversed(entryId, reversalId) == 1) { "تعذر تثبيت حالة القيد الأصلي بعد إنشاء القيد العكسي" }
        return reversalId
    }

    companion object {
        val DEFAULT_CHART = listOf(
            AccountingAccount(code="1000", name="الأصول", type="asset", isPosting=false),
            AccountingAccount(code="1100", name="الخزينة", type="asset"),
            AccountingAccount(code="1110", name="البنوك والمحافظ", type="asset"),
            AccountingAccount(code="1210", name="سلف وعهد الموظفين", type="asset"),
            AccountingAccount(code="1200", name="ذمم أولياء الأمور", type="asset"),
            AccountingAccount(code="2000", name="الالتزامات", type="liability", isPosting=false),
            AccountingAccount(code="2100", name="الموردون والمصروفات المستحقة", type="liability"),
            AccountingAccount(code="2200", name="مرتبات مستحقة", type="liability"),
            AccountingAccount(code="3000", name="حقوق الملكية", type="equity", isPosting=false),
            AccountingAccount(code="3100", name="رأس المال والأرصدة الافتتاحية", type="equity"),
            AccountingAccount(code="4000", name="الإيرادات", type="revenue", isPosting=false),
            AccountingAccount(code="4100", name="إيرادات الاشتراكات", type="revenue"),
            AccountingAccount(code="5000", name="المصروفات", type="expense", isPosting=false),
            AccountingAccount(code="5100", name="مصروفات تشغيلية", type="expense"),
            AccountingAccount(code="5200", name="مصروف المرتبات", type="expense")
        )
    }
}
