package com.tahseel.students.data

/** عمليات حساسة تُفرض صلاحياتها في طبقة المنطق (ViewModel/Repository) لا في الواجهة وحدها. */
enum class Permission {
    PAYMENT_CANCEL,      // إلغاء تحصيل (أي تاريخ)
    PAYMENT_CANCEL_SAME_DAY, // إلغاء إيصال اليوم نفسه بسبب إلزامي (D3)
    REFUND_REQUEST,      // إنشاء رصيد استرداد (طلب)
    REFUND_PAY,          // اعتماد وصرف الاسترداد
    PAYROLL_PREPARE,     // إعداد كشف المرتبات
    PAYROLL_PAY,         // صرف دفعة مرتب
    PAYROLL_REVERSE,     // إلغاء/تصحيح/عكس دفعة مرتب
    PAYROLL_RECOVERY,    // تحصيل مديونية موظف بعد العكس
    STOCKTAKE_SAVE,      // تسجيل الجرد الفعلي
    DATA_EXPORT,         // تصدير بيانات
    PERIOD_CLOSE,        // إقفال الفترات الشهرية
    BACKUP_CREATE,
    BACKUP_RESTORE,
    USER_MANAGE,
    STUDENT_EXIT_MANAGE  // تسوية الانسحاب وصرفها وتصحيحها وإلغاؤها (ADMIN فقط)
}

/**
 * السياسة المركزية. نقية (بلا Android) لتُختبر على JVM.
 * الأدوار مخزنة كنص في app_users.role ولا تتغير؛ لا هجرة في قاعدة البيانات.
 */
object PermissionPolicy {
    /**
     * false = وضع المراقبة: كل عملية سترفضها السياسة تُسجَّل في user_activity_logs ولا تُمنع.
     * true  = الفرض الفعلي. لا يُفعَّل إلا بعد نجاح الاختبارات ومراجعة سجل المراقبة.
     */
    @Volatile var enforcing: Boolean = false

    private val grants: Map<Permission, Set<String>> = mapOf(
        Permission.PAYMENT_CANCEL to setOf(UserRoles.ADMIN, UserRoles.FINANCE_MANAGER),
        Permission.PAYMENT_CANCEL_SAME_DAY to setOf(UserRoles.ADMIN, UserRoles.FINANCE_MANAGER, UserRoles.ACCOUNTANT, UserRoles.CASHIER, UserRoles.RECEPTION),
        Permission.REFUND_REQUEST to setOf(UserRoles.ADMIN, UserRoles.FINANCE_MANAGER, UserRoles.CASHIER),
        Permission.REFUND_PAY to setOf(UserRoles.ADMIN, UserRoles.FINANCE_MANAGER),
        Permission.PAYROLL_PREPARE to setOf(UserRoles.ADMIN, UserRoles.FINANCE_MANAGER, UserRoles.HR),
        Permission.PAYROLL_PAY to setOf(UserRoles.ADMIN, UserRoles.FINANCE_MANAGER),
        Permission.PAYROLL_REVERSE to setOf(UserRoles.ADMIN, UserRoles.FINANCE_MANAGER),
        Permission.PAYROLL_RECOVERY to setOf(UserRoles.ADMIN, UserRoles.FINANCE_MANAGER),
        Permission.STOCKTAKE_SAVE to setOf(UserRoles.ADMIN, UserRoles.FINANCE_MANAGER, UserRoles.ACCOUNTANT),
        Permission.DATA_EXPORT to setOf(UserRoles.ADMIN, UserRoles.FINANCE_MANAGER, UserRoles.ACCOUNTANT),
        Permission.PERIOD_CLOSE to setOf(UserRoles.ADMIN, UserRoles.FINANCE_MANAGER),
        Permission.BACKUP_CREATE to setOf(UserRoles.ADMIN),
        Permission.BACKUP_RESTORE to setOf(UserRoles.ADMIN),
        Permission.USER_MANAGE to setOf(UserRoles.ADMIN),
        Permission.STUDENT_EXIT_MANAGE to setOf(UserRoles.ADMIN)
    )

    /** هل تسمح السياسة للدور بهذه العملية؟ دور مجهول أو غائب = لا. ADMIN مسموح له دائمًا. */
    fun can(role: String?, permission: Permission): Boolean {
        if (role == null) return false
        if (role == UserRoles.ADMIN) return true
        return grants[permission]?.contains(role) == true
    }

    fun rolesFor(permission: Permission): Set<String> = grants[permission].orEmpty()

    /**
     * إلغاء إيصال بدون صلاحية الإلغاء الكاملة: مسموح فقط لإيصال اليوم نفسه وبسبب غير فارغ (D3).
     * تاريخ الإيصال مجهول (null) = غير مسموح.
     */
    fun canCancelPaymentSameDay(
        role: String?, paymentCreatedAt: Long?, nowMillis: Long, reason: String,
        zone: java.time.ZoneId = java.time.ZoneId.systemDefault()
    ): Boolean {
        if (!can(role, Permission.PAYMENT_CANCEL_SAME_DAY) || paymentCreatedAt == null || reason.isBlank()) return false
        val day = { t: Long -> java.time.Instant.ofEpochMilli(t).atZone(zone).toLocalDate() }
        return day(paymentCreatedAt) == day(nowMillis)
    }
}

/** المستخدم الحالي لطبقة المنطق. يضبطه AppNav عند الدخول ويمسحه عند الخروج. */
object SessionContext {
    // لقطة غير قابلة للتعديل تُبدَّل دفعة واحدة، فلا يرى القارئ دورًا لمستخدم ومعرّفًا لآخر.
    private data class Snapshot(val userId: Long, val username: String, val role: String)
    @Volatile private var current: Snapshot? = null
    val userId: Long? get() = current?.userId
    val username: String get() = current?.username ?: ""
    val role: String? get() = current?.role
    /** يكتب سجل المراقبة؛ يضبطه AppNav ليكتب في user_activity_logs. يُمسح مع الجلسة. */
    @Volatile var auditSink: ((action: String, details: String) -> Unit)? = null

    fun set(user: AppUser) { current = Snapshot(user.id, user.username, user.role) }
    /** تسجيل الخروج: لا يبقى مستخدم ولا مرجع للمسجِّل (الذي يلتقط نطاق الواجهة والمستخدم السابق). */
    fun clear() { current = null; auditSink = null }
}

object PermissionGuard {
    const val DENIED_MESSAGE = "حسابك لا يملك صلاحية تنفيذ هذه العملية."

    /**
     * يُستدعى أول كل عملية حساسة. يعيد true إذا يُسمح بالتنفيذ.
     * في وضع المراقبة: يسجّل الرفض المحتمل ويعيد true. في الفرض: يعيد false.
     */
    fun allow(permission: Permission, role: String? = SessionContext.role): Boolean {
        if (PermissionPolicy.can(role, permission)) return true
        val action = if (PermissionPolicy.enforcing) "PERMISSION_DENIED" else "PERMISSION_WOULD_DENY"
        val note = if (PermissionPolicy.enforcing) "مُنعت العملية" else "وضع المراقبة: لم تُمنع العملية"
        runCatching { SessionContext.auditSink?.invoke(action, "العملية ${permission.name} بالدور ${role ?: "غير مسجَّل"} — $note") }
        return !PermissionPolicy.enforcing
    }
}
