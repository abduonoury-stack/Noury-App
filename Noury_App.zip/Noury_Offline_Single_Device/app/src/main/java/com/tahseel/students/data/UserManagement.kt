package com.tahseel.students.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import android.util.Base64

@Entity(tableName = "app_users", indices = [Index(value = ["username"], unique = true), Index(value = ["isActive"])])
data class AppUser(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val displayName: String,
    val role: String,
    val passwordSalt: String,
    val passwordHash: String,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val lastLoginAt: Long? = null
)

@Entity(tableName = "user_activity_logs", indices = [Index(value = ["userId"]), Index(value = ["createdAt"])])
data class UserActivityLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long?,
    val username: String,
    val action: String,
    val details: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface UserDao {
    @Query("SELECT COUNT(*) FROM app_users") suspend fun countUsers(): Int
    @Query("SELECT * FROM app_users WHERE username = :username COLLATE NOCASE LIMIT 1") suspend fun findByUsername(username: String): AppUser?
    @Query("SELECT * FROM app_users ORDER BY isActive DESC, displayName COLLATE NOCASE") suspend fun allUsers(): List<AppUser>
    @Query("SELECT * FROM app_users WHERE id = :id LIMIT 1") suspend fun findById(id: Long): AppUser?
    @Insert suspend fun insert(user: AppUser): Long
    @Update suspend fun update(user: AppUser)
    @Insert suspend fun log(log: UserActivityLog)
    @Query("UPDATE app_users SET lastLoginAt = :at WHERE id = :id") suspend fun updateLastLogin(id: Long, at: Long)
    @Query("SELECT COUNT(*) FROM app_users WHERE isActive = 1") suspend fun activeCount(): Int
    @Query("SELECT COUNT(*) FROM app_users WHERE role = 'ADMIN' AND isActive = 1") suspend fun activeAdminCount(): Int
}

object PasswordSecurity {
    private const val ITERATIONS = 160_000
    private const val KEY_LENGTH = 256
    fun hash(password: String, salt: String? = null): Pair<String, String> {
        val saltBytes = if (salt == null) ByteArray(16).also { SecureRandom().nextBytes(it) } else Base64.decode(salt, Base64.NO_WRAP)
        val spec = PBEKeySpec(password.toCharArray(), saltBytes, ITERATIONS, KEY_LENGTH)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        return Base64.encodeToString(saltBytes, Base64.NO_WRAP) to Base64.encodeToString(bytes, Base64.NO_WRAP)
    }
    fun verify(password: String, salt: String, expectedHash: String): Boolean {
        val actual = hash(password, salt).second
        return java.security.MessageDigest.isEqual(
            Base64.decode(actual, Base64.NO_WRAP), Base64.decode(expectedHash, Base64.NO_WRAP)
        )
    }
}

object UserRoles {
    const val ADMIN = "ADMIN"
    const val FINANCE_MANAGER = "FINANCE_MANAGER"
    const val ACCOUNTANT = "ACCOUNTANT"
    const val CASHIER = "CASHIER"
    const val NURSERY = "NURSERY"
    const val RECEPTION = "RECEPTION"
    const val HR = "HR"
    const val VIEWER = "VIEWER"

    val labels = linkedMapOf(
        ADMIN to "مدير النظام",
        FINANCE_MANAGER to "المدير المالي",
        ACCOUNTANT to "المحاسب",
        CASHIER to "أمين الخزينة",
        NURSERY to "مسؤول الحضانة",
        RECEPTION to "موظف الاستقبال",
        HR to "مسؤول شؤون العاملين",
        VIEWER to "مستخدم مشاهدة"
    )

    fun canOpen(role: String, route: String): Boolean {
        if (role == ADMIN) return true
        val r = route.substringBefore("/")
        val common = setOf("dashboard", "hub")
        if (r in common) return true
        val finance = setOf("expenses", "financial-control", "finance-payroll", "cash-accounts", "refunds", "ledger")
        val student = setOf("students", "add-student", "student-profile", "student-finance", "search", "birthdays", "classrooms", "attendance", "student-exit")
        val collection = setOf("add", "edit", "subscription", "collection-status", "details")
        val hr = setOf("hr")
        val reports = setOf("reports")
        val settings = setOf("system-settings", "academy-profile", "periods", "backup", "users")
        return when (role) {
            FINANCE_MANAGER -> r in finance || r in collection || r in reports || r in setOf("student-profile", "student-finance", "search")
            ACCOUNTANT -> r in finance || r in reports || r in collection || r in setOf("student-profile", "student-finance", "search")
            CASHIER -> r in setOf("add", "edit", "details", "ledger", "cash-accounts", "refunds", "subscription", "collection-status")
            NURSERY -> r in setOf("students", "add-student", "student-profile", "search", "birthdays", "classrooms", "attendance")
            RECEPTION -> r in setOf("students", "add-student", "student-profile", "search", "birthdays", "add", "details", "subscription", "collection-status")
            HR -> r in hr || r in reports
            VIEWER -> r in reports
            else -> false
        } && r !in settings
    }
}
