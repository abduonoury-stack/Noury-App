package com.tahseel.students.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentDao {
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(student: Student): Long
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertAll(students: List<Student>): List<Long>
    @Update suspend fun update(student: Student): Int
    @Query("SELECT * FROM students ORDER BY CASE WHEN birthDate IS NULL THEN 1 ELSE 0 END, birthDate ASC, fullName COLLATE NOCASE") fun observeAll(): Flow<List<Student>>
    @Query("SELECT * FROM students WHERE id = :id") fun observeById(id: Long): Flow<Student?>
    @Query("SELECT * FROM students WHERE id = :id") suspend fun getById(id: Long): Student?

    @Query("SELECT attendanceDate FROM attendance WHERE studentId = :studentId AND attendanceDate BETWEEN :fromDate AND :toDate AND status = 'present' ORDER BY attendanceDate") suspend fun presentAttendanceDates(studentId: Long, fromDate: String, toDate: String): List<String>
    @Query("SELECT * FROM student_exit_settlements WHERE studentId = :studentId AND periodKey = :periodKey LIMIT 1") suspend fun exitSettlement(studentId: Long, periodKey: String): StudentExitSettlement?
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertExitSettlement(settlement: StudentExitSettlement): Long
    @Update suspend fun updateExitSettlement(settlement: StudentExitSettlement): Int
    @Query("SELECT * FROM student_exit_settlements WHERE id = :id LIMIT 1") suspend fun getExitSettlement(id: Long): StudentExitSettlement?
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertExitRefundCredit(credit: RefundCredit): Long
    @Query("SELECT * FROM refund_credits WHERE sourceType='exit_settlement' AND sourceId=:settlementId LIMIT 1") suspend fun exitRefundCredit(settlementId: Long): RefundCredit?
    @Query("SELECT COALESCE(SUM(amountPiasters),0) FROM refund_transactions WHERE refundCreditId=:creditId") suspend fun refundedFromCredit(creditId: Long): Long
    @Update suspend fun updateExitRefundCredit(credit: RefundCredit): Int
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertExitRefundTransaction(tx: RefundTransaction): Long
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertExitAudit(log: AuditLog): Long
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertExitSettlementEvent(event: StudentExitSettlementEvent): Long
    @Query("UPDATE student_exit_settlements SET refundedAmountPiasters = refundedAmountPiasters + :amountPiasters WHERE id = :settlementId AND settlementStatus = 'active' AND :amountPiasters > 0 AND refundedAmountPiasters + :amountPiasters <= refundAmountPiasters")
    suspend fun incrementExitRefundIfWithinLimit(settlementId: Long, amountPiasters: Long): Int

    @Query("UPDATE student_exit_settlements SET periodKey = :periodKey, withdrawalDate = :withdrawalDate, attendedDays = :attendedDays, monthlyFeePiasters = :monthlyFeePiasters, paidAmountPiasters = :paidAmountPiasters, earnedAmountPiasters = :earnedAmountPiasters, refundAmountPiasters = :refundAmountPiasters, amountDuePiasters = :amountDuePiasters, manualAdjustmentType = :manualAdjustmentType, manualAdjustmentAmountPiasters = :manualAdjustmentAmountPiasters, manualAdjustmentReason = :manualAdjustmentReason WHERE id = :id AND settlementStatus = 'active' AND refundAmountPiasters = :expectedRefundAmountPiasters AND withdrawalDate = :expectedWithdrawalDate AND attendedDays = :expectedAttendedDays")
    suspend fun updateExitSettlementCorrection(
        id: Long, expectedRefundAmountPiasters: Long, expectedWithdrawalDate: String, expectedAttendedDays: Int,
        periodKey: String, withdrawalDate: String, attendedDays: Int,
        monthlyFeePiasters: Long, paidAmountPiasters: Long, earnedAmountPiasters: Long,
        refundAmountPiasters: Long, amountDuePiasters: Long, manualAdjustmentType: String,
        manualAdjustmentAmountPiasters: Long, manualAdjustmentReason: String
    ): Int

    @Transaction
    suspend fun correctExitSettlementAtomically(expected: StudentExitSettlement, settlement: StudentExitSettlement, event: StudentExitSettlementEvent) {
        check(updateExitSettlementCorrection(
            settlement.id, expected.refundAmountPiasters, expected.withdrawalDate, expected.attendedDays,
            settlement.periodKey, settlement.withdrawalDate, settlement.attendedDays,
            settlement.monthlyFeePiasters, settlement.paidAmountPiasters, settlement.earnedAmountPiasters,
            settlement.refundAmountPiasters, settlement.amountDuePiasters, settlement.manualAdjustmentType,
            settlement.manualAdjustmentAmountPiasters, settlement.manualAdjustmentReason
        ) == 1) { "التسوية غير موجودة أو ملغاة" }
        val credit = exitRefundCredit(settlement.id)
        val now = System.currentTimeMillis()
        if (settlement.refundAmountPiasters > 0L) {
            require(settlement.refundAmountPiasters <= settlement.paidAmountPiasters) { "قيمة الاسترداد تتجاوز المبلغ المحصل" }
            if (credit == null) {
                val creditId = insertExitRefundCredit(RefundCredit(
                    studentId = settlement.studentId, paymentId = null,
                    originalAmountPiasters = settlement.refundAmountPiasters,
                    remainingAmountPiasters = settlement.refundAmountPiasters,
                    createdAt = now, note = "رصيد استرداد من تسوية انسحاب #${settlement.id}",
                    sourceType = "exit_settlement", sourceId = settlement.id,
                    approvalStatus = "approved", reason = "تصحيح واعتماد تسوية الانسحاب",
                    documentReference = "تسوية انسحاب #${settlement.id}", approvedAt = now
                ))
                insertExitAudit(AuditLog(entityType = "refund_credit", entityId = creditId, action = "exit_credit_created_by_correction", details = "actor=owner;settlement=${settlement.id};amount=${settlement.refundAmountPiasters};reason=${event.details}", createdAt = now))
            } else {
                val alreadyRefunded = refundedFromCredit(credit.id)
                require(settlement.refundAmountPiasters >= alreadyRefunded) { "قيمة الاسترداد الجديدة أقل من المبلغ الذي تم رده بالفعل" }
                check(updateExitRefundCredit(credit.copy(
                    originalAmountPiasters = settlement.refundAmountPiasters,
                    remainingAmountPiasters = settlement.refundAmountPiasters - alreadyRefunded,
                    approvalStatus = "approved", reason = "تصحيح معتمد لتسوية الانسحاب", approvedAt = now
                )) == 1) { "تعذر تحديث رصيد الاسترداد" }
            }
        } else if (credit != null) {
            val alreadyRefunded = refundedFromCredit(credit.id)
            require(alreadyRefunded == 0L) { "لا يمكن تصفير الاسترداد بعد صرف جزء منه" }
            check(updateExitRefundCredit(credit.copy(originalAmountPiasters = 0L, remainingAmountPiasters = 0L, approvalStatus = "cancelled", reason = "تم إلغاء الاستحقاق بتصحيح التسوية", approvedAt = now)) == 1)
        }
        val eventId = insertExitSettlementEvent(event)
        insertExitAudit(AuditLog(entityType = "student_exit_settlement", entityId = settlement.id, action = "correct", details = "actor=owner;event=$eventId;${event.details}", createdAt = now))
    }
    @Transaction
    suspend fun createExitSettlementWithCreditAtomically(settlement: StudentExitSettlement, student: Student) {
        val settlementId = insertExitSettlement(settlement)
        if (settlement.refundAmountPiasters > 0L) {
            require(settlement.paidAmountPiasters > 0L && settlement.refundAmountPiasters <= settlement.paidAmountPiasters) { "قيمة استرداد الانسحاب لا تتفق مع المبلغ المحصل" }
            val now = System.currentTimeMillis()
            val creditId = insertExitRefundCredit(RefundCredit(
                studentId = settlement.studentId, paymentId = null,
                originalAmountPiasters = settlement.refundAmountPiasters,
                remainingAmountPiasters = settlement.refundAmountPiasters,
                createdAt = now, note = "تسوية انسحاب معتمدة #$settlementId",
                sourceType = "exit_settlement", sourceId = settlementId,
                approvalStatus = "approved", reason = "تسوية انسحاب معتمدة",
                documentReference = "تسوية انسحاب #$settlementId", approvedAt = now
            ))
            insertExitAudit(AuditLog(entityType = "refund_credit", entityId = creditId, action = "exit_settlement_approved", details = "actor=owner;settlement=$settlementId;amount=${settlement.refundAmountPiasters};approvedBy=owner", createdAt = now))
        }
        check(update(student) == 1) { "تعذر تحديث حالة الطالب" }
    }

    @Transaction
    suspend fun reopenExitSettlementWithCreditAtomically(settlement: StudentExitSettlement, student: Student, event: StudentExitSettlementEvent) {
        check(reopenCancelledExitSettlement(
            settlement.id, settlement.periodKey, settlement.withdrawalDate, settlement.attendedDays,
            settlement.monthlyFeePiasters, settlement.paidAmountPiasters, settlement.earnedAmountPiasters,
            settlement.refundAmountPiasters, settlement.amountDuePiasters, settlement.manualAdjustmentType,
            settlement.manualAdjustmentAmountPiasters, settlement.manualAdjustmentReason
        ) == 1) { "التسوية لم تعد ملغاة أو تم فتحها بالفعل" }
        val existingCredit = exitRefundCredit(settlement.id)
        val now = System.currentTimeMillis()
        if (settlement.refundAmountPiasters > 0L) {
            require(settlement.paidAmountPiasters > 0L && settlement.refundAmountPiasters <= settlement.paidAmountPiasters) { "قيمة استرداد الانسحاب لا تتفق مع المبلغ المحصل" }
            if (existingCredit == null) {
                val creditId = insertExitRefundCredit(RefundCredit(
                    studentId = settlement.studentId, paymentId = null,
                    originalAmountPiasters = settlement.refundAmountPiasters,
                    remainingAmountPiasters = settlement.refundAmountPiasters,
                    createdAt = now, note = "تسوية انسحاب معتمدة #${settlement.id}",
                    sourceType = "exit_settlement", sourceId = settlement.id,
                    approvalStatus = "approved", reason = "إعادة اعتماد تسوية الانسحاب",
                    documentReference = "تسوية انسحاب #${settlement.id}", approvedAt = now
                ))
                insertExitAudit(AuditLog(entityType = "refund_credit", entityId = creditId, action = "exit_settlement_reapproved", details = "actor=owner;settlement=${settlement.id};amount=${settlement.refundAmountPiasters};approvedBy=owner", createdAt = now))
            } else {
                val alreadyRefunded = refundedFromCredit(existingCredit.id)
                require(settlement.refundAmountPiasters >= alreadyRefunded) { "قيمة الاسترداد الجديدة أقل من المبلغ الذي تم رده بالفعل" }
                check(updateExitRefundCredit(existingCredit.copy(
                    originalAmountPiasters = settlement.refundAmountPiasters,
                    remainingAmountPiasters = settlement.refundAmountPiasters - alreadyRefunded,
                    approvalStatus = "approved", approvedAt = now,
                    reason = "إعادة اعتماد تسوية الانسحاب"
                )) == 1) { "تعذر تحديث رصيد الاسترداد المرتبط بالتسوية" }
            }
        } else if (existingCredit != null) {
            val alreadyRefunded = refundedFromCredit(existingCredit.id)
            require(alreadyRefunded == 0L) { "لا يمكن إلغاء رصيد الاسترداد بعد صرف جزء منه" }
            check(updateExitRefundCredit(existingCredit.copy(originalAmountPiasters = 0L, remainingAmountPiasters = 0L, approvalStatus = "cancelled", reason = "تسوية الانسحاب أعيد اعتمادها دون استرداد", approvedAt = now)) == 1)
        }
        val eventId = insertExitSettlementEvent(event)
        check(update(student) == 1) { "تعذر تحديث حالة الطالب" }
        insertExitAudit(AuditLog(entityType = "student_exit_settlement", entityId = settlement.id, action = "reopen", details = "actor=owner;event=$eventId;${event.details}", createdAt = now))
    }

    @Transaction
    suspend fun recordExitRefundAgainstCreditAtomically(settlementId: Long, amountPiasters: Long, accountId: String, note: String): Long {
        require(amountPiasters > 0L) { "أدخل مبلغًا أكبر من صفر" }
        val settlement = getExitSettlement(settlementId) ?: error("التسوية غير موجودة")
        require(settlement.settlementStatus == "active") { "لا يمكن الصرف على تسوية ملغاة" }
        val credit = exitRefundCredit(settlementId) ?: error("لا يوجد رصيد استرداد معتمد لهذه التسوية")
        require(credit.approvalStatus == "approved") { "رصيد الاسترداد غير معتمد أو تم إلغاؤه" }
        require(amountPiasters <= credit.remainingAmountPiasters) { "المبلغ أكبر من رصيد الاسترداد المتبقي" }
        val remainingSettlement = (settlement.refundAmountPiasters - settlement.refundedAmountPiasters).coerceAtLeast(0L)
        require(amountPiasters <= remainingSettlement) { "المبلغ أكبر من المتبقي في التسوية" }
        val now = System.currentTimeMillis()
        check(updateExitRefundCredit(credit.copy(remainingAmountPiasters = credit.remainingAmountPiasters - amountPiasters)) == 1) { "تعذر تحديث رصيد الاسترداد" }
        val txId = insertExitRefundTransaction(RefundTransaction(
            refundCreditId = credit.id, amountPiasters = amountPiasters, refundedAt = now,
            method = "exit_settlement", note = note.trim(), accountId = accountId
        ))
        check(incrementExitRefundIfWithinLimit(settlementId, amountPiasters) == 1) { "تغير رصيد التسوية أو تجاوز المبلغ المتبقي" }
        val eventId = insertExitSettlementEvent(StudentExitSettlementEvent(
            settlementId = settlementId, eventType = "refund_paid", amountPiasters = amountPiasters,
            details = "صرف فعلي لولي الأمر. حركة الاسترداد #$txId. ${note.trim()}".trim(),
            createdAt = now, accountId = accountId
        ))
        insertExitAudit(AuditLog(entityType = "refund_credit", entityId = credit.id, action = "exit_refund_paid", details = "actor=owner;transaction=$txId;settlementEvent=$eventId;amount=$amountPiasters;account=$accountId", createdAt = now))
        return txId
    }
    @Query("UPDATE student_exit_settlements SET periodKey = :periodKey, withdrawalDate = :withdrawalDate, attendedDays = :attendedDays, monthlyFeePiasters = :monthlyFeePiasters, paidAmountPiasters = :paidAmountPiasters, earnedAmountPiasters = :earnedAmountPiasters, refundAmountPiasters = :refundAmountPiasters, amountDuePiasters = :amountDuePiasters, manualAdjustmentType = :manualAdjustmentType, manualAdjustmentAmountPiasters = :manualAdjustmentAmountPiasters, manualAdjustmentReason = :manualAdjustmentReason, settlementStatus = 'active', cancelledAt = NULL, cancellationReason = '' WHERE id = :id AND settlementStatus = 'cancelled'")
    suspend fun reopenCancelledExitSettlement(
        id: Long, periodKey: String, withdrawalDate: String, attendedDays: Int,
        monthlyFeePiasters: Long, paidAmountPiasters: Long, earnedAmountPiasters: Long,
        refundAmountPiasters: Long, amountDuePiasters: Long, manualAdjustmentType: String,
        manualAdjustmentAmountPiasters: Long, manualAdjustmentReason: String
    ): Int

    @Query("UPDATE student_exit_settlements SET settlementStatus = 'cancelled', cancelledAt = :cancelledAt, cancellationReason = :reason WHERE id = :id AND settlementStatus = 'active'")
    suspend fun markExitSettlementCancelled(id: Long, cancelledAt: Long, reason: String): Int

    @Transaction
    suspend fun cancelExitSettlementAtomically(settlement: StudentExitSettlement, student: Student, event: StudentExitSettlementEvent) {
        check(markExitSettlementCancelled(settlement.id, settlement.cancelledAt ?: System.currentTimeMillis(), settlement.cancellationReason) == 1) { "التسوية غير موجودة أو ملغاة" }
        val credit = exitRefundCredit(settlement.id)
        if (credit != null) {
            val now = System.currentTimeMillis()
            check(updateExitRefundCredit(credit.copy(remainingAmountPiasters = 0L, approvalStatus = "cancelled", reason = "تم إلغاء تسوية الانسحاب: ${settlement.cancellationReason}", approvedAt = now)) == 1) { "تعذر إيقاف رصيد الاسترداد" }
            insertExitAudit(AuditLog(entityType = "refund_credit", entityId = credit.id, action = "exit_credit_cancelled", details = "actor=owner;settlement=${settlement.id};reason=${settlement.cancellationReason}", createdAt = now))
        }
        check(update(student) == 1) { "تعذر تحديث حالة الطالب" }
        val eventId = insertExitSettlementEvent(event)
        insertExitAudit(AuditLog(entityType = "student_exit_settlement", entityId = settlement.id, action = "cancel", details = "actor=owner;event=$eventId;reason=${settlement.cancellationReason}", createdAt = System.currentTimeMillis()))
    }
    @Query("SELECT * FROM student_exit_settlement_events ORDER BY createdAt DESC, id DESC") fun observeAllExitSettlementEvents(): Flow<List<StudentExitSettlementEvent>>
    @Query("SELECT * FROM student_exit_settlements ORDER BY createdAt DESC") fun observeExitSettlements(): Flow<List<StudentExitSettlement>>
    @Query("SELECT * FROM students WHERE LOWER(TRIM(fullName)) = LOWER(TRIM(:name)) ORDER BY id LIMIT 1") suspend fun getByExactName(name: String): Student?
    @Query("SELECT * FROM students WHERE LOWER(TRIM(fullName)) = LOWER(TRIM(:name)) ORDER BY id") suspend fun getAllByExactName(name: String): List<Student>
    @Query("SELECT * FROM students WHERE REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(TRIM(motherWhatsapp), ' ', ''), '-', ''), '(', ''), ')', ''), '+', '') = :phone") suspend fun getByMotherPhone(phone: String): List<Student>
    @Query("SELECT * FROM students WHERE status = 'active' ORDER BY CASE WHEN birthDate IS NULL THEN 1 ELSE 0 END, birthDate ASC, fullName COLLATE NOCASE") suspend fun getActiveStudents(): List<Student>
    @Query("SELECT * FROM students WHERE fullName LIKE '%' || :query || '%' ORDER BY CASE WHEN birthDate IS NULL THEN 1 ELSE 0 END, birthDate ASC, fullName COLLATE NOCASE") fun search(query: String): Flow<List<Student>>
}

@Dao
interface FeeDao {
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertPlan(plan: FeePlan): Long
    @Update suspend fun updatePlan(plan: FeePlan): Int
    @Query("SELECT * FROM fee_plans WHERE isActive = 1 ORDER BY title") fun observeActivePlans(): Flow<List<FeePlan>>
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertFee(fee: StudentFee): Long
    @Query("SELECT * FROM student_fees WHERE studentId = :studentId ORDER BY dueAt DESC") fun observeStudentFees(studentId: Long): Flow<List<StudentFee>>
    @Query("SELECT * FROM student_fees WHERE studentId = :studentId AND periodKey = :periodKey") suspend fun feesForPeriod(studentId: Long, periodKey: String): List<StudentFee>
}

@Dao
interface FinanceDao {
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertSubscriptionPayment(payment: SubscriptionPayment): Long
    @Query("DELETE FROM subscription_payments WHERE paymentId = :paymentId") suspend fun deleteSubscriptionPayment(paymentId: Long): Int
    @Query("SELECT * FROM subscription_payments WHERE paymentId = :paymentId LIMIT 1") suspend fun subscriptionForPayment(paymentId: Long): SubscriptionPayment?
    @Query("SELECT paymentId FROM subscription_payments") fun observeSubscriptionPaymentIds(): Flow<List<Long>>
    @Update suspend fun updateReceipt(receipt: Receipt): Int
    @Query("SELECT sp.* FROM subscription_payments sp INNER JOIN payments p ON p.id = sp.paymentId WHERE sp.studentId = :studentId AND sp.periodKey = :periodKey AND p.isCancelled = 0 LIMIT 1") suspend fun subscriptionForPeriod(studentId: Long, periodKey: String): SubscriptionPayment?
    @Query("SELECT sp.* FROM subscription_payments sp INNER JOIN payments p ON p.id = sp.paymentId WHERE sp.studentId = :studentId AND p.isCancelled = 0 ORDER BY sp.periodKey DESC") fun observeSubscriptionHistory(studentId: Long): Flow<List<SubscriptionPayment>>
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertRefund(refund: RefundCredit): Long
    @Query("SELECT * FROM refund_credits WHERE id = :id") suspend fun refundCreditById(id: Long): RefundCredit?
    @Query("SELECT * FROM refund_credits WHERE paymentId = :paymentId LIMIT 1") suspend fun refundCreditForPayment(paymentId: Long): RefundCredit?
    @Query("SELECT * FROM refund_credits WHERE sourceType=:sourceType AND sourceId=:sourceId LIMIT 1") suspend fun refundCreditForSource(sourceType: String, sourceId: Long): RefundCredit?
    @Update suspend fun updateRefundCredit(credit: RefundCredit): Int
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertRefundTransaction(tx: RefundTransaction): Long
    @Query("SELECT * FROM refund_transactions WHERE id=:id LIMIT 1") suspend fun refundTransactionById(id: Long): RefundTransaction?
    @Query("SELECT COUNT(*) FROM refund_transactions WHERE refundCreditId = :creditId") suspend fun countRefundTransactions(creditId: Long): Int
    @Query("SELECT sp.* FROM subscription_payments sp INNER JOIN payments p ON p.id = sp.paymentId WHERE sp.periodKey = :periodKey AND p.isCancelled = 0 ORDER BY sp.createdAt DESC") fun observeValidSubscriptionPayments(periodKey: String): Flow<List<SubscriptionPayment>>
    @Query("SELECT * FROM refund_credits WHERE remainingAmountPiasters > 0 AND approvalStatus = 'approved' AND sourceType != 'exit_settlement' ORDER BY createdAt DESC") fun observeOpenRefundCredits(): Flow<List<RefundCredit>>
    @Query("SELECT * FROM refund_credits ORDER BY createdAt DESC") fun observeAllRefundCredits(): Flow<List<RefundCredit>>
    @Query("SELECT * FROM refund_transactions ORDER BY refundedAt DESC, id DESC") fun observeRefundTransactions(): Flow<List<RefundTransaction>>
    @Query("SELECT COALESCE(SUM(remainingAmountPiasters), 0) FROM refund_credits WHERE studentId = :studentId") fun observeRefundBalance(studentId: Long): Flow<Long>
    @Query("SELECT * FROM refund_credits WHERE studentId = :studentId ORDER BY createdAt DESC") fun observeRefunds(studentId: Long): Flow<List<RefundCredit>>
    @Query("SELECT rt.* FROM refund_transactions rt INNER JOIN refund_credits rc ON rc.id = rt.refundCreditId WHERE rc.studentId = :studentId ORDER BY rt.refundedAt DESC, rt.id DESC") fun observeRefundTransactionsForStudent(studentId: Long): Flow<List<RefundTransaction>>
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertReceipt(receipt: Receipt): Long
    @Query("SELECT * FROM receipts WHERE paymentId = :paymentId") suspend fun receiptForPayment(paymentId: Long): Receipt?
    @Insert suspend fun insertAudit(log: AuditLog): Long
    @Query("SELECT * FROM audit_logs ORDER BY createdAt DESC LIMIT :limit") fun observeAudit(limit: Int): Flow<List<AuditLog>>
    @Query("SELECT value FROM app_settings WHERE `key` = :key LIMIT 1") suspend fun getSetting(key: String): String?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putSetting(setting: AppSetting)
}

@Dao
interface ClassroomDao {
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(classroom: Classroom): Long
    @Update suspend fun update(classroom: Classroom): Int
    @Query("SELECT * FROM classrooms ORDER BY name COLLATE NOCASE") fun observeAll(): Flow<List<Classroom>>
    @Query("SELECT * FROM classrooms WHERE id = :id") fun observeById(id: Long): Flow<Classroom?>
    @Query("SELECT * FROM classrooms WHERE id = :id") suspend fun getById(id: Long): Classroom?
    @Query("UPDATE students SET className = :newName, updatedAt = :updatedAt WHERE className = :oldName") suspend fun renameStudentsClass(oldName: String, newName: String, updatedAt: Long): Int
    @Query("SELECT COUNT(*) FROM students WHERE className = :className AND status = 'active'") fun observeActiveCount(className: String): Flow<Int>
    @Query("SELECT * FROM students WHERE className = :className ORDER BY CASE WHEN birthDate IS NULL THEN 1 ELSE 0 END, birthDate ASC, fullName COLLATE NOCASE") fun observeStudents(className: String): Flow<List<Student>>
    @Query("SELECT * FROM students WHERE className = '' ORDER BY CASE WHEN birthDate IS NULL THEN 1 ELSE 0 END, birthDate ASC, fullName COLLATE NOCASE") fun observeUnassignedStudents(): Flow<List<Student>>
}

@Dao
interface PeriodDao {
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(period: AttendancePeriod): Long
    @Update suspend fun update(period: AttendancePeriod): Int
    @Query("SELECT * FROM attendance_periods ORDER BY isActive DESC, name COLLATE NOCASE") fun observeAll(): Flow<List<AttendancePeriod>>
    @Query("SELECT * FROM attendance_periods WHERE isActive = 1 ORDER BY name COLLATE NOCASE") fun observeActive(): Flow<List<AttendancePeriod>>
    @Query("SELECT * FROM attendance_periods WHERE id = :id LIMIT 1") suspend fun getById(id: Long): AttendancePeriod?
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertPriceHistory(item: PeriodPriceHistory): Long
    @Query("SELECT * FROM period_price_history WHERE periodId = :periodId ORDER BY effectiveFrom DESC, id DESC") fun observePriceHistory(periodId: Long): Flow<List<PeriodPriceHistory>>
    @Query("SELECT * FROM period_price_history ORDER BY effectiveFrom DESC, id DESC") fun observeAllPriceHistory(): Flow<List<PeriodPriceHistory>>
    @Query("SELECT amountPiasters FROM period_price_history WHERE periodId = :periodId AND effectiveFrom <= :at ORDER BY effectiveFrom DESC, id DESC LIMIT 1") suspend fun priceAt(periodId: Long, at: Long): Long?
}
