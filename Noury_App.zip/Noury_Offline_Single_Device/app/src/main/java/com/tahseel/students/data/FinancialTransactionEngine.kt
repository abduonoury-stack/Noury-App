package com.tahseel.students.data

import androidx.room.withTransaction
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId

/**
 * نقطة ترحيل موحدة للعمليات النقدية التي كانت تُحفظ في دفاتر تشغيلية منفصلة.
 * جميع المبالغ بالقروش، وكل عملية مصدر لها مفتاح ترحيل فريد يمنع تكرار القيد.
 */
data class CashGeneralLedgerReconciliation(
    val ledgerAccountCode: String,
    val ledgerAccountName: String,
    val cashAccountIds: List<String>,
    val expectedBalancePiasters: Long?,
    val generalLedgerBalancePiasters: Long,
    val differencePiasters: Long?,
    val status: String,
    val note: String = ""
)

class FinancialTransactionEngine(private val db: AppDatabase) {
    private val accounting get() = db.accountingDao()

    /** مطابقة رصيد دفاتر الخزائن التفصيلية مع حساب الأستاذ المجمع دون إجراء تسويات تلقائية. */
    suspend fun reconcileCashAccounts(movements: List<CashMovement>, asOf: Long): List<CashGeneralLedgerReconciliation> {
        val accounts = db.cashAccountDao().snapshotAll()
        val openings = db.cashControlDao().openingBalancesSnapshot().groupBy { it.accountId }
            .mapValues { (_, rows) -> rows.maxByOrNull { it.id } }
        return listOf("1100", "1110").map { code ->
            val group = accounts.filter { account -> if (code == "1100") account.type == "cash" else account.type != "cash" }
            val missing = group.filter { openings[it.id] == null }
            val expectedParts = if (group.isEmpty() || missing.isNotEmpty()) emptyList() else
                group.map { account -> expectedCashBalance(movements, openings[account.id], asOf, account.id) }
            val expected = if (expectedParts.isNotEmpty() && expectedParts.all { it != null })
                expectedParts.filterNotNull().fold(0L) { total, amount -> Math.addExact(total, amount) } else null
            val ledgerId = accounting.accountByCode(code)?.id
            val ledgerBalance = if (ledgerId == null) 0L else Math.subtractExact(accounting.cashRootDebitTotal(code), accounting.cashRootCreditTotal(code))
            val difference = expected?.let { Math.subtractExact(it, ledgerBalance) }
            CashGeneralLedgerReconciliation(
                ledgerAccountCode = code,
                ledgerAccountName = if (code == "1100") "الخزينة" else "البنوك والمحافظ",
                cashAccountIds = group.map { it.id },
                expectedBalancePiasters = expected,
                generalLedgerBalancePiasters = ledgerBalance,
                differencePiasters = difference,
                status = when { group.isEmpty() -> "NO_ACCOUNTS"; ledgerId == null -> "MISSING_GL_ACCOUNT"; missing.isNotEmpty() -> "MISSING_OPENING_BALANCE"; expected == null -> "NOT_ESTABLISHED_AS_OF"; difference == 0L -> "MATCHED"; else -> "DIFFERENCE" },
                note = when {
                    group.isEmpty() -> "لا توجد حسابات تشغيلية ضمن هذا التصنيف"
                    ledgerId == null -> "حساب الأستاذ العام $code غير موجود أو غير نشط"
                    missing.isNotEmpty() -> "يلزم تسجيل رصيد افتتاحي معتمد للحسابات: ${missing.joinToString { it.name }}"
                    expected == null -> "تاريخ المطابقة يسبق تاريخ سريان رصيد افتتاحي لأحد الحسابات"
                    difference == 0L -> "الرصيد التفصيلي مطابق لرصيد الأستاذ العام"
                    else -> "يوجد فرق؛ راجع الحركات والأرصدة الافتتاحية دون إجراء تسوية تلقائية"
                }
            )
        }
    }

    private data class PeriodWindow(val key: String, val start: Long, val end: Long)

    private fun periodFor(timestamp: Long): PeriodWindow {
        val zone = ZoneId.systemDefault()
        val date = Instant.ofEpochMilli(timestamp).atZone(zone).toLocalDate()
        val month = YearMonth.from(date)
        return PeriodWindow(
            month.toString(),
            month.atDay(1).atStartOfDay(zone).toInstant().toEpochMilli(),
            month.plusMonths(1).atDay(1).atStartOfDay(zone).toInstant().toEpochMilli() - 1L
        )
    }

    private suspend fun ensureOpenPeriod(timestamp: Long): String {
        val p = periodFor(timestamp)
        accounting.ensurePeriod(p.key, p.start, p.end)
        require(accounting.isPeriodOpen(p.key)) { "الفترة المحاسبية ${p.key} مغلقة؛ لا يمكن ترحيل العملية" }
        return p.key
    }

    private suspend fun cashLedgerAccountId(accountId: String): Pair<Long, String> {
        val cash = db.cashAccountDao().find(accountId) ?: error("حساب النقدية غير موجود")
        require(cash.isActive) { "حساب النقدية غير نشط" }
        val mapping = db.cashAccountDao().ledgerMapping(accountId)
            ?: error("حساب ${cash.name} غير مربوط بحساب أستاذ مستقل؛ افتح إعدادات الربط المحاسبي")
        val ledger = accounting.journalPostingAccountById(mapping.ledgerAccountId)
            ?: error("حساب الأستاذ المرتبط بـ ${cash.name} غير نشط أو غير قابل للترحيل")
        return ledger.id to cash.name
    }

    /** ترحيل قابل لإعادة المحاولة بأمان؛ لا يعيد إنشاء قيد موجود ولا يعيد قيدًا معكوسًا. */
    private suspend fun postOnce(entry: JournalEntry, lines: List<JournalLineDraft>): Long {
        val existing = accounting.sourcePost(entry.sourceType, entry.sourceId)
        if (existing != null) {
            val journal = accounting.journalById(existing.journalEntryId)
                ?: error("مرجع الترحيل موجود لكن القيد المرتبط به غير موجود؛ يلزم فحص قاعدة البيانات")
            require(journal.status == "posted") { "العملية مرتبطة بقيد معكوس؛ لا يمكن إعادة ترحيلها تلقائيًا" }
            return journal.id
        }
        return accounting.postJournal(entry, lines)
    }

    suspend fun postManualReceipt(paymentId: Long, amountPiasters: Long, accountId: String, receivedAt: Long, payerName: String): Long {
        require(paymentId > 0L && amountPiasters > 0L) { "بيانات التحصيل العام غير صحيحة" }
        val periodKey = ensureOpenPeriod(receivedAt)
        val (cashId, cashName) = cashLedgerAccountId(accountId)
        val revenue = accounting.accountByCode("4100") ?: error("حساب الإيرادات غير موجود")
        return postOnce(
            JournalEntry(entryNo = "MANUAL-REC-$paymentId", entryDate = receivedAt, periodKey = periodKey,
                description = "تحصيل عام من $payerName", sourceType = "manual_receipt", sourceId = paymentId.toString()),
            listOf(
                JournalLineDraft(cashId, debitPiasters = amountPiasters, memo = "تحصيل في $cashName"),
                JournalLineDraft(revenue.id, creditPiasters = amountPiasters, memo = "إيراد تحصيل عام")
            )
        )
    }

    suspend fun postSubscriptionReceipt(paymentId: Long, amountPiasters: Long, accountId: String, paidAt: Long, studentName: String, periodLabel: String): Long? {
        require(paymentId > 0L && amountPiasters >= 0L) { "بيانات التحصيل غير صحيحة" }
        if (amountPiasters == 0L) return null
        val periodKey = ensureOpenPeriod(paidAt)
        val (cashId, cashName) = cashLedgerAccountId(accountId)
        val revenue = accounting.accountByCode("4100") ?: error("حساب إيرادات الاشتراكات غير موجود")
        return postOnce(
            JournalEntry(entryNo = "SUB-$paymentId", entryDate = paidAt, periodKey = periodKey,
                description = "تحصيل اشتراك $periodLabel - $studentName", sourceType = "subscription_receipt", sourceId = paymentId.toString()),
            listOf(
                JournalLineDraft(cashId, debitPiasters = amountPiasters, memo = "إيداع في $cashName"),
                JournalLineDraft(revenue.id, creditPiasters = amountPiasters, memo = "إيراد اشتراك $periodLabel")
            )
        )
    }

    /** إثبات استحقاق فاتورة المصروف: مدين مصروف / دائن موردين، دون حركة نقدية. */
    suspend fun postAccruedExpense(expenseId: Long, expense: AccountingExpense): Long {
        require(expenseId > 0L && expense.amountPiasters > 0L) { "بيانات فاتورة المصروف غير صحيحة" }
        val periodKey = ensureOpenPeriod(expense.documentDate)
        require(periodKey == expense.periodKey) { "تاريخ الفاتورة لا يطابق الفترة المحاسبية المحددة" }
        val expenseAccount = accounting.journalPostingAccountById(expense.categoryAccountId)
            ?: error("حساب المصروف غير نشط أو غير قابل للترحيل")
        require(expenseAccount.type == "expense") { "الحساب المحدد ليس حساب مصروفات" }
        val payable = accounting.accountByCode("2100") ?: error("حساب الموردين والمصروفات المستحقة غير موجود")
        return postOnce(
            JournalEntry(entryNo = "EXP-$expenseId", entryDate = expense.documentDate, periodKey = periodKey,
                description = "إثبات فاتورة: ${expense.title}", sourceType = "accounting_expense", sourceId = expenseId.toString()),
            listOf(
                JournalLineDraft(expenseAccount.id, debitPiasters = expense.amountPiasters, memo = expense.title),
                JournalLineDraft(payable.id, creditPiasters = expense.amountPiasters, memo = expense.title)
            )
        )
    }

    /** إثبات السداد الفعلي لفاتورة؛ لا يتجاوز حساب الموردين إلا بالقيمة المدفوعة فعليًا. */
    suspend fun postAccountingExpensePayment(paymentId: Long, expense: AccountingExpense, amountPiasters: Long, cashAccountId: String, paidAt: Long): Long {
        require(paymentId > 0L && amountPiasters > 0L) { "بيانات دفعة المصروف غير صحيحة" }
        val periodKey = ensureOpenPeriod(paidAt)
        val (cashId, cashName) = cashLedgerAccountId(cashAccountId)
        val payable = accounting.accountByCode("2100") ?: error("حساب الموردين والمصروفات المستحقة غير موجود")
        return postOnce(
            JournalEntry(entryNo = "EXPPAY-$paymentId", entryDate = paidAt, periodKey = periodKey,
                description = "سداد فاتورة: ${expense.title}", sourceType = "accounting_expense_payment", sourceId = paymentId.toString()),
            listOf(
                JournalLineDraft(payable.id, debitPiasters = amountPiasters, memo = "سداد ${expense.title}"),
                JournalLineDraft(cashId, creditPiasters = amountPiasters, memo = "صرف ${expense.title} من $cashName")
            )
        )
    }

    /** إثبات استحقاق المرتب مرة واحدة وفق كشف المرتب المعتمد. */
    suspend fun postPayrollAccrual(row: EmployeePayroll): Long {
        val firstDay = YearMonth.parse(row.monthKey).atDay(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val periodKey = ensureOpenPeriod(firstDay)
        val salary = accounting.accountByCode("5200") ?: error("حساب مصروف المرتبات غير موجود")
        val payable = accounting.accountByCode("2200") ?: error("حساب المرتبات المستحقة غير موجود")
        val advance = accounting.accountByCode("1210") ?: error("حساب سلف الموظفين غير موجود")
        return postOnce(
            JournalEntry(entryNo = "PAYROLL-ACC-${row.id}", entryDate = firstDay, periodKey = periodKey,
                description = "إثبات استحقاق مرتبات ${row.monthKey}", sourceType = "employee_payroll_accrual", sourceId = row.id.toString()),
            payrollAccrualDrafts(row, salary.id, payable.id, advance.id)
        )
    }

    /** صرف سلفة الموظف: مدين سلف الموظفين / دائن حساب النقدية المرتبط. */
    suspend fun postEmployeeLoanIssue(loanId: Long, employeeName: String, amountPiasters: Long, cashAccountId: String, issuedAt: Long): Long {
        require(loanId > 0L && amountPiasters > 0L) { "بيانات السلفة غير صحيحة" }
        val periodKey = ensureOpenPeriod(issuedAt)
        val advance = accounting.accountByCode("1210") ?: error("حساب سلف وعهد الموظفين غير موجود")
        val (cashId, cashName) = cashLedgerAccountId(cashAccountId)
        return postOnce(
            JournalEntry(entryNo = "LOAN-$loanId", entryDate = issuedAt, periodKey = periodKey,
                description = "صرف سلفة للموظف $employeeName", sourceType = "employee_loan_issue", sourceId = loanId.toString()),
            listOf(
                JournalLineDraft(advance.id, debitPiasters = amountPiasters, memo = "سلفة $employeeName"),
                JournalLineDraft(cashId, creditPiasters = amountPiasters, memo = "صرف سلفة من $cashName")
            )
        )
    }

    suspend fun postPayrollPayment(paymentId: Long, amountPiasters: Long, accountId: String, paidAt: Long, monthKey: String): Long {
        require(paymentId > 0L && amountPiasters > 0L) { "بيانات صرف المرتب غير صحيحة" }
        val periodKey = ensureOpenPeriod(paidAt)
        val (cashId, cashName) = cashLedgerAccountId(accountId)
        val payable = accounting.accountByCode("2200") ?: error("حساب المرتبات المستحقة غير موجود")
        return postOnce(
            JournalEntry(entryNo = "PAYROLL-PAY-$paymentId", entryDate = paidAt, periodKey = periodKey,
                description = "صرف مرتبات $monthKey", sourceType = "employee_payroll_payment", sourceId = paymentId.toString()),
            listOf(
                JournalLineDraft(payable.id, debitPiasters = amountPiasters, memo = "صرف مرتب الموظف"),
                JournalLineDraft(cashId, creditPiasters = amountPiasters, memo = "صرف من $cashName")
            )
        )
    }

    suspend fun postManualRefund(transaction: RefundTransaction, credit: RefundCredit): Long {
        require(credit.sourceType == "manual_payment") { "مصدر رصيد الاسترداد لا يطابق مسار الاسترداد اليدوي" }
        return postRefundTransaction(transaction, "manual_refund", "تحصيل #${credit.paymentId ?: credit.id}")
    }

    suspend fun postExitSettlementRefund(transaction: RefundTransaction, settlementId: Long): Long =
        postRefundTransaction(transaction, "exit_settlement_refund", "تسوية انسحاب #$settlementId")

    private suspend fun postRefundTransaction(transaction: RefundTransaction, sourceType: String, reference: String): Long {
        require(transaction.amountPiasters > 0L) { "قيمة الاسترداد غير صحيحة" }
        val periodKey = ensureOpenPeriod(transaction.refundedAt)
        val (cashId, cashName) = cashLedgerAccountId(transaction.accountId ?: "cash")
        val revenue = accounting.accountByCode("4100") ?: error("حساب إيرادات الاشتراكات غير موجود")
        return postOnce(
            JournalEntry(
                entryNo = "REFUND-${transaction.id}", entryDate = transaction.refundedAt,
                periodKey = periodKey, description = "استرداد $reference",
                sourceType = sourceType, sourceId = transaction.id.toString()
            ),
            listOf(
                JournalLineDraft(revenue.id, debitPiasters = transaction.amountPiasters, memo = "تخفيض الإيراد مقابل الاسترداد"),
                JournalLineDraft(cashId, creditPiasters = transaction.amountPiasters, memo = "صرف استرداد من $cashName")
            )
        )
    }

    suspend fun postCashTransfer(transfer: CashTransfer): Long {
        require(transfer.amountPiasters > 0L) { "قيمة التحويل يجب أن تكون أكبر من صفر" }
        require(transfer.fromAccountId != transfer.toAccountId) { "لا يمكن التحويل إلى الحساب نفسه" }
        val periodKey = ensureOpenPeriod(transfer.transferredAt)
        val (fromLedger, fromName) = cashLedgerAccountId(transfer.fromAccountId)
        val (toLedger, toName) = cashLedgerAccountId(transfer.toAccountId)
        return postOnce(
            JournalEntry(
                entryNo = "CASH-TRANSFER-${transfer.id}", entryDate = transfer.transferredAt,
                periodKey = periodKey, description = "تحويل داخلي من $fromName إلى $toName",
                sourceType = "cash_transfer", sourceId = transfer.id.toString()
            ),
            listOf(
                JournalLineDraft(toLedger, debitPiasters = transfer.amountPiasters, memo = "استلام في $toName"),
                JournalLineDraft(fromLedger, creditPiasters = transfer.amountPiasters, memo = "تحويل من $fromName")
            )
        )
    }

    /** عند عكس صرف مرتب: الجزء المرتد يزيد النقدية، والجزء غير المرتد يصبح مديونية على الموظف. */
    suspend fun postPayrollReversal(
        reversalId: Long, originalPaymentId: Long, originalAmount: Long,
        returnedAmount: Long, accountId: String?, date: Long
    ): Long {
        require(originalAmount > 0L && returnedAmount in 0L..originalAmount) { "بيانات عكس المرتب غير صحيحة" }
        val periodKey = ensureOpenPeriod(date)
        val payable = accounting.accountByCode("2200") ?: error("حساب المرتبات المستحقة غير موجود")
        val receivable = accounting.accountByCode("1210") ?: error("حساب سلف وعهد الموظفين غير موجود")
        val lines = mutableListOf<JournalLineDraft>()
        if (returnedAmount > 0L) {
            require(!accountId.isNullOrBlank()) { "حساب استلام المبلغ المرتد مطلوب" }
            val (cashId, cashName) = cashLedgerAccountId(accountId)
            lines += JournalLineDraft(cashId, debitPiasters = returnedAmount, memo = "مبلغ مرتد من عكس صرف مرتب إلى $cashName")
        }
        val receivableAmount = originalAmount - returnedAmount
        if (receivableAmount > 0L) lines += JournalLineDraft(receivable.id, debitPiasters = receivableAmount, memo = "مديونية موظف عن عكس صرف مرتب #$originalPaymentId")
        lines += JournalLineDraft(payable.id, creditPiasters = originalAmount, memo = "إعادة إثبات المبلغ المستحق بعد عكس الصرف")
        return postOnce(
            JournalEntry(
                entryNo = "PAYROLL-REV-$reversalId", entryDate = date, periodKey = periodKey,
                description = "عكس صرف مرتب #$originalPaymentId",
                sourceType = "employee_payroll_reversal", sourceId = reversalId.toString()
            ), lines
        )
    }

    suspend fun postPayrollRecovery(recovery: EmployeePayrollRecoveryTransaction, reversalId: Long): Long {
        require(recovery.amountPiasters > 0L) { "قيمة التحصيل غير صحيحة" }
        val periodKey = ensureOpenPeriod(recovery.receivedAt)
        val (cashId, cashName) = cashLedgerAccountId(recovery.accountId)
        val receivable = accounting.accountByCode("1210") ?: error("حساب سلف وعهد الموظفين غير موجود")
        return postOnce(
            JournalEntry(
                entryNo = "PAYROLL-RECOVERY-${recovery.id}", entryDate = recovery.receivedAt,
                periodKey = periodKey, description = "تحصيل مديونية موظف من عكس مرتب #$reversalId",
                sourceType = "employee_payroll_recovery", sourceId = recovery.id.toString()
            ),
            listOf(
                JournalLineDraft(cashId, debitPiasters = recovery.amountPiasters, memo = "تحصيل فعلي في $cashName"),
                JournalLineDraft(receivable.id, creditPiasters = recovery.amountPiasters, memo = "تخفيض مديونية الموظف")
            )
        )
    }
}

/** يحفظ التحويل التشغيلي والقيد المقابل كوحدة واحدة، مع إمكانية إعادة المحاولة دون تكرار. */
class CashTransferRepository(private val db: AppDatabase) {
    suspend fun record(transfer: CashTransfer): Long = db.withTransaction {
        val id = db.cashTransferDao().record(transfer)
        val persisted = transfer.copy(id = id)
        FinancialTransactionEngine(db).postCashTransfer(persisted)
        id
    }
}
