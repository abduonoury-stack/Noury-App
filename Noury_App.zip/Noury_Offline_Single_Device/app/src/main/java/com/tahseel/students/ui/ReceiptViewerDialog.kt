package com.tahseel.students.ui

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.tahseel.students.data.AppDatabase
import com.tahseel.students.data.Payment
import com.tahseel.students.util.ReceiptLoader
import com.tahseel.students.util.ReceiptPdf
import com.tahseel.students.util.ReceiptPrint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

/**
 * Full-screen, right-to-left view of the receipt exactly as sent to the guardian (the same PDF page),
 * with print, save and share actions. Read-only; it never changes the payment.
 */
@Composable
fun ReceiptViewerDialog(payment: Payment, db: AppDatabase, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var file by remember(payment.id, payment.isCancelled) { mutableStateOf<File?>(null) }
    var bitmap by remember(payment.id, payment.isCancelled) { mutableStateOf<Bitmap?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(payment.id, payment.isCancelled) {
        runCatching {
            val data = ReceiptLoader.load(db, payment)
            val safe = payment.receiptNo.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val f = withContext(Dispatchers.IO) { ReceiptPdf.createMany(context, listOf(data), "receipt-$safe.pdf") }
            file = f
            bitmap = withContext(Dispatchers.IO) { ReceiptPrint.renderFirstPage(f) }
        }.onFailure { message = "تعذر تجهيز الإيصال: ${it.localizedMessage}" }
    }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val f = file
        if (uri != null && f != null) {
            runCatching { context.contentResolver.openOutputStream(uri)?.use { out -> FileInputStream(f).use { it.copyTo(out) } } }
                .onSuccess { message = "تم حفظ ملف PDF بنجاح." }
                .onFailure { message = "تعذر حفظ الإيصال: ${it.localizedMessage}" }
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 12.dp)) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "إغلاق") }
                        Text("الإيصال", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    }
                    Box(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), contentAlignment = Alignment.TopCenter) {
                        val bmp = bitmap
                        if (bmp != null) {
                            Image(
                                bitmap = bmp.asImageBitmap(), contentDescription = "إيصال ${payment.receiptNo}",
                                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White),
                                contentScale = ContentScale.FillWidth
                            )
                        } else if (message == null) {
                            CircularProgressIndicator(Modifier.padding(48.dp))
                        }
                    }
                    message?.let { Text(it, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 6.dp)) }
                    Column(Modifier.padding(vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        BigButton("طباعة", Icons.Default.Print, onClick = {
                            val f = file ?: return@BigButton
                            runCatching { ReceiptPrint.print(context, f, 1, "إيصال ${payment.receiptNo}") }
                                .onFailure { message = "تعذرت الطباعة: ${it.localizedMessage}" }
                        }, enabled = file != null)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = { saveLauncher.launch("إيصال-${payment.receiptNo}.pdf") },
                                enabled = file != null, modifier = Modifier.weight(1f)
                            ) { Text("حفظ PDF") }
                            OutlinedButton(
                                onClick = {
                                    val f = file ?: return@OutlinedButton
                                    runCatching { ReceiptPrint.share(context, f, "مشاركة الإيصال") }
                                        .onFailure { message = "تعذرت مشاركة الإيصال: ${it.localizedMessage}" }
                                },
                                enabled = file != null, modifier = Modifier.weight(1f)
                            ) { Text("مشاركة") }
                        }
                    }
                }
            }
        }
    }
}
