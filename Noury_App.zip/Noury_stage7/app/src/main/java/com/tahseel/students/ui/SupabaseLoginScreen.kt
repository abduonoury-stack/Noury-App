package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.tahseel.students.sync.SupabaseAuth
import com.tahseel.students.sync.SupabaseSnapshotSync
import com.tahseel.students.data.AppDatabase
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.text.font.FontWeight
import com.tahseel.students.util.FullDatabaseBackup
import java.io.File

@Composable
fun SupabaseLoginScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val auth = remember(context) { SupabaseAuth(context) }
    val snapshotSync = remember(context) { SupabaseSnapshotSync(context, auth) }
    val database = remember(context) { AppDatabase.create(context) }
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var loggedIn by remember { mutableStateOf(auth.hasSession()) }
    var cloudSnapshot by remember { mutableStateOf<SupabaseSnapshotSync.DownloadResult?>(null) }
    var confirmRestore by remember { mutableStateOf(false) }
    AppScaffold("ربط ومزامنة الأجهزة", onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Icon(Icons.Default.CloudSync, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp))
            Text("تسجيل الدخول إلى حساب المزامنة", style = MaterialTheme.typography.titleLarge)
            Text("المرحلة التاسعة: إنشاء نسخة سحابية آمنة من بيانات هذا الجهاز. لا يتم حذف أو استبدال أي بيانات محلية.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (loggedIn) {
                Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("تم تسجيل الدخول على هذا الجهاز", style = MaterialTheme.typography.titleMedium)
                    Text("معرّف الحساب: ${auth.currentUserId().orEmpty()}")
                    Text("معرّف هذا الجهاز: ${snapshotSync.deviceId()}", style = MaterialTheme.typography.bodySmall)
                    Text("استخدم زر الرفع على الجهاز الأول فقط. على الجهاز الثاني استخدم فحص النسخة ثم الاستعادة.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = {
                        busy = true; message = null
                        scope.launch {
                            try {
                                val result = snapshotSync.uploadPrimarySnapshot(database.openHelper.writableDatabase)
                                message = "تم رفع النسخة السحابية بنجاح. عدد السجلات: ${result.rowCount}. معرّف النسخة: ${result.snapshotId}"
                            } catch (e: Exception) {
                                message = e.message ?: "تعذر رفع النسخة السحابية"
                            } finally { busy = false }
                        }
                    }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                        if (busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Text("رفع النسخة الأولية إلى السحابة")
                    }
                    OutlinedButton(onClick = {
                        busy = true; message = null; cloudSnapshot = null
                        scope.launch {
                            try {
                                val result = snapshotSync.downloadLatestSnapshot()
                                cloudSnapshot = result
                                message = "تم العثور على نسخة سليمة. عدد السجلات: ${result.rowCount}. معرّف النسخة: ${result.snapshotId}"
                            } catch (e: Exception) { message = e.message ?: "تعذر فحص النسخة" }
                            finally { busy = false }
                        }
                    }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                        Text("فحص النسخة السحابية")
                    }
                    cloudSnapshot?.let { snap ->
                        Text("النسخة الجاهزة للاستعادة: ${snap.rowCount} سجل", fontWeight = FontWeight.Bold)
                        Button(onClick = { confirmRestore = true }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("استعادة بيانات الموبايل الأول على هذا الجهاز") }
                    }
                    Button(onClick = { auth.signOut(); loggedIn = false; cloudSnapshot = null; message = "تم تسجيل الخروج من هذا الجهاز" }, enabled = !busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors()) { Text("تسجيل الخروج") }
                } }
            } else {
                OutlinedTextField(email, { email = it }, label = { Text("البريد الإلكتروني") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(password, { password = it }, label = { Text("كلمة المرور") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
                Button(onClick = { busy = true; message = null; scope.launch { try { val result = auth.signIn(email, password); loggedIn = true; password = ""; message = "تم تسجيل الدخول بنجاح. لم يتم نقل بيانات." } catch (e: Exception) { message = e.message ?: "تعذر الاتصال" } finally { busy = false } } }, enabled = !busy && email.isNotBlank() && password.isNotBlank(), modifier = Modifier.fillMaxWidth()) { if (busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Text("تسجيل الدخول واختبار الاتصال") }
            }
            message?.let { Text(it, color = if (loggedIn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
            Text("لا تدخل مفتاح service_role. لا تضغط زر الرفع على الجهاز الثاني.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    if (confirmRestore && cloudSnapshot != null) {
        AlertDialog(
            onDismissRequest = { confirmRestore = false },
            title = { Text("تأكيد استعادة النسخة") },
            text = { Text("سيتم فحص أن قاعدة هذا الجهاز فارغة تمامًا، ثم حفظ نسخة أمان محلية، وبعدها استعادة ${cloudSnapshot!!.rowCount} سجل. إذا وُجد أي سجل محلي ستُلغى العملية دون تغيير البيانات. هل تريد المتابعة؟") },
            confirmButton = { TextButton(onClick = {
                confirmRestore = false
                val snap = cloudSnapshot ?: return@TextButton
                busy = true; message = null
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) {
                            val db = database.openHelper.writableDatabase
                            val localJson = FullDatabaseBackup.export(db, System.currentTimeMillis())
                            val checkedLocal = FullDatabaseBackup.validate(localJson)
                            val localRoot = org.json.JSONObject(checkedLocal)
                            val localTables = localRoot.getJSONObject("tables")
                            val businessRows = FullDatabaseBackup.tables.filter { it != "cash_accounts" }.sumOf { table ->
                                if (localTables.has(table)) localTables.getJSONArray(table).length() else 0
                            }
                            val cashRows = localTables.optJSONArray("cash_accounts")
                            val onlyDefaultCash = cashRows == null || (cashRows.length() == 1 && cashRows.getJSONObject(0).optString("id") == "cash")
                            check(businessRows == 0 && onlyDefaultCash) {
                                "تم إلغاء الاستعادة: وُجدت بيانات محلية (عددها $businessRows سجل بخلاف حساب الخزينة الافتراضي). لم يتم تغيير أي بيانات."
                            }
                            val dir = File(context.filesDir, "pre_restore_backups").apply { mkdirs() }
                            val safety = File(dir, "pre-restore-${System.currentTimeMillis()}.json")
                            safety.writeText(localJson, Charsets.UTF_8)
                            FullDatabaseBackup.validate(safety.readText(Charsets.UTF_8))
                            FullDatabaseBackup.restore(db, snap.payload)
                            val verified = FullDatabaseBackup.export(db, System.currentTimeMillis())
                            val restoredCount = FullDatabaseBackup.rowCount(FullDatabaseBackup.validate(verified))
                            check(restoredCount == snap.rowCount) { "تمت الاستعادة لكن فشل تحقق العدد: المتوقع ${snap.rowCount} والفعلي $restoredCount. احتفظ بنسخة الأمان ولا تستخدم التطبيق حتى المراجعة." }
                        }
                        message = "تمت الاستعادة والتحقق بنجاح: ${snap.rowCount} سجل. النسخة السحابية الأصلية لم تتغير."
                    } catch (e: Exception) { message = e.message ?: "فشلت الاستعادة" }
                    finally { busy = false }
                }
            }) { Text("تأكيد الاستعادة") } },
            dismissButton = { TextButton(onClick = { confirmRestore = false }) { Text("إلغاء") } }
        )
    }
}
