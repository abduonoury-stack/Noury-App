package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.tahseel.students.sync.SupabaseAuth
import kotlinx.coroutines.launch

@Composable
fun SupabaseLoginScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val auth = remember(context) { SupabaseAuth(context) }
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var loggedIn by remember { mutableStateOf(auth.hasSession()) }
    AppScaffold("ربط ومزامنة الأجهزة", onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Icon(Icons.Default.CloudSync, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp))
            Text("تسجيل الدخول إلى حساب المزامنة", style = MaterialTheme.typography.titleLarge)
            Text("هذه الخطوة تختبر الاتصال فقط. لن يتم نقل أو تعديل بيانات الطلاب أو الحسابات المحلية.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (loggedIn) {
                Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("تم تسجيل الدخول على هذا الجهاز", style = MaterialTheme.typography.titleMedium)
                    Text("معرّف الحساب: ${auth.currentUserId().orEmpty()}")
                    Button(onClick = { auth.signOut(); loggedIn = false; message = "تم تسجيل الخروج من هذا الجهاز" }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل الخروج") }
                } }
            } else {
                OutlinedTextField(email, { email = it }, label = { Text("البريد الإلكتروني") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(password, { password = it }, label = { Text("كلمة المرور") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
                Button(onClick = { busy = true; message = null; scope.launch { try { val result = auth.signIn(email, password); loggedIn = true; password = ""; message = "تم تسجيل الدخول بنجاح. لم يتم نقل بيانات." } catch (e: Exception) { message = e.message ?: "تعذر الاتصال" } finally { busy = false } } }, enabled = !busy && email.isNotBlank() && password.isNotBlank(), modifier = Modifier.fillMaxWidth()) { if (busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Text("تسجيل الدخول واختبار الاتصال") }
            }
            message?.let { Text(it, color = if (loggedIn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
            Text("لا تدخل مفتاح service_role. استخدم حساب Supabase المخصص للمشروع فقط.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
