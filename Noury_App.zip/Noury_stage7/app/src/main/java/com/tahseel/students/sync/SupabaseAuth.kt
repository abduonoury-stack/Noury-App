package com.tahseel.students.sync

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.tahseel.students.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Minimal Supabase Auth REST client. Never stores or logs the user's password. */
class SupabaseAuth(context: Context) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
    private val prefs = EncryptedSharedPreferences.create(
        context,
        "noury_supabase_auth",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    data class AuthResult(val userId: String, val email: String?)

    suspend fun signIn(email: String, password: String): AuthResult = withContext(Dispatchers.IO) {
        require(email.isNotBlank() && password.isNotEmpty()) { "أدخل البريد الإلكتروني وكلمة المرور" }
        val json = JSONObject().put("email", email.trim()).put("password", password)
        val request = Request.Builder()
            .url("${BuildConfig.SUPABASE_URL}/auth/v1/token?grant_type=password")
            .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Content-Type", "application/json")
            .post(json.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val message = runCatching { JSONObject(body).optString("msg").ifBlank { JSONObject(body).optString("message") } }.getOrNull()
                throw IOException(message?.takeIf { it.isNotBlank() } ?: "فشل تسجيل الدخول (HTTP ${response.code})")
            }
            val result = JSONObject(body)
            val access = result.optString("access_token")
            val refresh = result.optString("refresh_token")
            val user = result.optJSONObject("user") ?: throw IOException("استجابة تسجيل الدخول غير مكتملة")
            val userId = user.optString("id")
            if (access.isBlank() || refresh.isBlank() || userId.isBlank()) throw IOException("بيانات الجلسة غير مكتملة")
            prefs.edit().putString("access_token", access).putString("refresh_token", refresh)
                .putString("user_id", userId).putString("email", user.optString("email")).apply()
            AuthResult(userId, user.optString("email").takeIf { it.isNotBlank() })
        }
    }


    /** Refresh the short-lived access token before background synchronization. */
    suspend fun refreshAccessToken(): String? = withContext(Dispatchers.IO) {
        val refresh = prefs.getString("refresh_token", null) ?: return@withContext null
        val json = JSONObject().put("refresh_token", refresh)
        val request = Request.Builder()
            .url("${BuildConfig.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token")
            .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Content-Type", "application/json")
            .post(json.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("تعذر تحديث جلسة المزامنة (HTTP ${response.code})")
            val result = JSONObject(body)
            val access = result.optString("access_token")
            val nextRefresh = result.optString("refresh_token")
            if (access.isBlank() || nextRefresh.isBlank()) throw IOException("استجابة تحديث الجلسة غير مكتملة")
            prefs.edit().putString("access_token", access).putString("refresh_token", nextRefresh).apply()
            access
        }
    }

    fun currentUserId(): String? = prefs.getString("user_id", null)
    fun accessToken(): String? = prefs.getString("access_token", null)
    fun hasSession(): Boolean = !prefs.getString("refresh_token", null).isNullOrBlank()
    fun signOut() { prefs.edit().clear().apply() }
}
