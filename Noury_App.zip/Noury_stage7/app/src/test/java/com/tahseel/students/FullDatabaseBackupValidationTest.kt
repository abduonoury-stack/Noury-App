package com.tahseel.students

import com.tahseel.students.util.FullDatabaseBackup
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.MessageDigest

class FullDatabaseBackupValidationTest {
    private fun checksum(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    private fun canonical(value: Any?): String = when (value) {
        null, JSONObject.NULL -> "null"
        is JSONObject -> value.keys().asSequence().toList().sorted().joinToString(prefix = "{", postfix = "}") { JSONObject.quote(it) + ":" + canonical(value.get(it)) }
        is JSONArray -> (0 until value.length()).joinToString(prefix = "[", postfix = "]") { canonical(value.get(it)) }
        is String -> JSONObject.quote(value)
        is Number, is Boolean -> value.toString()
        else -> JSONObject.quote(value.toString())
    }

    private fun backup(rowCount: Int): String {
        val tables = JSONObject()
        listOf("students", "payments", "fee_plans", "student_fees", "receipts", "refund_credits",
            "subscription_payments", "refund_transactions", "audit_logs", "app_settings", "classrooms",
            "attendance", "expenses", "employees", "employee_attendance", "employee_leaves",
            "employee_payroll", "employee_loans", "employee_adjustments", "student_exit_settlements",
            "student_exit_settlement_events", "attendance_periods", "period_price_history", "employee_payroll_payments", "cash_opening_balance", "cash_counts", "expense_payments", "cash_accounts", "cash_transfers", "employee_payroll_reversals", "employee_payroll_recovery_transactions").forEach { tables.put(it, JSONArray()) }
        tables.put("cash_accounts", JSONArray().put(JSONObject().put("id", "cash").put("name", "الخزينة النقدية").put("type", "cash").put("isActive", true).put("createdAt", 0L)))
        val root = JSONObject().put("app", FullDatabaseBackup.APP).put("version", FullDatabaseBackup.VERSION)
            .put("exportedAt", 123L).put("receiptProfile", JSONObject()).put("tables", tables).put("rowCount", rowCount)
        root.put("checksum", checksum(canonical(root)))
        return root.toString()
    }

    @Test fun accepts_complete_empty_backup() {
        assertEquals(1, FullDatabaseBackup.rowCount(FullDatabaseBackup.validate(backup(1))))
    }

    @Test fun rejects_row_count_mismatch_even_when_checksum_is_valid() {
        val error = runCatching { FullDatabaseBackup.validate(backup(2)) }.exceptionOrNull()
        assertTrue(error?.message?.contains("عدد السجلات") == true)
    }

    @Test fun accepts_backup_after_json_object_keys_are_reordered() {
        val original = JSONObject(backup(1))
        val reordered = JSONObject()
        original.keys().asSequence().toList().sortedDescending().forEach { key -> reordered.put(key, original.get(key)) }
        assertEquals(1, FullDatabaseBackup.rowCount(FullDatabaseBackup.validate(reordered.toString())))
    }

    @Test fun rejects_missing_required_table() {
        val root = JSONObject(backup(0))
        root.getJSONObject("tables").remove("employees")
        root.remove("checksum")
        root.put("checksum", checksum(canonical(root)))
        val error = runCatching { FullDatabaseBackup.validate(root.toString()) }.exceptionOrNull()
        assertTrue(error != null)
    }
}
