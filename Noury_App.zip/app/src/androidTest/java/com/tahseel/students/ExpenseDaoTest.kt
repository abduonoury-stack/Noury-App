package com.tahseel.students

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.tahseel.students.data.AppDatabase
import com.tahseel.students.data.Expense
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.time.YearMonth
import java.time.ZoneId

@RunWith(AndroidJUnit4::class)
class ExpenseDaoTest {
    private lateinit var db: AppDatabase

    @Before fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries().build()
    }

    @After fun tearDown() = db.close()

    @Test fun monthly_lookup_finds_legacy_expense_without_month_key() = runBlocking {
        val month = YearMonth.of(2026, 11)
        val zone = ZoneId.systemDefault()
        val from = month.atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
        val until = month.plusMonths(1).atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
        val id = db.expenseDao().insert(Expense(
            title = "الإيجار", category = "الإيجار", amountPiasters = 100_000,
            spentAt = from, note = "legacy", monthKey = ""
        ))

        val found = db.expenseDao().findMonthly(month.toString(), "الإيجار", "الإيجار", from, until)
        assertNotNull(found)
        assertEquals(id, found!!.id)
    }

    @Test fun monthly_salary_lookup_returns_all_rows_and_prefers_hr_managed_record() = runBlocking {
        val month = YearMonth.of(2026, 11)
        val zone = ZoneId.systemDefault()
        val from = month.atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
        val until = month.plusMonths(1).atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
        val manualId = db.expenseDao().insert(Expense(
            title = "مرتبات شهر نوفمبر", category = "أخرى", amountPiasters = 250_000,
            spentAt = from, note = "يدوي", monthKey = month.toString()
        ))
        val hrId = db.expenseDao().insert(Expense(
            title = "المرتبات", category = "المرتبات", amountPiasters = 300_000,
            spentAt = from, note = "HR_SYNC: test", monthKey = month.toString()
        ))
        val rows = db.expenseDao().findMonthlyAll(month.toString(), "المرتبات", "المرتبات", from, until)
        assertEquals(2, rows.size)
        assertEquals(hrId, rows.first().id)
        assertTrue(rows.any { it.id == manualId })
    }

    @Test fun monthly_lookup_does_not_confuse_custom_expense_with_recurring_item() = runBlocking {
        val month = YearMonth.of(2026, 11)
        val zone = ZoneId.systemDefault()
        val from = month.atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
        val until = month.plusMonths(1).atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
        db.expenseDao().insert(Expense(
            title = "أدوات نظافة", category = "الإيجار", amountPiasters = 5_000,
            spentAt = from, monthKey = month.toString()
        ))

        val recurring = db.expenseDao().findMonthly(month.toString(), "الإيجار", "الإيجار", from, until)
        assertNull(recurring)
    }
}
