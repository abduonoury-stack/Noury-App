package com.tahseel.students

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.tahseel.students.data.AppDatabase
import com.tahseel.students.data.Student
import com.tahseel.students.data.StudentExitSettlement
import com.tahseel.students.data.StudentExitSettlementEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class StudentExitSettlementDaoTest {
    private lateinit var db: AppDatabase

    @Before fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).allowMainThreadQueries().build()
    }

    @After fun tearDown() = db.close()

    @Test fun concurrent_refunds_cannot_exceed_settlement_or_duplicate_balance() = runBlocking {
        val studentId = db.studentDao().insert(Student(fullName = "اختبار", enrollmentDate = 1L))
        val settlementId = db.studentDao().insertExitSettlement(
            StudentExitSettlement(studentId = studentId, periodKey = "2026-11", withdrawalDate = "2026-11-15",
                attendedDays = 2, monthlyFeePiasters = 10000, paidAmountPiasters = 10000,
                earnedAmountPiasters = 0, refundAmountPiasters = 10000, amountDuePiasters = 0)
        )

        val first = async(Dispatchers.IO) {
            runCatching {
                db.studentDao().recordExitRefundAtomically(settlementId, 7000,
                    StudentExitSettlementEvent(settlementId = settlementId, eventType = "refund_paid", amountPiasters = 7000, details = "first"))
            }.isSuccess
        }
        val second = async(Dispatchers.IO) {
            runCatching {
                db.studentDao().recordExitRefundAtomically(settlementId, 7000,
                    StudentExitSettlementEvent(settlementId = settlementId, eventType = "refund_paid", amountPiasters = 7000, details = "second"))
            }.isSuccess
        }

        assertEquals(1, listOf(first.await(), second.await()).count { it })
        assertEquals(7000L, db.studentDao().getExitSettlement(settlementId)!!.refundedAmountPiasters)
        assertEquals(1, kotlinx.coroutines.flow.first(db.studentDao().observeAllExitSettlementEvents()).size)
    }

    @Test fun cancelled_settlement_rejects_refund_and_does_not_create_event() = runBlocking {
        val studentId = db.studentDao().insert(Student(fullName = "اختبار", enrollmentDate = 1L))
        val settlementId = db.studentDao().insertExitSettlement(
            StudentExitSettlement(studentId = studentId, periodKey = "2026-11", withdrawalDate = "2026-11-15",
                attendedDays = 0, monthlyFeePiasters = 10000, paidAmountPiasters = 10000,
                earnedAmountPiasters = 0, refundAmountPiasters = 10000, amountDuePiasters = 0,
                settlementStatus = "cancelled")
        )

        val result = runCatching {
            db.studentDao().recordExitRefundAtomically(settlementId, 1000,
                StudentExitSettlementEvent(settlementId = settlementId, eventType = "refund_paid", amountPiasters = 1000, details = "blocked"))
        }

        assertTrue(result.isFailure)
        assertEquals(0L, db.studentDao().getExitSettlement(settlementId)!!.refundedAmountPiasters)
        assertTrue(kotlinx.coroutines.flow.first(db.studentDao().observeAllExitSettlementEvents()).isEmpty())
    }
}
