package com.tahseel.students

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.tahseel.students.data.AppDatabase
import com.tahseel.students.data.Employee
import com.tahseel.students.data.EmployeePayroll
import com.tahseel.students.data.EmployeePayrollPayment
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.first
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class EmployeePayrollPaymentDaoTest {
    private lateinit var db: AppDatabase

    @Before fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries().build()
    }

    @After fun tearDown() = db.close()

    @Test fun multiple_payments_are_saved_as_independent_rows_and_summed() = runBlocking {
        val dao = db.hrDao()
        val employeeId = dao.insertEmployee(Employee(fullName = "موظف اختبار", jobTitle = "مدرسة", phone = "01000000000", hireDate = "2026-01-01", baseSalaryPiasters = 100_000))
        dao.savePayroll(EmployeePayroll(employeeId = employeeId, monthKey = "2026-11", basePiasters = 100_000, netPiasters = 100_000))
        val payroll = dao.payroll(employeeId, "2026-11")!!

        dao.insertPayrollPayment(EmployeePayrollPayment(payrollId = payroll.id, amountPiasters = 30_000, paymentDate = "2026-11-05", paymentMethod = "نقدي"))
        dao.insertPayrollPayment(EmployeePayrollPayment(payrollId = payroll.id, amountPiasters = 20_000, paymentDate = "2026-11-12", paymentMethod = "تحويل بنكي"))

        assertEquals(50_000L, dao.payrollPaymentsTotal(payroll.id))
        val history = dao.observePayrollPayments("2026-11").first()
        assertEquals(2, history.size)
        assertEquals(20_000L, history.first().amountPiasters)
    }


    @Test fun voided_payment_stays_in_history_but_is_excluded_from_active_total() = runBlocking {
        val dao = db.hrDao()
        val employeeId = dao.insertEmployee(Employee(fullName = "موظف اختبار 3", jobTitle = "إداري", phone = "01000000002", hireDate = "2026-01-01", baseSalaryPiasters = 100_000))
        dao.savePayroll(EmployeePayroll(employeeId = employeeId, monthKey = "2026-11", basePiasters = 100_000, netPiasters = 100_000))
        val payroll = dao.payroll(employeeId, "2026-11")!!
        val originalId = dao.insertPayrollPayment(EmployeePayrollPayment(
            payrollId = payroll.id, amountPiasters = 30_000, paymentDate = "2026-11-05", paymentMethod = "نقدي"
        ))
        val original = dao.payrollPayment(originalId)!!
        dao.updatePayrollPayment(original.copy(status = "voided", voidedAt = 1234L, voidReason = "تم إدخال مبلغ غير صحيح"))
        val correctionId = dao.insertPayrollPayment(EmployeePayrollPayment(
            payrollId = payroll.id, amountPiasters = 25_000, paymentDate = "2026-11-06",
            paymentMethod = "تحويل بنكي", correctionOfPaymentId = originalId
        ))
        dao.updatePayrollPayment(dao.payrollPayment(originalId)!!.copy(correctedByPaymentId = correctionId))

        assertEquals(25_000L, dao.payrollPaymentsTotal(payroll.id))
        val history = dao.observePayrollPayments("2026-11").first()
        assertEquals(2, history.size)
        assertEquals("voided", history.first { it.id == originalId }.status)
        assertEquals("تم إدخال مبلغ غير صحيح", history.first { it.id == originalId }.voidReason)
        assertEquals(correctionId, history.first { it.id == originalId }.correctedByPaymentId)
        assertEquals(originalId, history.first { it.correctionOfPaymentId != null }.correctionOfPaymentId)
    }

    @Test fun already_voided_payment_cannot_be_reactivated_by_repeated_void_request() = runBlocking {
        val dao = db.hrDao()
        val employeeId = dao.insertEmployee(Employee(fullName = "موظف اختبار 4", jobTitle = "إداري", phone = "01000000003", hireDate = "2026-01-01", baseSalaryPiasters = 100_000))
        dao.savePayroll(EmployeePayroll(employeeId = employeeId, monthKey = "2026-11", basePiasters = 100_000, netPiasters = 100_000))
        val payroll = dao.payroll(employeeId, "2026-11")!!
        val id = dao.insertPayrollPayment(EmployeePayrollPayment(
            payrollId = payroll.id, amountPiasters = 10_000, paymentDate = "2026-11-05", paymentMethod = "نقدي",
            status = "voided", voidedAt = 1234L, voidReason = "اختبار"
        ))
        assertEquals(0L, dao.payrollPaymentsTotal(payroll.id))
        assertEquals("voided", dao.payrollPayment(id)?.status)
    }

    @Test fun updating_payroll_does_not_delete_payment_history() = runBlocking {
        val dao = db.hrDao()
        val employeeId = dao.insertEmployee(Employee(fullName = "موظف اختبار 2", jobTitle = "مشرفة", phone = "01000000001", hireDate = "2026-01-01", baseSalaryPiasters = 90_000))
        dao.savePayroll(EmployeePayroll(employeeId = employeeId, monthKey = "2026-11", basePiasters = 90_000, netPiasters = 90_000))
        val payroll = dao.payroll(employeeId, "2026-11")!!
        dao.insertPayrollPayment(EmployeePayrollPayment(payrollId = payroll.id, amountPiasters = 25_000, paymentDate = "2026-11-07", paymentMethod = "نقدي"))

        dao.savePayroll(payroll.copy(paidPiasters = 25_000, note = "تحديث بعد الصرف"))

        assertNotNull(dao.payroll(employeeId, "2026-11"))
        assertEquals(25_000L, dao.payrollPaymentsTotal(payroll.id))
    }
}

