package com.tahseel.students

import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.tahseel.students.data.AppDatabase
import com.tahseel.students.data.Payment
import com.tahseel.students.data.PaymentRepository
import com.tahseel.students.data.SaveResult
import com.tahseel.students.data.CancelResult
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** اختبارات أجهزة (Instrumented): تُشغَّل على هاتف/محاكي بالأمر connectedDebugAndroidTest */
@RunWith(AndroidJUnit4::class)
class PaymentDaoTest {
    private lateinit var db: AppDatabase
    private lateinit var repo: PaymentRepository

    @Before fun setUp() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(ctx, AppDatabase::class.java).allowMainThreadQueries().build()
        repo = PaymentRepository(db)
    }
    @After fun tearDown() = db.close()

    @Test fun first_and_multiple_receipts_and_total() = runBlocking {
        assertEquals(SaveResult.Success, repo.add("أحمد", "101", 150000))
        assertEquals(SaveResult.Success, repo.add("سارة", "102", 225050))
        assertEquals(SaveResult.Success, repo.add("أحمد", "103", 80000)) // دفعتان لنفس الطالب
        assertEquals(455050L, db.dao().observeTotal().first())
        assertEquals(3, db.dao().observeCount().first())
    }

    @Test fun duplicate_receipt_rejected_by_unique_constraint() = runBlocking {
        repo.add("أحمد", "101", 100)
        assertEquals(SaveResult.DuplicateReceipt, repo.add("سارة", "101", 200))
        assertEquals(1, db.dao().observeCount().first())
        try { db.dao().insert(Payment(studentName = "x", receiptNo = "101", amountPiasters = 1, createdAt = 1)); fail() }
        catch (e: SQLiteConstraintException) { }
    }

    @Test fun edit_updates_totals_and_blocks_duplicate() = runBlocking {
        repo.add("أحمد", "101", 100); repo.add("سارة", "102", 200)
        val p = db.dao().getAllAsc().first()
        assertEquals(SaveResult.Success, repo.update(p.copy(amountPiasters = 500)))
        assertEquals(700L, db.dao().observeTotal().first())
        assertEquals(SaveResult.DuplicateReceipt, repo.update(p.copy(receiptNo = "102")))
        assertEquals(700L, db.dao().observeTotal().first())
    }

    @Test fun edit_keeps_payment_receipt_and_audit_in_sync() = runBlocking {
        assertEquals(SaveResult.Success, repo.add("أحمد", "101", 1000))
        val payment = db.dao().getAllAsc().first().single()

        assertEquals(SaveResult.Success, repo.update(payment.copy(receiptNo = "102", amountPiasters = 1500)))

        val updated = db.dao().getById(payment.id)!!
        val receipt = db.financeDao().receiptForPayment(payment.id)
        val audit = db.financeDao().observeAudit(10).first().single()
        assertEquals("102", updated.receiptNo)
        assertEquals(1500L, updated.amountPiasters)
        assertNotNull(receipt)
        assertEquals("102", receipt!!.receiptNo)
        assertEquals("update", audit.action)
        assertEquals(payment.id, audit.entityId)
    }

    @Test fun failed_duplicate_edit_rolls_back_all_related_changes() = runBlocking {
        assertEquals(SaveResult.Success, repo.add("أحمد", "101", 1000))
        assertEquals(SaveResult.Success, repo.add("سارة", "102", 2000))
        val first = db.dao().getAllAsc().first().first()

        assertEquals(SaveResult.DuplicateReceipt, repo.update(first.copy(receiptNo = "102", amountPiasters = 9999)))

        val unchanged = db.dao().getById(first.id)!!
        assertEquals("101", unchanged.receiptNo)
        assertEquals(1000L, unchanged.amountPiasters)
        assertNull(db.financeDao().receiptForPayment(first.id))
        assertTrue(db.financeDao().observeAudit(10).first().isEmpty())
    }

    @Test fun cancellation_preserves_record_and_updates_totals() = runBlocking {
        repo.add("أحمد", "101", 100); repo.add("سارة", "102", 200)
        val payment = db.dao().getAllAsc().first()
        assertEquals(CancelResult.Success, repo.cancel(payment.id, "إدخال بالخطأ"))
        assertEquals(200L, db.dao().observeTotal().first())
        assertEquals(1, db.dao().observeCount().first())
        val retained = db.dao().getById(payment.id)
        assertNotNull(retained)
        assertTrue(retained!!.isCancelled)
        assertEquals("إدخال بالخطأ", retained.cancellationReason)
        assertEquals(CancelResult.AlreadyCancelled, repo.cancel(payment.id, "محاولة ثانية"))
        assertEquals(200L, db.dao().observeTotal().first())
    }

    @Test fun failed_restore_keeps_existing_data() = runBlocking {
        repo.add("أحمد", "101", 100)
        val bad = listOf(Payment(1, "أ", "X", 1, 1), Payment(2, "ب", "X", 1, 1)) // إيصال مكرر → فشل
        try { repo.replaceAll(bad); fail() } catch (e: Exception) { }
        val now = db.dao().getAllAsc()
        assertEquals(1, now.size); assertEquals("101", now[0].receiptNo)
    }

    @Test fun successful_restore_replaces_all() = runBlocking {
        repo.add("قديم", "OLD", 100)
        repo.replaceAll(listOf(Payment(7, "جديد", "N1", 300, 10), Payment(8, "جديد2", "N2", 400, 11)))
        assertEquals(700L, db.dao().observeTotal().first())
        assertEquals(listOf("N1", "N2"), db.dao().getAllAsc().map { it.receiptNo })
    }
}
