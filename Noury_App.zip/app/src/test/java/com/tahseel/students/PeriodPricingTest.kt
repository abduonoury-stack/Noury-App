package com.tahseel.students

import com.tahseel.students.data.PeriodPriceHistory
import com.tahseel.students.data.resolvePeriodPricePiasters
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PeriodPricingTest {
    @Test fun uses_latest_price_effective_at_month_start() {
        val rows = listOf(
            PeriodPriceHistory(id = 1, periodId = 7, amountPiasters = 70000, effectiveFrom = 100),
            PeriodPriceHistory(id = 2, periodId = 7, amountPiasters = 85000, effectiveFrom = 200),
            PeriodPriceHistory(id = 3, periodId = 8, amountPiasters = 99000, effectiveFrom = 50)
        )
        assertEquals(70000L, resolvePeriodPricePiasters(rows, 7, 199))
        assertEquals(85000L, resolvePeriodPricePiasters(rows, 7, 200))
        assertEquals(85000L, resolvePeriodPricePiasters(rows, 7, 250))
    }

    @Test fun does_not_fall_forward_to_future_or_other_period_prices() {
        val rows = listOf(
            PeriodPriceHistory(id = 1, periodId = 7, amountPiasters = 90000, effectiveFrom = 200),
            PeriodPriceHistory(id = 2, periodId = 8, amountPiasters = 70000, effectiveFrom = 50)
        )
        assertNull(resolvePeriodPricePiasters(rows, 7, 199))
        assertNull(resolvePeriodPricePiasters(rows, 9, 300))
    }

    @Test fun same_effective_date_uses_latest_record_id() {
        val rows = listOf(
            PeriodPriceHistory(id = 4, periodId = 7, amountPiasters = 70000, effectiveFrom = 100),
            PeriodPriceHistory(id = 5, periodId = 7, amountPiasters = 82000, effectiveFrom = 100)
        )
        assertEquals(82000L, resolvePeriodPricePiasters(rows, 7, 100))
    }
}
