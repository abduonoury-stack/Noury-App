package com.tahseel.students

import com.tahseel.students.data.calculateSubscriptionNetDuePiasters
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SubscriptionDiscountTest {
    @Test fun partial_discount_returns_remaining_due() {
        assertEquals(50_000L, calculateSubscriptionNetDuePiasters(70_000L, 20_000L))
    }

    @Test fun full_discount_is_a_valid_zero_due_exemption() {
        assertEquals(0L, calculateSubscriptionNetDuePiasters(70_000L, 70_000L))
    }

    @Test fun discount_cannot_exceed_original_fee() {
        assertNull(calculateSubscriptionNetDuePiasters(70_000L, 70_001L))
    }

    @Test fun negative_discount_is_rejected() {
        assertNull(calculateSubscriptionNetDuePiasters(70_000L, -1L))
    }

    @Test fun zero_or_negative_original_fee_is_rejected() {
        assertNull(calculateSubscriptionNetDuePiasters(0L, 0L))
        assertNull(calculateSubscriptionNetDuePiasters(-1L, 0L))
    }
}
