package com.tahseel.students

import com.tahseel.students.data.*
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.YearMonth

class ExpenseAuditTest {
    private val month = YearMonth.of(2026, 11)
    private fun expense(
        id: Long = 1,
        title: String = "الكهرباء",
        amount: Long = 100_000,
        paid: Long = 50_000,
        dueAt: Long = 1L
    ) = Expense(id = id, title = title, category = "كهرباء", amountPiasters = amount,
        paidAmountPiasters = paid, spentAt = 0L, dueAt = dueAt, monthKey = "2026-11")

    @Test fun overdue_unpaid_balance_is_flagged() {
        val issues = auditExpenseRegister(listOf(expense()), emptyList(), 100L, month)
        assertTrue(issues.any { it.code == "overdue" })
    }

    @Test fun detailed_payments_exceeding_stored_paid_are_an_error() {
        val payment = ExpensePayment(expenseId = 1, amountPiasters = 60_000, paidAt = 1L,
            paymentMethod = "نقدي", accountId = "cash")
        val issues = auditExpenseRegister(listOf(expense()), listOf(payment), 0L, month)
        assertTrue(issues.any { it.code == "payment_ledger_mismatch" && it.severity == ExpenseAuditSeverity.ERROR })
    }

    @Test fun legacy_aggregate_paid_without_detail_is_informational_not_error() {
        val issues = auditExpenseRegister(listOf(expense()), emptyList(), 0L, month)
        assertTrue(issues.any { it.code == "legacy_paid_balance" && it.severity == ExpenseAuditSeverity.INFO })
        assertTrue(issues.none { it.severity == ExpenseAuditSeverity.ERROR })
    }

    @Test fun identical_expense_entries_are_flagged_as_possible_duplicates() {
        val issues = auditExpenseRegister(listOf(expense(), expense(id = 2)), emptyList(), 0L, month)
        assertTrue(issues.any { it.code == "possible_duplicate" })
    }
}
