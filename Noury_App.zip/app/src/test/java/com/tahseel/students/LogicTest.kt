package com.tahseel.students

import com.tahseel.students.data.Payment
import com.tahseel.students.data.SubscriptionPayment
import com.tahseel.students.data.calculateSubscriptionNetDuePiasters
import com.tahseel.students.vm.sumPaidForStudents
import com.tahseel.students.util.BackupCodec
import com.tahseel.students.util.CsvExporter
import com.tahseel.students.util.Money
import com.tahseel.students.util.TextUtil
import org.junit.Assert.*
import org.junit.Test

class LogicTest {
    private fun p(id: Long, n: String, r: String, a: Long, t: Long = 1_700_000_000_000L + id) = Payment(id, n, r, a, t)

    // سيناريوهات 4 و5: مبلغ فارغ / سالب / صفر / نص
    @Test fun money_rejects_invalid() {
        assertNull(Money.parse("")); assertNull(Money.parse("   ")); assertNull(Money.parse("-5"))
        assertNull(Money.parse("0")); assertNull(Money.parse("abc")); assertNull(Money.parse("1.234")); assertNull(Money.parse("1e5"))
    }

    @Test fun money_parses_valid_and_arabic_digits() {
        assertEquals(150000L, Money.parse("1500"))
        assertEquals(225050L, Money.parse("2250.5"))
        assertEquals(225050L, Money.parse("٢٢٥٠٫٥٠"))
        assertEquals(100000L, Money.parse("1,000"))
        assertEquals("1,500.00 ج.م", Money.format(150000))
        assertEquals("2250.50", Money.plain(225050))
    }

    @Test fun arabic_search_normalization() {
        assertEquals(TextUtil.normalize("أحمد"), TextUtil.normalize("احمد"))
        assertEquals(TextUtil.normalize("فاطمة"), TextUtil.normalize("فاطمه"))
        assertEquals("منى حسن", TextUtil.cleanName("  منى    حسن "))
    }

    // سيناريو 13: CSV
    @Test fun csv_has_bom_header_and_rows() {
        val bytes = CsvExporter.build(listOf(p(1, "أحمد, علي", "101", 150000), p(2, "سارة", "102", 225050)))
        assertEquals(0xEF.toByte(), bytes[0]); assertEquals(0xBB.toByte(), bytes[1]); assertEquals(0xBF.toByte(), bytes[2])
        val text = String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
        val lines = text.trim().split("\r\n")
        assertEquals(3, lines.size)
        assertTrue(lines[0].startsWith("المسلسل,اسم الطالب,رقم الإيصال"))
        assertTrue(lines[1].startsWith("1,\"أحمد, علي\",101,1500.00,"))
        assertTrue(lines[2].startsWith("2,سارة,102,2250.50,"))
    }

    @Test fun csv_blocks_formula_injection() {
        assertEquals("'=1+1", CsvExporter.esc("=1+1"))
    }

    // سيناريو 12: نسخة احتياطية واستعادة
    @Test fun backup_roundtrip() {
        val list = listOf(p(1, "أحمد علي", "101", 150000), p(2, "سارة محمد", "102", 225050), p(3, "أحمد علي", "103", 80000))
        val d = BackupCodec.decode(BackupCodec.encode(list, 123L))
        assertTrue(d is BackupCodec.Decoded.Ok)
        d as BackupCodec.Decoded.Ok
        assertEquals(list, d.payments)
        assertEquals(455050L, d.total)
    }

    @Test fun backup_detects_tampering() {
        val json = BackupCodec.encode(listOf(p(1, "أحمد", "101", 150000)), 1L)
        assertTrue(BackupCodec.decode(json.replace("\"amountPiasters\": 150000", "\"amountPiasters\": 160000")) is BackupCodec.Decoded.Bad)
        assertTrue(BackupCodec.decode(json.replace("أحمد", "خالد")) is BackupCodec.Decoded.Bad)
    }

    @Test fun backup_rejects_garbage_and_foreign_json() {
        assertTrue(BackupCodec.decode("not json") is BackupCodec.Decoded.Bad)
        assertTrue(BackupCodec.decode("{}") is BackupCodec.Decoded.Bad)
        assertTrue(BackupCodec.decode("{\"app\":\"other\"}") is BackupCodec.Decoded.Bad)
        assertTrue(BackupCodec.decode("") is BackupCodec.Decoded.Bad)
    }

    @Test fun backup_rejects_duplicate_receipts() {
        val bad = BackupCodec.encode(listOf(p(1, "أ", "101", 100), p(2, "ب", "102", 100)), 1L).replace("\"102\"", "\"101\"")
        assertTrue(BackupCodec.decode(bad) is BackupCodec.Decoded.Bad)
    }

    @Test fun empty_backup_is_valid() {
        val d = BackupCodec.decode(BackupCodec.encode(emptyList(), 1L))
        assertTrue(d is BackupCodec.Decoded.Ok)
    }

    // المرحلة أ: لا تقريب عشري، والصفر مسموح فقط في parseNonNegative
    @Test fun money_no_floating_point_truncation() {
        assertEquals(1999L, Money.parse("19.99"))          // كان 19.99*100 يعطي 1998 مع Double
        assertEquals(1999L, Money.parse("١٩٫٩٩"))
        assertEquals(1L, Money.parse("0.01"))
    }

    @Test fun money_parse_non_negative_allows_zero_only_there() {
        assertEquals(0L, Money.parseNonNegative("0")); assertEquals(0L, Money.parseNonNegative("0.00"))
        assertNull(Money.parseNonNegative("")); assertNull(Money.parseNonNegative("-1")); assertNull(Money.parseNonNegative("1.234"))
        assertNull(Money.parse("0"))
        assertNull(Money.parseNonNegative("100000000.01"))
    }

    @Test fun monthly_subscription_discount_reduces_due_without_changing_gross_fee() {
        assertEquals(50000L, calculateSubscriptionNetDuePiasters(70000L, 20000L))
        assertEquals(70000L, calculateSubscriptionNetDuePiasters(70000L, 0L))
        assertNull(calculateSubscriptionNetDuePiasters(70000L, 70000L))
        assertNull(calculateSubscriptionNetDuePiasters(70000L, 80000L))
        assertNull(calculateSubscriptionNetDuePiasters(70000L, -100L))
        assertNull(calculateSubscriptionNetDuePiasters(0L, 0L))
    }

    @Test fun monthly_report_arrears_ignore_payments_from_inactive_students() {
        val rows = listOf(
            SubscriptionPayment(studentId = 1, periodKey = "2026-11", dueAmountPiasters = 70000, paidAmountPiasters = 70000, paymentId = 1),
            SubscriptionPayment(studentId = 2, periodKey = "2026-11", dueAmountPiasters = 70000, paidAmountPiasters = 70000, paymentId = 2)
        )
        assertEquals(70000L, sumPaidForStudents(rows, setOf(1L)))
        assertEquals(70000L, (140000L - sumPaidForStudents(rows, setOf(1L))).coerceAtLeast(0L))
    }

    @Test fun money_validates_thousands_separators() {
        assertEquals(100000L, Money.parse("1,000"))
        assertEquals(100000L, Money.parse("١٬٠٠٠"))
        assertEquals(123456789L, Money.parse("1,234,567.89"))
        assertNull(Money.parse("1,00"))
        assertNull(Money.parse("12,34,567"))
        assertNull(Money.parse("1,,000"))
        assertNull(Money.parse("1 00"))
        assertNull(Money.parse("1,000 000"))
    }
}
