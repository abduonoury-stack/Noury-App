package com.tahseel.students

import com.tahseel.students.data.*
import org.junit.Assert.*
import org.junit.Test

class CashControlTest {
    @Test fun noOpeningBalanceMeansNoBookBalance() {
        assertNull(expectedCashBalance(emptyList(), null, 2_000L))
    }

    @Test fun openingBalanceIncludesOnlyConfirmedMovementsAfterEffectiveDate() {
        val rows = listOf(
            CashMovement("in", 1_500L, CashDirection.INFLOW, "تحصيل", "إيصال", 5_000L, "payments#1", accountId = "cash"),
            CashMovement("out", 1_600L, CashDirection.OUTFLOW, "مصروف", "مصروف", 2_000L, "expenses#1", accountId = "cash"),
            CashMovement("excluded", 1_700L, CashDirection.INFLOW, "مراجعة", "معلق", 9_000L, "x", includedInTotals = false, accountId = "cash"),
            CashMovement("before", 900L, CashDirection.INFLOW, "قديم", "قديم", 7_000L, "old")
        )
        val opening = CashOpeningBalance(amountPiasters = 10_000L, effectiveAt = 1_000L, note = "جرد معتمد")
        assertEquals(13_000L, expectedCashBalance(rows, opening, 2_000L))
    }

    @Test fun beforeOpeningEffectiveDateHasNoKnownBalance() {
        val opening = CashOpeningBalance(amountPiasters = 8_000L, effectiveAt = 2_000L, note = "اعتماد")
        assertNull(expectedCashBalance(emptyList(), opening, 1_000L))
    }
}
