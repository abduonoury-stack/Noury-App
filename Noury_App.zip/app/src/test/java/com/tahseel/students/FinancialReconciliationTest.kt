package com.tahseel.students

import com.tahseel.students.data.Payment
import com.tahseel.students.data.netCashMovement
import com.tahseel.students.data.sumValidReceiptAmounts
import org.junit.Assert.assertEquals
import org.junit.Test

class FinancialReconciliationTest {
    @Test fun receipt_total_excludes_cancelled_receipts_and_clamps_negative_legacy_amounts() {
        val rows = listOf(
            Payment(id = 1, studentName = "A", receiptNo = "R1", amountPiasters = 12000, createdAt = 1),
            Payment(id = 2, studentName = "B", receiptNo = "R2", amountPiasters = 5000, createdAt = 2, isCancelled = true),
            Payment(id = 3, studentName = "C", receiptNo = "R3", amountPiasters = -300, createdAt = 3)
        )
        assertEquals(12000L, sumValidReceiptAmounts(rows))
    }

    @Test fun net_cash_movement_uses_all_valid_receipts_less_paid_expenses() {
        assertEquals(7500L, netCashMovement(12500L, 5000L))
        assertEquals(-2500L, netCashMovement(2500L, 5000L))
        assertEquals(0L, netCashMovement(-100L, -200L))
    }
}
