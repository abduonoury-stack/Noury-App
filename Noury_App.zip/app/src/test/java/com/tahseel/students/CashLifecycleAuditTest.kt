package com.tahseel.students

import com.tahseel.students.data.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CashLifecycleAuditTest {
    @Test fun clean_refund_exit_payroll_loan_and_salary_sync_records_have_no_issues() {
        val result = auditCashLifecycle(
            refundCredits = listOf(RefundCredit(id = 1, studentId = 10, paymentId = 100, originalAmountPiasters = 5000, remainingAmountPiasters = 2000)),
            refundTransactions = listOf(RefundTransaction(id = 1, refundCreditId = 1, amountPiasters = 3000, refundedAt = 1000)),
            settlements = listOf(StudentExitSettlement(id = 2, studentId = 20, periodKey = "2026-10", withdrawalDate = "2026-10-10", attendedDays = 10, monthlyFeePiasters = 10000, paidAmountPiasters = 10000, earnedAmountPiasters = 3000, refundAmountPiasters = 7000, amountDuePiasters = 0, refundedAmountPiasters = 4000)),
            settlementEvents = listOf(StudentExitSettlementEvent(id = 2, settlementId = 2, eventType = "refund_paid", amountPiasters = 4000, details = "صرف", createdAt = 2000)),
            payrollRows = listOf(EmployeePayroll(id = 3, employeeId = 30, monthKey = "2026-10", basePiasters = 10000, loanDeductionPiasters = 2000, netPiasters = 8000, paidPiasters = 5000)),
            payrollPayments = listOf(EmployeePayrollPayment(id = 4, payrollId = 3, amountPiasters = 5000, paymentDate = "2026-10-05", paymentMethod = "cash")),
            loans = listOf(EmployeeLoan(id = 5, employeeId = 30, amountPiasters = 5000, monthlyInstallmentPiasters = 2000, remainingPiasters = 3000, startMonth = "2026-10")),
            expenses = listOf(Expense(id = 6, title = "المرتبات", category = "المرتبات", amountPiasters = 8000, spentAt = 1, note = "HR_SYNC: payroll", paidAmountPiasters = 5000, monthKey = "2026-10"))
        )
        assertTrue(result.isConsistent)
        assertEquals(0, result.issues.size)
        assertEquals(7000L, result.refundTransactionsTotal + result.exitRefundsTotal)
    }

    @Test fun mismatched_refund_and_exit_ledgers_are_reported_without_mutating_rows() {
        val credit = RefundCredit(id = 1, studentId = 10, paymentId = 100, originalAmountPiasters = 5000, remainingAmountPiasters = 1000)
        val settlement = StudentExitSettlement(id = 2, studentId = 20, periodKey = "2026-10", withdrawalDate = "2026-10-10", attendedDays = 10, monthlyFeePiasters = 10000, paidAmountPiasters = 10000, earnedAmountPiasters = 3000, refundAmountPiasters = 7000, amountDuePiasters = 0, refundedAmountPiasters = 4000)
        val result = auditCashLifecycle(
            refundCredits = listOf(credit), refundTransactions = listOf(RefundTransaction(id = 1, refundCreditId = 1, amountPiasters = 3000)),
            settlements = listOf(settlement), settlementEvents = emptyList(), payrollRows = emptyList(), payrollPayments = emptyList(), loans = emptyList(), expenses = emptyList()
        )
        assertFalse(result.isConsistent)
        assertTrue(result.issues.any { it.category == "استرداد" })
        assertTrue(result.issues.any { it.category == "تسوية انسحاب" })
        assertEquals(1000L, credit.remainingAmountPiasters)
        assertEquals(4000L, settlement.refundedAmountPiasters)
    }

    @Test fun duplicate_refund_candidate_is_flagged_for_review_not_counted_as_deleted() {
        val timestamp = 1_800_000_000_000L
        val result = auditCashLifecycle(
            refundCredits = listOf(RefundCredit(id = 1, studentId = 10, paymentId = 100, originalAmountPiasters = 5000, remainingAmountPiasters = 0)),
            refundTransactions = listOf(RefundTransaction(id = 1, refundCreditId = 1, amountPiasters = 5000, refundedAt = timestamp)),
            settlements = listOf(StudentExitSettlement(id = 2, studentId = 10, periodKey = "2026-10", withdrawalDate = "2026-10-10", attendedDays = 10, monthlyFeePiasters = 10000, paidAmountPiasters = 10000, earnedAmountPiasters = 5000, refundAmountPiasters = 5000, amountDuePiasters = 0, refundedAmountPiasters = 5000)),
            settlementEvents = listOf(StudentExitSettlementEvent(id = 2, settlementId = 2, eventType = "refund_paid", amountPiasters = 5000, details = "صرف", createdAt = timestamp + 1000)),
            payrollRows = emptyList(), payrollPayments = emptyList(), loans = emptyList(), expenses = emptyList()
        )
        assertTrue(result.issues.any { it.category == "احتمال تكرار استرداد" })
        assertEquals(10000L, result.refundTransactionsTotal + result.exitRefundsTotal)
    }

    @Test fun payroll_and_loan_mismatches_are_reported() {
        val result = auditCashLifecycle(
            refundCredits = emptyList(), refundTransactions = emptyList(), settlements = emptyList(), settlementEvents = emptyList(),
            payrollRows = listOf(EmployeePayroll(id = 3, employeeId = 30, monthKey = "2026-10", basePiasters = 10000, loanDeductionPiasters = 1000, netPiasters = 9000, paidPiasters = 7000)),
            payrollPayments = listOf(EmployeePayrollPayment(id = 4, payrollId = 3, amountPiasters = 6000, paymentDate = "2026-10-05", paymentMethod = "cash")),
            loans = listOf(EmployeeLoan(id = 5, employeeId = 30, amountPiasters = 5000, monthlyInstallmentPiasters = 1000, remainingPiasters = 3000, startMonth = "2026-10")),
            expenses = emptyList()
        )
        assertTrue(result.issues.any { it.category == "مرتبات" })
        assertTrue(result.issues.any { it.category == "سلف الموظفين" })
        assertTrue(result.issues.any { it.category == "مزامنة المرتبات" })
    }

    @Test fun payroll_reversal_separates_actual_recovery_from_employee_receivable() {
        val payment = EmployeePayrollPayment(
            id = 20, payrollId = 4, amountPiasters = 12000, paymentDate = "2026-11-05",
            paymentMethod = "نقدي", status = "reversed", voidReason = "صرف بالخطأ"
        )
        val reversal = EmployeePayrollReversal(id = 8, originalPaymentId = 20, amountPiasters = 12000, reason = "صرف بالخطأ")
        val recovery = EmployeePayrollRecoveryTransaction(id = 9, reversalId = 8, amountPiasters = 5000, accountId = "cash")
        val audit = auditCashLifecycle(
            refundCredits = emptyList(), refundTransactions = emptyList(), settlements = emptyList(), settlementEvents = emptyList(),
            payrollRows = emptyList(), payrollPayments = listOf(payment), loans = emptyList(), expenses = emptyList(),
            payrollReversals = listOf(reversal), payrollRecoveries = listOf(recovery)
        )
        assertEquals(12000L, audit.payrollReversedTotal)
        assertEquals(5000L, audit.payrollRecoveredTotal)
        assertEquals(7000L, audit.payrollReceivableTotal)
        assertTrue(audit.issues.isEmpty())
    }


    @Test fun linked_exit_refund_credit_and_settlement_event_are_not_reported_as_duplicate() {
        val settlement = StudentExitSettlement(id = 22, studentId = 7, periodKey = "2026-11", withdrawalDate = "2026-11-12", attendedDays = 10, monthlyFeePiasters = 10000, paidAmountPiasters = 10000, earnedAmountPiasters = 4000, refundAmountPiasters = 6000, amountDuePiasters = 0, refundedAmountPiasters = 2500)
        val credit = RefundCredit(id = 5, studentId = 7, paymentId = null, originalAmountPiasters = 6000, remainingAmountPiasters = 3500, sourceType = "exit_settlement", sourceId = 22)
        val tx = RefundTransaction(id = 9, refundCreditId = 5, amountPiasters = 2500, refundedAt = 1500, method = "exit_settlement")
        val event = StudentExitSettlementEvent(id = 11, settlementId = 22, eventType = "refund_paid", amountPiasters = 2500, details = "صرف", createdAt = 1600)
        val result = auditCashLifecycle(
            refundCredits = listOf(credit), refundTransactions = listOf(tx), settlements = listOf(settlement),
            settlementEvents = listOf(event), payrollRows = emptyList(), payrollPayments = emptyList(),
            loans = emptyList(), expenses = emptyList()
        )
        assertFalse(result.issues.any { it.category == "احتمال تكرار استرداد" })
    }

}
