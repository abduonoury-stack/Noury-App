package com.tahseel.students

import com.tahseel.students.data.EmployeePayroll
import com.tahseel.students.data.payrollAccrualDrafts
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class PayrollAccountingTest {
    @Test fun accrual_splits_net_payable_loan_recovery_and_deductions() {
        val row = EmployeePayroll(employeeId = 7, monthKey = "2026-11", basePiasters = 100_000, allowancesPiasters = 10_000, bonusesPiasters = 5_000, deductionsPiasters = 8_000, loanDeductionPiasters = 12_000, netPiasters = 95_000)
        val lines = payrollAccrualDrafts(row, 5200, 2200, 1210)
        assertEquals(115_000L, lines.sumOf { it.debitPiasters })
        assertEquals(115_000L, lines.sumOf { it.creditPiasters })
        assertEquals(95_000L, lines.single { it.accountId == 2200L }.creditPiasters)
        assertEquals(12_000L, lines.single { it.accountId == 1210L }.creditPiasters)
    }

    @Test fun accrual_rejects_inconsistent_payroll_components() {
        val row = EmployeePayroll(employeeId = 7, monthKey = "2026-11", basePiasters = 100_000, deductionsPiasters = 8_000, loanDeductionPiasters = 12_000, netPiasters = 90_000)
        assertThrows(IllegalArgumentException::class.java) { payrollAccrualDrafts(row, 5200, 2200, 1210) }
    }
}
