package com.tahseel.students

import com.tahseel.students.data.Expense
import com.tahseel.students.data.expenseMonthTotals
import com.tahseel.students.data.expensesForMonth
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId

class ExpenseAccountingTest {
    private val zone = ZoneId.of("UTC")
    private fun millis(date: String) = Instant.parse(date).toEpochMilli()

    @Test fun month_filter_includes_month_key_and_legacy_rows_only() {
        val rows = listOf(
            Expense(id = 1, title = "rent", category = "rent", amountPiasters = 100, spentAt = millis("2026-10-01T00:00:00Z"), monthKey = "2026-11"),
            Expense(id = 2, title = "legacy", category = "other", amountPiasters = 200, spentAt = millis("2026-11-30T23:59:59Z"), monthKey = ""),
            Expense(id = 3, title = "old", category = "other", amountPiasters = 300, spentAt = millis("2026-10-31T23:59:59Z"), monthKey = "")
        )
        assertEquals(listOf(1L, 2L), expensesForMonth(rows, YearMonth.of(2026, 11), zone).map { it.id })
    }

    @Test fun totals_clamp_negative_and_overpaid_legacy_values_consistently() {
        val rows = listOf(
            Expense(id = 1, title = "A", category = "A", amountPiasters = 1000, spentAt = 0, paidAmountPiasters = 1200),
            Expense(id = 2, title = "B", category = "B", amountPiasters = 500, spentAt = 0, paidAmountPiasters = -50),
            Expense(id = 3, title = "C", category = "C", amountPiasters = -100, spentAt = 0, paidAmountPiasters = 20)
        )
        val totals = expenseMonthTotals(rows)
        assertEquals(1500L, totals.committed)
        assertEquals(1000L, totals.paid)
        assertEquals(500L, totals.remaining)
    }
}
