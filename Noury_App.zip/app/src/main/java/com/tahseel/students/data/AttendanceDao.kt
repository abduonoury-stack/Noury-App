package com.tahseel.students.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AttendanceDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveDay(records: List<Attendance>)

    @Query("UPDATE attendance SET className = :newName WHERE className = :oldName")
    suspend fun renameClassHistory(oldName: String, newName: String): Int

    @Query("SELECT * FROM attendance WHERE className = :className AND attendanceDate = :date")
    fun observeDay(className: String, date: String): Flow<List<Attendance>>

    @Query("SELECT * FROM attendance WHERE attendanceDate = :date ORDER BY className COLLATE NOCASE, studentName COLLATE NOCASE")
    fun observeAllDay(date: String): Flow<List<Attendance>>

    @Query("SELECT * FROM attendance WHERE className = :className ORDER BY attendanceDate DESC, studentName COLLATE NOCASE")
    fun observeClassHistory(className: String): Flow<List<Attendance>>

    @Query("SELECT * FROM attendance WHERE className = :className ORDER BY attendanceDate DESC, studentName COLLATE NOCASE")
    suspend fun classHistory(className: String): List<Attendance>

    @Query("SELECT DISTINCT attendanceDate FROM attendance WHERE className = :className ORDER BY attendanceDate DESC")
    suspend fun classDays(className: String): List<String>

    @Query("SELECT * FROM attendance WHERE studentId = :studentId ORDER BY attendanceDate DESC, id DESC")
    fun observeStudentHistory(studentId: Long): Flow<List<Attendance>>

    @Query("SELECT * FROM attendance WHERE className = :className AND studentId = :studentId ORDER BY attendanceDate DESC")
    suspend fun studentHistory(className: String, studentId: Long): List<Attendance>
}
