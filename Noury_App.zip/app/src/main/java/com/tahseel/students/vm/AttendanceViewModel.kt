package com.tahseel.students.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tahseel.students.data.Attendance
import com.tahseel.students.data.AttendanceDao
import com.tahseel.students.data.ClassroomDao
import com.tahseel.students.data.StudentDao
import com.tahseel.students.data.FinanceDao
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import com.tahseel.students.util.WorkdaySettings

class AttendanceViewModel(private val attendance: AttendanceDao, classroomsDao: ClassroomDao, private val studentsDao: StudentDao, private val financeDao: FinanceDao) : ViewModel() {
    val classrooms = classroomsDao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val students = studentsDao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private val _workdays = MutableStateFlow(WorkdaySettings.defaultDays)
    val workdays = _workdays.asStateFlow()
    init { refreshWorkdays() }
    fun refreshWorkdays() { viewModelScope.launch { _workdays.value = WorkdaySettings.load(financeDao) } }
    private val _day = MutableStateFlow<List<Attendance>>(emptyList())
    val day = _day.asStateFlow()
    private val _history = MutableStateFlow<List<Attendance>>(emptyList())
    val history = _history.asStateFlow()
    private val _allDay = MutableStateFlow<List<Attendance>>(emptyList())
    val allDay = _allDay.asStateFlow()

    private var dayJob: Job? = null
    private var historyJob: Job? = null
    private var allDayJob: Job? = null

    fun loadAllDay(date: String) {
        allDayJob?.cancel()
        allDayJob = viewModelScope.launch { attendance.observeAllDay(date).collect { _allDay.value = it } }
    }
    fun load(className: String, date: String) {
        dayJob?.cancel()
        historyJob?.cancel()
        _day.value = emptyList()
        _history.value = emptyList()
        dayJob = viewModelScope.launch { attendance.observeDay(className, date).collect { _day.value = it } }
        historyJob = viewModelScope.launch { attendance.observeClassHistory(className).collect { _history.value = it } }
    }
    fun save(className: String, date: String, studentIds: List<Long>, current: Map<Long, Boolean>, onDone: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                val selectedDate = runCatching { LocalDate.parse(date) }.getOrNull()
                if (selectedDate == null) { onDone("تاريخ الحضور غير صحيح"); return@launch }
                if (!WorkdaySettings.isWorkday(selectedDate, workdays.value)) {
                    onDone("هذا اليوم إجازة أسبوعية حسب أيام عمل الأكاديمية، ولا يمكن تسجيل الحضور أو الغياب فيه")
                    return@launch
                }
                val names = students.value.associateBy { it.id }
                val records = studentIds.mapNotNull { id -> names[id]?.let { s ->
                    Attendance(studentId = id, studentName = s.fullName, className = className, attendanceDate = date, status = if (current[id] == true) "present" else "absent")
                } }
                attendance.saveDay(records)
                onDone(null)
            } catch (e: Exception) { onDone(e.message ?: "تعذر حفظ الحضور") }
        }
    }
    /**
     * Finds students absent on the three most recent saved nursery workdays
     * strictly BEFORE the date currently selected on the attendance screen.
     * Students absent for three or more consecutive saved workdays qualify.
     * The selected day is deliberately excluded so the report can be used
     * before today's attendance has been saved.
     */
    fun consecutiveAbsenteesAll(
        beforeDate: String,
        onResult: (List<Pair<Attendance, List<String>>>) -> Unit
    ) {
        viewModelScope.launch {
            val result = mutableListOf<Pair<Attendance, List<String>>>()
            for (room in classrooms.value) {
                val dates = attendance.classDays(room.name)
                    .filter { it < beforeDate }
                    .filter { key -> runCatching { WorkdaySettings.isWorkday(LocalDate.parse(key), workdays.value) }.getOrDefault(false) }
                    .take(3)
                if (dates.size < 3) continue
                val recent = attendance.classHistory(room.name).filter { it.attendanceDate in dates }
                recent.groupBy { it.studentId }.values.forEach { rows ->
                    val byDate = rows.associateBy { it.attendanceDate }
                    if (dates.all { byDate[it]?.status == "absent" }) {
                        result += rows.first() to dates.sorted()
                    }
                }
            }
            onResult(result.distinctBy { it.first.studentId })
        }
    }

    fun consecutiveAbsentees(
        className: String,
        beforeDate: String,
        onResult: (List<Pair<Attendance, List<String>>>) -> Unit
    ) {
        viewModelScope.launch {
            val dates = attendance.classDays(className)
                .filter { it < beforeDate }
                .filter { key -> runCatching { WorkdaySettings.isWorkday(LocalDate.parse(key), workdays.value) }.getOrDefault(false) }
                .take(3)
            if (dates.size < 3) { onResult(emptyList()); return@launch }

            val recent = attendance.classHistory(className)
                .filter { it.attendanceDate in dates }
            val byStudent = recent.groupBy { it.studentId }
            val result = byStudent.values.mapNotNull { rows ->
                val map = rows.associateBy { it.attendanceDate }
                if (dates.all { map[it]?.status == "absent" }) {
                    rows.first() to dates.sorted()
                } else null
            }
            onResult(result)
        }
    }
}
