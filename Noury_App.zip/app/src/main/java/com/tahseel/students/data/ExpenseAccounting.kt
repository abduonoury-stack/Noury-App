package com.tahseel.students.data

import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId

data class ExpenseMonthTotals(
    val committed: Long,
    val paid: Long,
    val remaining: Long
)

/** One canonical month filter for current monthKey rows and legacy rows without monthKey. */
fun expensesForMonth(
    rows: List<Expense>,
    month: YearMonth,
    zone: ZoneId = ZoneId.systemDefault()
): List<Expense> {
    val from = month.atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
    val until = month.plusMonths(1).atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
    return rows.filter { row ->
        row.deletedAt == null && (row.monthKey == month.toString() ||
            (row.monthKey.isBlank() && row.spentAt >= from && row.spentAt < until))
    }
}

/** Clamp legacy or corrupted values identically in dashboard, reports and expense screens. */
fun expenseMonthTotals(rows: List<Expense>): ExpenseMonthTotals {
    val committed = rows.sumOf { it.amountPiasters.coerceAtLeast(0L) }
    val paid = rows.sumOf { row ->
        row.paidAmountPiasters.coerceIn(0L, row.amountPiasters.coerceAtLeast(0L))
    }
    return ExpenseMonthTotals(committed, paid, (committed - paid).coerceAtLeast(0L))
}
