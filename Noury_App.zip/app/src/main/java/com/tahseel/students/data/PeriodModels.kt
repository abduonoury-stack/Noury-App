package com.tahseel.students.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** فترة حضور قابلة للإدارة؛ السعر محفوظ بالقروش. */
@Entity(tableName = "attendance_periods", indices = [Index("isActive")])
data class AttendancePeriod(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val startTime: String,
    val endTime: String,
    val monthlyFeePiasters: Long,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

/** تاريخ أسعار الفترة؛ لا يُعدّل أي سجل سابق عند إضافة سعر جديد. */
@Entity(tableName = "period_price_history", indices = [Index("periodId"), Index("effectiveFrom")])
data class PeriodPriceHistory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val periodId: Long,
    val amountPiasters: Long,
    val effectiveFrom: Long,
    val recordedAt: Long = System.currentTimeMillis()
)

/** Resolves the price applicable to a billing month. No current-price or legacy fallback is allowed. */
fun resolvePeriodPricePiasters(
    history: List<PeriodPriceHistory>,
    periodId: Long,
    billingMonthStart: Long
): Long? = history.asSequence()
    .filter { it.periodId == periodId && it.effectiveFrom <= billingMonthStart }
    .maxWithOrNull(compareBy<PeriodPriceHistory> { it.effectiveFrom }.thenBy { it.id })
    ?.amountPiasters
