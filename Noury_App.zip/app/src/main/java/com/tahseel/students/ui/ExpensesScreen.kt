package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tahseel.students.data.Expense
import com.tahseel.students.data.ExpenseDao
import com.tahseel.students.data.CashAccountDao
import com.tahseel.students.data.expensesForMonth
import com.tahseel.students.data.expenseMonthTotals
import com.tahseel.students.util.Money
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale

private val recurringExpenseNames = listOf("الإيجار", "المرتبات", "فاتورة المياه", "فاتورة الكهرباء", "قرض البنك", "عامل النظافة")

class ExpensesViewModel(private val dao: ExpenseDao, cashAccountDao: CashAccountDao) : ViewModel() {
    val accounts = cashAccountDao.observeActive().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val items = dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val payments = dao.observeAllPayments().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun ensureMonth(month: YearMonth) = viewModelScope.launch {
        val zone = ZoneId.systemDefault()
        val monthStart = month.atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
        val nextMonthStart = month.plusMonths(1).atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
        recurringExpenseNames.forEach { name ->
            if (dao.findMonthly(month.toString(), name, name, monthStart, nextMonthStart) == null) {
                val due = month.atDay(5).atStartOfDay(zone).toInstant().toEpochMilli()
                dao.insertIfMissing(Expense(title = name, category = name, amountPiasters = 0L,
                    spentAt = monthStart, note = "", paidAmountPiasters = 0L, dueAt = due, monthKey = month.toString()))
            }
        }
    }

    fun save(id: Long?, title: String, category: String, amount: Long, paid: Long, note: String, dueAt: Long, month: YearMonth) = viewModelScope.launch {
        val old = id?.let { items.value.firstOrNull { e -> e.id == it } }
        // بند المرتبات مصدره شؤون العاملين حصريًا ولا يُسمح بإنشائه أو تعديله يدويًا.
        val normalizedTitle = title.trim()
        val isSalaryEntry = category == "المرتبات" || normalizedTitle.contains("المرتبات") || normalizedTitle.contains("مرتبات") || normalizedTitle.contains("رواتب")
        if (isSalaryEntry || old?.note?.startsWith("HR_SYNC:") == true) return@launch
        val now = System.currentTimeMillis()
        val monthStart = month.atDay(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        if (old != null && amount < old.paidAmountPiasters) return@launch
        val item = Expense(id = id ?: 0, title = title.trim(), category = category,
            amountPiasters = amount.coerceAtLeast(0), spentAt = monthStart, note = note.trim(),
            createdAt = old?.createdAt ?: now, updatedAt = now,
            paidAmountPiasters = old?.paidAmountPiasters ?: 0L, dueAt = dueAt, monthKey = month.toString())
        if (id == null) dao.insert(item) else dao.update(item)
    }
    fun recordPayment(expenseId: Long, amount: Long, date: LocalDate, method: String, note: String, accountId: String) = viewModelScope.launch {
        val timestamp = date.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        dao.recordPayment(expenseId, amount, timestamp, method, note, accountId)
    }
    fun delete(id: Long) = viewModelScope.launch {
        val old = items.value.firstOrNull { it.id == id } ?: return@launch
        if (old.note.startsWith("HR_SYNC:")) return@launch
        if (dao.countPayments(id) > 0) return@launch
        dao.delete(id)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpensesScreen(vm: ExpensesViewModel, onBack: () -> Unit) {
    val rows by vm.items.collectAsState()
    val paymentRows by vm.payments.collectAsState()
    val cashAccounts by vm.accounts.collectAsState()
    var month by remember { mutableStateOf(YearMonth.now()) }
    LaunchedEffect(month) { vm.ensureMonth(month) }
    val monthRows = expensesForMonth(rows, month).filterNot { it.category == "أرشيف مزامنة المرتبات" }
    val expenseTotals = expenseMonthTotals(monthRows)
    val total = expenseTotals.committed
    val paidTotal = expenseTotals.paid
    val remaining = expenseTotals.remaining
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var paid by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var dueAt by remember { mutableLongStateOf(month.atDay(5).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()) }
    var editing by remember { mutableStateOf<Long?>(null) }
    var showDatePicker by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<Long?>(null) }
    var paymentTarget by remember { mutableStateOf<Expense?>(null) }
    var paymentAmount by remember { mutableStateOf("") }
    var paymentDate by remember { mutableStateOf(LocalDate.now().toString()) }
    var paymentMethod by remember { mutableStateOf("نقدي") }
    var paymentAccountId by remember { mutableStateOf("cash") }
    var paymentNote by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("أخرى") }
    val moneyInput: (String) -> Long = { Money.parseNonNegative(it) ?: 0L }
    AppScaffold(title = "المصروفات الشهرية", onBack = onBack) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(shape = MaterialTheme.shapes.large) { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { month = month.minusMonths(1) }) { Text("‹ السابق") }
                    Text(month.format(DateTimeFormatter.ofPattern("yyyy / MM")), style = MaterialTheme.typography.titleLarge)
                    TextButton(onClick = { month = month.plusMonths(1) }) { Text("التالي ›") }
                }
                SummaryLine("إجمالي الالتزامات", total)
                SummaryLine("المدفوع فعليًا", paidTotal)
                SummaryLine("المتبقي", remaining, true)
            } }
            Text("البنود الشهرية الثابتة", style = MaterialTheme.typography.titleMedium)
            Text("تُنشأ البنود تلقائيًا لكل شهر. سجّل كل دفعة بتاريخها وطريقة دفعها؛ والمتبقي يُحسب تلقائيًا.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            monthRows.forEach { item ->
                Card(shape = MaterialTheme.shapes.medium) { Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(item.title, style = MaterialTheme.typography.titleMedium)
                            Text(when { item.amountPiasters == 0L -> "لم يتم تحديد القيمة"; item.paidAmountPiasters >= item.amountPiasters -> "مدفوع بالكامل"; item.paidAmountPiasters > 0 -> "مدفوع جزئيًا"; else -> "لم يُدفع" }, style = MaterialTheme.typography.bodySmall, color = if (item.amountPiasters > item.paidAmountPiasters) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                        }
                        if (item.note.startsWith("HR_SYNC:")) {
                            Text("مُدار تلقائيًا من شؤون العاملين", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        } else {
                            IconButton(onClick = { editing = item.id; title = item.title; selectedCategory = item.category; amount = "%.2f".format(Locale.US, item.amountPiasters / 100.0); paid = "%.2f".format(Locale.US, item.paidAmountPiasters / 100.0); note = item.note; dueAt = item.dueAt }) { Icon(Icons.Default.Edit, contentDescription = "تعديل") }
                            if (paymentRows.none { it.expenseId == item.id }) {
                                IconButton(onClick = { deleteTarget = item.id }) { Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error) }
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("القيمة: ${Money.format(item.amountPiasters)}")
                        Text("المدفوع: ${Money.format(item.paidAmountPiasters)}")
                    }
                    Text("المتبقي: ${Money.format((item.amountPiasters - item.paidAmountPiasters).coerceAtLeast(0))}", color = MaterialTheme.colorScheme.error)
                    if (!item.note.startsWith("HR_SYNC:") && item.paidAmountPiasters < item.amountPiasters) {
                        OutlinedButton(onClick = { paymentTarget = item; paymentAmount = ""; paymentDate = LocalDate.now().toString(); paymentMethod = "نقدي"; paymentAccountId = "cash"; paymentNote = "" }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل دفعة جديدة") }
                    }
                    paymentRows.filter { it.expenseId == item.id }.sortedByDescending { it.paidAt }.forEach { payment ->
                        Text("دفعة ${Money.format(payment.amountPiasters)} • ${Instant.ofEpochMilli(payment.paidAt).atZone(ZoneId.systemDefault()).toLocalDate()} • ${payment.paymentMethod}", style = MaterialTheme.typography.bodySmall)
                    }
                    Text("الاستحقاق: ${Instant.ofEpochMilli(item.dueAt).atZone(ZoneId.systemDefault()).toLocalDate()}", style = MaterialTheme.typography.bodySmall)
                } }
            }
            HorizontalDivider()
            Text(if (editing == null) "إضافة مصروف آخر" else "تعديل بند المصروف", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(title, { title = it }, label = { Text("اسم المصروف") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Text("البند")
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                recurringExpenseNames.filterNot { it == "المرتبات" }.chunked(2).forEach { group -> Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { group.forEach { c -> FilterChip(selected = selectedCategory == c, onClick = { selectedCategory = c; if (editing == null) title = c }, label = { Text(c) }) } } }
                FilterChip(selected = selectedCategory == "أخرى", onClick = { selectedCategory = "أخرى" }, label = { Text("أخرى") })
            }
            OutlinedTextField(amount, { amount = it.filter { c -> c.isDigit() || c == '.' || c == ',' } }, label = { Text("إجمالي المصروف بالجنيه") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Text("يُسجّل المدفوع من خلال دفعات منفصلة بتاريخ وطريقة دفع محددين.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = { showDatePicker = true }, modifier = Modifier.fillMaxWidth()) { Text("تاريخ الاستحقاق: ${Instant.ofEpochMilli(dueAt).atZone(ZoneId.systemDefault()).toLocalDate()}") }
            OutlinedTextField(note, { note = it }, label = { Text("ملاحظات (اختياري)") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                val totalP = moneyInput(amount)
                if (title.isNotBlank() && totalP > 0) {
                    vm.save(editing, title, selectedCategory, totalP, 0L, note, dueAt, month)
                    editing = null; title = ""; amount = ""; paid = ""; note = ""; selectedCategory = "أخرى"
                }
            }, modifier = Modifier.fillMaxWidth(), enabled = title.isNotBlank() && moneyInput(amount) > 0 && moneyInput(amount) >= (rows.firstOrNull { it.id == editing }?.paidAmountPiasters ?: 0L)) { Text(if (editing == null) "حفظ المصروف" else "حفظ التعديلات") }
            if (editing != null) TextButton(onClick = { editing = null; title = ""; amount = ""; paid = ""; note = ""; selectedCategory = "أخرى" }) { Text("إلغاء التعديل") }
        }
    }
    if (showDatePicker) {
        val pickerState = rememberDatePickerState(initialSelectedDateMillis = dueAt)
        DatePickerDialog(onDismissRequest = { showDatePicker = false }, confirmButton = { TextButton(onClick = { dueAt = pickerState.selectedDateMillis ?: dueAt; showDatePicker = false }) { Text("تأكيد") } }, dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("إلغاء") } }) { DatePicker(state = pickerState) }
    }
    if (paymentTarget != null) AlertDialog(
        onDismissRequest = { paymentTarget = null },
        title = { Text("تسجيل دفعة مصروف") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(paymentTarget?.title.orEmpty())
            OutlinedTextField(paymentAmount, { paymentAmount = it.filter { c -> c.isDigit() || c == '.' || c == ',' } }, label = { Text("قيمة الدفعة بالجنيه") }, singleLine = true)
            OutlinedTextField(paymentDate, { paymentDate = it }, label = { Text("تاريخ الدفع (YYYY-MM-DD)") }, singleLine = true)
            CashAccountDropdown(accounts = cashAccounts, selectedId = paymentAccountId, onSelected = { paymentAccountId = it }, label = "حساب الصرف")
            OutlinedTextField(paymentMethod, { paymentMethod = it }, label = { Text("تفصيل وسيلة الدفع") }, singleLine = true)
            OutlinedTextField(paymentNote, { paymentNote = it }, label = { Text("ملاحظات") })
        } },
        confirmButton = { TextButton(onClick = {
            val date = runCatching { LocalDate.parse(paymentDate) }.getOrNull()
            val amountValue = moneyInput(paymentAmount)
            val target = paymentTarget
            if (target != null && date != null && amountValue > 0L && paymentMethod.isNotBlank() && amountValue <= (target.amountPiasters - target.paidAmountPiasters).coerceAtLeast(0L)) {
                vm.recordPayment(target.id, amountValue, date, paymentMethod, paymentNote, paymentAccountId)
                paymentTarget = null
            }
        }, enabled = moneyInput(paymentAmount) > 0 && runCatching { LocalDate.parse(paymentDate) }.isSuccess && paymentMethod.isNotBlank()) { Text("تسجيل") } },
        dismissButton = { TextButton(onClick = { paymentTarget = null }) { Text("إلغاء") } }
    )
    if (deleteTarget != null) AlertDialog(onDismissRequest = { deleteTarget = null }, title = { Text("حذف المصروف؟") }, text = { Text("سيتم حذف هذا البند من سجل الشهر المحدد.") }, confirmButton = { TextButton(onClick = { vm.delete(deleteTarget!!); deleteTarget = null }) { Text("حذف") } }, dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("إلغاء") } })
}

@Composable
private fun SummaryLine(label: String, value: Long, warning: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Text(Money.format(value), color = if (warning && value > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
    }
}
