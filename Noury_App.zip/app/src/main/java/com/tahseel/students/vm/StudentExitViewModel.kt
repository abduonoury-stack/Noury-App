package com.tahseel.students.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tahseel.students.data.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth
import com.tahseel.students.util.WorkdaySettings

data class ExitPreview(
    val student: Student, val periodKey: String, val withdrawalDate: String,
    val attendedDays: Int, val monthlyFee: Long, val paid: Long,
    val earned: Long, val refund: Long, val due: Long,
    val manualAdjustmentType: String = "none",
    val manualAdjustmentAmount: Long = 0,
    val manualAdjustmentReason: String = ""
)

class StudentExitViewModel(private val studentsDao: StudentDao, private val financeDao: FinanceDao, private val cashAccountDao: CashAccountDao) : ViewModel() {
    val cashAccounts = cashAccountDao.observeActive().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val students = studentsDao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val settlements = studentsDao.observeExitSettlements().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val events = studentsDao.observeAllExitSettlementEvents().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private suspend fun calculate(studentId: Long, withdrawalDate: String): Pair<ExitPreview?, String?> {
        val date = runCatching { LocalDate.parse(withdrawalDate) }.getOrNull()
            ?: return null to "تاريخ الانسحاب غير صحيح"
        if (date.isAfter(LocalDate.now())) return null to "تاريخ الانسحاب لا يمكن أن يكون في المستقبل"
        val student = studentsDao.getById(studentId) ?: return null to "الطالب غير موجود"
        val month = YearMonth.from(date)
        val period = month.toString()
        val sub = financeDao.subscriptionForPeriod(studentId, period)
        val enrollmentMonth = runCatching { java.time.Instant.ofEpochMilli(student.enrollmentDate).atZone(java.time.ZoneId.systemDefault()).toLocalDate().withDayOfMonth(1) }.getOrNull()
        val firstMonthApplies = enrollmentMonth == month.atDay(1)
        val monthlyFee = sub?.dueAmountPiasters ?: student.firstMonthAmountPiasters.takeIf { firstMonthApplies }
            ?: return null to "لا يوجد اشتراك مسجل لهذا الطالب في الشهر المحدد، ولا توجد قيمة شهر التحاق محفوظة لهذا الشهر"
        val paid = sub?.paidAmountPiasters ?: 0L
        // Count attendance only on the academy-configured workdays.
        val workdays = WorkdaySettings.load(financeDao)
        val attended = studentsDao.presentAttendanceDates(studentId, month.atDay(1).toString(), date.toString())
            .count { raw -> runCatching { LocalDate.parse(raw).dayOfWeek in workdays }.getOrDefault(false) }
        val earned = (monthlyFee * attended.toLong() / 30L).coerceAtMost(monthlyFee)
        return ExitPreview(student, period, date.toString(), attended, monthlyFee, paid, earned,
            (paid - earned).coerceAtLeast(0L), (earned - paid).coerceAtLeast(0L)) to null
    }

    fun preview(studentId: Long, withdrawalDate: String, onResult: (ExitPreview?, String?) -> Unit) = viewModelScope.launch {
        val existing = studentsDao.exitSettlement(studentId, runCatching { YearMonth.from(LocalDate.parse(withdrawalDate)).toString() }.getOrDefault(""))
        if (existing != null && existing.settlementStatus != "cancelled") {
            onResult(null, "تم حفظ تسوية لهذا الطالب في نفس الشهر بالفعل؛ استخدم التعديل من سجل التسويات"); return@launch
        }
        val (result, error) = calculate(studentId, withdrawalDate)
        onResult(result, error)
    }

    fun save(preview: ExitPreview, onResult: (String) -> Unit) = viewModelScope.launch {
        runCatching {
            val existing = studentsDao.exitSettlement(preview.student.id, preview.periodKey)
            require(existing == null || existing.settlementStatus == "cancelled") { "تم حفظ تسوية لهذا الطالب في نفس الشهر بالفعل" }
            val adjusted = applyAdjustment(preview, preview.manualAdjustmentType, preview.manualAdjustmentAmount)
            if (existing != null) {
                require(existing.refundedAmountPiasters <= adjusted.refund) {
                    "لا يمكن إعادة فتح التسوية لأن المبلغ المصروف سابقًا (${existing.refundedAmountPiasters / 100.0} جنيه) أكبر من قيمة الاسترداد الجديدة (${adjusted.refund / 100.0} جنيه). راجع التسوية السابقة أولًا."
                }
            }
            require(preview.manualAdjustmentType == "none" || preview.manualAdjustmentAmount == 0L || preview.manualAdjustmentReason.isNotBlank()) { "اكتب سبب المبلغ الإداري" }
            val record = StudentExitSettlement(
                id = existing?.id ?: 0L, studentId = adjusted.student.id, periodKey = adjusted.periodKey,
                withdrawalDate = adjusted.withdrawalDate, attendedDays = adjusted.attendedDays,
                monthlyFeePiasters = adjusted.monthlyFee, paidAmountPiasters = adjusted.paid,
                earnedAmountPiasters = adjusted.earned, refundAmountPiasters = adjusted.refund,
                amountDuePiasters = adjusted.due,
                manualAdjustmentType = adjusted.manualAdjustmentType,
                manualAdjustmentAmountPiasters = if (adjusted.manualAdjustmentType == "none") 0L else adjusted.manualAdjustmentAmount,
                manualAdjustmentReason = if (adjusted.manualAdjustmentType == "none") "" else adjusted.manualAdjustmentReason,
                refundedAmountPiasters = existing?.refundedAmountPiasters ?: 0L,
                settlementStatus = "active", cancelledAt = null, cancellationReason = ""
            )
            if (existing == null) {
                studentsDao.createExitSettlementWithCreditAtomically(record, adjusted.student.copy(status = "inactive", updatedAt = System.currentTimeMillis()))
            } else {
                studentsDao.reopenExitSettlementWithCreditAtomically(
                    record,
                    adjusted.student.copy(status = "inactive", updatedAt = System.currentTimeMillis()),
                    StudentExitSettlementEvent(settlementId = existing.id, eventType = "reopen", amountPiasters = 0,
                        details = "إعادة فتح تسوية ملغاة وإنشاء حساب جديد. سبب الإلغاء السابق: ${existing.cancellationReason}")
                )
            }
        }.onSuccess { onResult("تم حفظ التسوية وتغيير حالة الطالب إلى منقطع") }
            .onFailure { onResult("تعذر حفظ التسوية: ${it.message ?: "خطأ غير معروف"}") }
    }

    private fun applyAdjustment(p: ExitPreview, type: String, amount: Long): ExitPreview {
        require(amount >= 0) { "المبلغ الإداري لا يمكن أن يكون سالبًا" }
        val baseRefund = (p.paid - p.earned).coerceAtLeast(0L)
        val baseDue = (p.earned - p.paid).coerceAtLeast(0L)
        return when (type) {
            "deduct_refund" -> {
                require(amount <= baseRefund) { "المبلغ الإداري أكبر من قيمة المبلغ المسترد" }
                p.copy(refund = baseRefund - amount, due = baseDue)
            }
            "add_due" -> p.copy(refund = baseRefund, due = baseDue + amount)
            else -> p.copy(refund = baseRefund, due = baseDue)
        }
    }

    /** يسجل الصرف الفعلي كحركة مستقلة، ويسمح بالصرف الجزئي دون تجاوز المستحق. */
    fun recordRefund(settlementId: Long, amountPiasters: Long, note: String, accountId: String, onResult: (String) -> Unit) = viewModelScope.launch {
        runCatching {
            require(cashAccountDao.find(accountId)?.isActive == true) { "حساب الصرف غير موجود أو غير نشط" }
            studentsDao.recordExitRefundAgainstCreditAtomically(settlementId, amountPiasters, accountId, note)
        }.onSuccess { onResult("تم تسجيل الصرف الفعلي وحفظه في سجل المراجعة") }
            .onFailure { onResult("لم يتم تسجيل الصرف: ${it.message ?: "خطأ غير معروف"}") }
    }

    /** يعيد الحساب من سجلات الاشتراك والحضور، ويحفظ فرق التصحيح دون المساس بما تم صرفه. */
    fun correctSettlement(settlementId: Long, correctedWithdrawalDate: String, reason: String, adjustmentType: String, adjustmentAmountPiasters: Long, adjustmentReason: String, onResult: (String) -> Unit) = viewModelScope.launch {
        runCatching {
            require(reason.isNotBlank()) { "اكتب سبب التصحيح" }
            val old = studentsDao.getExitSettlement(settlementId) ?: error("التسوية غير موجودة")
            require(old.settlementStatus == "active") { "لا يمكن تصحيح تسوية ملغاة؛ أعد فتحها وفق إجراءات التسوية أولًا" }
            val (p, errorMessage) = calculate(old.studentId, correctedWithdrawalDate)
            val fresh = p ?: error(errorMessage ?: "تعذر إعادة الحساب")
            val conflicting = studentsDao.exitSettlement(old.studentId, fresh.periodKey)
            require(conflicting == null || conflicting.id == old.id) { "توجد تسوية أخرى لهذا الطالب في الشهر المحدد" }
            val adjusted = applyAdjustment(fresh, adjustmentType, adjustmentAmountPiasters)
            require(adjustmentType == "none" || adjustmentAmountPiasters == 0L || adjustmentReason.isNotBlank()) { "اكتب سبب المبلغ الإداري" }
            val updated = old.copy(
                periodKey = adjusted.periodKey, withdrawalDate = adjusted.withdrawalDate,
                attendedDays = adjusted.attendedDays, monthlyFeePiasters = adjusted.monthlyFee,
                paidAmountPiasters = adjusted.paid, earnedAmountPiasters = adjusted.earned,
                refundAmountPiasters = adjusted.refund, amountDuePiasters = adjusted.due,
                manualAdjustmentType = adjustmentType,
                manualAdjustmentAmountPiasters = if (adjustmentType == "none") 0L else adjustmentAmountPiasters,
                manualAdjustmentReason = if (adjustmentType == "none") "" else adjustmentReason.trim()
                // refundedAmountPiasters محفوظ كما هو؛ الصرف السابق لا يُعاد كتابته.
            )
            val delta = adjusted.refund - old.refundAmountPiasters
            val status = when {
                old.refundedAmountPiasters > adjusted.refund -> "تم صرف زيادة عن قيمة الاسترداد الجديدة بمقدار ${(old.refundedAmountPiasters - adjusted.refund) / 100.0} جنيه؛ يلزم مراجعة ولي الأمر."
                adjusted.refund > old.refundedAmountPiasters -> "المتبقي لرده بعد التصحيح ${(adjusted.refund - old.refundedAmountPiasters) / 100.0} جنيه."
                else -> "لا يوجد مبلغ استرداد متبقٍ بعد التصحيح."
            }
            studentsDao.correctExitSettlementAtomically(old, updated, StudentExitSettlementEvent(
                settlementId = settlementId, eventType = "correction", amountPiasters = delta,
                details = "سبب التصحيح: ${reason.trim()} | تاريخ الانسحاب: ${old.withdrawalDate} ← ${fresh.withdrawalDate} | الحضور: ${old.attendedDays} ← ${fresh.attendedDays} يوم | المستحق: ${old.earnedAmountPiasters / 100.0} ← ${adjusted.earned / 100.0} جنيه | الاسترداد: ${old.refundAmountPiasters / 100.0} ← ${adjusted.refund / 100.0} جنيه | المبلغ الإداري: ${adjustmentType} / ${(if (adjustmentType == "none") 0L else adjustmentAmountPiasters) / 100.0} جنيه | سبب المبلغ الإداري: ${if (adjustmentType == "none") "لا يوجد" else adjustmentReason.trim()} | المصروف فعليًا محفوظ: ${old.refundedAmountPiasters / 100.0} جنيه. $status"
            ))
            status
        }.onSuccess { onResult("تم تصحيح التسوية. $it") }
            .onFailure { onResult("تعذر التصحيح: ${it.message ?: "خطأ غير معروف"}") }
    }

    fun cancelSettlement(settlementId: Long, reason: String, onResult: (String) -> Unit) = viewModelScope.launch {
        runCatching {
            require(reason.isNotBlank()) { "اكتب سبب إلغاء التسوية" }
            val old = studentsDao.getExitSettlement(settlementId) ?: error("التسوية غير موجودة")
            require(old.settlementStatus == "active") { "هذه التسوية ملغاة بالفعل" }
            val student = studentsDao.getById(old.studentId) ?: error("الطالب غير موجود")
            val updated = old.copy(settlementStatus = "cancelled", cancelledAt = System.currentTimeMillis(), cancellationReason = reason.trim())
            val paidWarning = if (old.refundedAmountPiasters > 0) " تم صرف ${old.refundedAmountPiasters / 100.0} جنيه بالفعل؛ تم الاحتفاظ بحركة الصرف ويلزم مراجعة استردادها أو تسويتها يدويًا." else ""
            studentsDao.cancelExitSettlementAtomically(updated, student.copy(status = "active", updatedAt = System.currentTimeMillis()),
                StudentExitSettlementEvent(settlementId = settlementId, eventType = "cancel", amountPiasters = 0,
                    details = "إلغاء التسوية. السبب: ${reason.trim()}.$paidWarning"))
            "تم إلغاء التسوية وإعادة حالة الطالب إلى نشط.$paidWarning"
        }.onSuccess { onResult(it) }.onFailure { onResult("تعذر إلغاء التسوية: ${it.message ?: "خطأ غير معروف"}") }
    }

}
