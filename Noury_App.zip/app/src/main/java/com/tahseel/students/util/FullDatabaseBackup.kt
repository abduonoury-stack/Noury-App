package com.tahseel.students.util

import android.content.ContentValues
import android.database.Cursor
import android.util.Base64
import androidx.sqlite.db.SupportSQLiteDatabase
import org.json.JSONArray
import org.json.JSONObject

/** نسخة كاملة من جداول Room مع الاحتفاظ بالمعرّفات والعلاقات بين السجلات. */
object FullDatabaseBackup {
    const val APP = "tahseel-students"
    const val VERSION = 13
    // ترتيب الإدخال يحترم المفاتيح الأجنبية؛ الحذف يتم بالعكس.
    private val legacyTablesV3 = listOf("students", "payments", "fee_plans", "student_fees", "receipts", "refund_credits", "subscription_payments", "refund_transactions", "audit_logs", "app_settings", "classrooms", "attendance", "expenses")
    private val legacyTablesV4 = legacyTablesV3 + listOf("employees", "employee_attendance", "employee_leaves", "employee_payroll", "employee_loans", "employee_adjustments")
    // الإصدار 5: تسويات انسحاب الطلاب وسجل أحداثها. تأتي بعد students لأنها تشير إليه بمفتاح أجنبي.
    private val exitTables = listOf("student_exit_settlements", "student_exit_settlement_events")
    private val legacyV5Tables = legacyTablesV4 + exitTables
    private val periodTables = listOf("attendance_periods", "period_price_history")
    private val legacyV6Tables = legacyV5Tables + periodTables
    private val legacyV7Tables = legacyV6Tables + "employee_payroll_payments"
    private val legacyV8Tables = legacyV7Tables + listOf("cash_opening_balance", "cash_counts")
    private val legacyV9Tables = legacyV8Tables
    private val legacyV10Tables = legacyV9Tables + "expense_payments"
    private val legacyV11Tables = legacyV10Tables + listOf("cash_accounts", "cash_transfers")
    private val v12Tables = legacyV11Tables + listOf("employee_payroll_reversals", "employee_payroll_recovery_transactions")
    val tables = v12Tables + listOf("accounting_accounts", "accounting_periods", "journal_entries", "journal_lines", "accounting_vendors", "accounting_expenses", "accounting_expense_payments", "accounting_source_posts")
    private val legacyV2Tables = legacyTablesV3.take(10)

    fun export(db: SupportSQLiteDatabase, exportedAt: Long, receiptProfile: JSONObject = JSONObject()): String {
        // نفّذ checkpoint قبل المعاملة، ثم اقرأ كل الجداول داخل معاملة واحدة
        // حتى تمثل النسخة لحظة بيانات واحدة ولا تختلط بتعديلات متزامنة.
        db.query("PRAGMA wal_checkpoint(FULL)").use { }
        db.beginTransaction()
        try {
            val root = JSONObject().put("app", APP).put("version", VERSION).put("exportedAt", exportedAt).put("receiptProfile", JSONObject(receiptProfile.toString()))
            val all = JSONObject()
            var totalRows = 0
            tables.forEach { table ->
                val rows = JSONArray()
                db.query("SELECT * FROM `$table` ORDER BY 1").use { c ->
                    while (c.moveToNext()) {
                        val row = JSONObject()
                        for (i in 0 until c.columnCount) {
                            val key = c.getColumnName(i)
                            when (c.getType(i)) {
                                Cursor.FIELD_TYPE_NULL -> row.put(key, JSONObject.NULL)
                                Cursor.FIELD_TYPE_INTEGER -> row.put(key, c.getLong(i))
                                Cursor.FIELD_TYPE_FLOAT -> row.put(key, c.getDouble(i))
                                Cursor.FIELD_TYPE_BLOB -> row.put(key, JSONObject().put("__blob", Base64.encodeToString(c.getBlob(i), Base64.NO_WRAP)))
                                else -> row.put(key, c.getString(i))
                            }
                        }
                        rows.put(row); totalRows++
                    }
                }
                all.put(table, rows)
            }
            root.put("tables", all).put("rowCount", totalRows)
            val canonical = root.toString()
            root.put("checksum", sha256(canonical))
            db.setTransactionSuccessful()
            return root.toString(2)
        } finally {
            db.endTransaction()
        }
    }

    fun validate(json: String): String {
        val root = JSONObject(json.removePrefix("\uFEFF"))
        require(root.optString("app") == APP) { "هذا الملف ليس نسخة احتياطية لتطبيق تحصيل الطلاب" }
        val backupVersion = root.optInt("version")
        require(backupVersion in 2..VERSION) { "إصدار النسخة غير مدعوم" }
        val tablesObject = root.getJSONObject("tables")
        val requiredTables = when (backupVersion) { 2 -> legacyV2Tables; 3 -> legacyTablesV3; 4 -> legacyTablesV4; 5 -> legacyV5Tables; 6 -> legacyV6Tables; 7 -> legacyV7Tables; 8 -> legacyV7Tables; 9 -> legacyV9Tables; 10 -> legacyV10Tables; 11 -> legacyV11Tables; 12 -> v12Tables; else -> tables }
        requiredTables.forEach { require(tablesObject.has(it) && tablesObject.get(it) is JSONArray) { "النسخة غير مكتملة: جدول $it غير موجود" } }
        if (backupVersion >= 11) {
            val accounts = tablesObject.getJSONArray("cash_accounts")
            val accountIds = mutableSetOf<String>()
            var hasCash = false
            for (i in 0 until accounts.length()) {
                val account = accounts.getJSONObject(i)
                val id = account.getString("id")
                require(accountIds.add(id)) { "دليل الحسابات يحتوي على معرّف مكرر: $id" }
                if (id == "cash" && account.optString("type") == "cash") hasCash = true
            }
            require(hasCash) { "النسخة لا تحتوي على حساب الخزينة النقدية الأساسي" }
            val transfers = tablesObject.getJSONArray("cash_transfers")
            for (i in 0 until transfers.length()) {
                val transfer = transfers.getJSONObject(i)
                val from = transfer.getString("fromAccountId")
                val to = transfer.getString("toAccountId")
                require(from != to && from in accountIds && to in accountIds && transfer.getLong("amountPiasters") > 0L) {
                    "بيانات تحويل غير صالحة بين الحسابات في السجل رقم ${i + 1}"
                }
            }
        }
        // ملفات الإصدار 2 لم تكن تحتوي على الفصول والحضور والمصروفات؛ لا نلمس هذه الجداول عند استعادتها.
        val expected = root.getString("checksum")
        root.remove("checksum")
        require(sha256(root.toString()) == expected) { "فشل فحص سلامة النسخة؛ قد يكون الملف تالفًا أو معدلًا" }
        // تحقق إضافي من عدد السجلات المعلن، حتى لا تمر نسخة مبتورة منطقيًا رغم سلامة JSON.
        if (root.has("rowCount")) {
            var actualRows = 0
            requiredTables.forEach { actualRows += tablesObject.getJSONArray(it).length() }
            require(root.getInt("rowCount") == actualRows) { "عدد السجلات داخل النسخة لا يطابق بيانات الجداول" }
        }
        root.put("checksum", expected)
        return root.toString()
    }

    fun restore(db: SupportSQLiteDatabase, validatedJson: String) {
        val root = JSONObject(validatedJson)
        val data = root.getJSONObject("tables")
        db.beginTransaction()
        try {
            // نسخة قديمة بلا جداول التسوية: لا نحذف تسويات موجودة ولا نتركها تتعارض مع حذف الطلاب.
            if (exitTables.any { !data.has(it) }) {
                exitTables.forEach { t ->
                    db.query("SELECT COUNT(*) FROM `$t`").use { c ->
                        check(!(c.moveToFirst() && c.getLong(0) > 0)) {
                            "هذه النسخة قديمة ولا تحتوي على تسويات انسحاب الطلاب، بينما توجد تسويات محفوظة حاليًا. لم تتم الاستعادة حفاظًا على التسويات؛ استعد من نسخة أحدث."
                        }
                    }
                }
            }
            if (!data.has("employee_payroll_payments")) {
                db.query("SELECT COUNT(*) FROM employee_payroll_payments").use { c ->
                    check(!(c.moveToFirst() && c.getLong(0) > 0)) {
                        "هذه النسخة لا تحتوي على سجل دفعات المرتبات، بينما توجد دفعات محفوظة حاليًا. لم تتم الاستعادة حفاظًا على سجل الصرف؛ استخدم نسخة أحدث."
                    }
                }
            }
            if (!data.has("cash_opening_balance") || !data.has("cash_counts")) {
                listOf("cash_opening_balance", "cash_counts").forEach { table ->
                    db.query("SELECT COUNT(*) FROM `$table`").use { c ->
                        check(!(c.moveToFirst() && c.getLong(0) > 0)) {
                            "هذه النسخة لا تحتوي على بيانات ضبط الخزينة ($table)، بينما توجد بيانات محفوظة حاليًا. لم تتم الاستعادة حتى لا يختل رصيد الخزينة أو سجل الجرد؛ استخدم نسخة أحدث."
                        }
                    }
                }
            }
            if (!data.has("expense_payments")) {
                db.query("SELECT COUNT(*) FROM expense_payments").use { c ->
                    check(!(c.moveToFirst() && c.getLong(0) > 0)) {
                        "هذه النسخة لا تحتوي على سجل دفعات المصروفات التفصيلي، بينما توجد دفعات محفوظة حاليًا. لم تتم الاستعادة حفاظًا على سجل الصرف؛ استخدم نسخة أحدث."
                    }
                }
            }
            if (!data.has("cash_transfers")) {
                db.query("SELECT COUNT(*) FROM cash_transfers").use { c ->
                    check(!(c.moveToFirst() && c.getLong(0) > 0)) {
                        "هذه النسخة لا تحتوي على سجل التحويلات بين الحسابات، بينما توجد تحويلات محفوظة حاليًا. لم تتم الاستعادة حفاظًا على أرصدة الحسابات."
                    }
                }
            }
            if (!data.has("cash_accounts")) {
                db.query("SELECT COUNT(*) FROM cash_accounts WHERE id!='cash'").use { c ->
                    check(!(c.moveToFirst() && c.getLong(0) > 0)) {
                        "هذه النسخة لا تحتوي على دليل الحسابات النقدية، بينما توجد حسابات إضافية محفوظة حاليًا. لم تتم الاستعادة حفاظًا على تصنيف الحركات؛ استخدم نسخة أحدث."
                    }
                }
            }
            if (root.optInt("version") < 12) {
                db.query("SELECT COUNT(*) FROM refund_credits WHERE sourceType='manual_payment'").use { c ->
                    check(!(c.moveToFirst() && c.getLong(0) > 0)) {
                        "هذه النسخة أقدم من دورة الاسترداد اليدوي، بينما توجد طلبات استرداد يدوية محفوظة حاليًا. لم تتم الاستعادة حتى لا تُفقد هذه الأرصدة أو مستنداتها؛ استخدم نسخة Backup 12 أو أحدث."
                    }
                }
            }
            if (!data.has("journal_entries")) {
                listOf("journal_entries", "accounting_expenses", "accounting_vendors").forEach { table ->
                    db.query("SELECT COUNT(*) FROM `$table`").use { c ->
                        check(!(c.moveToFirst() && c.getLong(0) > 0)) {
                            "هذه النسخة أقدم من نظام المحاسبة الجديد، وتوجد قيود أو فواتير محاسبية على الجهاز. لم تتم الاستعادة حتى لا تُفقد البيانات المحاسبية الجديدة."
                        }
                    }
                }
            }
            if (!data.has("employee_payroll_reversals") || !data.has("employee_payroll_recovery_transactions")) {
                listOf("employee_payroll_reversals", "employee_payroll_recovery_transactions").forEach { table ->
                    db.query("SELECT COUNT(*) FROM `$table`").use { c ->
                        check(!(c.moveToFirst() && c.getLong(0) > 0)) {
                            "هذه النسخة لا تحتوي على سجل عكس المرتبات وتحصيل المديونيات ($table)، بينما توجد حركات محفوظة حاليًا. لم تتم الاستعادة حفاظًا على السجل المالي؛ استخدم نسخة أحدث."
                        }
                    }
                }
            }
            val includedTables = tables.filter { data.has(it) }
            includedTables.asReversed().forEach { db.delete(it, null, null) }
            includedTables.forEach { table ->
                val rows = data.getJSONArray(table)
                for (i in 0 until rows.length()) {
                    val obj = rows.getJSONObject(i)
                    val values = ContentValues()
                    val keys = obj.keys()
                    while (keys.hasNext()) {
                        val key = keys.next(); val value = obj.get(key)
                        when {
                            value == JSONObject.NULL -> values.putNull(key)
                            value is JSONObject && value.has("__blob") -> values.put(key, Base64.decode(value.getString("__blob"), Base64.DEFAULT))
                            value is Boolean -> values.put(key, if (value) 1 else 0)
                            value is Int -> values.put(key, value)
                            value is Long -> values.put(key, value)
                            value is Double -> values.put(key, value)
                            else -> values.put(key, value.toString())
                        }
                    }
                    check(db.insert(table, android.database.sqlite.SQLiteDatabase.CONFLICT_ABORT, values) >= 0) { "تعذر استعادة سجل من جدول $table" }
                }
            }
            // النسخ حتى الإصدار 11 لم تكن تحتوي على أرصدة موحدة لتسويات الانسحاب.
            // أنشئها بعد استعادة السجلات القديمة، واربط أحداث الصرف السابقة بها مرة واحدة.
            if (root.optInt("version") < 12) backfillExitSettlementCredits(db)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    private fun backfillExitSettlementCredits(db: SupportSQLiteDatabase) {
        db.execSQL("""INSERT OR IGNORE INTO refund_credits (studentId,paymentId,originalAmountPiasters,remainingAmountPiasters,createdAt,note,sourceType,sourceId,approvalStatus,reason,documentReference,approvedAt)
            SELECT s.studentId,NULL,s.refundAmountPiasters,
                CASE WHEN s.settlementStatus='active' THEN MAX(0,s.refundAmountPiasters-COALESCE(SUM(CASE WHEN e.eventType='refund_paid' THEN e.amountPiasters ELSE 0 END),0)) ELSE 0 END,
                s.createdAt,'ترحيل رصيد من تسوية انسحاب #' || s.id,'exit_settlement',s.id,
                CASE WHEN s.settlementStatus='active' THEN 'approved' ELSE 'cancelled' END,
                'رصيد مرحّل من تسوية انسحاب محفوظة','تسوية انسحاب #' || s.id,s.createdAt
            FROM student_exit_settlements s
            LEFT JOIN student_exit_settlement_events e ON e.settlementId=s.id
            WHERE s.refundAmountPiasters>0
            GROUP BY s.id""")
        db.execSQL("""INSERT INTO refund_transactions (refundCreditId,amountPiasters,refundedAt,method,note,accountId)
            SELECT c.id,e.amountPiasters,e.createdAt,'exit_settlement',e.details || ' [exit_event=' || e.id || ']',e.accountId
            FROM student_exit_settlement_events e
            INNER JOIN refund_credits c ON c.sourceType='exit_settlement' AND c.sourceId=e.settlementId
            WHERE e.eventType='refund_paid' AND e.amountPiasters>0
              AND NOT EXISTS (SELECT 1 FROM refund_transactions rt WHERE rt.refundCreditId=c.id AND rt.refundedAt=e.createdAt AND rt.amountPiasters=e.amountPiasters AND rt.note=e.details || ' [exit_event=' || e.id || ']')""")
    }

    fun rowCount(json: String): Int {
        val t = JSONObject(json).getJSONObject("tables")
        return tables.sumOf { if (t.has(it)) t.getJSONArray(it).length() else 0 }
    }
    private fun sha256(value: String): String = java.security.MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}
