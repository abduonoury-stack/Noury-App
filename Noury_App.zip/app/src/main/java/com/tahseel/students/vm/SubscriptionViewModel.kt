package com.tahseel.students.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tahseel.students.data.Student
import com.tahseel.students.data.CashAccountDao
import com.tahseel.students.data.StudentDao
import com.tahseel.students.data.SubscriptionRepository
import com.tahseel.students.data.SubscriptionResult
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.CancellationException
import android.util.Log
import java.time.YearMonth

class SubscriptionViewModel(
    studentDao: StudentDao,
    private val repository: SubscriptionRepository,
    cashAccountDao: CashAccountDao
) : ViewModel() {
    val cashAccounts = cashAccountDao.observeActive().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val students = studentDao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    suspend fun quoteAmount(student: Student, period: YearMonth): Long? = repository.monthlyAmountPiasters(student, period)

    fun collect(studentId: Long, period: YearMonth, receiptNo: String, paidPounds: String, discountPounds: String, discountNote: String, accountId: String, onResult: (String) -> Unit) = viewModelScope.launch {
        val paidPoundsValue = paidPounds.trim().toLongOrNull()
        val paid = paidPoundsValue?.let { runCatching { Math.multiplyExact(it, 100L) }.getOrNull() }
        val discountPoundsValue = discountPounds.trim().ifBlank { "0" }.toLongOrNull()
        val discount = discountPoundsValue?.takeIf { it >= 0L }?.let { runCatching { Math.multiplyExact(it, 100L) }.getOrNull() }
        if (discount == null) {
            onResult("اكتب خصمًا صحيحًا بالجنيه أو اترك الخانة فارغة")
            return@launch
        }
        if (paid == null || paid < 0) {
            onResult("اكتب المبلغ المدفوع بالجنيه كرقم صحيح غير سالب")
            return@launch
        }
        try {
            when (val result = repository.collectMonthly(
                studentId, period, receiptNo, paid, discount, discountNote, accountId
            )) {
                is SubscriptionResult.Rejected -> onResult(result.reason)
                is SubscriptionResult.Success -> onResult(
                    if (result.duePiasters == 0L) "تم تسجيل الإعفاء الكامل بنجاح\nرقم الإشعار: ${result.receiptNo}"
                    else "تم التحصيل بنجاح\nرقم الإيصال: ${result.receiptNo}"
                )
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            Log.e("NourySubscription", "Subscription collection failed; database transaction was rolled back", error)
            val detail = error.localizedMessage?.takeIf { it.isNotBlank() }
            onResult("تعذر تسجيل الاشتراك بسبب خطأ أثناء الحفظ. لم يتم اعتماد التحصيل.\n${detail ?: "راجع إعدادات الحسابات والفترة المحاسبية أو أرسل سجل الخطأ للدعم."}")
        }
    }
}
