package com.tahseel.students.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tahseel.students.data.Payment
import com.tahseel.students.data.CashAccount
import com.tahseel.students.data.CashAccountDao
import com.tahseel.students.data.PaymentRepository
import com.tahseel.students.data.SaveResult
import com.tahseel.students.data.StudentDao
import com.tahseel.students.util.Money
import com.tahseel.students.util.TextUtil
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class FormState(
    val name: String = "",
    val receipt: String = "",
    val motherPhone: String = "",
    val amount: String = "",
    val accountId: String = "cash",
    val isEditing: Boolean = false,
    val accounts: List<CashAccount> = emptyList(),
    val nameErr: String? = null,
    val receiptErr: String? = null,
    val amountErr: String? = null,
    val saving: Boolean = false,
    val loading: Boolean = false,
    val notFound: Boolean = false,
    val phoneHint: String? = null
)

sealed class FormEvent {
    data class Message(val text: String) : FormEvent()
    object Done : FormEvent()
}

/** editId = null → تسجيل جديد، وإلا → تعديل العملية الموجودة (يبقى تاريخها الأصلي). */
class PaymentFormViewModel(private val repo: PaymentRepository, private val studentsDao: StudentDao, private val cashAccountDao: CashAccountDao, private val editId: Long?) : ViewModel() {
    private val _state = MutableStateFlow(FormState(loading = editId != null, isEditing = editId != null))
    val state: StateFlow<FormState> = _state.asStateFlow()

    private val _events = Channel<FormEvent>(Channel.BUFFERED)
    val events: Flow<FormEvent> = _events.receiveAsFlow()

    private var original: Payment? = null

    init {
        viewModelScope.launch { cashAccountDao.observeActive().collect { rows -> _state.update { it.copy(accounts = rows) } } }
        if (editId != null) {
            viewModelScope.launch {
                val p = repo.dao.getById(editId)
                if (p == null) {
                    _state.update { it.copy(loading = false, notFound = true) }
                } else {
                    original = p
                    val linkedStudent = studentsDao.getByExactName(p.studentName)
                    _state.update {
                        it.copy(name = p.studentName, receipt = p.receiptNo,
                            motherPhone = linkedStudent?.motherWhatsapp.orEmpty(),
                            amount = Money.plain(p.amountPiasters), accountId = p.accountId.orEmpty(), loading = false)
                    }
                }
            }
        }
    }

    fun onName(v: String) = _state.update { it.copy(name = v.take(100), nameErr = null) }
    fun onReceipt(v: String) = _state.update { it.copy(receipt = v.take(40), receiptErr = null) }
    fun onMotherPhone(v: String) {
        val cleaned = v.filter { ch -> ch.isDigit() || ch == '+' || ch == '-' || ch == ' ' || ch == '(' || ch == ')' }.take(20)
        _state.update { it.copy(motherPhone = cleaned, phoneHint = null) }
        val digits = normalizePhone(cleaned)
        if (digits.length >= 10) viewModelScope.launch {
            val matches = studentsDao.getByMotherPhone(digits)
            when (matches.size) {
                1 -> _state.update { it.copy(name = matches.first().fullName, nameErr = null, phoneHint = "تم التعرف على الطالب: ${matches.first().fullName}") }
                in 2..Int.MAX_VALUE -> _state.update { it.copy(phoneHint = "هذا الرقم مرتبط بأكثر من طالب؛ راجع بيانات الطلاب") }
                else -> Unit
            }
        }
    }

    private fun normalizePhone(value: String): String = value.map { ch -> when (ch) {
        in '٠'..'٩' -> ('0'.code + (ch - '٠')).toChar()
        in '۰'..'۹' -> ('0'.code + (ch - '۰')).toChar()
        else -> ch
    } }.filter { it.isDigit() }.joinToString("")
    fun onAmount(v: String) = _state.update { it.copy(amount = v.take(15), amountErr = null) }
    fun onAccount(v: String) = _state.update { it.copy(accountId = v) }

    fun save() {
        val s = _state.value
        if (s.saving || s.loading) return
        val name = TextUtil.cleanName(s.name)
        val receipt = s.receipt.trim()
        val amount = Money.parse(s.amount)

        val nameErr = if (name.isEmpty()) "اكتب اسم الطالب" else null
        val receiptErr = if (receipt.isEmpty()) "اكتب رقم الإيصال" else null
        val amountErr = when {
            s.amount.isBlank() -> "اكتب مبلغ الدفع"
            amount == null -> "المبلغ غير صالح: اكتب رقمًا أكبر من صفر"
            else -> null
        }
        if (nameErr != null || receiptErr != null || amountErr != null || amount == null) {
            _state.update { it.copy(nameErr = nameErr, receiptErr = receiptErr, amountErr = amountErr) }
            return
        }

        _state.update { it.copy(saving = true) }
        viewModelScope.launch {
            val phone = s.motherPhone.trim()
            val phoneDigits = normalizePhone(phone)
            val phoneMatches = if (phoneDigits.isNotBlank()) studentsDao.getByMotherPhone(phoneDigits) else emptyList()
            val resolvedName = when (phoneMatches.size) {
                1 -> phoneMatches.first().fullName
                else -> name
            }
            val matchedStudent = when {
                phoneMatches.size == 1 -> phoneMatches.first()
                phoneMatches.isEmpty() -> studentsDao.getByExactName(resolvedName)
                else -> null
            }
            val result = if (phoneMatches.size > 1) SaveResult.Error("رقم موبايل الأم مرتبط بأكثر من طالب") else if (editId == null) {
                if (matchedStudent == null) SaveResult.Error("لا يوجد ملف طالب مرتبط بهذا الاسم. أضف الطالب أولاً من إدارة الطلاب")
                else repo.addCurrentMonthSubscription(matchedStudent.id, receipt, amount, s.accountId)
            } else {
                val o = original
                if (o == null) SaveResult.Error("العملية غير موجودة")
                else repo.update(o.copy(studentName = resolvedName, receiptNo = receipt, amountPiasters = amount))
            }
            when (result) {
                SaveResult.Success -> {
                    // رقم الأم محفوظ في ملف الطالب نفسه؛ يُحدّث فقط عند وجود اسم مطابق ورقم مُدخل.
                    if (phone.isNotBlank() && phoneMatches.isEmpty()) {
                        val student = studentsDao.getByExactName(resolvedName)
                        if (student != null && student.motherWhatsapp != phone) {
                            studentsDao.update(student.copy(motherWhatsapp = phone, updatedAt = System.currentTimeMillis()))
                        }
                    }
                    if (editId == null) {
                        _state.value = FormState()
                        _events.send(FormEvent.Message("تم حفظ عملية الدفع بنجاح ✔"))
                    } else {
                        _state.update { it.copy(saving = false) }
                        _events.send(FormEvent.Done)
                    }
                }
                SaveResult.DuplicateReceipt ->
                    _state.update { it.copy(saving = false, receiptErr = "رقم الإيصال مسجل من قبل") }
                is SaveResult.Error -> {
                    _state.update { it.copy(saving = false) }
                    _events.send(FormEvent.Message(result.message))
                }
            }
        }
    }
}
