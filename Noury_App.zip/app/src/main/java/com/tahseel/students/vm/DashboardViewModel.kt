package com.tahseel.students.vm

import com.tahseel.students.data.resolvePeriodPricePiasters
import com.tahseel.students.data.sumValidReceiptAmounts
import com.tahseel.students.data.netCashMovement

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tahseel.students.data.Payment
import com.tahseel.students.data.PaymentRepository
import com.tahseel.students.data.StudentDao
import com.tahseel.students.data.FinanceDao
import com.tahseel.students.data.expensesForMonth
import com.tahseel.students.data.expenseMonthTotals
import com.tahseel.students.util.TimeUtil
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId

data class DashboardPeriodSummary(val id: Long, val name: String, val startTime: String, val endTime: String, val expected: Long, val collected: Long)

data class DashboardState(
    val periodSummaries: List<DashboardPeriodSummary> = emptyList(),
    val total: Long = 0,
    val count: Int = 0,
    val todayCount: Int = 0,
    val todayTotal: Long = 0,
    val last: Payment? = null,
    val month: YearMonth = YearMonth.now(),
    val expected: Long = 0,
    val collected: Long = 0,
    val totalCollected: Long = 0,
    val remaining: Long = 0,
    val activeStudents: Int = 0,
    val paidStudents: Int = 0,
    val unpaidStudents: Int = 0,
    val morningExpected: Long = 0,
    val morningCollected: Long = 0,
    val eveningExpected: Long = 0,
    val eveningCollected: Long = 0,
    val expenses: Long = 0,
    val net: Long = 0
)

@OptIn(ExperimentalCoroutinesApi::class)
class DashboardViewModel(
    repo: PaymentRepository,
    private val studentsDao: StudentDao,
    private val financeDao: FinanceDao,
    private val expenseDao: com.tahseel.students.data.ExpenseDao,
    private val periodDao: com.tahseel.students.data.PeriodDao
) : ViewModel() {
    private val today = MutableStateFlow(LocalDate.now())
    private val selectedMonth = MutableStateFlow(YearMonth.now())
    private val todayList = today.flatMapLatest { d ->
        repo.dao.observeBetween(TimeUtil.startOf(d), TimeUtil.startOf(d.plusDays(1)))
    }
    private val monthPayments = selectedMonth.flatMapLatest { m ->
        financeDao.observeValidSubscriptionPayments(m.toString())
    }
    private val monthReceipts = selectedMonth.flatMapLatest { m ->
        repo.dao.observeBetween(TimeUtil.startOfMonth(m), TimeUtil.startOfNextMonth(m))
    }

    val state: StateFlow<DashboardState> = combine(
        repo.dao.observeTotal(), repo.dao.observeCount(), todayList, repo.dao.observeLast(),
        studentsDao.observeAll(), selectedMonth, monthPayments, monthReceipts, expenseDao.observeAll(), periodDao.observeAll(), periodDao.observeAllPriceHistory()
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val total = values[0] as Long
        val count = values[1] as Int
        @Suppress("UNCHECKED_CAST")
        val todayPayments = values[2] as List<Payment>
        val last = values[3] as Payment?
        @Suppress("UNCHECKED_CAST")
        val allStudents = values[4] as List<com.tahseel.students.data.Student>
        val month = values[5] as YearMonth
        @Suppress("UNCHECKED_CAST")
        val payments = values[6] as List<com.tahseel.students.data.SubscriptionPayment>
        @Suppress("UNCHECKED_CAST")
        val receipts = values[7] as List<Payment>
        @Suppress("UNCHECKED_CAST")
        val expenseRows = values[8] as List<com.tahseel.students.data.Expense>
        @Suppress("UNCHECKED_CAST")
        val allPeriods = values[9] as List<com.tahseel.students.data.AttendancePeriod>
        @Suppress("UNCHECKED_CAST")
        val priceHistory = values[10] as List<com.tahseel.students.data.PeriodPriceHistory>
        val monthExpenses = expensesForMonth(expenseRows, month)
        val expenses = expenseMonthTotals(monthExpenses).paid
        val totalCollected = sumValidReceiptAmounts(receipts)

        val eligible = allStudents.filter { student ->
            if (student.status != "active") false else {
                val enrolled = Instant.ofEpochMilli(student.enrollmentDate).atZone(ZoneId.systemDefault()).toLocalDate()
                !month.isBefore(YearMonth.from(enrolled))
            }
        }
        val byStudent = payments.associateBy { it.studentId }
        fun dueFor(student: com.tahseel.students.data.Student): Long =
            byStudent[student.id]?.dueAmountPiasters
                ?: if (month == YearMonth.from(Instant.ofEpochMilli(student.enrollmentDate).atZone(ZoneId.systemDefault()).toLocalDate()) && student.firstMonthAmountPiasters != null)
                    student.firstMonthAmountPiasters
                else {
                val pid = student.periodId ?: if (student.attendanceEndHour == 16 || student.attendanceEndHour == 17) 2L else 1L
                val at = month.atDay(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                student.monthlyFeeOverridePiasters ?: resolvePeriodPricePiasters(priceHistory, pid, at) ?: 0L
            }
        val expected = eligible.sumOf { dueFor(it) }
        val collected = eligible.sumOf { student -> minOf(dueFor(student), byStudent[student.id]?.paidAmountPiasters ?: 0L) }
        val remaining = (expected - eligible.sumOf { student ->
            val due = dueFor(student)
            minOf(due, byStudent[student.id]?.paidAmountPiasters ?: 0L)
        }).coerceAtLeast(0L)
        fun startTimeOf(student: com.tahseel.students.data.Student): String {
            val id = student.periodId ?: if (student.attendanceEndHour == 16 || student.attendanceEndHour == 17) 2L else 1L
            return allPeriods.firstOrNull { it.id == id }?.startTime ?: if (id == 2L) "10:00" else "08:00"
        }
        val evening = eligible.filter { startTimeOf(it) >= "12:00" }
        val morning = eligible.filter { startTimeOf(it) < "12:00" }
        val morningExpected = morning.sumOf { dueFor(it) }
        val eveningExpected = evening.sumOf { dueFor(it) }
        val morningCollected = morning.sumOf { byStudent[it.id]?.paidAmountPiasters?.coerceAtMost(dueFor(it)) ?: 0L }
        val eveningCollected = evening.sumOf { byStudent[it.id]?.paidAmountPiasters?.coerceAtMost(dueFor(it)) ?: 0L }
        val periodSummaries = allPeriods.mapNotNull { period ->
            val assigned = eligible.filter { student ->
                (student.periodId ?: if (student.attendanceEndHour == 16 || student.attendanceEndHour == 17) 2L else 1L) == period.id
            }
            if (assigned.isEmpty()) null else DashboardPeriodSummary(
                id = period.id, name = period.name, startTime = period.startTime, endTime = period.endTime,
                expected = assigned.sumOf { dueFor(it) },
                collected = assigned.sumOf { byStudent[it.id]?.paidAmountPiasters?.coerceAtMost(dueFor(it)) ?: 0L }
            )
        }
        DashboardState(
            periodSummaries = periodSummaries,
            total = total, count = count, todayCount = todayPayments.size,
            todayTotal = todayPayments.sumOf { it.amountPiasters }, last = last,
            month = month, expected = expected, collected = collected, remaining = remaining,
            activeStudents = eligible.size,
            paidStudents = eligible.count { (byStudent[it.id]?.paidAmountPiasters ?: 0L) >= dueFor(it) && dueFor(it) > 0L },
            unpaidStudents = eligible.count { (byStudent[it.id]?.paidAmountPiasters ?: 0L) < dueFor(it) && dueFor(it) > 0L },
            morningExpected = morningExpected, morningCollected = morningCollected,
            eveningExpected = eveningExpected, eveningCollected = eveningCollected,
            expenses = expenses, totalCollected = totalCollected, net = netCashMovement(totalCollected, expenses)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardState())

    fun refreshDay() { today.value = LocalDate.now() }
    fun previousMonth() { selectedMonth.update { it.minusMonths(1) } }
    fun nextMonth() { selectedMonth.update { it.plusMonths(1) } }
}
