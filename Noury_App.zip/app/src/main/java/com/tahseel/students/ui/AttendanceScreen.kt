package com.tahseel.students.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.data.Attendance
import com.tahseel.students.data.Student
import com.tahseel.students.util.AcademyProfileStore
import com.tahseel.students.vm.AttendanceViewModel
import java.net.URLEncoder
import java.time.Instant
import java.time.LocalDate
import java.time.Period
import java.time.ZoneId
import com.tahseel.students.util.WorkdaySettings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceScreen(vm: AttendanceViewModel, onBack: () -> Unit, onProfile: (Long) -> Unit) {
    val rooms by vm.classrooms.collectAsStateWithLifecycle()
    val allStudents by vm.students.collectAsStateWithLifecycle()
    val dayRows by vm.day.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val allDay by vm.allDay.collectAsStateWithLifecycle()
    val workdays by vm.workdays.collectAsStateWithLifecycle()
    var roomName by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now()) }
    LaunchedEffect(workdays) { date = WorkdaySettings.onOrBefore(date, workdays) }
    LaunchedEffect(Unit) { vm.refreshWorkdays() }
    var marks by remember { mutableStateOf<Map<Long, Boolean>>(emptyMap()) }
    var savedMessage by remember { mutableStateOf("") }
    var report by remember { mutableStateOf<List<Pair<Attendance, List<String>>>?>(null) }
    var absenceClassDetail by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val roster = allStudents.filter { it.className == roomName && it.status == "active" }.sortedWith(
        compareBy<Student> { it.birthDate == null }.thenBy { it.birthDate ?: Long.MAX_VALUE }
    )
    LaunchedEffect(roomName, date) { if (roomName.isNotBlank()) vm.load(roomName, date.toString()) }
    LaunchedEffect(date) { vm.loadAllDay(date.toString()) }
    LaunchedEffect(dayRows, roster) {
        if (dayRows.isNotEmpty()) marks = dayRows.associate { it.studentId to (it.status == "present") }
        else marks = roster.associate { it.id to true }
    }
    var expanded by remember { mutableStateOf(false) }
    AppScaffold(
        title = if (absenceClassDetail != null) "غياب فصل $absenceClassDetail" else "حضور وغياب الطلاب",
        onBack = { if (absenceClassDetail != null) absenceClassDetail = null else onBack() }
    ) { pad ->
        if (rooms.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Card(Modifier.fillMaxWidth().padding(20.dp)) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("لا توجد فصول مسجلة", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                        Text("أضف الفصول أولاً من إدارة الفصول، ثم ارجع لتسجيل الحضور.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.padding(pad).fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item(key = "attendance-date") {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            TextButton(onClick = { date = WorkdaySettings.previous(date.minusDays(1), workdays) }) { Text("السابق") }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(date.toString(), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                                Text(if (WorkdaySettings.isWorkday(date, workdays)) "يوم عمل" else "إجازة أسبوعية", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            TextButton(onClick = { date = WorkdaySettings.next(date.plusDays(1), workdays) }) { Text("التالي") }
                        }
                    }
                }

                if (absenceClassDetail == null) {
                    item(key = "overview-title") { SectionTitle("كشف الغياب اليومي لجميع الفصول") }
                    val totalAbsent = allDay.count { it.status == "absent" }
                    val totalPresent = allDay.count { it.status == "present" }
                    val savedRooms = rooms.count { room -> allDay.any { it.className.normalizedClassName() == room.name.normalizedClassName() } }
                    item(key = "overview-metrics") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            AttendanceSummaryMetric("غائب", totalAbsent.toString(), Modifier.weight(1f))
                            AttendanceSummaryMetric("حاضر", totalPresent.toString(), Modifier.weight(1f))
                            AttendanceSummaryMetric("كشف مسجل", "$savedRooms/${rooms.size}", Modifier.weight(1f))
                        }
                    }
                    items(rooms, key = { "room-${it.id}" }) { room ->
                        val rows = allDay.filter { it.className.normalizedClassName() == room.name.normalizedClassName() }
                        val absent = rows.filter { it.status == "absent" }
                        val enrolledCount = allStudents.count { it.className.normalizedClassName() == room.name.normalizedClassName() && it.status == "active" }
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable {
                                roomName = room.name
                                marks = emptyMap()
                                absenceClassDetail = room.name
                            },
                            shape = MaterialTheme.shapes.large,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text(room.name, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                                    Surface(
                                        color = if (rows.isEmpty()) MaterialTheme.colorScheme.surfaceVariant else if (absent.isNotEmpty()) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer,
                                        shape = MaterialTheme.shapes.small
                                    ) {
                                        Text(
                                            if (rows.isEmpty()) "لم يسجل" else "${absent.size} غائب",
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                            style = MaterialTheme.typography.labelMedium,
                                            color = if (rows.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant else if (absent.isNotEmpty()) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                                Text(
                                    if (rows.isEmpty()) "لم يتم حفظ كشف الحضور لهذا الفصل في هذا التاريخ" else "${rows.count { it.status == "present" }} حاضر • ${absent.size} غائب • $enrolledCount طالب منتظم",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (absent.isNotEmpty()) {
                                    Text("الغائبون: ${absent.joinToString("، ") { it.studentName }}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                                }
                                Text("اضغط لفتح كشف هذا الفصل", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                    }
                    item(key = "consecutive-absence") {
                        OutlinedButton(
                            onClick = { vm.consecutiveAbsenteesAll(date.toString()) { report = it } },
                            modifier = Modifier.fillMaxWidth(),
                            shape = MaterialTheme.shapes.large
                        ) {
                            Icon(Icons.Default.EventBusy, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("كشف الغياب 3 أيام متتالية أو أكثر")
                        }
                    }
                    item(key = "attendance-entry-title") {
                        SectionTitle("تسجيل حضور الفصل")
                        Text("اختر الفصل لعرض أسماء طلابه وتسجيل حالتهم في التاريخ المحدد.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    item(key = "attendance-room-picker") {
                        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                            OutlinedTextField(
                                value = roomName.ifBlank { "اختر الفصل" },
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("الفصل المحدد") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                                modifier = Modifier.menuAnchor().fillMaxWidth(),
                                shape = MaterialTheme.shapes.large
                            )
                            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                rooms.forEach { room ->
                                    DropdownMenuItem(
                                        text = { Text(room.name) },
                                        onClick = {
                                            roomName = room.name
                                            marks = emptyMap()
                                            savedMessage = ""
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                    if (roomName.isBlank()) {
                        item(key = "attendance-select-hint") {
                            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                                Text("بعد اختيار الفصل ستظهر أسماء الطلاب هنا مباشرة.", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    } else {
                        item(key = "attendance-roster-tools") {
                            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                        Text("طلاب فصل $roomName", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                                        Text("${roster.size} طالب", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                        OutlinedButton(onClick = { marks = roster.associate { it.id to true } }, modifier = Modifier.weight(1f)) { Text("تحديد الكل حاضر") }
                                        OutlinedButton(onClick = { marks = roster.associate { it.id to false } }, modifier = Modifier.weight(1f)) { Text("تحديد الكل غائب") }
                                    }
                                }
                            }
                        }
                        if (roster.isEmpty()) {
                            item(key = "attendance-empty-roster") {
                                Card(Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("لا يوجد طلاب منتظمون في هذا الفصل", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                                        Text("راجع توزيع الطلاب على الفصول وحالة انتظامهم من إدارة الطلاب.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        } else {
                            items(roster, key = { "student-${it.id}" }) { student ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = MaterialTheme.shapes.medium,
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                                ) {
                                    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        StudentAvatar(student.photoUri, 48.dp, student.id)
                                        Column(Modifier.weight(1f).clickable { onProfile(student.id) }, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                            Text(student.fullName, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                                            Text("العمر: ${attendanceStudentAgeLabel(student.birthDate)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Checkbox(checked = marks[student.id] == true, onCheckedChange = { checked -> marks = marks + (student.id to checked) })
                                            Text(
                                                if (marks[student.id] == true) "حاضر" else "غائب",
                                                color = if (marks[student.id] == true) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        item(key = "attendance-save") {
                            Button(
                                onClick = { vm.save(roomName, date.toString(), roster.map { it.id }, marks) { err -> savedMessage = err ?: "تم حفظ كشف الحضور" } },
                                modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
                                enabled = roster.isNotEmpty(),
                                shape = MaterialTheme.shapes.large
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("حفظ كشف اليوم")
                            }
                            if (savedMessage.isNotBlank()) {
                                Text(savedMessage, modifier = Modifier.fillMaxWidth().padding(top = 6.dp), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                } else {
                    val detailClassName = absenceClassDetail.orEmpty()
                    val absentStudents = allDay.filter { it.className.normalizedClassName() == detailClassName.normalizedClassName() && it.status == "absent" }
                    item(key = "absence-detail-heading") {
                        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { absenceClassDetail = null }) { Icon(Icons.Default.ArrowBack, contentDescription = "رجوع") }
                                Column(Modifier.weight(1f)) {
                                    Text("غياب فصل $absenceClassDetail", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                                    Text("${absentStudents.size} طالب غائب • $date", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                    if (absentStudents.isEmpty()) {
                        item(key = "absence-detail-empty") {
                            Card(Modifier.fillMaxWidth()) {
                                Text("لا توجد أسماء غياب مسجلة لهذا الفصل في هذا اليوم. قد يكون كشف الفصل لم يُحفظ بعد أو أن جميع الطلاب حاضرون.", Modifier.padding(18.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    } else {
                        items(absentStudents, key = { "absent-${it.studentId}" }) { row ->
                            Card(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.large) {
                                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    val student = allStudents.firstOrNull { it.id == row.studentId }
                                    StudentAvatar(student?.photoUri, 48.dp, row.studentId)
                                    Column(Modifier.weight(1f).clickable { onProfile(row.studentId) }, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Text(row.studentName, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                                        Text("غائب • $date", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                                    }
                                    IconButton(onClick = { openAbsenceWhatsApp(context, student, listOf(date.toString())) }, enabled = !student?.motherWhatsapp.isNullOrBlank()) { Icon(Icons.Default.Message, contentDescription = "واتساب") }
                                    IconButton(onClick = { openAbsenceMotherCall(context, student) }, enabled = !student?.motherWhatsapp.isNullOrBlank()) { Icon(Icons.Default.Call, contentDescription = "اتصال") }
                                }
                            }
                        }
                    }
                    item(key = "absence-detail-back-to-attendance") {
                        OutlinedButton(onClick = { absenceClassDetail = null }, modifier = Modifier.fillMaxWidth()) {
                            Text("العودة لتسجيل حضور الفصل – $roomName")
                        }
                    }
                }
            }
        }
    }
    report?.let { rows ->
        AlertDialog(onDismissRequest = { report = null }, title = { Text("الطلاب الغائبون 3 أيام عمل متتالية أو أكثر") },
            text = { if (rows.isEmpty()) Text("لا يوجد طلاب غائبون في آخر 3 أيام عمل مسجلة قبل التاريخ المحدد.") else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.heightIn(max = 440.dp)) { items(rows, key = { it.first.studentId }) { (rec, dates) ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    val reportStudent = allStudents.firstOrNull { it.id == rec.studentId }
                    StudentAvatar(reportStudent?.photoUri, 44.dp, rec.studentId)
                    Text(rec.studentName, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.clickable { onProfile(rec.studentId) })
                }
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("الفصل: ${rec.className} • ${dates.size} أيام غياب متتالية على الأقل", style = MaterialTheme.typography.bodySmall)
                    Text("تواريخ الغياب: ${dates.joinToString("، ")}", style = MaterialTheme.typography.bodySmall)
                    val student = allStudents.firstOrNull { it.id == rec.studentId }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { openAbsenceWhatsApp(context, student, dates) },
                            enabled = !student?.motherWhatsapp.isNullOrBlank(),
                            modifier = Modifier.weight(1f)
                        ) { Icon(Icons.Default.Message, null); Spacer(Modifier.width(5.dp)); Text("واتساب") }
                        OutlinedButton(
                            onClick = { openAbsenceMotherCall(context, student) },
                            enabled = !student?.motherWhatsapp.isNullOrBlank(),
                            modifier = Modifier.weight(1f)
                        ) { Icon(Icons.Default.Call, null); Spacer(Modifier.width(5.dp)); Text("اتصال") }
                    }
                }
            } } }, confirmButton = { TextButton(onClick = { report = null }) { Text("إغلاق") } })
    }
}


@Composable
private fun AttendanceSummaryMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.fillMaxWidth().padding(vertical = 10.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun openAbsenceMotherCall(context: android.content.Context, student: Student?) {
    if (student == null) return
    val raw = student.motherWhatsapp.trim()
    val digits = raw.filter { it.isDigit() }
    val phone = when {
        raw.startsWith("+") -> digits
        digits.startsWith("00") -> digits.drop(2)
        digits.startsWith("0") -> "20${digits.drop(1)}"
        digits.startsWith("20") -> digits
        else -> digits
    }
    if (phone.length < 10) {
        Toast.makeText(context, "رقم الأم غير مسجل أو غير صحيح", Toast.LENGTH_LONG).show()
        return
    }
    try {
        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")))
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(context, "تعذر فتح تطبيق الاتصال", Toast.LENGTH_LONG).show()
    }
}

private fun openAbsenceWhatsApp(context: android.content.Context, student: Student?, dates: List<String>) {
    if (student == null) return
    val raw = student.motherWhatsapp.trim()
    val digits = raw.filter { it.isDigit() }
    val phone = when { raw.startsWith("+") -> digits; digits.startsWith("00") -> digits.drop(2); digits.startsWith("0") -> "20${digits.drop(1)}"; digits.startsWith("20") -> digits; else -> digits }
    if (phone.length < 10) { Toast.makeText(context, "رقم واتساب الأم غير مسجل أو غير صحيح", Toast.LENGTH_LONG).show(); return }
    val message = "أهلًا بحضرتك 🌷\nبنطمن على ${student.fullName}، لاحظنا غيابه عن الحضانة خلال الأيام: ${dates.joinToString("، ")}، ونتمنى يكون بخير. يا ريت تطمنينا عليه.\n${AcademyProfileStore.getName(context)}"
    val uri = Uri.parse("https://wa.me/$phone?text=${URLEncoder.encode(message, "UTF-8")}")
    for (pkg in listOf("com.whatsapp.w4b", "com.whatsapp")) try { context.startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg)); return } catch (_: ActivityNotFoundException) { }
    try { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: ActivityNotFoundException) { Toast.makeText(context, "واتساب غير مثبت على الجهاز", Toast.LENGTH_LONG).show() }
}


private fun String.normalizedClassName(): String = trim().replace(Regex("\\s+"), " ").lowercase()

private fun attendanceStudentAgeLabel(birthDate: Long?): String {
    if (birthDate == null) return "غير مسجل"
    val birth = Instant.ofEpochMilli(birthDate).atZone(ZoneId.systemDefault()).toLocalDate()
    val age = Period.between(birth, LocalDate.now())
    return "${age.years} سنة و${age.months} شهر"
}
