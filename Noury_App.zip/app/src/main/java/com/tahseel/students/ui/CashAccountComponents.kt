package com.tahseel.students.ui

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.tahseel.students.data.CashAccount

@Composable
fun CashAccountDropdown(
    accounts: List<CashAccount>,
    selectedId: String,
    onSelected: (String) -> Unit,
    label: String
) {
    var expanded by remember { mutableStateOf(false) }
    val selected = accounts.firstOrNull { it.id == selectedId }
    Button(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth(), enabled = accounts.isNotEmpty()) {
        Text("$label: ${selected?.name ?: "اختر حسابًا"}")
    }
    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
        accounts.forEach { account ->
            DropdownMenuItem(text = { Text(account.name) }, onClick = {
                onSelected(account.id)
                expanded = false
            })
        }
    }
}
