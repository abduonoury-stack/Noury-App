package com.tahseel.students.util

import com.tahseel.students.data.AppSetting
import com.tahseel.students.data.FinanceDao
import java.time.DayOfWeek
import java.time.LocalDate

/** One academy-wide workweek shared by student and employee attendance. */
object WorkdaySettings {
    const val KEY = "academy_workdays"
    val defaultDays: Set<DayOfWeek> = setOf(
        DayOfWeek.SUNDAY, DayOfWeek.MONDAY, DayOfWeek.TUESDAY,
        DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY
    )

    fun parse(value: String?): Set<DayOfWeek> {
        if (value.isNullOrBlank()) return defaultDays
        val parsed = value.split(',').mapNotNull { token ->
            runCatching { DayOfWeek.valueOf(token.trim().uppercase()) }.getOrNull()
        }.toSet()
        return parsed.ifEmpty { defaultDays }
    }

    fun serialize(days: Set<DayOfWeek>): String = days.sortedBy { it.value }.joinToString(",") { it.name }
    fun isWorkday(date: LocalDate, days: Set<DayOfWeek>) = date.dayOfWeek in days

    fun onOrBefore(date: LocalDate, days: Set<DayOfWeek>): LocalDate {
        var d = date
        repeat(7) { if (isWorkday(d, days)) return d else d = d.minusDays(1) }
        return date
    }
    fun next(date: LocalDate, days: Set<DayOfWeek>): LocalDate {
        var d = date
        repeat(7) { if (isWorkday(d, days)) return d else d = d.plusDays(1) }
        return date
    }
    fun previous(date: LocalDate, days: Set<DayOfWeek>): LocalDate {
        var d = date
        repeat(7) { if (isWorkday(d, days)) return d else d = d.minusDays(1) }
        return date
    }
    fun nearestWorkdayInMonth(date: LocalDate, days: Set<DayOfWeek>): LocalDate {
        for (offset in 0..date.lengthOfMonth()) {
            val candidate = date.plusDays(offset.toLong())
            if (candidate.month == date.month && isWorkday(candidate, days)) return candidate
        }
        for (offset in 1..date.dayOfMonth) {
            val candidate = date.minusDays(offset.toLong())
            if (candidate.month == date.month && isWorkday(candidate, days)) return candidate
        }
        return date
    }
    suspend fun load(dao: FinanceDao): Set<DayOfWeek> = parse(dao.getSetting(KEY))
    suspend fun save(dao: FinanceDao, days: Set<DayOfWeek>) {
        dao.putSetting(AppSetting(KEY, serialize(days)))
    }
}
