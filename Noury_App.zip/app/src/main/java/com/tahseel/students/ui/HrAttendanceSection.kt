package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tahseel.students.data.Employee
import com.tahseel.students.data.EmployeeAttendance
import java.time.LocalDate
import java.time.DayOfWeek
import java.time.YearMonth
import java.time.format.DateTimeFormatter

@Composable
fun HrAttendanceSection(
    employees: List<Employee>, attendance: List<EmployeeAttendance>, monthlyAttendance: List<EmployeeAttendance>,
    selectedDate: LocalDate, month: YearMonth, workdays: Set<DayOfWeek>, onMonthChange: (YearMonth) -> Unit,
    onSelectDate: (LocalDate) -> Unit, onSetAttendance: (Employee, String, LocalDate) -> Unit,
    onSetTimes: (Employee, String, String, Int, LocalDate) -> Unit
) {
    MonthSelector(month, onMonthChange)
    val monthDays = (1..month.lengthOfMonth()).map { month.atDay(it) }.filter { it.dayOfWeek in workdays }
    Text("اختر يومًا من الشهر لمراجعة أو تسجيل الحضور والغياب", style = MaterialTheme.typography.titleMedium)
    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(vertical = 4.dp)) {
        items(monthDays) { day ->
            val dayRows = monthlyAttendance.filter { it.workDate == day.toString() }
            FilterChip(selected = selectedDate == day, onClick = { onSelectDate(day) },
                label = { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(day.dayOfMonth.toString()); Text("غ ${dayRows.count { it.status == "absent" }}", style = MaterialTheme.typography.labelSmall) } })
        }
    }
    val monthAbsent = monthlyAttendance.filter { it.status == "absent" && runCatching { LocalDate.parse(it.workDate).dayOfWeek in workdays }.getOrDefault(false) }
    val monthPresent = monthlyAttendance.count { (it.status == "present" || it.status == "late") && runCatching { LocalDate.parse(it.workDate).dayOfWeek in workdays }.getOrDefault(false) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StatCard("أيام الغياب", monthAbsent.size.toString(), Modifier.weight(1f))
        StatCard("أيام الحضور", monthPresent.toString(), Modifier.weight(1f))
    }
    Text("ملخص الغياب لكل موظف خلال ${month.format(DateTimeFormatter.ofPattern("MM / yyyy"))}", style = MaterialTheme.typography.titleMedium)
    employees.filter { it.status != "deleted" }.forEach { emp ->
        val rows = monthAbsent.filter { it.employeeId == emp.id }.sortedBy { it.workDate }
        if (rows.isNotEmpty()) Card { Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(emp.fullName, style = MaterialTheme.typography.titleSmall); Text("عدد أيام الغياب: ${rows.size}")
            Text("تواريخ الغياب: ${rows.joinToString(" ، ") { it.workDate.takeLast(2) }}", style = MaterialTheme.typography.bodySmall)
        } }
    }
    if (monthAbsent.isEmpty()) Card { Text("لا توجد أيام غياب مسجلة في هذا الشهر.", Modifier.padding(18.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
    HorizontalDivider()
    Text("تسجيل الحضور والانصراف • ${selectedDate.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))}", style = MaterialTheme.typography.titleMedium)
    Text("اختر حالة كل موظف في اليوم المحدد، ثم احفظ وقت الحضور والانصراف.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        StatCard("حاضر", attendance.count { it.status == "present" || it.status == "late" }.toString(), Modifier.weight(1f))
        StatCard("غائب", attendance.count { it.status == "absent" }.toString(), Modifier.weight(1f))
        StatCard("إجازة", attendance.count { it.status == "leave" }.toString(), Modifier.weight(1f))
    }
    employees.filter { it.status == "active" }.forEach { employee ->
        val record = attendance.firstOrNull { it.employeeId == employee.id }
        var checkIn by remember(employee.id, selectedDate, record?.checkIn) { mutableStateOf(record?.checkIn ?: "") }
        var checkOut by remember(employee.id, selectedDate, record?.checkOut) { mutableStateOf(record?.checkOut ?: "") }
        Card { Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(employee.fullName, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                Text(record?.let { when(it.status) { "present", "late" -> "حاضر"; "absent" -> "غائب"; "leave" -> "إجازة"; else -> "" } } ?: "لم يسجل", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("present" to "حاضر", "absent" to "غائب", "leave" to "إجازة").forEach { (key, label) ->
                    FilterChip(selected = if (key == "present") record?.status == "present" || record?.status == "late" else record?.status == key,
                        onClick = { onSetAttendance(employee, key, selectedDate) }, label = { Text(label) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(checkIn, { checkIn = it }, modifier = Modifier.weight(1f), label = { Text("حضور HH:MM") }, singleLine = true)
                OutlinedTextField(checkOut, { checkOut = it }, modifier = Modifier.weight(1f), label = { Text("انصراف HH:MM") }, singleLine = true)
            }
            Button(onClick = { onSetTimes(employee, checkIn, checkOut, 0, selectedDate) }) { Text("حفظ الوقت") }
        } }
    }
}
