package com.tahseel.students.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "classrooms", indices = [Index(value = ["name"], unique = true)])
data class Classroom(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val level: String = "",
    val teacherName: String = "",
    val capacity: Int = 20,
    val createdAt: Long = System.currentTimeMillis()
)
