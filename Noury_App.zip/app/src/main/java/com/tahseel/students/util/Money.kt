package com.tahseel.students.util

import java.math.BigDecimal
import java.util.Locale

object Money {
    private val MAX_EGP = BigDecimal("100000000")
    private val AMOUNT_PATTERN = Regex("^\\d+(\\.\\d{1,2})?$")

    /** يحوّل الأرقام العربية/الفارسية وفواصل الآلاف إلى صيغة إنجليزية قياسية. */
    fun normalizeDigits(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            when (ch) {
                in '\u0660'..'\u0669' -> sb.append('0' + (ch - '\u0660'))
                in '\u06F0'..'\u06F9' -> sb.append('0' + (ch - '\u06F0'))
                '\u066B' -> sb.append('.')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    /**
     * يقبل فواصل الآلاف فقط إذا كانت صحيحة (1,000 أو ١٬٠٠٠)،
     * ويرفض الفواصل أو المسافات العشوائية حتى لا يتحول إدخال خاطئ إلى مبلغ مختلف.
     */
    private fun normalizedAmount(input: String): String? {
        val value = normalizeDigits(input.trim())
        if (value.isEmpty()) return null

        val decimalParts = value.split('.')
        if (decimalParts.size > 2) return null
        val integerPart = decimalParts[0]
        val fractionPart = decimalParts.getOrNull(1)
        if (fractionPart != null && (fractionPart.isEmpty() || fractionPart.length > 2 || !fractionPart.all(Char::isDigit))) return null

        val separators = integerPart.filter { it == ',' || it == '\u066C' || it == ' ' || it == '\u00A0' }.toSet()
        val digitsOnly: String
        if (separators.isEmpty()) {
            if (!integerPart.all(Char::isDigit)) return null
            digitsOnly = integerPart
        } else {
            // لا نخلط أنواع فواصل الآلاف في نفس الرقم.
            if (separators.size != 1) return null
            val separator = separators.first()
            val groups = integerPart.split(separator)
            if (groups.size < 2 || groups.first().length !in 1..3 || !groups.first().all(Char::isDigit)) return null
            if (groups.drop(1).any { it.length != 3 || !it.all(Char::isDigit) }) return null
            digitsOnly = groups.joinToString("")
        }
        if (digitsOnly.isEmpty()) return null
        return digitsOnly + (fractionPart?.let { ".$it" } ?: "")
    }

    /** يعيد المبلغ بالقروش، أو null إذا كان غير صالح (فارغ/سالب/صفر/نص/أكثر من خانتين عشريتين). */
    fun parse(input: String): Long? = parseNonNegative(input)?.takeIf { it > 0L }

    /** مثل parse لكنه يقبل الصفر (مثل المبلغ المدفوع). يستخدم BigDecimal فلا يوجد تقريب عشري. */
    fun parseNonNegative(input: String): Long? {
        val normalized = normalizedAmount(input) ?: return null
        if (!AMOUNT_PATTERN.matches(normalized)) return null
        return runCatching {
            val amount = BigDecimal(normalized)
            if (amount.compareTo(MAX_EGP) > 0) null else amount.movePointRight(2).longValueExact()
        }.getOrNull()
    }

    fun plain(p: Long): String = String.format(Locale.US, "%d.%02d", p / 100, p % 100)

    fun format(p: Long): String = String.format(Locale.US, "%,d.%02d", p / 100, p % 100) + " ج.م"
}
