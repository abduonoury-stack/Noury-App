package com.tahseel.students.vm

import com.tahseel.students.data.resolvePeriodPricePiasters

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tahseel.students.data.FinanceDao
import com.tahseel.students.data.Student
import com.tahseel.students.data.StudentDao
import com.tahseel.students.data.SubscriptionPayment
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId

 data class CollectionStudentRow(
    val student: Student,
    val duePiasters: Long,
    val paidPiasters: Long,
    val payment: SubscriptionPayment?
) {
    val isPaid: Boolean get() = payment != null && paidPiasters >= duePiasters
    val remainingPiasters: Long get() = (duePiasters - paidPiasters).coerceAtLeast(0L)
}

data class CollectionStatusSummary(
    val rows: List<CollectionStudentRow> = emptyList(),
    val dueTotal: Long = 0L,
    val collectedTotal: Long = 0L,
    val remainingTotal: Long = 0L,
    val paidCount: Int = 0,
    val unpaidCount: Int = 0
)

@OptIn(ExperimentalCoroutinesApi::class)
class CollectionStatusViewModel(
    private val studentsDao: StudentDao,
    private val financeDao: FinanceDao,
    private val periodDao: com.tahseel.students.data.PeriodDao
) : ViewModel() {
    val period = MutableStateFlow(YearMonth.now())
    val search = MutableStateFlow("")
    val filter = MutableStateFlow("all") // all, paid, unpaid

    private val periodPayments = period.flatMapLatest { month ->
        financeDao.observeValidSubscriptionPayments(month.toString())
    }

    val summary: StateFlow<CollectionStatusSummary> = combine(
        studentsDao.observeAll(), period, periodPayments, periodDao.observeAll(), periodDao.observeAllPriceHistory()
    ) { students, month, payments, allPeriods, priceHistory ->
        val paymentByStudent = payments.associateBy { it.studentId }
        val rows = students.asSequence()
            .filter { it.status == "active" }
            .mapNotNull { student ->
                val enrollmentDate = Instant.ofEpochMilli(student.enrollmentDate)
                    .atZone(ZoneId.systemDefault()).toLocalDate()
                val enrollmentMonth = YearMonth.from(enrollmentDate)
                if (month.isBefore(enrollmentMonth)) return@mapNotNull null
                val payment = paymentByStudent[student.id]
                val due = payment?.dueAmountPiasters ?: if (month == enrollmentMonth && student.firstMonthAmountPiasters != null) {
                    student.firstMonthAmountPiasters
                } else {
                    val pid = student.periodId ?: if (student.attendanceEndHour == 16 || student.attendanceEndHour == 17) 2L else 1L
                    val at = month.atDay(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                    student.monthlyFeeOverridePiasters ?: resolvePeriodPricePiasters(priceHistory, pid, at) ?: 0L
                }
                if (due <= 0L) return@mapNotNull null
                CollectionStudentRow(student, due, payment?.paidAmountPiasters ?: 0L, payment)
            }
            .sortedBy { it.student.fullName.lowercase() }
            .toList()
        CollectionStatusSummary(
            rows = rows,
            dueTotal = rows.sumOf { it.duePiasters },
            collectedTotal = rows.sumOf { it.paidPiasters },
            remainingTotal = rows.sumOf { it.remainingPiasters },
            paidCount = rows.count { it.isPaid },
            unpaidCount = rows.count { !it.isPaid }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), CollectionStatusSummary())

    val visibleRows: StateFlow<List<CollectionStudentRow>> = combine(summary, search, filter) { summary, query, selected ->
        val normalized = query.trim().lowercase()
        summary.rows.filter { row ->
            val normalizedDigits = normalized.map { ch -> when (ch) { in '٠'..'٩' -> ('0'.code + (ch - '٠')).toChar(); in '۰'..'۹' -> ('0'.code + (ch - '۰')).toChar(); else -> ch } }.filter { it.isDigit() }.joinToString("")
            val phoneDigits = row.student.motherWhatsapp.map { ch -> when (ch) { in '٠'..'٩' -> ('0'.code + (ch - '٠')).toChar(); in '۰'..'۹' -> ('0'.code + (ch - '۰')).toChar(); else -> ch } }.filter { it.isDigit() }.joinToString("")
            val matchesName = normalized.isBlank() || row.student.fullName.lowercase().contains(normalized) || (normalizedDigits.isNotEmpty() && phoneDigits.contains(normalizedDigits))
            val matchesFilter = when (selected) {
                "paid" -> row.isPaid
                "unpaid" -> !row.isPaid
                else -> true
            }
            matchesName && matchesFilter
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun previousMonth() { period.update { it.minusMonths(1) } }
    fun nextMonth() { period.update { it.plusMonths(1) } }
    fun selectFilter(value: String) { filter.value = value }
}
