package com.tahseel.students.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "attendance", indices = [Index(value = ["className", "attendanceDate"]), Index(value = ["studentId", "attendanceDate"], unique = true)])
data class Attendance(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val studentName: String,
    val className: String,
    /** ISO date yyyy-MM-dd */
    val attendanceDate: String,
    /** present | absent */
    val status: String,
    val createdAt: Long = System.currentTimeMillis()
)
