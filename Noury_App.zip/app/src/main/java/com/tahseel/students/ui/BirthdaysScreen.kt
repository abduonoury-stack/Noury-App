package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.data.StudentDao
import java.time.Instant
import java.time.LocalDate
import java.time.Period
import java.time.ZoneId

private val birthdayMonths = listOf("يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BirthdaysScreen(dao: StudentDao, onBack: () -> Unit, onProfile: (Long) -> Unit) {
    val students by dao.observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val today = LocalDate.now()
    var month by remember { mutableIntStateOf(today.monthValue) }
    var expanded by remember { mutableStateOf(false) }
    val zone = remember { ZoneId.systemDefault() }
    val birthdayStudents = students.mapNotNull { student ->
        val millis = student.birthDate ?: return@mapNotNull null
        val birth = runCatching { Instant.ofEpochMilli(millis).atZone(zone).toLocalDate() }.getOrNull() ?: return@mapNotNull null
        if (birth.monthValue != month) return@mapNotNull null
        val day = minOf(birth.dayOfMonth, java.time.YearMonth.of(today.year, month).lengthOfMonth())
        val ageDate = LocalDate.of(today.year, month, day)
        val age = Period.between(birth, ageDate).years.coerceAtLeast(0)
        Triple(student, birth, age)
    }.sortedWith(compareBy({ it.second.dayOfMonth }, { it.first.fullName }))

    AppScaffold(title = "أعياد ميلاد الطلاب", onBack = onBack) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("اختار الشهر لعرض الطلاب أصحاب أعياد الميلاد فيه", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                OutlinedTextField(
                    value = birthdayMonths[month - 1], onValueChange = {}, readOnly = true,
                    label = { Text("الشهر") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    birthdayMonths.forEachIndexed { index, name ->
                        DropdownMenuItem(text = { Text(name) }, onClick = { month = index + 1; expanded = false })
                    }
                }
            }
            Card {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Text("عدد أعياد الميلاد في ${birthdayMonths[month - 1]}", style = MaterialTheme.typography.labelLarge)
                    Text("${birthdayStudents.size} طالب", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
                }
            }
            if (birthdayStudents.isEmpty()) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Cake, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("مفيش أعياد ميلاد مسجلة في الشهر ده", style = MaterialTheme.typography.titleMedium)
                        Text("تأكد إن تاريخ الميلاد متسجل في ملف الطالب.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(birthdayStudents, key = { it.first.id }) { (student, birth, age) ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(student.fullName, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.clickable { onProfile(student.id) })
                                    Text("${birth.dayOfMonth} ${birthdayMonths[birth.monthValue - 1]} ${birth.year}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(if (student.status == "active") "منتظم" else "منقطع", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                                }
                                Column(horizontalAlignment = androidx.compose.ui.Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("${birth.dayOfMonth}", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                                    Text("هيكمل $age سنة", style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
