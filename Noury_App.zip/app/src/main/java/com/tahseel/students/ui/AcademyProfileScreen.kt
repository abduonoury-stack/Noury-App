package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.tahseel.students.util.AcademyProfileStore

@Composable
fun AcademyProfileScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(AcademyProfileStore.name.value) }
    var address by remember { mutableStateOf(AcademyProfileStore.address.value) }
    var phone by remember { mutableStateOf(AcademyProfileStore.phone.value) }
    var message by remember { mutableStateOf<String?>(null) }
    AppScaffold("بيانات الأكاديمية", onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("اسم الأكاديمية هنا هو الاسم الرئيسي المستخدم في جميع شاشات البرنامج، والإيصالات، والتقارير، وكشوف الطباعة ورسائل أولياء الأمور. تعديل الاسم لا يغيّر أي حركة مالية سابقة.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(name, { name = it; message = null }, label = { Text("اسم الحضانة / الأكاديمية") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(address, { address = it; message = null }, label = { Text("العنوان") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            OutlinedTextField(phone, { phone = it; message = null }, label = { Text("رقم الهاتف") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Button(onClick = {
                if (name.isBlank()) message = "اكتب اسم الأكاديمية أولًا"
                else {
                    AcademyProfileStore.save(context, name, address, phone)
                    message = "تم حفظ بيانات الأكاديمية. الاسم الجديد اتحدث في جميع شاشات البرنامج."
                }
            }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Save, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("حفظ البيانات") }
            message?.let { Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium) }
        }
    }
}
