package com.tahseel.students.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection

/**
 * Noury App — shared playful premium design system.
 * Calm accounting-first surfaces, royal purple identity and restrained peach/gold accents.
 */
object LdaPalette {
    val Royal = Color(0xFF493276)
    val RoyalDeep = Color(0xFF352052)
    val RoyalMid = Color(0xFF67469A)
    val Peach = Color(0xFFF4B18D)
    val PeachContainer = Color(0xFFFFE9D9)
    val Gold = Color(0xFFE8D39A)
    val Lilac = Color(0xFFF0EAF8)
    val Canvas = Color(0xFFF8F5FC)
    val Surface = Color(0xFFFFFFFF)
    val SurfaceSoft = Color(0xFFF1EDF6)
    val Border = Color(0xFFE7DDF2)
    val MutedText = Color(0xFF6E657A)
    val Success = Color(0xFF16816E)
    val SuccessContainer = Color(0xFFDDF2EC)
    val Warning = Color(0xFFAD6A38)
    val WarningContainer = Color(0xFFFFF0E7)
    val Error = Color(0xFFB3261E)
    val ErrorContainer = Color(0xFFFCE8E6)
}

private val ldaColors = lightColorScheme(
    primary = LdaPalette.Royal,
    onPrimary = Color.White,
    primaryContainer = LdaPalette.Lilac,
    onPrimaryContainer = LdaPalette.RoyalDeep,
    secondary = Color(0xFFE99A70),
    onSecondary = Color.White,
    secondaryContainer = LdaPalette.PeachContainer,
    onSecondaryContainer = Color(0xFF75452F),
    tertiary = LdaPalette.Gold,
    onTertiary = Color(0xFF3C2B08),
    background = LdaPalette.Canvas,
    onBackground = Color(0xFF211A2A),
    surface = LdaPalette.Surface,
    onSurface = Color(0xFF211A2A),
    surfaceVariant = LdaPalette.SurfaceSoft,
    onSurfaceVariant = LdaPalette.MutedText,
    outline = LdaPalette.Border,
    outlineVariant = Color(0xFFF0EBF4),
    error = LdaPalette.Error,
    errorContainer = LdaPalette.ErrorContainer,
    onErrorContainer = Color(0xFF641B16)
)

private val ldaShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(13.dp),
    medium = RoundedCornerShape(17.dp),
    large = RoundedCornerShape(21.dp),
    extraLarge = RoundedCornerShape(27.dp)
)

private fun ldaText(
    size: androidx.compose.ui.unit.TextUnit,
    weight: FontWeight = FontWeight.Normal,
    lineHeight: androidx.compose.ui.unit.TextUnit = (size.value * 1.34f).sp
) = TextStyle(
    fontFamily = FontFamily.SansSerif,
    fontSize = size,
    lineHeight = lineHeight,
    fontWeight = weight
)

private val ldaTypography = Typography(
    displayLarge = ldaText(38.sp, FontWeight.ExtraBold, 46.sp),
    displayMedium = ldaText(34.sp, FontWeight.ExtraBold, 42.sp),
    displaySmall = ldaText(30.sp, FontWeight.Bold, 38.sp),
    headlineLarge = ldaText(30.sp, FontWeight.Bold, 38.sp),
    headlineMedium = ldaText(27.sp, FontWeight.Bold, 35.sp),
    headlineSmall = ldaText(24.sp, FontWeight.Bold, 32.sp),
    titleLarge = ldaText(22.sp, FontWeight.Bold, 30.sp),
    titleMedium = ldaText(18.sp, FontWeight.SemiBold, 26.sp),
    titleSmall = ldaText(16.sp, FontWeight.SemiBold, 23.sp),
    bodyLarge = ldaText(17.sp, FontWeight.Normal, 26.sp),
    bodyMedium = ldaText(16.sp, FontWeight.Normal, 24.sp),
    bodySmall = ldaText(14.sp, FontWeight.Normal, 21.sp),
    labelLarge = ldaText(15.sp, FontWeight.Bold, 21.sp),
    labelMedium = ldaText(14.sp, FontWeight.SemiBold, 20.sp),
    labelSmall = ldaText(13.sp, FontWeight.Medium, 18.sp)
)

@Composable
fun TahseelTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = ldaColors,
            typography = ldaTypography,
            shapes = ldaShapes,
            content = content
        )
    }
}
