package com.tahseel.students.util

object TextUtil {
    fun cleanName(s: String): String = s.trim().replace(Regex("\\s+"), " ")

    /** تطبيع عربي للبحث: حذف التشكيل والتطويل وتوحيد الألف والياء والتاء المربوطة. */
    fun normalize(s: String): String {
        val sb = StringBuilder()
        for (c in s.trim()) {
            when {
                c in '\u064B'..'\u065F' || c == '\u0640' || c == '\u0670' -> {}
                c == 'أ' || c == 'إ' || c == 'آ' || c == 'ٱ' -> sb.append('ا')
                c == 'ى' -> sb.append('ي')
                c == 'ة' -> sb.append('ه')
                else -> sb.append(c.lowercaseChar())
            }
        }
        return sb.toString().replace(Regex("\\s+"), " ")
    }
}
