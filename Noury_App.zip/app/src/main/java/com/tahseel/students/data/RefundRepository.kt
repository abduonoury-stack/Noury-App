package com.tahseel.students.data

import androidx.room.withTransaction

sealed class RefundResult {
    data class Success(val transactionId: Long, val remainingPiasters: Long) : RefundResult()
    data class Rejected(val reason: String) : RefundResult()
}

sealed class RefundCreditCreateResult {
    data class Success(val creditId: Long) : RefundCreditCreateResult()
    data class Rejected(val reason: String) : RefundCreditCreateResult()
}

/** Posts a real refund atomically against the credit and the selected cash/bank account. */
class RefundRepository(private val db: AppDatabase) {
    /** إنشاء رصيد استرداد يدوي معتمد من إيصال تحصيل عام؛ لا ينشئ حركة نقدية عكسية عند الإنشاء. */
    suspend fun createManualCredit(paymentId: Long, amountPiasters: Long, reason: String, documentReference: String): RefundCreditCreateResult = try {
        db.withTransaction {
            require(amountPiasters > 0L) { "قيمة الاسترداد يجب أن تكون أكبر من صفر" }
            require(reason.trim().isNotBlank()) { "سبب الاسترداد إلزامي" }
            require(documentReference.trim().isNotBlank()) { "رقم المستند أو مرجعه إلزامي للاسترداد اليدوي" }
            val payment = db.dao().getById(paymentId) ?: return@withTransaction RefundCreditCreateResult.Rejected("إيصال التحصيل الأصلي غير موجود")
            if (payment.isCancelled) return@withTransaction RefundCreditCreateResult.Rejected("لا يمكن إنشاء استرداد من إيصال ملغى")
            if (db.financeDao().subscriptionForPayment(paymentId) != null) return@withTransaction RefundCreditCreateResult.Rejected("إيصالات الاشتراك الشهري تُسوّى من خلال تسوية انسحاب الطالب، ولا تُسترد من المسار اليدوي")
            if (amountPiasters > payment.amountPiasters) return@withTransaction RefundCreditCreateResult.Rejected("قيمة الاسترداد أكبر من مبلغ التحصيل الأصلي")
            if (db.financeDao().refundCreditForPayment(paymentId) != null) return@withTransaction RefundCreditCreateResult.Rejected("يوجد بالفعل رصيد استرداد مرتبط بهذا الإيصال")
            val student = payment.studentId?.let { db.studentDao().getById(it) } ?: run {
                val matches = db.studentDao().getAllByExactName(payment.studentName)
                if (matches.size != 1) return@withTransaction RefundCreditCreateResult.Rejected(
                    if (matches.isEmpty()) "لا يوجد ملف طالب مرتبط بالإيصال؛ راجع بيانات الطالب قبل إنشاء الاسترداد"
                    else "اسم الطالب مكرر في الملفات؛ اربط إيصال التحصيل بملف الطالب الصحيح أولًا"
                )
                matches.single()
            }
            val now = System.currentTimeMillis()
            val id = db.financeDao().insertRefund(RefundCredit(
                studentId = student.id, paymentId = payment.id,
                originalAmountPiasters = amountPiasters, remainingAmountPiasters = amountPiasters,
                createdAt = now, note = reason.trim(), sourceType = "manual_payment", sourceId = payment.id,
                approvalStatus = "approved", reason = reason.trim(), documentReference = documentReference.trim(), approvedAt = now
            ))
            db.financeDao().insertAudit(AuditLog(
                entityType = "refund_credit", entityId = id, action = "manual_create_approved",
                details = "payment=$paymentId;amount=$amountPiasters;reason=${reason.trim()};document=${documentReference.trim()};approvedBy=owner",
                createdAt = now
            ))
            RefundCreditCreateResult.Success(id)
        }
    } catch (e: Exception) {
        RefundCreditCreateResult.Rejected(e.message ?: "تعذر إنشاء رصيد الاسترداد")
    }

    suspend fun refund(
        creditId: Long,
        amountPiasters: Long,
        method: String,
        note: String,
        accountId: String = "cash"
    ): RefundResult = try {
        db.withTransaction {
            require(amountPiasters > 0L) { "قيمة الاسترداد يجب أن تكون أكبر من صفر" }
            require(method.isNotBlank()) { "حدد طريقة رد المبلغ" }
            val account = db.cashAccountDao().find(accountId)
                ?: return@withTransaction RefundResult.Rejected("حساب الصرف غير موجود")
            if (!account.isActive) return@withTransaction RefundResult.Rejected("حساب الصرف غير نشط")
            val credit = db.financeDao().refundCreditById(creditId)
                ?: return@withTransaction RefundResult.Rejected("رصيد الاسترداد غير موجود")
            if (credit.sourceType == "exit_settlement") return@withTransaction RefundResult.Rejected("أرصدة تسويات الانسحاب تُصرف من شاشة تسوية الانسحاب حتى يتطابق سجل التسوية مع سجل الاسترداد")
            if (credit.approvalStatus != "approved") return@withTransaction RefundResult.Rejected("رصيد الاسترداد غير معتمد")
            if (credit.remainingAmountPiasters < amountPiasters)
                return@withTransaction RefundResult.Rejected("قيمة الاسترداد أكبر من الرصيد المتبقي")
            val remaining = credit.remainingAmountPiasters - amountPiasters
            val now = System.currentTimeMillis()
            val transactionId = db.financeDao().insertRefundTransaction(
                RefundTransaction(
                    refundCreditId = creditId,
                    amountPiasters = amountPiasters,
                    refundedAt = now,
                    method = method.trim(),
                    note = note.trim(),
                    accountId = accountId
                )
            )
            check(db.financeDao().updateRefundCredit(credit.copy(remainingAmountPiasters = remaining)) == 1) {
                "تعذر تحديث رصيد الاسترداد"
            }
            db.financeDao().insertAudit(AuditLog(
                entityType = "refund_credit", entityId = creditId, action = "refund",
                details = "actor=owner;transaction=$transactionId;amount=$amountPiasters;account=$accountId;method=${method.trim()}",
                createdAt = now
            ))
            RefundResult.Success(transactionId, remaining)
        }
    } catch (e: Exception) {
        RefundResult.Rejected(e.message ?: "تعذر تسجيل الاسترداد")
    }
}
