package com.tahseel.students.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "employees", indices = [Index("fullName"), Index("status"), Index("jobTitle")])
data class Employee(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeCode: String = "",
    val fullName: String,
    val jobTitle: String,
    val phone: String,
    val whatsapp: String = "",
    val address: String = "",
    val nationalId: String = "",
    val birthDate: String = "",
    val hireDate: String,
    val contractType: String = "دائم",
    val contractEndDate: String = "",
    val department: String = "",
    val workStart: String = "08:00",
    val workEnd: String = "16:00",
    val weeklyDays: String = "السبت-الخميس",
    val baseSalaryPiasters: Long,
    val emergencyName: String = "",
    val emergencyPhone: String = "",
    val notes: String = "",
    val status: String = "active",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "employee_attendance", foreignKeys = [ForeignKey(entity = Employee::class, parentColumns = ["id"], childColumns = ["employeeId"], onDelete = ForeignKey.RESTRICT)], indices = [Index(value = ["employeeId", "workDate"], unique = true), Index("workDate")])
data class EmployeeAttendance(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val workDate: String,
    val checkIn: String = "",
    val checkOut: String = "",
    val status: String = "present", // present, absent, late, leave
    val lateMinutes: Int = 0,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "employee_leaves", foreignKeys = [ForeignKey(entity = Employee::class, parentColumns = ["id"], childColumns = ["employeeId"], onDelete = ForeignKey.RESTRICT)], indices = [Index("employeeId"), Index("startDate")])
data class EmployeeLeave(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val leaveType: String,
    val startDate: String,
    val endDate: String,
    val days: Double,
    val reason: String = "",
    val status: String = "pending", // pending, approved, rejected
    val decisionNote: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "employee_payroll", foreignKeys = [ForeignKey(entity = Employee::class, parentColumns = ["id"], childColumns = ["employeeId"], onDelete = ForeignKey.RESTRICT)], indices = [Index(value = ["employeeId", "monthKey"], unique = true), Index("monthKey")])
data class EmployeePayroll(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val monthKey: String,
    val basePiasters: Long,
    val allowancesPiasters: Long = 0,
    val bonusesPiasters: Long = 0,
    val deductionsPiasters: Long = 0,
    val loanDeductionPiasters: Long = 0,
    val netPiasters: Long,
    val paidPiasters: Long = 0,
    val paidAt: Long? = null,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)


@Entity(tableName = "employee_payroll_payments", foreignKeys = [ForeignKey(entity = EmployeePayroll::class, parentColumns = ["id"], childColumns = ["payrollId"], onDelete = ForeignKey.RESTRICT)], indices = [Index("payrollId"), Index("paymentDate"), Index("correctionOfPaymentId"), Index("correctedByPaymentId")])
data class EmployeePayrollPayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val payrollId: Long,
    val amountPiasters: Long,
    val paymentDate: String,
    val paymentMethod: String,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "'active'") val status: String = "active",
    val voidedAt: Long? = null,
    @ColumnInfo(defaultValue = "''") val voidReason: String = "",
    @ColumnInfo(defaultValue = "NULL") val correctionOfPaymentId: Long? = null,
    @ColumnInfo(defaultValue = "NULL") val correctedByPaymentId: Long? = null,
    val accountId: String? = "cash"
)



/** عكس محاسبي لدفعة مرتب صُرفت فعليًا؛ لا يعني أن النقد عاد بالكامل. */
@Entity(
    tableName = "employee_payroll_reversals",
    foreignKeys = [ForeignKey(entity = EmployeePayrollPayment::class, parentColumns = ["id"], childColumns = ["originalPaymentId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("originalPaymentId", unique = true), Index("createdAt")]
)
data class EmployeePayrollReversal(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val originalPaymentId: Long,
    val amountPiasters: Long,
    val reason: String,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

/** كل تحصيل فعلي من الموظف؛ يدعم التحصيل الجزئي والمتكرر دون زيادة رصيد الحساب قبل الاستلام. */
@Entity(
    tableName = "employee_payroll_recovery_transactions",
    foreignKeys = [
        ForeignKey(entity = EmployeePayrollReversal::class, parentColumns = ["id"], childColumns = ["reversalId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = CashAccount::class, parentColumns = ["id"], childColumns = ["accountId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index("reversalId"), Index("receivedAt"), Index("accountId")]
)
data class EmployeePayrollRecoveryTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reversalId: Long,
    val amountPiasters: Long,
    val receivedAt: Long = System.currentTimeMillis(),
    val accountId: String,
    val note: String = ""
)

@Entity(tableName = "employee_loans", foreignKeys = [ForeignKey(entity = Employee::class, parentColumns = ["id"], childColumns = ["employeeId"], onDelete = ForeignKey.RESTRICT)], indices = [Index("employeeId"), Index("status")])
data class EmployeeLoan(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val amountPiasters: Long,
    val monthlyInstallmentPiasters: Long,
    val remainingPiasters: Long,
    val startMonth: String,
    val note: String = "",
    val status: String = "active",
    val createdAt: Long = System.currentTimeMillis(),
    val accountId: String? = "cash",
    @ColumnInfo(defaultValue = "0") val issuedAt: Long = 0L
)

@Entity(tableName = "employee_adjustments", foreignKeys = [ForeignKey(entity = Employee::class, parentColumns = ["id"], childColumns = ["employeeId"], onDelete = ForeignKey.RESTRICT)], indices = [Index("employeeId"), Index("monthKey")])
data class EmployeeAdjustment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val monthKey: String,
    val type: String, // bonus, penalty
    val amountPiasters: Long,
    val reason: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface HrDao {
    @Insert suspend fun insertEmployee(item: Employee): Long
    @Update suspend fun updateEmployee(item: Employee)
    @Query("SELECT * FROM employees ORDER BY CASE WHEN status='active' THEN 0 ELSE 1 END, fullName COLLATE NOCASE") fun observeEmployees(): Flow<List<Employee>>
    @Query("SELECT * FROM employees WHERE id=:id LIMIT 1") suspend fun employee(id: Long): Employee?
    @Query("SELECT COUNT(*) FROM employees") fun observeEmployeeCount(): Flow<Int>
    @Query("SELECT * FROM employee_attendance WHERE workDate=:date ORDER BY id") fun observeAttendance(date: String): Flow<List<EmployeeAttendance>>
    @Query("SELECT * FROM employee_attendance WHERE workDate BETWEEN :from AND :until ORDER BY workDate, employeeId") fun observeAttendanceRange(from: String, until: String): Flow<List<EmployeeAttendance>>
    @Query("SELECT * FROM employee_attendance WHERE employeeId=:employeeId AND workDate=:date LIMIT 1") suspend fun attendance(employeeId: Long, date: String): EmployeeAttendance?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveAttendance(item: EmployeeAttendance)
    @Query("SELECT * FROM employee_leaves ORDER BY createdAt DESC") fun observeLeaves(): Flow<List<EmployeeLeave>>
    @Insert suspend fun insertLeave(item: EmployeeLeave): Long
    @Query("UPDATE employee_leaves SET status=:status, decisionNote=:note WHERE id=:id") suspend fun decideLeave(id: Long, status: String, note: String = "")
    @Query("SELECT * FROM employee_payroll WHERE monthKey=:month ORDER BY employeeId") fun observePayroll(month: String): Flow<List<EmployeePayroll>>
    @Query("SELECT * FROM employee_payroll ORDER BY monthKey, employeeId") fun observeAllPayroll(): Flow<List<EmployeePayroll>>
    @Query("SELECT * FROM employee_payroll WHERE monthKey=:month ORDER BY employeeId") suspend fun payrollSnapshot(month: String): List<EmployeePayroll>
    @Query("SELECT * FROM employee_payroll WHERE employeeId=:employeeId AND monthKey=:month LIMIT 1") suspend fun payroll(employeeId: Long, month: String): EmployeePayroll?
    @Query("SELECT monthKey FROM employee_payroll WHERE id=:payrollId LIMIT 1") suspend fun payrollMonthForId(payrollId: Long): String?
    @Query("SELECT COALESCE(SUM(amountPiasters),0) FROM employee_payroll_payments WHERE payrollId=:payrollId AND status='active'") suspend fun payrollPaymentsTotal(payrollId: Long): Long
    @Query("SELECT * FROM employee_payroll_payments WHERE id=:id LIMIT 1") suspend fun payrollPayment(id: Long): EmployeePayrollPayment?
    @Query("SELECT p.* FROM employee_payroll_payments p INNER JOIN employee_payroll r ON r.id=p.payrollId WHERE r.monthKey=:month ORDER BY p.paymentDate DESC,p.id DESC") fun observePayrollPayments(month: String): Flow<List<EmployeePayrollPayment>>
    @Query("SELECT * FROM employee_payroll_payments ORDER BY paymentDate DESC,id DESC") fun observeAllPayrollPayments(): Flow<List<EmployeePayrollPayment>>
    @Insert suspend fun insertPayrollPayment(item: EmployeePayrollPayment): Long
    @Update suspend fun updatePayrollPayment(item: EmployeePayrollPayment)
    @Upsert suspend fun savePayroll(item: EmployeePayroll)
    @Query("SELECT * FROM employee_payroll_reversals WHERE originalPaymentId=:paymentId LIMIT 1") suspend fun payrollReversalForPayment(paymentId: Long): EmployeePayrollReversal?
    @Query("SELECT * FROM employee_payroll_reversals WHERE id=:id LIMIT 1") suspend fun payrollReversalById(id: Long): EmployeePayrollReversal?
    @Query("SELECT * FROM employee_payroll_reversals ORDER BY createdAt DESC,id DESC") fun observeAllPayrollReversals(): Flow<List<EmployeePayrollReversal>>
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertPayrollReversal(item: EmployeePayrollReversal): Long
    @Query("SELECT COALESCE(SUM(amountPiasters),0) FROM employee_payroll_recovery_transactions WHERE reversalId=:reversalId") suspend fun payrollRecoveryTotal(reversalId: Long): Long
    @Query("SELECT * FROM employee_payroll_recovery_transactions ORDER BY receivedAt DESC,id DESC") fun observeAllPayrollRecoveries(): Flow<List<EmployeePayrollRecoveryTransaction>>
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertPayrollRecovery(item: EmployeePayrollRecoveryTransaction): Long
    @Query("SELECT * FROM employee_loans ORDER BY createdAt DESC") fun observeLoans(): Flow<List<EmployeeLoan>>
    @Insert suspend fun insertLoan(item: EmployeeLoan): Long
    @Query("SELECT * FROM employee_adjustments WHERE monthKey=:month ORDER BY createdAt DESC") fun observeAdjustments(month: String): Flow<List<EmployeeAdjustment>>
    @Insert suspend fun insertAdjustment(item: EmployeeAdjustment): Long
    @Query("SELECT COALESCE(SUM(amountPiasters),0) FROM employee_adjustments WHERE employeeId=:employeeId AND monthKey=:month AND type='bonus'") suspend fun bonuses(employeeId: Long, month: String): Long
    @Query("SELECT COALESCE(SUM(amountPiasters),0) FROM employee_adjustments WHERE employeeId=:employeeId AND monthKey=:month AND type='allowance'") suspend fun allowances(employeeId: Long, month: String): Long
    @Query("SELECT COALESCE(SUM(amountPiasters),0) FROM employee_adjustments WHERE employeeId=:employeeId AND monthKey=:month AND type='penalty'") suspend fun penalties(employeeId: Long, month: String): Long
    @Query("SELECT * FROM employee_loans WHERE employeeId=:employeeId AND status='active' AND remainingPiasters>0 ORDER BY createdAt") suspend fun activeLoans(employeeId: Long): List<EmployeeLoan>
    @Update suspend fun updateLoan(item: EmployeeLoan)
    @Query("SELECT COUNT(*) FROM employee_attendance WHERE workDate BETWEEN :from AND :until AND status='absent'") fun observeAbsenceCount(from: String, until: String): Flow<Int>
    @Query("SELECT workDate FROM employee_attendance WHERE employeeId=:employeeId AND workDate BETWEEN :from AND :until AND status='absent'") suspend fun absenceDates(employeeId: Long, from: String, until: String): List<String>
}
