package com.tahseel.students.util

import com.tahseel.students.data.Payment

object CsvExporter {
    /** UTF-8 مع BOM ليفتح Excel العربية بشكل صحيح. الترتيب تصاعدي والمسلسل = ترتيب العملية. */
    fun build(ascending: List<Payment>): ByteArray {
        val sb = StringBuilder()
        sb.append("المسلسل,اسم الطالب,رقم الإيصال,المبلغ (ج.م),التاريخ والوقت\r\n")
        ascending.forEachIndexed { i, p ->
            sb.append(i + 1).append(',')
                .append(esc(p.studentName)).append(',')
                .append(esc(p.receiptNo)).append(',')
                .append(Money.plain(p.amountPiasters)).append(',')
                .append(TimeUtil.csvTime(p.createdAt)).append("\r\n")
        }
        val bom = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())
        return bom + sb.toString().toByteArray(Charsets.UTF_8)
    }

    fun esc(value: String): String {
        var s = value
        // حماية من حقن الصيغ في Excel
        if (s.isNotEmpty() && s[0] in "=+-@\t\r") s = "'$s"
        val needsQuote = s.any { it == ',' || it == '"' || it == '\n' || it == '\r' }
        return if (needsQuote) "\"" + s.replace("\"", "\"\"") + "\"" else s
    }
}
