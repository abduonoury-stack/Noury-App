package com.tahseel.students.util

import com.tahseel.students.data.Payment
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.security.MessageDigest

/** صيغة النسخة الاحتياطية: JSON منظم + عدّاد + إجمالي + SHA-256 للتحقق من السلامة. */
object BackupCodec {
    const val APP = "tahseel-students"
    const val VERSION = 1

    sealed class Decoded {
        data class Ok(val payments: List<Payment>, val exportedAt: Long, val total: Long) : Decoded()
        data class Bad(val reason: String) : Decoded()
    }

    fun checksum(list: List<Payment>): String {
        val sb = StringBuilder()
        list.sortedBy { it.id }.forEach {
            sb.append(it.id).append('|').append(it.studentName).append('|').append(it.receiptNo)
                .append('|').append(it.amountPiasters).append('|').append(it.createdAt).append('\n')
        }
        val digest = MessageDigest.getInstance("SHA-256").digest(sb.toString().toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun encode(list: List<Payment>, exportedAt: Long): String {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("studentName", it.studentName)
                    .put("receiptNo", it.receiptNo)
                    .put("amountPiasters", it.amountPiasters)
                    .put("createdAt", it.createdAt)
            )
        }
        return JSONObject()
            .put("app", APP)
            .put("version", VERSION)
            .put("exportedAt", exportedAt)
            .put("count", list.size)
            .put("totalPiasters", list.sumOf { it.amountPiasters })
            .put("checksum", checksum(list))
            .put("payments", arr)
            .toString(2)
    }

    fun decode(text: String): Decoded {
        try {
            val root = JSONObject(text.removePrefix("\uFEFF"))
            if (root.optString("app") != APP) return Decoded.Bad("هذا الملف ليس نسخة احتياطية لتطبيق تحصيل الطلاب")
            val version = root.getInt("version")
            if (version != VERSION) return Decoded.Bad("إصدار النسخة ($version) غير مدعوم في هذا التطبيق")
            val arr = root.getJSONArray("payments")
            val list = ArrayList<Payment>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val p = Payment(
                    id = o.getLong("id"),
                    studentName = o.getString("studentName"),
                    receiptNo = o.getString("receiptNo"),
                    amountPiasters = o.getLong("amountPiasters"),
                    createdAt = o.getLong("createdAt"),
                    accountId = null // النسخة القديمة لا تحمل معلومة موثوقة عن حساب الاستلام.
                )
                if (p.id <= 0) return Decoded.Bad("بيانات تالفة: معرّف غير صالح في العملية رقم ${i + 1}")
                if (p.studentName.isBlank()) return Decoded.Bad("بيانات تالفة: اسم طالب فارغ في العملية رقم ${i + 1}")
                if (p.receiptNo.isBlank()) return Decoded.Bad("بيانات تالفة: رقم إيصال فارغ في العملية رقم ${i + 1}")
                if (p.amountPiasters <= 0) return Decoded.Bad("بيانات تالفة: مبلغ غير صالح في العملية رقم ${i + 1}")
                if (p.createdAt <= 0) return Decoded.Bad("بيانات تالفة: تاريخ غير صالح في العملية رقم ${i + 1}")
                list.add(p)
            }
            if (list.map { it.id }.toSet().size != list.size) return Decoded.Bad("بيانات تالفة: معرّفات مكررة")
            if (list.map { it.receiptNo }.toSet().size != list.size) return Decoded.Bad("بيانات تالفة: أرقام إيصالات مكررة")
            if (root.getInt("count") != list.size) return Decoded.Bad("عدد العمليات لا يطابق المسجل في الملف")
            val total = list.sumOf { it.amountPiasters }
            if (root.getLong("totalPiasters") != total) return Decoded.Bad("إجمالي المبالغ لا يطابق المسجل في الملف")
            if (root.getString("checksum") != checksum(list)) return Decoded.Bad("فشل فحص السلامة: الملف عُدّل أو تالف")
            return Decoded.Ok(list, root.optLong("exportedAt", 0L), total)
        } catch (e: JSONException) {
            return Decoded.Bad("الملف تالف أو ليس بصيغة النسخة الاحتياطية الصحيحة")
        } catch (e: Exception) {
            return Decoded.Bad("تعذرت قراءة الملف: ${e.message ?: "خطأ غير معروف"}")
        }
    }
}
