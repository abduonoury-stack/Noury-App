package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tahseel.students.data.Employee
import com.tahseel.students.data.EmployeeAdjustment
import com.tahseel.students.data.EmployeeLoan
import com.tahseel.students.util.Money

@Composable
fun HrLoansAdjustmentsSection(
    employees: List<Employee>,
    loans: List<EmployeeLoan>,
    adjustments: List<EmployeeAdjustment>,
    onAddLoan: () -> Unit,
    onAddAdjustment: () -> Unit
) {
    val activeLoans = loans.filter { it.status == "active" && it.remainingPiasters > 0 }
    val outstanding = activeLoans.sumOf { it.remainingPiasters }
    val bonusTotal = adjustments.filter { it.type == "bonus" }.sumOf { it.amountPiasters }
    val allowanceTotal = adjustments.filter { it.type == "allowance" }.sumOf { it.amountPiasters }
    val penaltyTotal = adjustments.filter { it.type == "penalty" }.sumOf { it.amountPiasters }

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        Button(onClick = onAddLoan, modifier = Modifier.weight(1f)) { Text("تسجيل سلفة") }
        OutlinedButton(onClick = onAddAdjustment, modifier = Modifier.weight(1f)) { Text("مكافأة / بدل / جزاء") }
    }

    Text("ملخص السلف", style = MaterialTheme.typography.titleMedium)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        SummaryCard("السلف النشطة", activeLoans.size.toString(), Modifier.weight(1f))
        SummaryCard("إجمالي المتبقي", Money.format(outstanding), Modifier.weight(1f))
    }
    if (loans.isEmpty()) {
        EmptyHrCard("لا توجد سلف مسجلة حتى الآن")
    } else {
        loans.forEach { loan ->
            val employeeName = employees.firstOrNull { it.id == loan.employeeId }?.fullName ?: "موظف مؤرشف"
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(employeeName, style = MaterialTheme.typography.titleSmall)
                    Text("أصل السلفة: ${Money.format(loan.amountPiasters)}")
                    Text("القسط الشهري: ${Money.format(loan.monthlyInstallmentPiasters)} • بداية الخصم: ${loan.startMonth}")
                    Text("المتبقي: ${Money.format(loan.remainingPiasters)}", color = MaterialTheme.colorScheme.primary)
                    Text("المسدد: ${Money.format((loan.amountPiasters - loan.remainingPiasters).coerceAtLeast(0))}")
                    Text("الحالة: ${if (loan.status == "active") "نشطة" else "مغلقة"}")
                    if (loan.monthlyInstallmentPiasters > loan.amountPiasters) {
                        Text("تنبيه: القسط أكبر من أصل السلفة، راجع البيانات.", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }

    HorizontalDivider()
    Text("ملخص مكافآت وبدلات وجزاءات الشهر", style = MaterialTheme.typography.titleMedium)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        SummaryCard("المكافآت", Money.format(bonusTotal), Modifier.weight(1f))
        SummaryCard("البدلات", Money.format(allowanceTotal), Modifier.weight(1f))
        SummaryCard("الجزاءات", Money.format(penaltyTotal), Modifier.weight(1f))
    }
    if (adjustments.isEmpty()) {
        EmptyHrCard("لا توجد حركات إضافية مسجلة لهذا الشهر")
    } else {
        adjustments.forEach { item ->
            val employeeName = employees.firstOrNull { it.id == item.employeeId }?.fullName ?: "موظف مؤرشف"
            val typeLabel = when (item.type) {
                "bonus" -> "مكافأة"
                "allowance" -> "بدل"
                "penalty" -> "جزاء / خصم"
                else -> "حركة أخرى"
            }
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(employeeName, style = MaterialTheme.typography.titleSmall)
                    Text("$typeLabel • ${Money.format(item.amountPiasters)}", color = MaterialTheme.colorScheme.primary)
                    Text(item.reason, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun SummaryCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall)
            Text(value, style = MaterialTheme.typography.titleSmall)
        }
    }
}

@Composable
private fun EmptyHrCard(message: String) {
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Text(message, modifier = Modifier.padding(14.dp), style = MaterialTheme.typography.bodyMedium)
    }
}
