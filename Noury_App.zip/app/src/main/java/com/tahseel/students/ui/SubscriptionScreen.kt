package com.tahseel.students.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.util.AcademyProfileStore
import com.tahseel.students.util.Money
import com.tahseel.students.vm.SubscriptionViewModel
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscriptionScreen(vm: SubscriptionViewModel, onBack: () -> Unit) {
    val students by vm.students.collectAsStateWithLifecycle()
    val cashAccounts by vm.cashAccounts.collectAsStateWithLifecycle()
    val active = students.filter { it.status == "active" }
    var selectedId by remember { mutableStateOf<Long?>(null) }
    var expanded by remember { mutableStateOf(false) }
    var periodText by remember { mutableStateOf(YearMonth.now().toString()) }
    var paidText by remember { mutableStateOf("") }
    var discountText by remember { mutableStateOf("") }
    var discountNote by remember { mutableStateOf("") }
    var discountReason by remember { mutableStateOf("منحة") }
    var accountId by remember { mutableStateOf("cash") }
    var receiptText by remember { mutableStateOf("") }
    var resultMessage by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val receiptPrefs = remember { context.getSharedPreferences("receipt_profile", android.content.Context.MODE_PRIVATE) }
    val nurseryName by AcademyProfileStore.name.collectAsStateWithLifecycle()
    var nurseryAddress by remember { mutableStateOf(receiptPrefs.getString("address", "") ?: "") }
    var nurseryPhone by remember { mutableStateOf(receiptPrefs.getString("phone", "01555713020") ?: "01555713020") }
    var receiptFile by remember { mutableStateOf<File?>(null) }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null && receiptFile != null) {
            runCatching { context.contentResolver.openOutputStream(uri)?.use { out -> FileInputStream(receiptFile!!).use { it.copyTo(out) } } }
                .onSuccess { resultMessage = "تم حفظ ملف PDF بنجاح." }
                .onFailure { resultMessage = "تعذر حفظ الإيصال: ${it.localizedMessage}" }
        }
    }
    val selected = active.firstOrNull { it.id == selectedId }
    val period = runCatching { YearMonth.parse(periodText.trim()) }.getOrNull()
    var grossDue by remember { mutableStateOf<Long?>(null) }
    val discountPiasters = discountText.toLongOrNull()?.takeIf { it >= 0L }
        ?.let { runCatching { Math.multiplyExact(it, 100L) }.getOrNull() } ?: 0L
    val netDue = grossDue?.takeIf { discountPiasters <= it }?.minus(discountPiasters)
    LaunchedEffect(selected?.id, periodText, selected?.monthlyFeeOverridePiasters) {
        discountText = ""
        discountNote = ""
        discountReason = "منحة"
        grossDue = null
        if (selected != null && period != null) {
            val enrollmentMonth = Instant.ofEpochMilli(selected.enrollmentDate).atZone(ZoneId.systemDefault()).toLocalDate().let { YearMonth.from(it) }
            grossDue = if (period == enrollmentMonth && selected.firstMonthAmountPiasters != null)
                selected.firstMonthAmountPiasters else vm.quoteAmount(selected, period)
        }
    }

    AppScaffold(title = "تحصيل الاشتراك الشهري", onBack = onBack) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("اختر الطفل والشهر. اترك رقم الإيصال فارغًا ليُنشئه البرنامج تلقائيًا.", style = MaterialTheme.typography.bodyMedium)
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                OutlinedTextField(
                    value = selected?.fullName.orEmpty(), onValueChange = {}, readOnly = true,
                    label = { Text("الطفل") }, placeholder = { Text("اختر طالبًا نشطًا") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    active.forEach { student ->
                        DropdownMenuItem(text = { Text(student.fullName) }, onClick = {
                            selectedId = student.id
                            receiptText = ""
                            paidText = ""
                            discountText = ""
                            discountNote = ""
                            discountReason = "منحة"
                            expanded = false
                        })
                    }
                }
            }
            OutlinedTextField(
                value = periodText, onValueChange = { periodText = it },
                label = { Text("شهر الاشتراك") }, placeholder = { Text("YYYY-MM مثل 2026-11") },
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            if (selected != null) {
                Text("قيمة الاشتراك تُحدد تلقائيًا حسب فترة الطالب والسعر الساري في شهر التحصيل.")
                grossDue?.let { Text("قيمة الاشتراك الأصلية: ${Money.format(it)}", style = MaterialTheme.typography.bodyLarge) }
                OutlinedTextField(
                    value = discountText,
                    onValueChange = { discountText = it.filter(Char::isDigit) },
                    label = { Text("خصم الشهر بالجنيه (اختياري)") },
                    placeholder = { Text("مثال: 200") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true
                )
                if (grossDue != null && discountPiasters > grossDue!!) {
                    Text("الخصم لا يمكن أن يتجاوز قيمة الاشتراك الأصلية.", color = MaterialTheme.colorScheme.error)
                }
                if (discountPiasters > 0L) {
                    Text("قيمة الخصم: ${Money.format(discountPiasters)}", color = MaterialTheme.colorScheme.secondary)
                    val isFullExemption = grossDue != null && discountPiasters == grossDue
                    if (isFullExemption) {
                        Text("سبب الخصم: إعفاء كامل", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                    } else {
                        Text("سبب الخصم", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("منحة", "حالة خاصة", "خصم إداري").forEach { reason ->
                                FilterChip(selected = discountReason == reason, onClick = { discountReason = reason }, label = { Text(reason) })
                            }
                        }
                    }
                    OutlinedTextField(
                        value = discountNote, onValueChange = { discountNote = it },
                        label = { Text("تفاصيل إضافية (اختياري)") }, modifier = Modifier.fillMaxWidth(), singleLine = true
                    )
                }
                netDue?.let {
                    if (it == 0L && discountPiasters > 0L) {
                        Text("تمت التسوية بالإعفاء الكامل — لا توجد مبالغ مستحقة أو حركة نقدية.", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    } else {
                        Text("المستحق بعد الخصم: ${Money.format(it)}", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                    }
                }
                if (period != null) {
                    val enrollmentMonth = Instant.ofEpochMilli(selected.enrollmentDate).atZone(ZoneId.systemDefault()).toLocalDate().let { YearMonth.from(it) }
                    if (period == enrollmentMonth && selected.firstMonthAmountPiasters != null) {
                        Text("هذا شهر الالتحاق؛ تم تطبيق المبلغ الجزئي المحدد في ملف الطالب.", color = MaterialTheme.colorScheme.secondary)
                    }
                }
            }
            if (netDue == 0L && discountPiasters > 0L) {
                Text("لن يتم اختيار حساب مالي؛ لأن الإعفاء الكامل لا يتضمن استلام أموال.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
            } else {
                CashAccountDropdown(accounts = cashAccounts, selectedId = accountId, onSelected = { accountId = it }, label = "حساب استلام الاشتراك")
            }
            OutlinedTextField(
                value = if (netDue == 0L && discountPiasters > 0L) "0" else paidText,
                onValueChange = { paidText = it.filter(Char::isDigit) },
                label = { Text(if (netDue == 0L && discountPiasters > 0L) "المبلغ المدفوع (إعفاء كامل)" else "المبلغ المدفوع بالجنيه") },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                readOnly = netDue == 0L && discountPiasters > 0L
            )
            OutlinedTextField(
                value = receiptText, onValueChange = { receiptText = it },
                label = { Text("رقم الإيصال") }, placeholder = { Text("اختياري؛ يُنشأ تلقائيًا إذا تُرك فارغًا") },
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("اسم الأكاديمية على الإيصال", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(nurseryName, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    Text("لتغيير الاسم، استخدم الإعدادات ← بيانات الأكاديمية. سيتغير في جميع الشاشات والإيصالات.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            OutlinedTextField(nurseryAddress, { nurseryAddress = it }, label = { Text("العنوان (اختياري)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(nurseryPhone, { nurseryPhone = it }, label = { Text("رقم الهاتف (اختياري)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Text("يُحصّل صافي المستحق كاملًا مرة واحدة. عند الإعفاء الكامل يُسجل المستحق صفرًا دون تسجيل تحصيل نقدي.", style = MaterialTheme.typography.bodySmall)
            BigButton(
                if (netDue == 0L && discountPiasters > 0L) "تأكيد الإعفاء وإنشاء الإشعار" else "تأكيد التحصيل وإنشاء الإيصال", Icons.Default.ReceiptLong,
                onClick = {
                    val id = selectedId
                    if (id == null) resultMessage = "اختر الطفل أولًا"
                    else if (period == null) resultMessage = "اكتب الشهر بصيغة YYYY-MM"
                    else {
                        saving = true
                        val dueAtSubmission = grossDue
                        val selectedAtSubmission = selected
                        val periodAtSubmission = period
                        val paidTextAtSubmission = if (netDue == 0L && discountPiasters > 0L) "0" else paidText
                        val discountAtSubmission = discountPiasters
                        val discountReasonAtSubmission = if (discountPiasters > 0L && grossDue != null && discountPiasters == grossDue) "إعفاء كامل" else discountReason
                        val discountNoteAtSubmission = if (discountPiasters > 0L) listOf(discountReasonAtSubmission, discountNote.trim()).filter { it.isNotBlank() }.joinToString(" — ") else ""
                        val netDueAtSubmission = netDue
                        val generatedReceipt = receiptText.trim().ifBlank {
                            "SUB-${periodAtSubmission.toString().replace("-", "")}-${id}-${System.currentTimeMillis()}"
                        }
                        vm.collect(id, periodAtSubmission, generatedReceipt, paidTextAtSubmission, discountText, discountNoteAtSubmission, accountId) { message ->
                            saving = false
                            resultMessage = message
                            if ((message.startsWith("تم التحصيل") || message.startsWith("تم تسجيل الإعفاء")) && selectedAtSubmission != null && periodAtSubmission != null && dueAtSubmission != null && netDueAtSubmission != null) {
                                val paidPiasters = netDueAtSubmission
                                val issuedNo = Regex("رقم (?:الإيصال|الإشعار): ([^\\n]+)").find(message)?.groupValues?.get(1)?.trim()
                                    ?: receiptText.trim().ifBlank { "receipt-${System.currentTimeMillis()}" }
                                receiptPrefs.edit().putString("address", nurseryAddress).putString("phone", nurseryPhone).apply()
                                receiptFile = runCatching {
                                    com.tahseel.students.util.ReceiptPdf.create(context, nurseryName, nurseryAddress, nurseryPhone,
                                        selectedAtSubmission.fullName, periodAtSubmission.toString(), issuedNo, netDueAtSubmission, paidPiasters,
                                        guardianName = selectedAtSubmission.motherName.ifBlank { selectedAtSubmission.fatherName },
                                        className = selectedAtSubmission.className,
                                        discountPiasters = discountAtSubmission,
                                        discountNote = discountNoteAtSubmission)
                                }.getOrNull()
                                if (receiptFile == null) resultMessage = "تم تسجيل العملية، لكن تعذر إنشاء ملف PDF. يمكنك إعادة المحاولة من سجل الطالب."
                                paidText = ""
                                discountText = ""
                                discountNote = ""
                                discountReason = "منحة"
                                receiptText = ""
                            }
                        }
                    }
                }, enabled = !saving && active.isNotEmpty()
            )
            if (receiptFile != null) {
                Text("تم إنشاء إيصال PDF للعملية الأخيرة.", color = MaterialTheme.colorScheme.primary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { saveLauncher.launch("إيصال-${System.currentTimeMillis()}.pdf") }, modifier = Modifier.weight(1f)) { Text("حفظ PDF") }
                    Button(onClick = {
                        runCatching {
                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", receiptFile!!)
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(send, "مشاركة إيصال التحصيل"))
                        }.onFailure { resultMessage = "تعذرت مشاركة الإيصال: ${it.localizedMessage}" }
                    }, modifier = Modifier.weight(1f)) { Text("مشاركة") }
                }
            }
            if (active.isEmpty()) Text("لا يوجد طلاب نشطون. أضف ملف طالب أولًا.")
        }
    }
    resultMessage?.let { msg ->
        AlertDialog(onDismissRequest = { resultMessage = null }, confirmButton = {
            TextButton(onClick = { resultMessage = null }) { Text("حسنًا") }
        }, text = { Text(msg) })
    }
}
