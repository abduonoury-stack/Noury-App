package com.tahseel.students.util

import android.content.Context
import android.net.Uri
import android.util.Xml
import com.tahseel.students.data.Student
import org.xmlpull.v1.XmlPullParser
import java.time.LocalDate
import java.time.ZoneId
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object StudentExcel {
    val headers = listOf("اسم الطفل رباعي", "تاريخ الميلاد YYYY-MM-DD", "اسم الأم", "واتساب الأم", "اسم الأب", "هاتف الأب", "العنوان", "تاريخ الالتحاق YYYY-MM-DD", "الفترة: صباحية أو مسائية", "اسم الفصل", "ملاحظات")
    fun writeTemplate(context: Context, uri: Uri) {
        context.contentResolver.openOutputStream(uri)?.use { raw -> ZipOutputStream(raw).use { z ->
            fun entry(name:String, data:String) { z.putNextEntry(ZipEntry(name)); z.write(data.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            entry("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""")
            entry("_rels/.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            entry("xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="الطلاب" sheetId="1" r:id="rId1"/></sheets></workbook>""")
            entry("xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""")
            val cells = mutableListOf<String>()
            for ((i, h) in headers.withIndex()) {
                val col = ('A'.code + i).toChar()
                val esc = h.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                cells.add("<c r=\"${col}1\" t=\"inlineStr\"><is><t>${esc}</t></is></c>")
            }
            entry("xl/worksheets/sheet1.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData><row r=\"1\">"+cells.joinToString("")+"</row></sheetData></worksheet>")
        }} ?: error("تعذر إنشاء ملف Excel")
    }
    fun read(context: Context, uri: Uri): List<List<String>> {
        val entries= mutableMapOf<String,ByteArray>()
        context.contentResolver.openInputStream(uri)?.use { input -> ZipInputStream(input).use { z -> while(true) { val e=z.nextEntry ?: break; if(!e.isDirectory && (e.name=="xl/worksheets/sheet1.xml" || e.name=="xl/sharedStrings.xml")) entries[e.name]=z.readBytes(); z.closeEntry() } } } ?: error("تعذر فتح الملف")
        val shared=entries["xl/sharedStrings.xml"]?.let { parseShared(it) } ?: emptyList()
        val xml=entries["xl/worksheets/sheet1.xml"] ?: error("الملف لا يحتوي على ورقة بيانات")
        val parser=Xml.newPullParser(); parser.setInput(xml.inputStream(),"UTF-8")
        val rows= mutableListOf<List<String>>(); var row:MutableList<String>?=null; var cellType=""; var value=""; var inV=false; var inT=false; var cellIndex=0
        while(parser.eventType!=XmlPullParser.END_DOCUMENT) {
            when(parser.eventType) {
                XmlPullParser.START_TAG -> when(parser.name) {
                    "row" -> { row= mutableListOf(); cellIndex=0 }
                    "c" -> { cellType=parser.getAttributeValue(null,"t") ?: ""; value=""; cellIndex=columnIndex(parser.getAttributeValue(null,"r") ?: "") }
                    "v" -> inV=true
                    "t" -> inT=true
                }
                XmlPullParser.TEXT -> if(inV || inT) value+=parser.text
                XmlPullParser.END_TAG -> when(parser.name) {
                    "v" -> inV=false
                    "t" -> inT=false
                    "c" -> { val v=if(cellType=="s") shared.getOrNull(value.toIntOrNull() ?: -1).orEmpty() else value; while((row?.size ?: 0)<=cellIndex) row?.add(""); row?.set(cellIndex,v) }
                    "row" -> { rows.add(row ?: mutableListOf()); row=null }
                }
            }; parser.next()
        }
        return rows.drop(1).filter { it.any(String::isNotBlank) }
    }
    private fun parseShared(bytes:ByteArray):List<String> { val p=Xml.newPullParser(); p.setInput(bytes.inputStream(),"UTF-8"); val out= mutableListOf<String>(); var inSi=false; var b=StringBuilder(); while(p.eventType!=XmlPullParser.END_DOCUMENT){ if(p.eventType==XmlPullParser.START_TAG && p.name=="si"){inSi=true;b=StringBuilder()} else if(p.eventType==XmlPullParser.TEXT && inSi)b.append(p.text) else if(p.eventType==XmlPullParser.END_TAG && p.name=="si"){out.add(b.toString());inSi=false};p.next() };return out }
    private fun columnIndex(ref:String):Int { val letters=ref.takeWhile { it.isLetter() }.uppercase(); var n=0; letters.forEach { n=n*26+(it-'A'+1) }; return (n-1).coerceAtLeast(0) }
    fun toStudents(
        rows: List<List<String>>,
        knownClasses: Set<String>,
        existing: List<Student>
    ): Pair<List<Student>, List<String>> {
        val result = mutableListOf<Student>()
        val errors = mutableListOf<String>()
        val names = existing.map { norm(it.fullName) }.toMutableSet()
        val phones = existing.map { norm(it.motherWhatsapp) }
            .filter { it.isNotBlank() }.toMutableSet()
        val today = LocalDate.now()
        val zone = ZoneId.systemDefault()

        rows.forEachIndexed { index, row ->
            val line = index + 2
            fun value(column: Int): String = row.getOrNull(column)?.trim().orEmpty()

            val name = value(0)
            if (name.isBlank()) {
                errors.add("الصف $line: اسم الطفل فارغ")
                return@forEachIndexed
            }

            val birthText = value(1)
            val birthDate = if (birthText.isBlank()) null
                else runCatching { LocalDate.parse(birthText) }.getOrNull()
            if (birthText.isNotBlank() && (birthDate == null || birthDate.isAfter(today))) {
                errors.add("الصف $line: تاريخ الميلاد غير صحيح")
                return@forEachIndexed
            }

            val enrollmentDate = runCatching { LocalDate.parse(value(7)) }.getOrNull()
            if (enrollmentDate == null) {
                errors.add("الصف $line: تاريخ الالتحاق مطلوب بصيغة YYYY-MM-DD")
                return@forEachIndexed
            }

            val endHourText = value(8).ifBlank { "صباحية" }
            if (endHourText !in setOf("صباحية", "صباحي", "مسائية", "مسائي", "3", "4", "15", "16")) {
                errors.add("الصف $line: الفترة يجب أن تكون صباحية أو مسائية")
                return@forEachIndexed
            }

            val classroom = value(9)
            if (classroom.isNotBlank() && classroom !in knownClasses) {
                errors.add("الصف $line: الفصل '$classroom' غير مسجل")
                return@forEachIndexed
            }

            val phone = value(3)
            if (norm(name) in names || (phone.isNotBlank() && norm(phone) in phones)) {
                errors.add("الصف $line: طالب مكرر بالاسم أو رقم واتساب الأم")
                return@forEachIndexed
            }

            names.add(norm(name))
            if (phone.isNotBlank()) phones.add(norm(phone))

            result.add(
                Student(
                    fullName = name,
                    birthDate = birthDate?.atStartOfDay(zone)?.toInstant()?.toEpochMilli(),
                    enrollmentDate = enrollmentDate.atStartOfDay(zone).toInstant().toEpochMilli(),
                    attendanceEndHour = if (endHourText in setOf("مسائية", "مسائي", "4", "16")) 16 else 15,
                    motherName = value(2),
                    motherWhatsapp = phone,
                    fatherName = value(4),
                    fatherPhone = value(5),
                    address = value(6),
                    className = classroom,
                    notes = value(10),
                    status = "active"
                )
            )
        }
        return result to errors
    }
    private fun norm(s:String)=s.filter(Char::isLetterOrDigit).lowercase()
}
