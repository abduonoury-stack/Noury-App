package com.tahseel.students.util

import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

object TimeUtil {
    private val zone: ZoneId get() = ZoneId.systemDefault()
    private val MONTHS = arrayOf(
        "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
        "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
    )

    fun startOf(d: LocalDate): Long = d.atStartOfDay(zone).toInstant().toEpochMilli()
    fun startOfMonth(m: YearMonth): Long = startOf(m.atDay(1))
    fun startOfNextMonth(m: YearMonth): Long = startOf(m.plusMonths(1).atDay(1))

    fun fmt(ms: Long): String =
        DateTimeFormatter.ofPattern("yyyy/MM/dd  HH:mm", Locale.US).withZone(zone).format(Instant.ofEpochMilli(ms))

    fun csvTime(ms: Long): String =
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.US).withZone(zone).format(Instant.ofEpochMilli(ms))

    fun fileStamp(ms: Long = System.currentTimeMillis()): String =
        DateTimeFormatter.ofPattern("yyyyMMdd-HHmm", Locale.US).withZone(zone).format(Instant.ofEpochMilli(ms))

    fun fmtDate(d: LocalDate): String = d.format(DateTimeFormatter.ofPattern("yyyy/MM/dd", Locale.US))
    fun fmtMonth(m: YearMonth): String = "${MONTHS[m.monthValue - 1]} ${m.year}"
}
