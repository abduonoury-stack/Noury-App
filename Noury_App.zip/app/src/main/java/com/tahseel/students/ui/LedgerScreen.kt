package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.util.Money
import com.tahseel.students.util.TimeUtil
import com.tahseel.students.vm.LedgerViewModel
import com.tahseel.students.vm.Period

@Composable
fun LedgerScreen(vm: LedgerViewModel, onBack: () -> Unit, onOpen: (Long) -> Unit, onStudentProfile: (Long) -> Unit) {
    val s by vm.state.collectAsStateWithLifecycle()
    val f by vm.filter.collectAsStateWithLifecycle()
    var showPicker by remember { mutableStateOf(false) }

    AppScaffold(
        title = "سجل التحصيل", onBack = onBack,
        bottomBar = {
            Surface(color = MaterialTheme.colorScheme.primary, shadowElevation = 8.dp) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("إجمالي التحصيل", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.bodyMedium)
                        Text(Money.format(s.total), color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.titleLarge)
                    }
                    Text("${s.rows.size} عملية", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 12.dp)) {
            OutlinedTextField(
                value = f.query, onValueChange = vm::setQuery, singleLine = true,
                label = { Text("بحث بالاسم أو رقم الإيصال") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = f.period == Period.ALL, onClick = { vm.setPeriod(Period.ALL) }, label = { Text("الكل") })
                FilterChip(selected = f.period == Period.DAY, onClick = { vm.setPeriod(Period.DAY) }, label = { Text("يوم") })
                FilterChip(selected = f.period == Period.MONTH, onClick = { vm.setPeriod(Period.MONTH) }, label = { Text("شهر") })
            }
            if (f.period == Period.DAY || f.period == Period.MONTH) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    // في RTL: السهم الأيمن = السابق، الأيسر = التالي
                    IconButton(onClick = { if (f.period == Period.DAY) vm.shiftDay(-1) else vm.shiftMonth(-1) }) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "السابق")
                    }
                    Text(
                        if (f.period == Period.DAY) TimeUtil.fmtDate(f.day) else TimeUtil.fmtMonth(f.month),
                        modifier = Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.titleMedium
                    )
                    if (f.period == Period.DAY) IconButton(onClick = { showPicker = true }) { Icon(Icons.Default.DateRange, "اختيار تاريخ") }
                    IconButton(onClick = { if (f.period == Period.DAY) vm.shiftDay(1) else vm.shiftMonth(1) }) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "التالي")
                    }
                }
            }
            if (s.rows.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(if (s.allCount == 0) "لا توجد عمليات مسجلة بعد" else "لا توجد نتائج مطابقة", style = MaterialTheme.typography.bodyLarge)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                    items(s.rows, key = { it.payment.id }) { r -> PaymentRow(r.payment, r.serial, onClick = { onOpen(r.payment.id) }, onStudentClick = r.payment.studentId?.let { id -> { onStudentProfile(id) } }) }
                }
            }
        }
    }
    if (showPicker) DatePickerDialogSimple(f.day, onPick = vm::setDay, onDismiss = { showPicker = false })
}
