package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tahseel.students.data.Employee
import com.tahseel.students.util.Money

@Composable
internal fun HrEmployeesSection(
    employees: List<Employee>,
    onAdd: () -> Unit,
    onEdit: (Employee) -> Unit,
    onLeave: (Long) -> Unit,
    onLoan: (Long) -> Unit,
    onArchive: (Employee) -> Unit,
    onToggleStatus: (Employee) -> Unit
) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f)) {
            Text("ملفات العاملين", style = MaterialTheme.typography.titleMedium)
            Text(
                "إدارة بيانات الموظفين وحالة العمل",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Button(onClick = onAdd) { Text("+ إضافة موظف") }
    }

    val activeEmployees = employees.filter { it.status != "deleted" }
    if (activeEmployees.isEmpty()) {
        Card { Text("لا يوجد موظفون مسجلون. ابدأ بإضافة أول ملف موظف.", Modifier.padding(18.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
    activeEmployees.forEach { employee ->
        Card(shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth()) {
            Column(
                Modifier.fillMaxWidth().padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(employee.fullName, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "${employee.employeeCode}  •  ${employee.jobTitle}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    AssistChip(
                        onClick = { onToggleStatus(employee) },
                        label = { Text(if (employee.status == "active") "نشط" else "موقوف") }
                    )
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Text("الموبايل: ${employee.phone.ifBlank { "غير مسجل" }}", style = MaterialTheme.typography.bodyMedium)
                Text("المرتب الأساسي: ${Money.format(employee.baseSalaryPiasters)}", style = MaterialTheme.typography.bodyMedium)
                Text(
                    "تاريخ التعيين: ${employee.hireDate}  •  ${employee.contractType}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    TextButton(onClick = { onEdit(employee) }) { Text("تعديل") }
                    TextButton(onClick = { onLeave(employee.id) }) { Text("إجازة") }
                    TextButton(onClick = { onLoan(employee.id) }) { Text("سلفة") }
                    TextButton(onClick = { onArchive(employee) }) { Text("أرشفة") }
                }
            }
        }
    }
}
