package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tahseel.students.data.Employee
import com.tahseel.students.data.EmployeeLeave
import com.tahseel.students.data.EmployeePayroll
import com.tahseel.students.data.EmployeePayrollPayment
import com.tahseel.students.data.EmployeeLoan
import com.tahseel.students.util.Money
import java.time.YearMonth

@Composable
internal fun HrReportsSection(
    month: YearMonth,
    employees: List<Employee>,
    absenceCount: Int,
    leaves: List<EmployeeLeave>,
    payroll: List<EmployeePayroll>,
    payrollPayments: List<EmployeePayrollPayment>,
    loans: List<EmployeeLoan>,
    onMonthChange: (YearMonth) -> Unit
) {
    MonthSelector(month, onMonthChange)
    Text("تقرير الموارد البشرية", style = MaterialTheme.typography.titleLarge)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StatCard("العاملون النشطون", employees.count { it.status == "active" }.toString(), Modifier.weight(1f))
        StatCard("العاملون الموقوفون", employees.count { it.status == "inactive" }.toString(), Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StatCard("غياب الشهر", absenceCount.toString(), Modifier.weight(1f))
        StatCard("طلبات الإجازة", leaves.count { it.status == "pending" }.toString(), Modifier.weight(1f))
    }
    val activePayments = payrollPayments.filter { it.status == "active" }
    val voidedPayments = payrollPayments.filter { it.status == "voided" }
    val reversedPayments = payrollPayments.filter { it.status == "reversed" }
    val paidTotal = activePayments.sumOf { it.amountPiasters.coerceAtLeast(0L) }
    val netTotal = payroll.sumOf { it.netPiasters.coerceAtLeast(0L) }
    val remainingTotal = (netTotal - paidTotal).coerceAtLeast(0L)
    val inconsistentPayroll = payroll.filter { row ->
        row.paidPiasters != activePayments.filter { it.payrollId == row.id }.sumOf { it.amountPiasters.coerceAtLeast(0L) }
    }
    StatCard("صافي المرتبات المستحقة", Money.format(netTotal), Modifier.fillMaxWidth())
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StatCard("المدفوع المحتسب", Money.format(paidTotal), Modifier.weight(1f))
        StatCard("المتبقي للصرف", Money.format(remainingTotal), Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StatCard("دفعات سارية", activePayments.size.toString(), Modifier.weight(1f))
        StatCard("ملغاة قبل الصرف", voidedPayments.size.toString(), Modifier.weight(1f))
    }
    if (reversedPayments.isNotEmpty()) {
        StatCard("دفعات معكوسة بعد الصرف", reversedPayments.size.toString(), Modifier.fillMaxWidth())
        Text("الدفعات المعكوسة مستبعدة من صافي مستحق المرتب، لكنها تظل ظاهرة كخروج نقدي تاريخي، ويظهر ما تم تحصيله فعليًا كحركة واردة مستقلة.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    if (inconsistentPayroll.isNotEmpty()) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("تنبيه مراجعة حسابية", color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.titleSmall)
                Text("يوجد ${inconsistentPayroll.size} كشف مرتب لا يتطابق فيه إجمالي المدفوع المسجل مع مجموع حركات الصرف السارية. راجع سجل الدفعات قبل اعتماد التقرير.", color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
    Text("ملخص المرتبات حسب الموظف", style = MaterialTheme.typography.titleMedium)
    if (payroll.isEmpty()) Text("لا توجد كشوف مرتبات لهذا الشهر.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    payroll.forEach { row ->
        val employee = employees.firstOrNull { it.id == row.employeeId }
        val paid = activePayments.filter { it.payrollId == row.id }.sumOf { it.amountPiasters.coerceAtLeast(0L) }
        Card {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(employee?.fullName ?: "موظف غير معروف (#${row.employeeId})", style = MaterialTheme.typography.titleSmall)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("الصافي: ${Money.format(row.netPiasters)}")
                    Text("المدفوع: ${Money.format(paid)}", color = MaterialTheme.colorScheme.primary)
                }
                Text("المتبقي: ${Money.format((row.netPiasters - paid).coerceAtLeast(0L))}", color = if (row.netPiasters > paid) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
    if (payrollPayments.isNotEmpty()) {
        Text("سجل حركات صرف المرتبات", style = MaterialTheme.typography.titleMedium)
        payrollPayments.forEach { payment ->
            val row = payroll.firstOrNull { it.id == payment.payrollId }
            val employee = row?.let { target -> employees.firstOrNull { it.id == target.employeeId } }
            Card {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(employee?.fullName ?: "موظف غير معروف", style = MaterialTheme.typography.titleSmall)
                        Text(Money.format(payment.amountPiasters), style = MaterialTheme.typography.titleSmall)
                    }
                    Text("${payment.paymentDate} • ${payment.paymentMethod}", style = MaterialTheme.typography.bodySmall)
                    Text(when (payment.status) { "active" -> "حركة سارية"; "reversed" -> "عكس بعد صرف فعلي"; else -> "ملغاة قبل الصرف" }, color = if (payment.status == "active") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelMedium)
                    if (payment.status != "active") {
                        Text("سبب الإلغاء: ${payment.voidReason.ifBlank { "غير مسجل" }}", style = MaterialTheme.typography.bodySmall)
                        payment.correctedByPaymentId?.let { Text("تم استبدالها بالحركة رقم $it", style = MaterialTheme.typography.bodySmall) }
                    }
                    payment.correctionOfPaymentId?.let { Text("حركة تصحيح للأصل رقم $it", style = MaterialTheme.typography.bodySmall) }
                    if (payment.note.isNotBlank()) Text(payment.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
    StatCard(
        "إجمالي السلف المتبقية",
        Money.format(loans.filter { it.status == "active" }.sumOf { it.remainingPiasters }),
        Modifier.fillMaxWidth()
    )
    Text("يمكن مراجعة التفاصيل من تبويبات العاملين والحضور والإجازات والمرتبات والسلف.", style = MaterialTheme.typography.bodySmall)
}
