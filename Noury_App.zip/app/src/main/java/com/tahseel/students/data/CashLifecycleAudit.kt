package com.tahseel.students.data

import kotlin.math.abs

/** Read-only financial integrity review. It never changes stored balances or transactions. */
data class CashAuditIssue(
    val category: String,
    val reference: String,
    val message: String
)

data class CashLifecycleAudit(
    val refundCreditsTotal: Long = 0L,
    val refundTransactionsTotal: Long = 0L,
    val exitRefundsTotal: Long = 0L,
    val payrollNetTotal: Long = 0L,
    val payrollPaidTotal: Long = 0L,
    val payrollReversedTotal: Long = 0L,
    val payrollRecoveredTotal: Long = 0L,
    val payrollReceivableTotal: Long = 0L,
    val loanIssuedTotal: Long = 0L,
    val loanRemainingTotal: Long = 0L,
    val issues: List<CashAuditIssue> = emptyList(),
    val isLoaded: Boolean = false
) {
    val isConsistent: Boolean get() = isLoaded && issues.isEmpty()
}

fun auditCashLifecycle(
    refundCredits: List<RefundCredit>,
    refundTransactions: List<RefundTransaction>,
    settlements: List<StudentExitSettlement>,
    settlementEvents: List<StudentExitSettlementEvent>,
    payrollRows: List<EmployeePayroll>,
    payrollPayments: List<EmployeePayrollPayment>,
    loans: List<EmployeeLoan>,
    expenses: List<Expense>,
    payrollReversals: List<EmployeePayrollReversal> = emptyList(),
    payrollRecoveries: List<EmployeePayrollRecoveryTransaction> = emptyList()
): CashLifecycleAudit {
    val issues = mutableListOf<CashAuditIssue>()

    refundCredits.forEach { credit ->
        val refunded = refundTransactions.asSequence()
            .filter { it.refundCreditId == credit.id }
            .sumOf { it.amountPiasters.coerceAtLeast(0L) }
        val expectedRemaining = if (credit.approvalStatus == "cancelled") 0L else (credit.originalAmountPiasters - refunded).coerceAtLeast(0L)
        if (credit.originalAmountPiasters < 0L || credit.remainingAmountPiasters < 0L ||
            credit.remainingAmountPiasters > credit.originalAmountPiasters || refunded > credit.originalAmountPiasters ||
            credit.remainingAmountPiasters != expectedRemaining) {
            issues += CashAuditIssue(
                "استرداد", "رصيد #${credit.id}",
                "الرصيد الأصلي ${credit.originalAmountPiasters} قرشًا، والمتبقي المسجل ${credit.remainingAmountPiasters}، ومجموع حركات الرد $refunded؛ المتوقع للمتبقي $expectedRemaining."
            )
        }
    }
    refundTransactions.filter { it.amountPiasters <= 0L }.forEach {
        issues += CashAuditIssue("استرداد", "حركة #${it.id}", "قيمة حركة الاسترداد يجب أن تكون أكبر من صفر.")
    }
    refundCredits.filter { it.sourceType == "manual_payment" && (it.reason.isBlank() || it.documentReference.isBlank()) }.forEach {
        issues += CashAuditIssue("استرداد يدوي", "رصيد #${it.id}", "الاسترداد اليدوي لا يحتوي على سبب أو مرجع مستند موثق.")
    }
    refundCredits.filter { it.remainingAmountPiasters > 0L && it.approvalStatus != "approved" }.forEach {
        issues += CashAuditIssue("اعتماد استرداد", "رصيد #${it.id}", "يوجد رصيد قابل للصرف لكنه غير معتمد.")
    }

    settlements.forEach { settlement ->
        val paidEvents = settlementEvents.asSequence()
            .filter { it.settlementId == settlement.id && it.eventType == "refund_paid" }
            .sumOf { it.amountPiasters.coerceAtLeast(0L) }
        if (settlement.refundedAmountPiasters < 0L || settlement.refundedAmountPiasters > settlement.refundAmountPiasters ||
            paidEvents != settlement.refundedAmountPiasters) {
            issues += CashAuditIssue(
                "تسوية انسحاب", "تسوية #${settlement.id}",
                "قيمة الصرف المسجلة ${settlement.refundedAmountPiasters} قرشًا، ومجموع أحداث الصرف $paidEvents، وقيمة الاسترداد الحالية ${settlement.refundAmountPiasters}."
            )
        }
    }

    val activePayrollPayments = payrollPayments.filter { it.status == "active" }
    payrollRows.forEach { row ->
        val paidFromTransactions = activePayrollPayments.asSequence()
            .filter { it.payrollId == row.id }
            .sumOf { it.amountPiasters.coerceAtLeast(0L) }
        if (row.netPiasters < 0L || row.paidPiasters < 0L || row.paidPiasters > row.netPiasters ||
            paidFromTransactions != row.paidPiasters) {
            issues += CashAuditIssue(
                "مرتبات", "كشف #${row.id} (${row.monthKey})",
                "صافي المستحق ${row.netPiasters} قرشًا، والمدفوع في الكشف ${row.paidPiasters}، ومجموع الحركات السارية $paidFromTransactions."
            )
        }
    }
    activePayrollPayments.filter { it.amountPiasters <= 0L }.forEach {
        issues += CashAuditIssue("مرتبات", "حركة #${it.id}", "قيمة حركة الصرف السارية يجب أن تكون أكبر من صفر.")
    }

    val payrollPaymentsById = payrollPayments.associateBy { it.id }
    payrollReversals.forEach { reversal ->
        val original = payrollPaymentsById[reversal.originalPaymentId]
        val recovered = payrollRecoveries.filter { it.reversalId == reversal.id }.sumOf { it.amountPiasters.coerceAtLeast(0L) }
        if (original == null || original.status != "reversed" || reversal.amountPiasters <= 0L ||
            reversal.amountPiasters != original.amountPiasters || recovered > reversal.amountPiasters || reversal.reason.isBlank()) {
            issues += CashAuditIssue("عكس المرتبات", "عكس #${reversal.id}", "سجل العكس لا يتطابق مع الدفعة الأصلية أو تجاوز التحصيل الفعلي قيمة العكس.")
        }
    }
    payrollRecoveries.filter { recovery ->
        recovery.amountPiasters <= 0L || payrollReversals.none { it.id == recovery.reversalId } || recovery.accountId.isBlank()
    }.forEach { recovery ->
        issues += CashAuditIssue("تحصيل مديونية مرتب", "تحصيل #${recovery.id}", "حركة التحصيل غير مرتبطة بعكس صحيح أو قيمتها غير موجبة أو حسابها غير محدد.")
    }
    payrollPayments.filter { it.status == "reversed" && payrollReversals.none { reversal -> reversal.originalPaymentId == it.id } }.forEach { payment ->
        issues += CashAuditIssue("عكس المرتبات", "دفعة #${payment.id}", "حالة الدفعة معكوسة لكن لا يوجد سجل عكس مرتبط بها.")
    }
    val payrollReversedTotal = payrollReversals.sumOf { it.amountPiasters.coerceAtLeast(0L) }
    val payrollRecoveredTotal = payrollRecoveries.sumOf { it.amountPiasters.coerceAtLeast(0L) }
    val payrollReceivableTotal = (payrollReversedTotal - payrollRecoveredTotal).coerceAtLeast(0L)

    val loanIssued = loans.sumOf { it.amountPiasters.coerceAtLeast(0L) }
    val loanRemaining = loans.sumOf { it.remainingPiasters.coerceAtLeast(0L) }
    val loanDeductions = payrollRows.sumOf { it.loanDeductionPiasters.coerceAtLeast(0L) }
    if (loans.any { it.amountPiasters < 0L || it.remainingPiasters < 0L || it.remainingPiasters > it.amountPiasters }) {
        issues += CashAuditIssue("سلف الموظفين", "أرصدة السلف", "يوجد رصيد سلفة سالب أو أكبر من قيمة السلفة الأصلية.")
    }
    if (loanIssued - loanRemaining != loanDeductions) {
        issues += CashAuditIssue(
            "سلف الموظفين", "مطابقة إجمالية",
            "إجمالي السلف ${loanIssued} قرشًا، والمتبقي ${loanRemaining}، والمخصوم في كشوف المرتبات ${loanDeductions}. الفرق يحتاج مراجعة."
        )
    }

    val payrollByMonth = payrollRows.groupBy { it.monthKey }
    val syncedExpensesByMonth = expenses.filter { it.note.startsWith("HR_SYNC:") }.groupBy { expense ->
        expense.monthKey.takeIf { it.isNotBlank() } ?: runCatching {
            java.time.Instant.ofEpochMilli(expense.spentAt).atZone(java.time.ZoneId.systemDefault()).toLocalDate().toString().take(7)
        }.getOrDefault("")
    }
    (payrollByMonth.keys + syncedExpensesByMonth.keys).filter { it.isNotBlank() }.forEach { month ->
        val payroll = payrollByMonth[month].orEmpty()
        val synced = syncedExpensesByMonth[month].orEmpty()
        val expectedNet = payroll.sumOf { it.netPiasters.coerceAtLeast(0L) }
        val expectedPaid = payroll.sumOf { it.paidPiasters.coerceAtLeast(0L) }
        val actualNet = synced.sumOf { it.amountPiasters.coerceAtLeast(0L) }
        val actualPaid = synced.sumOf { it.paidAmountPiasters.coerceAtLeast(0L) }
        if (synced.size > 1 || (payroll.isNotEmpty() && synced.size != 1) ||
            (payroll.isEmpty() && synced.isNotEmpty()) ||
            (synced.isNotEmpty() && (expectedNet != actualNet || expectedPaid != actualPaid))) {
            issues += CashAuditIssue(
                "مزامنة المرتبات", month,
                "كشف HR: مستحق $expectedNet ومدفوع $expectedPaid قرشًا؛ بند HR_SYNC: عدد ${synced.size}، مستحق $actualNet ومدفوع $actualPaid."
            )
        }
    }

    // A same-student, same-amount refund recorded in both ledgers is a review warning,
    // not an automatic deletion or a definitive duplicate determination.
    val creditsById = refundCredits.associateBy { it.id }
    val settlementsById = settlements.associateBy { it.id }
    refundTransactions.forEach { tx ->
        val studentId = creditsById[tx.refundCreditId]?.studentId ?: return@forEach
        val linkedExitCredit = creditsById[tx.refundCreditId]
        val duplicateCandidate = settlementEvents.firstOrNull { event ->
            if (event.eventType != "refund_paid" || event.amountPiasters != tx.amountPiasters) return@firstOrNull false
            val settlement = settlementsById[event.settlementId] ?: return@firstOrNull false
            if (settlement.studentId != studentId) return@firstOrNull false
            if (linkedExitCredit?.sourceType == "exit_settlement" && linkedExitCredit.sourceId == event.settlementId) return@firstOrNull false
            abs(settlementEventsTimestampDistance(event.createdAt, tx.refundedAt)) <= 24L * 60L * 60L * 1000L
        }
        if (duplicateCandidate != null) {
            issues += CashAuditIssue(
                "احتمال تكرار استرداد", "حركة #${tx.id} / حدث #${duplicateCandidate.id}",
                "يوجد رد بنفس القيمة للطالب نفسه في سجل رصيد الاسترداد وتسوية الانسحاب خلال 24 ساعة. راجع المستندات قبل جمع الحركتين نقديًا."
            )
        }
    }

    return CashLifecycleAudit(
        refundCreditsTotal = refundCredits.sumOf { it.originalAmountPiasters.coerceAtLeast(0L) },
        refundTransactionsTotal = refundTransactions.sumOf { it.amountPiasters.coerceAtLeast(0L) },
        exitRefundsTotal = settlements.sumOf { it.refundedAmountPiasters.coerceAtLeast(0L) },
        payrollNetTotal = payrollRows.sumOf { it.netPiasters.coerceAtLeast(0L) },
        payrollPaidTotal = payrollRows.sumOf { it.paidPiasters.coerceAtLeast(0L) },
        payrollReversedTotal = payrollReversedTotal,
        payrollRecoveredTotal = payrollRecoveredTotal,
        payrollReceivableTotal = payrollReceivableTotal,
        loanIssuedTotal = loanIssued,
        loanRemainingTotal = loanRemaining,
        issues = issues,
        isLoaded = true
    )
}

private fun settlementEventsTimestampDistance(a: Long, b: Long): Long = if (a >= b) a - b else b - a
