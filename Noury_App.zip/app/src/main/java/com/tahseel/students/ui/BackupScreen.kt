package com.tahseel.students.ui

import android.content.ContentResolver
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.util.TimeUtil
import com.tahseel.students.vm.BackupViewModel

@Composable
fun BackupScreen(vm: BackupViewModel, onBack: () -> Unit) {
    val s by vm.state.collectAsStateWithLifecycle()
    val cr: ContentResolver = LocalContext.current.contentResolver

    val createLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.createBackup(uri, cr)
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.prepareRestore(uri, cr)
    }
    val csvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) vm.exportCsv(uri, cr)
    }

    AppScaffold("النسخ الاحتياطي", onBack) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("بياناتك محفوظة على هذا الهاتف فقط. أنشئ نسخة احتياطية بانتظام واحفظها في مكان آمن (ذاكرة الهاتف أو بطاقة SD أو أي مجلد تختاره).", style = MaterialTheme.typography.bodyMedium)
            BigButton("إنشاء نسخة احتياطية", Icons.Default.Backup, { createLauncher.launch("tahseel-backup-${TimeUtil.fileStamp()}.json") }, enabled = !s.busy)
            BigButton("استعادة نسخة سابقة", Icons.Default.Restore, { restoreLauncher.launch(arrayOf("*/*")) }, primary = false, enabled = !s.busy)
            if (s.hasSnapshot) BigButton("الرجوع إلى نسخة الأمان الأخيرة", Icons.Default.Restore, { vm.prepareRestoreFromSnapshot() }, primary = false, enabled = !s.busy)
            BigButton("تصدير سجل التحصيل CSV (Excel)", Icons.Default.Share, { csvLauncher.launch("tahseel-records-${TimeUtil.fileStamp()}.csv") }, primary = false, enabled = !s.busy)
            if (s.busy) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { CircularProgressIndicator() }
            s.message?.let {
                Card(colors = CardDefaults.cardColors(containerColor = if (s.isError) LdaPalette.ErrorContainer else LdaPalette.SuccessContainer)) {
                    Text((if (s.isError) "✖ " else "✔ ") + it, Modifier.padding(16.dp), style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }

    s.pending?.let { p ->
        AlertDialog(
            onDismissRequest = vm::cancelRestore,
            title = { Text("تأكيد الاستعادة") },
            text = {
                Text(
                    "تم فحص النسخة الشاملة بنجاح:\n• عدد السجلات في جميع الجداول: ${p.rowCount}" +
                        (if (p.exportedAt > 0) "\n• تاريخ النسخة: ${TimeUtil.fmt(p.exportedAt)}" else "") +
                        "\n\nسيتم استبدال جميع بيانات الطلاب والتحصيل والإيصالات والأرصدة والاستردادات والإعدادات بهذه النسخة. يُحفظ تلقائيًا نسخة أمان من بياناتك الحالية قبل الاستبدال. متابعة؟"
                )
            },
            confirmButton = { TextButton(onClick = vm::confirmRestore) { Text("استعادة", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = vm::cancelRestore) { Text("إلغاء") } }
        )
    }
}
