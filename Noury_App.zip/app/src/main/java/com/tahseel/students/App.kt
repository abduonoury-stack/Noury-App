package com.tahseel.students

import android.app.Application
import com.tahseel.students.data.AppDatabase
import com.tahseel.students.data.PaymentRepository

class App : Application() {
    val db: AppDatabase by lazy { AppDatabase.create(this) }
    val repo: PaymentRepository by lazy { PaymentRepository(db) }
    val refundRepo: com.tahseel.students.data.RefundRepository by lazy { com.tahseel.students.data.RefundRepository(db) }
    val subscriptionRepo: com.tahseel.students.data.SubscriptionRepository by lazy { com.tahseel.students.data.SubscriptionRepository(db) }
}
