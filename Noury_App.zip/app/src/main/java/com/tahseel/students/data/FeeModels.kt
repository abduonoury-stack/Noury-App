package com.tahseel.students.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** تعريف بند مصروفات؛ يمكن ربطه بطفل بعينه أو استخدامه كبند عام. */
@Entity(tableName = "fee_plans", indices = [Index("studentId"), Index("isActive")])
data class FeePlan(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amountPiasters: Long,
    val studentId: Long? = null,
    val billingType: String = "monthly", // monthly أو one_time
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

/** مطالبة مالية مستحقة على طفل لفترة محددة؛ المبالغ بالقروش. */
@Entity(
    tableName = "student_fees",
    foreignKeys = [ForeignKey(entity = Student::class, parentColumns = ["id"], childColumns = ["studentId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("studentId"), Index(value = ["studentId", "periodKey", "feePlanId"], unique = true)]
)
data class StudentFee(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val feePlanId: Long,
    val periodKey: String,
    val description: String,
    val amountPiasters: Long,
    val dueAt: Long,
    val discountPiasters: Long = 0,
    val createdAt: Long = System.currentTimeMillis()
)

/** رصيد زائد قابل للاسترداد؛ لا يُخصم تلقائياً من اشتراكات الشهور التالية. */
@Entity(
    tableName = "refund_credits",
    foreignKeys = [ForeignKey(entity = Student::class, parentColumns = ["id"], childColumns = ["studentId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("studentId"), Index("paymentId", unique = true), Index(value = ["sourceType", "sourceId"], unique = true)]
)
data class RefundCredit(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val paymentId: Long?,
    val originalAmountPiasters: Long,
    val remainingAmountPiasters: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val note: String = "",
    @ColumnInfo(defaultValue = "'payment'") val sourceType: String = "payment",
    val sourceId: Long? = paymentId,
    @ColumnInfo(defaultValue = "'approved'") val approvalStatus: String = "approved",
    @ColumnInfo(defaultValue = "''") val reason: String = "",
    @ColumnInfo(defaultValue = "''") val documentReference: String = "",
    val approvedAt: Long? = createdAt
)

/** إيصال مستقل لكل دفعة؛ يمكن إعادة توليد PDF من بيانات الدفعة دون تخزين ملف PDF داخل القاعدة. */
@Entity(
    tableName = "receipts",
    foreignKeys = [ForeignKey(entity = Payment::class, parentColumns = ["id"], childColumns = ["paymentId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("paymentId", unique = true), Index("receiptNo", unique = true)]
)
data class Receipt(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val paymentId: Long,
    val receiptNo: String,
    val issuedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit_logs", indices = [Index("createdAt"), Index("entityType"), Index("entityId")])
data class AuditLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val entityType: String,
    val entityId: Long,
    val action: String,
    val details: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

/** إعدادات محلية عامة؛ يوم الاستحقاق موحد لكل الأطفال وفق قرار الإصدار 2.0. */
@Entity(tableName = "app_settings")
data class AppSetting(
    @PrimaryKey val key: String,
    val value: String
)


/** سجل اشتراك شهري واحد لكل طفل وفترة؛ يمنع تكرار التحصيل أو تقسيم الاشتراك. */
@Entity(
    tableName = "subscription_payments",
    foreignKeys = [
        ForeignKey(entity = Student::class, parentColumns = ["id"], childColumns = ["studentId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = Payment::class, parentColumns = ["id"], childColumns = ["paymentId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index(value = ["studentId", "periodKey"], unique = true), Index("paymentId", unique = true)]
)
data class SubscriptionPayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val periodKey: String,
    val dueAmountPiasters: Long,
    val paidAmountPiasters: Long,
    val paymentId: Long,
    val isPartialEnrollmentMonth: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val discountPiasters: Long = 0,
    val discountNote: String = ""
)


/** سجل مستقل لكل مبلغ تم رده فعليًا لولي الأمر. */
@Entity(
    tableName = "refund_transactions",
    foreignKeys = [ForeignKey(entity = RefundCredit::class, parentColumns = ["id"], childColumns = ["refundCreditId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("refundCreditId"), Index("refundedAt")]
)
data class RefundTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val refundCreditId: Long,
    val amountPiasters: Long,
    val refundedAt: Long = System.currentTimeMillis(),
    val method: String = "cash",
    val note: String = "",
    val accountId: String? = "cash"
)


/** تسوية مالية نهائية للطالب عند الانسحاب، محفوظة كسجل مستقل غير قابل للتكرار لنفس الشهر. */
@Entity(
    tableName = "student_exit_settlements",
    foreignKeys = [ForeignKey(entity = Student::class, parentColumns = ["id"], childColumns = ["studentId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("studentId"), Index(value = ["studentId", "periodKey"], unique = true)]
)
data class StudentExitSettlement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val periodKey: String,
    val withdrawalDate: String,
    val attendedDays: Int,
    val monthlyFeePiasters: Long,
    val paidAmountPiasters: Long,
    val earnedAmountPiasters: Long,
    val refundAmountPiasters: Long,
    val amountDuePiasters: Long,
    val createdAt: Long = System.currentTimeMillis(),
    /** إجمالي ما تم رده فعليًا؛ لا يتغير عند تصحيح قيمة التسوية. */
    val refundedAmountPiasters: Long = 0,
    /** add_due: يضاف للمبلغ المطلوب من ولي الأمر، deduct_refund: يخصم من المبلغ المسترد. */
    val manualAdjustmentType: String = "none",
    val manualAdjustmentAmountPiasters: Long = 0,
    val manualAdjustmentReason: String = "",
    /** active أو cancelled؛ لا نحذف التسوية عند الإلغاء. */
    val settlementStatus: String = "active",
    val cancelledAt: Long? = null,
    val cancellationReason: String = ""
)

/** سجل تدقيق غير قابل للمحو لكل صرف أو تصحيح مرتبط بتسوية انسحاب. */
@Entity(
    tableName = "student_exit_settlement_events",
    foreignKeys = [ForeignKey(entity = StudentExitSettlement::class, parentColumns = ["id"], childColumns = ["settlementId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("settlementId"), Index("createdAt")]
)
data class StudentExitSettlementEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val settlementId: Long,
    /** refund_paid أو correction */
    val eventType: String,
    /** مبلغ الصرف الفعلي أو فرق الاسترداد الناتج عن التصحيح، بالقروش. */
    val amountPiasters: Long,
    val details: String,
    val createdAt: Long = System.currentTimeMillis(),
    val accountId: String? = "cash"
)
