package com.tahseel.students.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** دليل الحسابات المحاسبي — كل المبالغ بالقروش. */
@Entity(tableName = "accounting_accounts", indices = [Index(value = ["code"], unique = true), Index("parentId"), Index("type")])
data class AccountingAccount(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val name: String,
    val type: String, // asset, liability, equity, revenue, expense
    val parentId: Long? = null,
    val isPosting: Boolean = true,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "accounting_periods", indices = [Index(value = ["startDate", "endDate"])])
data class AccountingPeriod(
    @PrimaryKey val periodKey: String,
    val startDate: Long,
    val endDate: Long,
    val status: String = "open", // open, closed
    val closedAt: Long? = null,
    val note: String = ""
)

@Entity(tableName = "journal_entries", indices = [Index("entryDate"), Index("periodKey"), Index(value = ["sourceType", "sourceId"])])
data class JournalEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val entryNo: String,
    val entryDate: Long,
    val periodKey: String,
    val description: String,
    val sourceType: String = "manual",
    val sourceId: String = "",
    val status: String = "posted", // posted, reversed
    val reversedEntryId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "journal_lines", foreignKeys = [ForeignKey(entity = JournalEntry::class, parentColumns = ["id"], childColumns = ["entryId"], onDelete = ForeignKey.CASCADE), ForeignKey(entity = AccountingAccount::class, parentColumns = ["id"], childColumns = ["accountId"], onDelete = ForeignKey.RESTRICT)], indices = [Index("entryId"), Index("accountId")])
data class JournalLine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val entryId: Long,
    val accountId: Long,
    val debitPiasters: Long = 0,
    val creditPiasters: Long = 0,
    val memo: String = ""
)

@Entity(tableName = "accounting_vendors", indices = [Index("name")])
data class AccountingVendor(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val taxNumber: String = "",
    val address: String = "",
    val notes: String = "",
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "accounting_expenses", indices = [Index("documentDate"), Index("dueDate"), Index("vendorId"), Index("periodKey")])
data class AccountingExpense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val documentNo: String = "",
    val title: String,
    val categoryAccountId: Long,
    val vendorId: Long? = null,
    val documentDate: Long,
    val dueDate: Long,
    val amountPiasters: Long,
    val paidPiasters: Long = 0,
    val periodKey: String,
    val status: String = "unpaid", // unpaid, partial, paid, void
    val note: String = "",
    val journalEntryId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "accounting_expense_payments", foreignKeys = [ForeignKey(entity = AccountingExpense::class, parentColumns = ["id"], childColumns = ["expenseId"], onDelete = ForeignKey.RESTRICT), ForeignKey(entity = CashAccount::class, parentColumns = ["id"], childColumns = ["cashAccountId"], onDelete = ForeignKey.RESTRICT)], indices = [Index("expenseId"), Index("paidAt"), Index("cashAccountId")])
data class AccountingExpensePayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val expenseId: Long,
    val amountPiasters: Long,
    val paidAt: Long,
    val cashAccountId: String,
    val method: String,
    val note: String = "",
    val journalEntryId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "accounting_source_posts", indices = [Index(value = ["sourceType", "sourceId"], unique = true)])
data class AccountingSourcePost(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sourceType: String,
    val sourceId: String,
    val journalEntryId: Long,
    val createdAt: Long = System.currentTimeMillis()
)

data class JournalLineDraft(val accountId: Long, val debitPiasters: Long = 0, val creditPiasters: Long = 0, val memo: String = "")

data class AccountLedgerRow(
    val id: Long,
    val entryId: Long,
    val accountId: Long,
    val debitPiasters: Long,
    val creditPiasters: Long,
    val memo: String,
    val accountCode: String,
    val accountName: String,
    val entryDate: Long,
    val entryNo: String,
    val description: String
)

data class TrialBalanceRow(
    val accountId: Long,
    val code: String,
    val name: String,
    val type: String,
    val debitPiasters: Long,
    val creditPiasters: Long
)

/** Builds the balanced payroll accrual using gross salary, net payable, employee-loan recovery and deductions. */
fun payrollAccrualDrafts(row: EmployeePayroll, salaryAccountId: Long, payableAccountId: Long, employeeAdvanceAccountId: Long): List<JournalLineDraft> {
    val gross = row.basePiasters + row.allowancesPiasters + row.bonusesPiasters
    require(gross > 0L) { "إجمالي استحقاق المرتب غير صحيح" }
    require(row.netPiasters >= 0L && row.loanDeductionPiasters >= 0L && row.deductionsPiasters >= 0L) { "مكونات المرتب لا يمكن أن تكون سالبة" }
    require(gross == row.netPiasters + row.loanDeductionPiasters + row.deductionsPiasters) {
        "مكونات كشف المرتب غير متوازنة محاسبيًا؛ راجع الاستحقاق والخصومات والسلفة قبل الصرف"
    }
    val drafts = mutableListOf(JournalLineDraft(salaryAccountId, debitPiasters = gross, memo = "إجمالي استحقاق ${row.monthKey}"))
    if (row.netPiasters > 0L) drafts += JournalLineDraft(payableAccountId, creditPiasters = row.netPiasters, memo = "صافي المرتب المستحق")
    if (row.loanDeductionPiasters > 0L) drafts += JournalLineDraft(employeeAdvanceAccountId, creditPiasters = row.loanDeductionPiasters, memo = "استقطاع قسط سلفة الموظف")
    if (row.deductionsPiasters > 0L) drafts += JournalLineDraft(salaryAccountId, creditPiasters = row.deductionsPiasters, memo = "خصومات وغياب الشهر")
    return drafts
}

@Dao
abstract class AccountingDao {
    @Query("SELECT * FROM accounting_accounts ORDER BY code, id") abstract fun observeAccounts(): Flow<List<AccountingAccount>>
    @Query("SELECT * FROM accounting_accounts WHERE isActive = 1 AND isPosting = 1 ORDER BY code") abstract suspend fun postingAccounts(): List<AccountingAccount>
    @Insert(onConflict = OnConflictStrategy.ABORT) abstract suspend fun insertAccount(account: AccountingAccount): Long
    @Query("SELECT * FROM accounting_periods ORDER BY startDate DESC") abstract fun observePeriods(): Flow<List<AccountingPeriod>>
    @Query("SELECT * FROM accounting_expenses ORDER BY documentDate DESC, id DESC") abstract fun observeExpenses(): Flow<List<AccountingExpense>>
    @Query("SELECT * FROM accounting_vendors WHERE isActive = 1 ORDER BY name") abstract fun observeVendors(): Flow<List<AccountingVendor>>
    @Query("SELECT * FROM journal_entries ORDER BY entryDate DESC, id DESC LIMIT 200") abstract fun observeJournal(): Flow<List<JournalEntry>>
    @Query("SELECT * FROM accounting_accounts WHERE code=:code AND isActive=1 AND isPosting=1 LIMIT 1") abstract suspend fun accountByCode(code: String): AccountingAccount?
    @Query("SELECT * FROM accounting_expenses WHERE id=:id LIMIT 1") abstract suspend fun expenseById(id: Long): AccountingExpense?
    @Query("SELECT * FROM cash_accounts WHERE id=:id AND isActive=1 LIMIT 1") abstract suspend fun activeCashAccount(id: String): CashAccount?
    @Query("SELECT * FROM accounting_periods WHERE periodKey=:key LIMIT 1") abstract suspend fun periodByKey(key: String): AccountingPeriod?
    @Query("SELECT COALESCE(SUM(debitPiasters),0) FROM journal_lines WHERE accountId=:accountId") abstract suspend fun accountDebitTotal(accountId: Long): Long
    @Query("SELECT COALESCE(SUM(creditPiasters),0) FROM journal_lines WHERE accountId=:accountId") abstract suspend fun accountCreditTotal(accountId: Long): Long
    @Query("SELECT a.id AS accountId, a.code AS code, a.name AS name, a.type AS type, COALESCE(SUM(CASE WHEN e.status='posted' THEN l.debitPiasters ELSE 0 END),0) AS debitPiasters, COALESCE(SUM(CASE WHEN e.status='posted' THEN l.creditPiasters ELSE 0 END),0) AS creditPiasters FROM accounting_accounts a LEFT JOIN journal_lines l ON l.accountId=a.id LEFT JOIN journal_entries e ON e.id=l.entryId GROUP BY a.id,a.code,a.name,a.type ORDER BY a.code") abstract fun observeTrialBalance(): Flow<List<TrialBalanceRow>>
    @Query("SELECT * FROM journal_lines WHERE entryId = :entryId ORDER BY id") abstract suspend fun linesForEntry(entryId: Long): List<JournalLine>
    @Query("SELECT COALESCE(SUM(debitPiasters),0) FROM journal_lines WHERE entryId = :entryId") abstract suspend fun debitTotal(entryId: Long): Long
    @Query("SELECT COALESCE(SUM(creditPiasters),0) FROM journal_lines WHERE entryId = :entryId") abstract suspend fun creditTotal(entryId: Long): Long
    @Query("SELECT EXISTS(SELECT 1 FROM accounting_source_posts WHERE sourceType=:type AND sourceId=:sourceId)") abstract suspend fun alreadyPosted(type: String, sourceId: String): Boolean
    @Query("SELECT EXISTS(SELECT 1 FROM accounting_periods WHERE periodKey=:periodKey AND status='open')") abstract suspend fun isPeriodOpen(periodKey: String): Boolean
    @Query("SELECT EXISTS(SELECT 1 FROM accounting_accounts WHERE id=:accountId AND isActive=1 AND isPosting=1)") abstract suspend fun isPostingAccount(accountId: Long): Boolean
    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun insertPeriod(period: AccountingPeriod)
    @Insert abstract suspend fun insertVendor(vendor: AccountingVendor): Long
    @Update abstract suspend fun updateVendor(vendor: AccountingVendor)
    @Insert abstract suspend fun insertExpense(expense: AccountingExpense): Long
    @Insert abstract suspend fun insertExpensePayment(payment: AccountingExpensePayment): Long
    @Insert abstract suspend fun insertJournal(entry: JournalEntry): Long
    @Insert abstract suspend fun insertLines(lines: List<JournalLine>)
    @Insert abstract suspend fun insertSourcePost(post: AccountingSourcePost)
    @Query("UPDATE accounting_expenses SET paidPiasters=:paid, status=:status WHERE id=:id") abstract suspend fun updateExpensePaymentState(id: Long, paid: Long, status: String)
    @Query("UPDATE accounting_expenses SET journalEntryId=:entryId WHERE id=:id") abstract suspend fun setExpenseJournal(id: Long, entryId: Long)
    @Query("UPDATE accounting_expense_payments SET journalEntryId=:entryId WHERE id=:id") abstract suspend fun setExpensePaymentJournal(id: Long, entryId: Long)
    @Query("SELECT * FROM cash_accounts WHERE isActive=1 ORDER BY CASE WHEN id='cash' THEN 0 ELSE 1 END, name") abstract fun observeActiveCashAccounts(): Flow<List<CashAccount>>
    @Query("SELECT * FROM accounting_expenses WHERE status IN ('unpaid','partial') ORDER BY dueDate,id") abstract fun observeOutstandingExpenses(): Flow<List<AccountingExpense>>
    @Query("SELECT * FROM accounting_vendors WHERE id=:id LIMIT 1") abstract suspend fun vendorById(id: Long): AccountingVendor?
    @Query("UPDATE accounting_periods SET status='closed', closedAt=:closedAt, note=:note WHERE periodKey=:periodKey AND status='open'") abstract suspend fun closePeriodRow(periodKey: String, closedAt: Long, note: String): Int
    @Query("UPDATE accounting_periods SET status='open', closedAt=NULL, note=:note WHERE periodKey=:periodKey AND status='closed'") abstract suspend fun reopenPeriodRow(periodKey: String, note: String): Int
    @Query("UPDATE journal_entries SET status='reversed', reversedEntryId=:reversalId WHERE id=:entryId AND status='posted'") abstract suspend fun markEntryReversed(entryId: Long, reversalId: Long): Int
    @Query("SELECT * FROM journal_entries WHERE id=:id LIMIT 1") abstract suspend fun journalById(id: Long): JournalEntry?
    @Query("SELECT * FROM accounting_periods WHERE status='open' ORDER BY startDate") abstract fun observeOpenPeriods(): Flow<List<AccountingPeriod>>
    @Query("SELECT l.*, a.code AS accountCode, a.name AS accountName, e.entryDate AS entryDate, e.entryNo AS entryNo, e.description AS description FROM journal_lines l INNER JOIN journal_entries e ON e.id=l.entryId INNER JOIN accounting_accounts a ON a.id=l.accountId WHERE l.accountId=:accountId AND e.status IN ('posted','reversed') ORDER BY e.entryDate,e.id,l.id") abstract fun observeAccountLedger(accountId: Long): Flow<List<AccountLedgerRow>>
    @Query("SELECT COUNT(*) FROM journal_entries WHERE periodKey=:periodKey AND status='posted'") abstract suspend fun postedEntriesInPeriod(periodKey: String): Int
    @Query("SELECT COUNT(*) FROM accounting_expenses WHERE periodKey=:periodKey AND status IN ('unpaid','partial')") abstract suspend fun outstandingInvoicesInPeriod(periodKey: String): Int

    @Transaction
    open suspend fun postJournal(entry: JournalEntry, drafts: List<JournalLineDraft>): Long {
        require(drafts.size >= 2) { "القيد يجب أن يحتوي على سطرين على الأقل" }
        require(isPeriodOpen(entry.periodKey)) { "الفترة المحاسبية غير موجودة أو مغلقة" }
        require(drafts.all { isPostingAccount(it.accountId) }) { "يحتوي القيد على حساب غير نشط أو غير قابل للترحيل" }
        require(drafts.all { it.debitPiasters >= 0 && it.creditPiasters >= 0 && (it.debitPiasters == 0L) != (it.creditPiasters == 0L) }) { "كل سطر يجب أن يكون مدينًا أو دائنًا فقط وبقيمة موجبة" }
        val debit = drafts.sumOf { it.debitPiasters }
        val credit = drafts.sumOf { it.creditPiasters }
        require(debit > 0 && debit == credit) { "القيد غير متوازن: إجمالي المدين يجب أن يساوي إجمالي الدائن" }
        if (entry.sourceType != "manual" && entry.sourceId.isNotBlank()) require(!alreadyPosted(entry.sourceType, entry.sourceId)) { "تم ترحيل هذه العملية من قبل" }
        val id = insertJournal(entry)
        insertLines(drafts.map { JournalLine(entryId = id, accountId = it.accountId, debitPiasters = it.debitPiasters, creditPiasters = it.creditPiasters, memo = it.memo) })
        if (entry.sourceType != "manual" && entry.sourceId.isNotBlank()) insertSourcePost(AccountingSourcePost(sourceType = entry.sourceType, sourceId = entry.sourceId, journalEntryId = id))
        return id
    }

    /** Record a real partial/full settlement. The cash credit is posted only for the amount actually paid. */
    @Transaction
    open suspend fun recordExpensePayment(expenseId: Long, amountPiasters: Long, cashAccountId: String, method: String, paidAt: Long = System.currentTimeMillis(), note: String = ""): Long {
        require(amountPiasters > 0L) { "قيمة الدفعة يجب أن تكون أكبر من صفر" }
        val expense = expenseById(expenseId) ?: throw IllegalArgumentException("الفاتورة غير موجودة")
        require(expense.status == "unpaid" || expense.status == "partial") { "الفاتورة غير قابلة للسداد" }
        val remaining = expense.amountPiasters - expense.paidPiasters
        require(amountPiasters <= remaining) { "قيمة الدفعة أكبر من المتبقي" }
        val cash = activeCashAccount(cashAccountId) ?: throw IllegalArgumentException("حساب الخزينة غير موجود أو غير نشط")
        val periodKey = java.time.Instant.ofEpochMilli(paidAt).atZone(java.time.ZoneId.systemDefault()).toLocalDate().let { java.time.YearMonth.from(it).toString() }
        require(isPeriodOpen(periodKey)) { "فترة السداد غير مفتوحة" }
        val payable = accountByCode("2100") ?: throw IllegalStateException("حساب المستحقات غير موجود")
        val cashCode = if (cash.type == "cash") "1100" else "1110"
        val cashLedgerAccount = accountByCode(cashCode) ?: throw IllegalStateException("حساب الأستاذ المقابل للخزينة غير موجود")
        val paymentId = insertExpensePayment(AccountingExpensePayment(expenseId=expenseId, amountPiasters=amountPiasters, paidAt=paidAt, cashAccountId=cashAccountId, method=method, note=note))
        val entryId = postJournal(JournalEntry(entryNo="EXPPAY-$paymentId", entryDate=paidAt, periodKey=periodKey, description="سداد فاتورة: ${expense.title}", sourceType="accounting_expense_payment", sourceId=paymentId.toString()), listOf(
            JournalLineDraft(payable.id, debitPiasters=amountPiasters, memo="سداد ${expense.title}"),
            JournalLineDraft(cashLedgerAccount.id, creditPiasters=amountPiasters, memo="صرف ${expense.title} من ${cash.name}")
        ))
        setExpensePaymentJournal(paymentId, entryId)
        val newPaid = expense.paidPiasters + amountPiasters
        updateExpensePaymentState(expenseId, newPaid, if (newPaid == expense.amountPiasters) "paid" else "partial")
        return paymentId
    }

    /** Creates the current calendar month only when it does not already exist. */
    @Transaction
    open suspend fun ensurePeriod(periodKey: String, startDate: Long, endDate: Long) {
        if (periodByKey(periodKey) == null) insertPeriod(AccountingPeriod(periodKey, startDate, endDate))
    }

    /** ترحيل تحصيل اشتراك فعلي: مدين خزينة/بنك، دائن إيراد اشتراكات بالقيمة الصافية المحصلة. */
    @Transaction
    open suspend fun postSubscriptionRevenue(paymentId: Long, amountPiasters: Long, cashAccountId: String, paidAt: Long, studentName: String, periodLabel: String): Long? {
        require(paymentId > 0L && amountPiasters >= 0L) { "بيانات التحصيل غير صحيحة" }
        if (amountPiasters == 0L) return null // الإعفاء الكامل لا يمثل حركة نقدية أو إيرادًا محصلًا.
        require(!alreadyPosted("subscription_receipt", paymentId.toString())) { "تم ترحيل إيصال الاشتراك محاسبيًا من قبل" }
        val cash = activeCashAccount(cashAccountId) ?: throw IllegalArgumentException("حساب التحصيل غير موجود أو غير نشط")
        val date = java.time.Instant.ofEpochMilli(paidAt).atZone(java.time.ZoneId.systemDefault()).toLocalDate()
        val ym = java.time.YearMonth.from(date)
        val periodKey = ym.toString()
        ensurePeriod(periodKey,
            ym.atDay(1).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli(),
            ym.atEndOfMonth().plusDays(1).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli() - 1L)
        val cashCode = if (cash.type == "cash") "1100" else "1110"
        val cashLedger = accountByCode(cashCode) ?: throw IllegalStateException("حساب الأستاذ المقابل للخزينة غير موجود")
        val revenue = accountByCode("4100") ?: throw IllegalStateException("حساب إيرادات الاشتراكات غير موجود")
        return postJournal(
            JournalEntry(entryNo="SUB-$paymentId", entryDate=paidAt, periodKey=periodKey,
                description="تحصيل اشتراك $periodLabel - $studentName", sourceType="subscription_receipt", sourceId=paymentId.toString()),
            listOf(
                JournalLineDraft(cashLedger.id, debitPiasters=amountPiasters, memo="إيداع في ${cash.name}"),
                JournalLineDraft(revenue.id, creditPiasters=amountPiasters, memo="إيراد اشتراك $periodLabel")
            )
        )
    }

    /** Record an accrued expense: Dr expense / Cr supplier payable. No cash movement is fabricated. */
    @Transaction
    open suspend fun recordAccruedExpense(expense: AccountingExpense): Long {
        require(expense.amountPiasters > 0L) { "قيمة الفاتورة يجب أن تكون أكبر من صفر" }
        require(expense.paidPiasters == 0L) { "تسجيل الفاتورة يتم أولاً كاستحقاق، ثم تسجل الدفعات منفصلة" }
        require(expense.status == "unpaid") { "حالة الفاتورة الأولية غير صحيحة" }
        require(isPeriodOpen(expense.periodKey)) { "الفترة المحاسبية غير موجودة أو مغلقة" }
        val expenseAccount = accountByIdForPosting(expense.categoryAccountId)
            ?: throw IllegalArgumentException("حساب المصروف غير نشط أو غير قابل للترحيل")
        require(expenseAccount.type == "expense") { "يجب اختيار حساب من نوع المصروفات" }
        val payable = accountByCode("2100") ?: throw IllegalStateException("حساب الموردين والمصروفات المستحقة غير موجود")
        val id = insertExpense(expense)
        val entry = JournalEntry(
            entryNo = "EXP-$id", entryDate = expense.documentDate, periodKey = expense.periodKey,
            description = "إثبات فاتورة: ${expense.title}", sourceType = "accounting_expense",
            sourceId = id.toString()
        )
        val entryId = postJournal(entry, listOf(
            JournalLineDraft(expense.categoryAccountId, debitPiasters = expense.amountPiasters, memo = expense.title),
            JournalLineDraft(payable.id, creditPiasters = expense.amountPiasters, memo = expense.title)
        ))
        setExpenseJournal(id, entryId)
        return id
    }

    @Query("SELECT * FROM accounting_accounts WHERE id=:id AND isActive=1 AND isPosting=1 LIMIT 1")
    public abstract suspend fun accountByIdForPosting(id: Long): AccountingAccount?

    /** Close only after all invoices in the period are settled; no silent carry-forward. */
    @Transaction
    open suspend fun closePeriod(periodKey: String, note: String = ""): Boolean {
        require(periodByKey(periodKey)?.status == "open") { "الفترة غير موجودة أو مغلقة بالفعل" }
        // Outstanding supplier balances may legitimately carry into the next period.
        return closePeriodRow(periodKey, System.currentTimeMillis(), note) == 1
    }

    @Transaction
    open suspend fun reopenPeriod(periodKey: String, note: String): Boolean {
        require(note.isNotBlank()) { "اكتب سبب إعادة فتح الفترة" }
        require(periodByKey(periodKey)?.status == "closed") { "الفترة غير مغلقة" }
        return reopenPeriodRow(periodKey, note) == 1
    }

    /** Reverse a posted journal by creating a separate equal-and-opposite entry. */
    /** Opening balances are posted once as a balanced journal at the approved cut-off date. */
    @Transaction
    open suspend fun postOpeningBalances(cutoffDate: Long, drafts: List<JournalLineDraft>, approvalNote: String): Long {
        require(approvalNote.isNotBlank()) { "اعتماد الأرصدة الافتتاحية ومصدرها مطلوب" }
        val periodKey = java.time.Instant.ofEpochMilli(cutoffDate).atZone(java.time.ZoneId.systemDefault()).toLocalDate().let { java.time.YearMonth.from(it).toString() }
        require(!alreadyPosted("opening_balances", periodKey)) { "تم تسجيل الأرصدة الافتتاحية لهذه الفترة من قبل" }
        return postJournal(
            JournalEntry(entryNo="OPEN-$periodKey", entryDate=cutoffDate, periodKey=periodKey,
                description="الأرصدة الافتتاحية المعتمدة: $approvalNote", sourceType="opening_balances", sourceId=periodKey),
            drafts
        )
    }

    @Transaction
    open suspend fun reverseJournal(entryId: Long, reversalDate: Long, reason: String): Long {
        require(reason.isNotBlank()) { "سبب العكس مطلوب" }
        val original = journalById(entryId) ?: throw IllegalArgumentException("القيد غير موجود")
        require(original.status == "posted") { "القيد ليس مرحلاً أو سبق عكسه" }
        val periodKey = java.time.Instant.ofEpochMilli(reversalDate).atZone(java.time.ZoneId.systemDefault()).toLocalDate().let { java.time.YearMonth.from(it).toString() }
        require(isPeriodOpen(periodKey)) { "فترة العكس غير مفتوحة" }
        val lines = linesForEntry(entryId)
        require(lines.size >= 2) { "القيد الأصلي غير مكتمل" }
        val reversalId = postJournal(
            JournalEntry(entryNo="REV-$entryId-${System.currentTimeMillis()}", entryDate=reversalDate, periodKey=periodKey,
                description="عكس القيد ${original.entryNo}: $reason", sourceType="reversal", sourceId=entryId.toString()),
            lines.map { JournalLineDraft(it.accountId, debitPiasters=it.creditPiasters, creditPiasters=it.debitPiasters, memo="عكس: ${it.memo}") }
        )
        markEntryReversed(entryId, reversalId)
        return reversalId
    }

    companion object {
        val DEFAULT_CHART = listOf(
            AccountingAccount(code="1000", name="الأصول", type="asset", isPosting=false),
            AccountingAccount(code="1100", name="الخزينة", type="asset"),
            AccountingAccount(code="1110", name="البنوك والمحافظ", type="asset"),
            AccountingAccount(code="1210", name="سلف وعهد الموظفين", type="asset"),
            AccountingAccount(code="1200", name="ذمم أولياء الأمور", type="asset"),
            AccountingAccount(code="2000", name="الالتزامات", type="liability", isPosting=false),
            AccountingAccount(code="2100", name="الموردون والمصروفات المستحقة", type="liability"),
            AccountingAccount(code="2200", name="مرتبات مستحقة", type="liability"),
            AccountingAccount(code="3000", name="حقوق الملكية", type="equity", isPosting=false),
            AccountingAccount(code="3100", name="رأس المال والأرصدة الافتتاحية", type="equity"),
            AccountingAccount(code="4000", name="الإيرادات", type="revenue", isPosting=false),
            AccountingAccount(code="4100", name="إيرادات الاشتراكات", type="revenue"),
            AccountingAccount(code="5000", name="المصروفات", type="expense", isPosting=false),
            AccountingAccount(code="5100", name="مصروفات تشغيلية", type="expense"),
            AccountingAccount(code="5200", name="مصروف المرتبات", type="expense")
        )
    }
}
