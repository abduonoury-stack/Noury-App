package com.tahseel.students.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** دليل الحسابات المحاسبي — كل المبالغ بالقروش. */
@Entity(tableName = "accounting_accounts", indices = [Index(value = ["code"], unique = true), Index("parentId"), Index("type")])
data class AccountingAccount(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val name: String,
    val type: String, // asset, liability, equity, revenue, expense
    val parentId: Long? = null,
    val isPosting: Boolean = true,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "accounting_periods", indices = [Index(value = ["startDate", "endDate"])])
data class AccountingPeriod(
    @PrimaryKey val periodKey: String,
    val startDate: Long,
    val endDate: Long,
    val status: String = "open", // open, closed
    val closedAt: Long? = null,
    val note: String = ""
)

@Entity(tableName = "journal_entries", indices = [Index("entryDate"), Index("periodKey"), Index(value = ["sourceType", "sourceId"])])
data class JournalEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val entryNo: String,
    val entryDate: Long,
    val periodKey: String,
    val description: String,
    val sourceType: String = "manual",
    val sourceId: String = "",
    val status: String = "posted", // posted, reversed
    val reversedEntryId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "journal_lines", foreignKeys = [ForeignKey(entity = JournalEntry::class, parentColumns = ["id"], childColumns = ["entryId"], onDelete = ForeignKey.CASCADE), ForeignKey(entity = AccountingAccount::class, parentColumns = ["id"], childColumns = ["accountId"], onDelete = ForeignKey.RESTRICT)], indices = [Index("entryId"), Index("accountId")])
data class JournalLine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val entryId: Long,
    val accountId: Long,
    val debitPiasters: Long = 0,
    val creditPiasters: Long = 0,
    val memo: String = ""
)

@Entity(tableName = "accounting_vendors", indices = [Index("name")])
data class AccountingVendor(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val taxNumber: String = "",
    val address: String = "",
    val notes: String = "",
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "accounting_expenses", indices = [Index("documentDate"), Index("dueDate"), Index("vendorId"), Index("periodKey")])
data class AccountingExpense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val documentNo: String = "",
    val title: String,
    val categoryAccountId: Long,
    val vendorId: Long? = null,
    val documentDate: Long,
    val dueDate: Long,
    val amountPiasters: Long,
    val paidPiasters: Long = 0,
    val periodKey: String,
    val status: String = "unpaid", // unpaid, partial, paid, void
    val note: String = "",
    val journalEntryId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "accounting_expense_payments", foreignKeys = [ForeignKey(entity = AccountingExpense::class, parentColumns = ["id"], childColumns = ["expenseId"], onDelete = ForeignKey.RESTRICT), ForeignKey(entity = CashAccount::class, parentColumns = ["id"], childColumns = ["cashAccountId"], onDelete = ForeignKey.RESTRICT)], indices = [Index("expenseId"), Index("paidAt"), Index("cashAccountId")])
data class AccountingExpensePayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val expenseId: Long,
    val amountPiasters: Long,
    val paidAt: Long,
    val cashAccountId: String,
    val method: String,
    val note: String = "",
    val journalEntryId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "accounting_source_posts", indices = [Index(value = ["sourceType", "sourceId"], unique = true)])
data class AccountingSourcePost(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sourceType: String,
    val sourceId: String,
    val journalEntryId: Long,
    val createdAt: Long = System.currentTimeMillis()
)

data class JournalLineDraft(val accountId: Long, val debitPiasters: Long = 0, val creditPiasters: Long = 0, val memo: String = "")

@Dao
abstract class AccountingDao {
    @Query("SELECT * FROM accounting_accounts ORDER BY code") abstract fun observeAccounts(): Flow<List<AccountingAccount>>
    @Query("SELECT * FROM accounting_accounts WHERE isActive = 1 AND isPosting = 1 ORDER BY code") abstract suspend fun postingAccounts(): List<AccountingAccount>
    @Insert(onConflict = OnConflictStrategy.ABORT) abstract suspend fun insertAccount(account: AccountingAccount): Long
    @Query("SELECT * FROM accounting_periods ORDER BY startDate DESC") abstract fun observePeriods(): Flow<List<AccountingPeriod>>
    @Query("SELECT * FROM accounting_expenses ORDER BY documentDate DESC, id DESC") abstract fun observeExpenses(): Flow<List<AccountingExpense>>
    @Query("SELECT * FROM accounting_vendors WHERE isActive = 1 ORDER BY name") abstract fun observeVendors(): Flow<List<AccountingVendor>>
    @Query("SELECT * FROM journal_entries ORDER BY entryDate DESC, id DESC LIMIT 200") abstract fun observeJournal(): Flow<List<JournalEntry>>
    @Query("SELECT * FROM journal_lines WHERE entryId = :entryId ORDER BY id") abstract suspend fun linesForEntry(entryId: Long): List<JournalLine>
    @Query("SELECT COALESCE(SUM(debitPiasters),0) FROM journal_lines WHERE entryId = :entryId") abstract suspend fun debitTotal(entryId: Long): Long
    @Query("SELECT COALESCE(SUM(creditPiasters),0) FROM journal_lines WHERE entryId = :entryId") abstract suspend fun creditTotal(entryId: Long): Long
    @Query("SELECT EXISTS(SELECT 1 FROM accounting_source_posts WHERE sourceType=:type AND sourceId=:sourceId)") abstract suspend fun alreadyPosted(type: String, sourceId: String): Boolean
    @Query("SELECT EXISTS(SELECT 1 FROM accounting_periods WHERE periodKey=:periodKey AND status='open')") abstract suspend fun isPeriodOpen(periodKey: String): Boolean
    @Query("SELECT EXISTS(SELECT 1 FROM accounting_accounts WHERE id=:accountId AND isActive=1 AND isPosting=1)") abstract suspend fun isPostingAccount(accountId: Long): Boolean
    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun insertPeriod(period: AccountingPeriod)
    @Insert abstract suspend fun insertVendor(vendor: AccountingVendor): Long
    @Insert abstract suspend fun insertExpense(expense: AccountingExpense): Long
    @Insert abstract suspend fun insertExpensePayment(payment: AccountingExpensePayment): Long
    @Insert abstract suspend fun insertJournal(entry: JournalEntry): Long
    @Insert abstract suspend fun insertLines(lines: List<JournalLine>)
    @Insert abstract suspend fun insertSourcePost(post: AccountingSourcePost)
    @Query("UPDATE accounting_expenses SET paidPiasters=:paid, status=:status WHERE id=:id") abstract suspend fun updateExpensePaymentState(id: Long, paid: Long, status: String)

    @Transaction
    open suspend fun postJournal(entry: JournalEntry, drafts: List<JournalLineDraft>): Long {
        require(drafts.size >= 2) { "القيد يجب أن يحتوي على سطرين على الأقل" }
        require(isPeriodOpen(entry.periodKey)) { "الفترة المحاسبية غير موجودة أو مغلقة" }
        require(drafts.all { isPostingAccount(it.accountId) }) { "يحتوي القيد على حساب غير نشط أو غير قابل للترحيل" }
        require(drafts.all { it.debitPiasters >= 0 && it.creditPiasters >= 0 && (it.debitPiasters == 0L) != (it.creditPiasters == 0L) }) { "كل سطر يجب أن يكون مدينًا أو دائنًا فقط وبقيمة موجبة" }
        val debit = drafts.sumOf { it.debitPiasters }
        val credit = drafts.sumOf { it.creditPiasters }
        require(debit > 0 && debit == credit) { "القيد غير متوازن: إجمالي المدين يجب أن يساوي إجمالي الدائن" }
        if (entry.sourceType != "manual" && entry.sourceId.isNotBlank()) require(!alreadyPosted(entry.sourceType, entry.sourceId)) { "تم ترحيل هذه العملية من قبل" }
        val id = insertJournal(entry)
        insertLines(drafts.map { JournalLine(entryId = id, accountId = it.accountId, debitPiasters = it.debitPiasters, creditPiasters = it.creditPiasters, memo = it.memo) })
        if (entry.sourceType != "manual" && entry.sourceId.isNotBlank()) insertSourcePost(AccountingSourcePost(sourceType = entry.sourceType, sourceId = entry.sourceId, journalEntryId = id))
        return id
    }

    companion object {
        val DEFAULT_CHART = listOf(
            AccountingAccount(code="1000", name="الأصول", type="asset", isPosting=false),
            AccountingAccount(code="1100", name="الخزينة", type="asset"),
            AccountingAccount(code="1110", name="البنوك والمحافظ", type="asset"),
            AccountingAccount(code="1200", name="ذمم أولياء الأمور", type="asset"),
            AccountingAccount(code="2000", name="الالتزامات", type="liability", isPosting=false),
            AccountingAccount(code="2100", name="الموردون والمصروفات المستحقة", type="liability"),
            AccountingAccount(code="2200", name="مرتبات مستحقة", type="liability"),
            AccountingAccount(code="3000", name="حقوق الملكية", type="equity", isPosting=false),
            AccountingAccount(code="3100", name="رأس المال والأرصدة الافتتاحية", type="equity"),
            AccountingAccount(code="4000", name="الإيرادات", type="revenue", isPosting=false),
            AccountingAccount(code="4100", name="إيرادات الاشتراكات", type="revenue"),
            AccountingAccount(code="5000", name="المصروفات", type="expense", isPosting=false),
            AccountingAccount(code="5100", name="مصروفات تشغيلية", type="expense"),
            AccountingAccount(code="5200", name="مصروف المرتبات", type="expense")
        )
    }
}
