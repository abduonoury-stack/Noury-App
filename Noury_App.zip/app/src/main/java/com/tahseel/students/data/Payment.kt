package com.tahseel.students.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** المبلغ يُخزَّن بالقروش (Long) لتفادي أخطاء الكسور العشرية. رقم الإيصال فريد بقيد Unique في القاعدة. */
@Entity(
    tableName = "payments",
    indices = [Index(value = ["receiptNo"], unique = true), Index(value = ["studentId"])]
)
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentName: String,
    val receiptNo: String,
    val amountPiasters: Long,
    val createdAt: Long,
    /** Nullable para conservar los pagos históricos durante la migración. */
    val studentId: Long? = null,
    val isCancelled: Boolean = false,
    val cancelledAt: Long? = null,
    val cancellationReason: String = "",
    val accountId: String? = "cash"
)
