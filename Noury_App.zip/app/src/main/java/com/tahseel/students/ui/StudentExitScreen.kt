package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.util.Money
import com.tahseel.students.vm.*
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentExitScreen(vm: StudentExitViewModel, onBack: () -> Unit, onProfile: (Long) -> Unit) {
    val students by vm.students.collectAsStateWithLifecycle()
    val history by vm.settlements.collectAsStateWithLifecycle()
    val events by vm.events.collectAsStateWithLifecycle()
    val cashAccounts by vm.cashAccounts.collectAsStateWithLifecycle()
    var selectedId by remember { mutableStateOf<Long?>(null) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var menu by remember { mutableStateOf(false) }
    var preview by remember { mutableStateOf<ExitPreview?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var actionSettlementId by remember { mutableStateOf<Long?>(null) }
    var refundAmount by remember { mutableStateOf("") }
    var refundNote by remember { mutableStateOf("") }
    var refundAccountId by remember { mutableStateOf("cash") }
    var correctionReason by remember { mutableStateOf("") }
    var correctionDate by remember { mutableStateOf("") }
    var adjustmentType by remember { mutableStateOf("none") }
    var adjustmentAmount by remember { mutableStateOf("") }
    var adjustmentReason by remember { mutableStateOf("") }
    var cancelReason by remember { mutableStateOf("") }
    var dialogMode by remember { mutableStateOf("") }
    val selected = students.firstOrNull { it.id == selectedId }
    AppScaffold("تسوية حساب الطالب عند الانسحاب", onBack) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("تتم التسوية من أول الشهر حتى تاريخ الانسحاب، وقيمة اليوم = المصروف الشهري ÷ 30.", style = MaterialTheme.typography.bodyMedium)
            ExposedDropdownMenuBox(expanded = menu, onExpandedChange = { menu = !menu }) {
                OutlinedTextField(value = selected?.fullName.orEmpty(), onValueChange = {}, readOnly = true,
                    label = { Text("اختر الطالب") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(menu) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    students.filter { it.status == "active" }.forEach { st -> DropdownMenuItem(text = { Text(st.fullName) }, onClick = { selectedId = st.id; preview = null; menu = false }) }
                }
            }
            OutlinedTextField(value = date, onValueChange = { date = it; preview = null }, label = { Text("تاريخ الانسحاب (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Button(onClick = { val id = selectedId; if (id == null) message = "اختر الطالب أولًا" else { busy = true; vm.preview(id, date) { p, err -> preview = p; message = err; busy = false } } }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Calculate, null); Spacer(Modifier.width(8.dp)); Text("احسب التسوية")
            }
            preview?.let { p ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Text("معاينة التسوية", style = MaterialTheme.typography.titleLarge)
                        Text(p.student.fullName, style = MaterialTheme.typography.titleMedium)
                        HorizontalDivider()
                        Line("الشهر", p.periodKey)
                        Line("تاريخ الانسحاب", p.withdrawalDate)
                        Line("أيام الحضور المسجلة", p.attendedDays.toString())
                        Line("المصروف الشهري", Money.format(p.monthlyFee))
                        Line("قيمة اليوم (÷ 30)", Money.format(p.monthlyFee / 30L))
                        Line("إجمالي المدفوع", Money.format(p.paid))
                        Line("المستحق عن أيام الحضور", Money.format(p.earned))
                        HorizontalDivider()
                        Text("مبلغ إداري يدوي (اختياري)", style = MaterialTheme.typography.titleMedium)
                        Text("اختار طريقة تطبيقه حسب الحالة، واكتب سبب المبلغ.", style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = adjustmentType == "none", onClick = { adjustmentType = "none" }, label = { Text("بدون") })
                            FilterChip(selected = adjustmentType == "deduct_refund", onClick = { adjustmentType = "deduct_refund" }, label = { Text("خصم من المسترد") })
                            FilterChip(selected = adjustmentType == "add_due", onClick = { adjustmentType = "add_due" }, label = { Text("إضافة للمستحق") })
                        }
                        OutlinedTextField(value = adjustmentAmount, onValueChange = { adjustmentAmount = it }, label = { Text("المبلغ الإداري بالجنيه") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(value = adjustmentReason, onValueChange = { adjustmentReason = it }, label = { Text("سبب المبلغ الإداري") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                        val adminPiasters = runCatching { java.math.BigDecimal(adjustmentAmount.trim().ifBlank { "0" }.replace(',', '.')).movePointRight(2).longValueExact() }.getOrDefault(0L)
                        val adjusted = adjustedPreview(p, adjustmentType, adminPiasters)
                        Line("المبلغ الإداري", if (adjustmentType == "none") "بدون" else Money.format(adminPiasters))
                        HorizontalDivider()
                        if (adjusted.refund > 0) Line("صافي المبلغ المسترد لولي الأمر", Money.format(adjusted.refund), true)
                        if (adjusted.due > 0) Line("إجمالي المطلوب سداده للأكاديمية", Money.format(adjusted.due), true)
                        if (adjusted.refund == 0L && adjusted.due == 0L) Line("الحساب", "متوازن")
                        Text("الحساب يعتمد على أيام الحضور المسجلة بحالة (حاضر) في سجل الحضور.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Button(onClick = { busy = true; vm.save(p.copy(manualAdjustmentType = adjustmentType, manualAdjustmentAmount = adminPiasters, manualAdjustmentReason = adjustmentReason, refund = adjusted.refund, due = adjusted.due)) { message = it; busy = false; if (it.startsWith("تم حفظ")) { preview = null; adjustmentType = "none"; adjustmentAmount = ""; adjustmentReason = "" } } }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("حفظ التسوية")
                        }
                    }
                }
            }
            if (history.isNotEmpty()) {
                HorizontalDivider()
                Text("سجل التسويات المحفوظة", style = MaterialTheme.typography.titleLarge)
                history.forEach { h ->
                    val name = students.firstOrNull { it.id == h.studentId }?.fullName ?: "طالب رقم ${h.studentId}"
                    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(name, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.clickable { onProfile(h.studentId) })
                        Text("${h.periodKey} • ${h.withdrawalDate} • حضور ${h.attendedDays} يوم")
                        if (h.settlementStatus == "cancelled") Text("حالة التسوية: ملغاة • ${h.cancellationReason}", color = MaterialTheme.colorScheme.error)
                        else Text("حالة التسوية: نشطة", color = MaterialTheme.colorScheme.primary)
                        if (h.manualAdjustmentAmountPiasters > 0) Text("المبلغ الإداري: ${Money.format(h.manualAdjustmentAmountPiasters)} • ${if (h.manualAdjustmentType == "add_due") "إضافة للمستحق" else "خصم من المسترد"} • ${h.manualAdjustmentReason}")
                        if (h.refundAmountPiasters > 0) Text("قيمة الاسترداد بعد آخر حساب: ${Money.format(h.refundAmountPiasters)}")
                        if (h.amountDuePiasters > 0) Text("المبلغ المطلوب سداده للأكاديمية: ${Money.format(h.amountDuePiasters)}")
                        Text("تم صرفه فعليًا: ${Money.format(h.refundedAmountPiasters)}")
                        val remaining = (h.refundAmountPiasters - h.refundedAmountPiasters).coerceAtLeast(0L)
                        if (remaining > 0) Text("المتبقي لرده: ${Money.format(remaining)}", color = MaterialTheme.colorScheme.primary)
                        if (h.refundedAmountPiasters > h.refundAmountPiasters) Text("تنبيه: يوجد صرف زائد عن الاستحقاق الحالي بمقدار ${Money.format(h.refundedAmountPiasters - h.refundAmountPiasters)}", color = MaterialTheme.colorScheme.error)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (h.settlementStatus == "active" && remaining > 0) OutlinedButton(onClick = {
                                actionSettlementId = h.id; refundAmount = String.format(java.util.Locale.US, "%.2f", remaining / 100.0); refundNote = ""; refundAccountId = "cash"; dialogMode = "refund"
                            }) { Text("تسجيل صرف") }
                            if (h.settlementStatus == "active") {
                                OutlinedButton(onClick = {
                                    actionSettlementId = h.id; correctionReason = ""; correctionDate = h.withdrawalDate
                                    adjustmentType = h.manualAdjustmentType
                                    adjustmentAmount = String.format(java.util.Locale.US, "%.2f", h.manualAdjustmentAmountPiasters / 100.0)
                                    adjustmentReason = h.manualAdjustmentReason; dialogMode = "correct"
                                }) { Text("تعديل التسوية") }
                                OutlinedButton(onClick = { actionSettlementId = h.id; cancelReason = ""; dialogMode = "cancel" }, colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("إلغاء التسوية") }
                            }
                        }
                        val relatedEvents = events.filter { it.settlementId == h.id }
                        if (relatedEvents.isNotEmpty()) {
                            Text("سجل المراجعة", style = MaterialTheme.typography.labelLarge)
                            relatedEvents.forEach { ev ->
                                Text("${when (ev.eventType) { "refund_paid" -> "صرف فعلي"; "cancel" -> "إلغاء"; "reopen" -> "إعادة فتح"; else -> "تعديل" }} • ${Money.format(kotlin.math.abs(ev.amountPiasters))} • ${java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date(ev.createdAt))}", style = MaterialTheme.typography.bodySmall)
                                if (ev.details.isNotBlank()) Text(ev.details, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    } }
                }
            }
        }
    }
    if (dialogMode == "refund" && actionSettlementId != null) {
        AlertDialog(onDismissRequest = { dialogMode = "" }, title = { Text("تسجيل مبلغ تم رده فعليًا") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = refundAmount, onValueChange = { refundAmount = it }, label = { Text("المبلغ بالجنيه") }, singleLine = true)
                CashAccountDropdown(accounts = cashAccounts, selectedId = refundAccountId, onSelected = { refundAccountId = it }, label = "حساب الصرف")
                OutlinedTextField(value = refundNote, onValueChange = { refundNote = it }, label = { Text("طريقة الصرف / ملاحظة (اختياري)") })
            } },
            confirmButton = { TextButton(onClick = {
                val amount = runCatching { java.math.BigDecimal(refundAmount.trim().replace(',', '.')).movePointRight(2).longValueExact() }.getOrNull()
                if (amount == null || amount <= 0) message = "أدخل مبلغًا صحيحًا بالجنيه"
                else { busy = true; vm.recordRefund(actionSettlementId!!, amount, refundNote, refundAccountId) { message = it; busy = false; if (it.startsWith("تم تسجيل")) dialogMode = "" } }
            }, enabled = !busy) { Text("تأكيد تسجيل الصرف") } },
            dismissButton = { TextButton(onClick = { dialogMode = "" }) { Text("إلغاء") } })
    }
    if (dialogMode == "correct" && actionSettlementId != null) {
        AlertDialog(onDismissRequest = { dialogMode = "" }, title = { Text("تصحيح التسوية") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("سيعيد البرنامج الحساب من سجل الحضور والاشتراك. يمكنك تصحيح تاريخ الانسحاب أيضًا، مع الاحتفاظ بكل ما تم صرفه فعليًا.")
                OutlinedTextField(value = correctionDate, onValueChange = { correctionDate = it }, label = { Text("تاريخ الانسحاب الصحيح (YYYY-MM-DD)") }, singleLine = true)
                Text("المبلغ الإداري اليدوي", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = adjustmentType == "none", onClick = { adjustmentType = "none" }, label = { Text("بدون") })
                    FilterChip(selected = adjustmentType == "deduct_refund", onClick = { adjustmentType = "deduct_refund" }, label = { Text("خصم من المسترد") })
                    FilterChip(selected = adjustmentType == "add_due", onClick = { adjustmentType = "add_due" }, label = { Text("إضافة للمستحق") })
                }
                OutlinedTextField(value = adjustmentAmount, onValueChange = { adjustmentAmount = it }, label = { Text("المبلغ الإداري بالجنيه") }, singleLine = true)
                OutlinedTextField(value = adjustmentReason, onValueChange = { adjustmentReason = it }, label = { Text("سبب المبلغ الإداري") }, minLines = 2)
                OutlinedTextField(value = correctionReason, onValueChange = { correctionReason = it }, label = { Text("سبب تعديل التسوية (إجباري)") }, minLines = 2)
            } },
            confirmButton = { TextButton(onClick = { busy = true; val admin = runCatching { java.math.BigDecimal(adjustmentAmount.trim().ifBlank { "0" }.replace(',', '.')).movePointRight(2).longValueExact() }.getOrNull()
                if (admin == null || admin < 0) { message = "أدخل مبلغًا إداريًا صحيحًا"; busy = false }
                else { busy = true; vm.correctSettlement(actionSettlementId!!, correctionDate, correctionReason, adjustmentType, admin, adjustmentReason) { message = it; busy = false; if (it.startsWith("تم تصحيح")) dialogMode = "" } } }, enabled = !busy && correctionReason.isNotBlank()) { Text("تنفيذ التصحيح") } },
            dismissButton = { TextButton(onClick = { dialogMode = "" }) { Text("إلغاء") } })
    }
    if (dialogMode == "cancel" && actionSettlementId != null) {
        AlertDialog(onDismissRequest = { dialogMode = "" }, title = { Text("إلغاء التسوية") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("سيتم إلغاء أثر التسوية وإعادة حالة الطالب إلى نشط، مع الاحتفاظ بالتسوية وحركات الصرف في سجل المراجعة. إذا تم صرف مبلغ بالفعل فسيظهر تنبيه بالمبلغ المصروف.")
                OutlinedTextField(value = cancelReason, onValueChange = { cancelReason = it }, label = { Text("سبب الإلغاء (إجباري)") }, minLines = 2)
            } },
            confirmButton = { TextButton(onClick = { busy = true; vm.cancelSettlement(actionSettlementId!!, cancelReason) { message = it; busy = false; if (it.startsWith("تم إلغاء")) dialogMode = "" } }, enabled = !busy && cancelReason.isNotBlank()) { Text("تأكيد الإلغاء") } },
            dismissButton = { TextButton(onClick = { dialogMode = "" }) { Text("رجوع") } })
    }
    message?.let { AlertDialog(onDismissRequest = { message = null }, confirmButton = { TextButton(onClick = { message = null }) { Text("حسنًا") } }, text = { Text(it) }) }
}

private fun adjustedPreview(p: ExitPreview, type: String, amount: Long): ExitPreview {
    val baseRefund = (p.paid - p.earned).coerceAtLeast(0L)
    val baseDue = (p.earned - p.paid).coerceAtLeast(0L)
    return when (type) {
        "deduct_refund" -> p.copy(refund = (baseRefund - amount.coerceAtLeast(0L)).coerceAtLeast(0L), due = baseDue)
        "add_due" -> p.copy(refund = baseRefund, due = baseDue + amount.coerceAtLeast(0L))
        else -> p.copy(refund = baseRefund, due = baseDue)
    }
}

@Composable
private fun Line(label: String, value: String, emphasize: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = if (emphasize) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium, color = if (emphasize) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
    }
}
