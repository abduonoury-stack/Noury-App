package com.tahseel.students.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tahseel.students.data.Student
import com.tahseel.students.data.StudentDao
import com.tahseel.students.data.ClassroomDao
import com.tahseel.students.data.PeriodDao
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class StudentsViewModel(private val dao: StudentDao, private val classroomDao: ClassroomDao, private val periodDao: PeriodDao) : ViewModel() {
    val classrooms = classroomDao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val periods = periodDao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val students = dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun save(
        name: String, className: String, birthDate: Long?, enrollmentDate: Long, endHour: Int, periodId: Long?, customMonthlyFee: String,
        firstMonthPounds: String, motherName: String, whatsapp: String,
        fatherName: String, fatherPhone: String, address: String, notes: String,
        existing: Student? = null,
        photoUri: String? = null,
        onResult: (String?) -> Unit
    ) = viewModelScope.launch {
        val cleanName = name.trim()
        if (cleanName.isBlank()) { onResult("اكتب اسم الطفل رباعيًا"); return@launch }
        val first = if (firstMonthPounds.isBlank()) null else firstMonthPounds.toLongOrNull()?.takeIf { it > 0 }?.times(100)
        if (firstMonthPounds.isNotBlank() && first == null) { onResult("قيمة شهر الالتحاق يجب أن تكون رقمًا صحيحًا أكبر من صفر"); return@launch }
        val customFee = if (customMonthlyFee.isBlank()) null else customMonthlyFee.toLongOrNull()?.takeIf { it > 0 }?.times(100)
        if (customMonthlyFee.isNotBlank() && customFee == null) { onResult("السعر الخاص يجب أن يكون رقمًا صحيحًا أكبر من صفر"); return@launch }
        val resolvedPeriodId = periodId ?: existing?.periodId ?: if (endHour == 16) 2L else 1L
        val currentMonthStart = java.time.YearMonth.now().atDay(1).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        val currentPeriodPrice = periodDao.priceAt(resolvedPeriodId, currentMonthStart)
        if (existing == null && customFee == null && currentPeriodPrice == null) {
            onResult("لا يوجد سعر ساري لهذه الفترة في تاريخ اليوم. عدّل تاريخ سريان السعر أو أدخل سعرًا معتمدًا للطالب")
            return@launch
        }
        val approvedMonthlyFee = customFee ?: existing?.monthlyFeeOverridePiasters ?: if (existing == null) currentPeriodPrice else null
        val record = Student(
            id = existing?.id ?: 0L,
            fullName = cleanName, enrollmentDate = enrollmentDate, className = className.trim(),
            attendanceEndHour = endHour, periodId = resolvedPeriodId, monthlyFeeOverridePiasters = approvedMonthlyFee, firstMonthAmountPiasters = first,
            motherName = motherName.trim(), motherWhatsapp = whatsapp.trim(),
            fatherName = fatherName.trim(), fatherPhone = fatherPhone.trim(),
            address = address.trim(), notes = notes.trim(),
            birthDate = birthDate, photoUri = photoUri?.takeIf { it.isNotBlank() },
            status = existing?.status ?: "active",
            createdAt = existing?.createdAt ?: System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        if (existing == null) dao.insert(record) else dao.update(record)
        onResult(null)
    }

    fun importStudents(records: List<Student>, onResult: (String?) -> Unit) = viewModelScope.launch {
        try {
            if (records.isEmpty()) { onResult("لا توجد بيانات صالحة للاستيراد"); return@launch }
            val now = System.currentTimeMillis()
            val currentMonthStart = java.time.YearMonth.now().atDay(1).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
            val normalized = records.map { student ->
                val pid = student.periodId ?: if (student.attendanceEndHour == 16 || student.attendanceEndHour == 17) 2L else 1L
                val fee = student.monthlyFeeOverridePiasters ?: periodDao.priceAt(pid, currentMonthStart)
                    ?: throw IllegalArgumentException("لا يوجد سعر موثق وساري للفترة الخاصة بالطالب ${student.fullName}")
                student.copy(periodId = pid, monthlyFeeOverridePiasters = fee)
            }
            dao.insertAll(normalized)
            onResult(null)
        } catch (e: Exception) { onResult("تعذر استيراد البيانات: ${e.message ?: "خطأ غير معروف"}") }
    }

    fun setRegularity(student: Student, regular: Boolean, onResult: (String?) -> Unit) = viewModelScope.launch {
        val updated = student.copy(
            status = if (regular) "active" else "inactive",
            updatedAt = System.currentTimeMillis()
        )
        val count = dao.update(updated)
        onResult(if (count == 1) null else "تعذر تحديث حالة الطالب")
    }
}
