package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.data.AttendancePeriod
import com.tahseel.students.data.PeriodDao
import com.tahseel.students.data.PeriodPriceHistory
import com.tahseel.students.util.Money
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.Instant
import java.time.ZoneId

@Composable
fun PeriodManagementScreen(dao: PeriodDao, onBack: () -> Unit) {
    val periods by dao.observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val priceHistory by dao.observeAllPriceHistory().collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf<AttendancePeriod?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    AppScaffold(title = "إدارة الفترات والاشتراكات", onBack = onBack) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("أضف فترات بأسماء ومواعيد وأسعار مختلفة. إيقاف الفترة يمنع اختيارها للطلاب الجدد فقط، ولا يغيّر ملفات الطلاب الحاليين.", style = MaterialTheme.typography.bodyMedium)
            Button(onClick = { editing = null; showEditor = true }, modifier = Modifier.fillMaxWidth()) { Text("إضافة فترة جديدة") }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(periods, key = { it.id }) { item ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(item.name, style = MaterialTheme.typography.titleMedium)
                                AssistChip(onClick = {
                                    scope.launch { dao.update(item.copy(isActive = !item.isActive)); message = if (item.isActive) "تم إيقاف الفترة عن استقبال طلاب جدد" else "تم تفعيل الفترة" }
                                }, label = { Text(if (item.isActive) "نشطة" else "متوقفة") })
                            }
                            Text("${item.startTime} – ${item.endTime}")
                            Text("${Money.format(item.monthlyFeePiasters)} شهريًا", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                            priceHistory.filter { it.periodId == item.id }.sortedByDescending { it.effectiveFrom }.take(4).forEach { record ->
                                val effectiveDate = Instant.ofEpochMilli(record.effectiveFrom).atZone(ZoneId.systemDefault()).toLocalDate()
                                Text("سعر ${Money.format(record.amountPiasters)} ساري من $effectiveDate", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            OutlinedButton(onClick = { editing = item; showEditor = true }, modifier = Modifier.fillMaxWidth()) { Text("تعديل المواعيد أو السعر") }
                        }
                    }
                }
            }
        }
    }
    if (showEditor) {
        var name by remember(editing?.id) { mutableStateOf(editing?.name.orEmpty()) }
        var start by remember(editing?.id) { mutableStateOf(editing?.startTime ?: "08:00") }
        var end by remember(editing?.id) { mutableStateOf(editing?.endTime ?: "13:00") }
        var price by remember(editing?.id) { mutableStateOf(editing?.monthlyFeePiasters?.div(100)?.toString().orEmpty()) }
        var effective by remember(editing?.id) { mutableStateOf(LocalDate.now().toString()) }
        var error by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showEditor = false },
            title = { Text(if (editing == null) "إضافة فترة" else "تعديل الفترة") },
            text = {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("اسم الفترة") }, singleLine = true)
                    OutlinedTextField(start, { start = it }, label = { Text("موعد البداية (HH:MM)") }, singleLine = true)
                    OutlinedTextField(end, { end = it }, label = { Text("موعد النهاية (HH:MM)") }, singleLine = true)
                    OutlinedTextField(price, { price = it.filter(Char::isDigit) }, label = { Text("السعر الشهري بالجنيه") }, singleLine = true)
                    OutlinedTextField(effective, { effective = it }, label = { Text("تاريخ سريان السعر (YYYY-MM-DD)") }, singleLine = true)
                    Text("عند تغيير السعر يُسجل كسعر جديد بتاريخ سريان مستقل. الأسعار والفواتير السابقة لا تتغير.", style = MaterialTheme.typography.bodySmall)
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val amount = price.toLongOrNull()
                    val date = runCatching { LocalDate.parse(effective) }.getOrNull()
                    val timeOk = Regex("^(?:[01][0-9]|2[0-3]):[0-5][0-9]$").matches(start) && Regex("^(?:[01][0-9]|2[0-3]):[0-5][0-9]$").matches(end)
                    when {
                        name.isBlank() -> error = "اكتب اسم الفترة"
                        !timeOk -> error = "اكتب المواعيد بصيغة ساعة:دقيقة مثل 08:00"
                        amount == null || amount <= 0 -> error = "اكتب سعرًا صحيحًا أكبر من صفر"
                        date == null -> error = "تاريخ السريان غير صحيح"
                        else -> scope.launch {
                            val effectiveAt = date.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                            val old = editing
                            if (old == null) {
                                val id = dao.insert(AttendancePeriod(name = name.trim(), startTime = start, endTime = end, monthlyFeePiasters = amount * 100))
                                dao.insertPriceHistory(PeriodPriceHistory(periodId = id, amountPiasters = amount * 100, effectiveFrom = effectiveAt))
                                message = "تمت إضافة الفترة وتسجيل سعرها"
                            } else {
                                dao.update(old.copy(name = name.trim(), startTime = start, endTime = end, monthlyFeePiasters = amount * 100))
                                if (old.monthlyFeePiasters != amount * 100) {
                                    dao.insertPriceHistory(PeriodPriceHistory(periodId = old.id, amountPiasters = amount * 100, effectiveFrom = effectiveAt))
                                    message = "تم تحديث الفترة وتسجيل السعر الجديد بتاريخ سريانه"
                                } else message = "تم تحديث بيانات الفترة"
                            }
                            showEditor = false
                        }
                    }
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { showEditor = false }) { Text("إلغاء") } }
        )
    }
    message?.let { AlertDialog(onDismissRequest = { message = null }, confirmButton = { TextButton(onClick = { message = null }) { Text("حسنًا") } }, text = { Text(it) }) }
}
