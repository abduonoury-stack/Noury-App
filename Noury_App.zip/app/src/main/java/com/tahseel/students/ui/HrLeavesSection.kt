package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tahseel.students.data.Employee
import com.tahseel.students.data.EmployeeLeave

@Composable
internal fun HrLeavesSection(
    employees: List<Employee>,
    leaves: List<EmployeeLeave>,
    onNewLeave: () -> Unit,
    onDecision: (Long, Boolean) -> Unit
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text("طلبات الإجازات", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        Button(onClick = onNewLeave) { Text("طلب جديد +") }
    }
    if (leaves.isEmpty()) {
        Card { Text("لا توجد طلبات إجازات مسجلة حتى الآن.", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
    leaves.forEach { leave ->
        val employee = employees.firstOrNull { it.id == leave.employeeId }
        Card {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(employee?.fullName ?: "موظف غير متاح", style = MaterialTheme.typography.titleSmall)
                Text("${leave.leaveType} • ${leave.startDate} إلى ${leave.endDate} • ${leave.days} يوم")
                Text("السبب: ${leave.reason.ifBlank { "غير محدد" }}")
                Text("الحالة: ${when (leave.status) { "approved" -> "مقبولة"; "rejected" -> "مرفوضة"; else -> "بانتظار الموافقة" }}")
                if (leave.status == "pending") {
                    Row {
                        TextButton(onClick = { onDecision(leave.id, true) }) { Text("موافقة") }
                        TextButton(onClick = { onDecision(leave.id, false) }) { Text("رفض") }
                    }
                }
            }
        }
    }
}
