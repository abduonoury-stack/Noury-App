package com.tahseel.students.data

import java.time.YearMonth

enum class ExpenseAuditSeverity { WARNING, ERROR, INFO }

data class ExpenseAuditIssue(
    val code: String,
    val severity: ExpenseAuditSeverity,
    val title: String,
    val detail: String,
    val expenseId: Long? = null
)

/**
 * Read-only checks over the expense register and its detailed payment ledger.
 * Legacy paid balances without detailed payment rows are reported as informational,
 * not as errors, because older app versions stored only the aggregate paid amount.
 */
fun auditExpenseRegister(
    expenses: List<Expense>,
    payments: List<ExpensePayment>,
    now: Long,
    month: YearMonth
): List<ExpenseAuditIssue> {
    val monthRows = expensesForMonth(expenses, month)
    val paymentsByExpense = payments.groupBy { it.expenseId }
    val issues = mutableListOf<ExpenseAuditIssue>()

    monthRows.forEach { expense ->
        val amount = expense.amountPiasters
        val paid = expense.paidAmountPiasters
        val detailed = paymentsByExpense[expense.id].orEmpty()
        val detailedTotal = detailed.sumOf { it.amountPiasters.coerceAtLeast(0L) }

        if (amount < 0L || paid < 0L) {
            issues += ExpenseAuditIssue(
                "negative_value", ExpenseAuditSeverity.ERROR,
                "قيمة سالبة في بند مصروف",
                "راجع إجمالي المصروف والمدفوع؛ لا ينبغي أن تكون القيم سالبة.",
                expense.id
            )
        }
        if (paid > amount.coerceAtLeast(0L)) {
            issues += ExpenseAuditIssue(
                "overpaid", ExpenseAuditSeverity.ERROR,
                "المدفوع أكبر من قيمة المصروف",
                "المدفوع المسجل يتجاوز أصل الالتزام.",
                expense.id
            )
        }
        if (detailedTotal > paid.coerceAtLeast(0L)) {
            issues += ExpenseAuditIssue(
                "payment_ledger_mismatch", ExpenseAuditSeverity.ERROR,
                "دفتر الدفعات لا يطابق إجمالي المدفوع",
                "مجموع الدفعات التفصيلية أكبر من المدفوع المخزن في بند المصروف.",
                expense.id
            )
        } else if (paid > detailedTotal && paid > 0L) {
            issues += ExpenseAuditIssue(
                "legacy_paid_balance", ExpenseAuditSeverity.INFO,
                "رصيد مدفوع تاريخي غير مفصل",
                "يوجد مدفوع مسجل قديمًا دون تفاصيل دفعات كاملة؛ لا يُعد خطأ تلقائيًا.",
                expense.id
            )
        }
        if (amount > paid.coerceAtLeast(0L) && expense.dueAt in 1 until now) {
            issues += ExpenseAuditIssue(
                "overdue", ExpenseAuditSeverity.WARNING,
                "مصروف تجاوز تاريخ الاستحقاق",
                "يوجد متبقٍ على بند حلّ تاريخ استحقاقه.",
                expense.id
            )
        }
        detailed.filter { it.accountId.isNullOrBlank() }.forEach {
            issues += ExpenseAuditIssue(
                "unassigned_account", ExpenseAuditSeverity.WARNING,
                "دفعة دون حساب صرف محدد",
                "راجع حساب الخزينة أو البنك المرتبط بهذه الدفعة.",
                expense.id
            )
        }
        detailed.filter { it.amountPiasters <= 0L }.forEach {
            issues += ExpenseAuditIssue(
                "invalid_payment", ExpenseAuditSeverity.ERROR,
                "دفعة بقيمة غير صحيحة",
                "يجب أن تكون قيمة كل دفعة أكبر من صفر.",
                expense.id
            )
        }
    }

    val duplicates = monthRows
        .filter { it.amountPiasters > 0L && it.title.isNotBlank() }
        .groupBy { listOf(it.title.trim().lowercase(), it.category.trim().lowercase(), it.amountPiasters.toString()) }
    duplicates.values.filter { it.size > 1 }.forEach { group ->
        issues += ExpenseAuditIssue(
            "possible_duplicate", ExpenseAuditSeverity.WARNING,
            "بنود متشابهة تحتاج مراجعة",
            "توجد بنود لها الاسم والتصنيف والقيمة نفسها في الشهر؛ تحقق من أنها ليست مكررة.",
            group.first().id
        )
    }

    return issues
}
