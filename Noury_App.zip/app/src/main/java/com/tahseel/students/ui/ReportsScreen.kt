package com.tahseel.students.ui

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.util.Money
import com.tahseel.students.util.TimeUtil
import com.tahseel.students.util.MonthlyReportPrinter
import com.tahseel.students.vm.ReportsViewModel
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.time.LocalDate
import java.time.ZoneId

@Composable
fun ReportsScreen(vm: ReportsViewModel, onBack: () -> Unit, onOpen: (Long) -> Unit, onStudentProfile: (Long) -> Unit) {
    val sum by vm.summary.collectAsStateWithLifecycle()
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refreshDate() }
    val sq by vm.studentQuery.collectAsStateWithLifecycle()
    val sres by vm.studentResults.collectAsStateWithLifecycle()
    val range by vm.range.collectAsStateWithLifecycle()
    val rres by vm.rangeResults.collectAsStateWithLifecycle()
    val monthly by vm.monthlyReport.collectAsStateWithLifecycle()
    val cashAudit by vm.cashLifecycleAudit.collectAsStateWithLifecycle()
    val cashLedger by vm.cashLedger.collectAsStateWithLifecycle()
    val unassignedCashMovements by vm.unassignedCashMovements.collectAsStateWithLifecycle()
    val cashAccounts by vm.cashAccounts.collectAsStateWithLifecycle()
    val selectedCashAccountId by vm.selectedCashAccountId.collectAsStateWithLifecycle()
    val cashControl by vm.cashControl.collectAsStateWithLifecycle()
    var openingAmount by remember { mutableStateOf("") }
    var openingDate by remember { mutableStateOf(LocalDate.now().toString()) }
    var openingNote by remember { mutableStateOf("") }
    var countAmount by remember { mutableStateOf("") }
    var countDate by remember { mutableStateOf(LocalDate.now().toString()) }
    var countNote by remember { mutableStateOf("") }
    var cashInputError by remember { mutableStateOf("") }
    val context = LocalContext.current
    var pick by remember { mutableStateOf(0) }

    AppScaffold("التقارير", onBack) { pad ->
        LazyColumn(Modifier.padding(pad).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
            item { SectionTitle("التقرير المالي الشهري") }
            item {
                Card(Modifier.fillMaxWidth()) { Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(onClick = vm::previousMonth) { Text("‹ السابق") }
                        Text(monthly.month.format(DateTimeFormatter.ofPattern("yyyy / MM", Locale.US)), style = MaterialTheme.typography.titleLarge)
                        TextButton(onClick = vm::nextMonth) { Text("التالي ›") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatCard("الاشتراكات المستحقة", Money.format(monthly.due), Modifier.weight(1f))
                        StatCard("إجمالي المقبوضات", Money.format(monthly.collected), Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatCard("تحصيل الاشتراكات", Money.format(monthly.subscriptionCollected), Modifier.weight(1f))
                        StatCard("المصروفات المدفوعة", Money.format(monthly.expensesPaid), Modifier.weight(1f))
                    }
                    StatCard("صافي الحركة النقدية", Money.format(monthly.net), Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatCard("المصروفات المستحقة", Money.format(monthly.expensesTotal), Modifier.weight(1f))
                        StatCard("المتبقي من المصروفات", Money.format(monthly.expensesRemaining), Modifier.weight(1f))
                    }
                    StatCard("متأخرات الاشتراكات", Money.format(monthly.arrears), Modifier.fillMaxWidth())
                    Text("عدد الطلاب النشطين المستحق عليهم: ${monthly.studentDueCount}", style = MaterialTheme.typography.bodySmall)
                    Button(onClick = { MonthlyReportPrinter.print(context, monthly) }, modifier = Modifier.fillMaxWidth().heightIn(min=52.dp)) { Text("طباعة التقرير – A4") }
                    OutlinedButton(onClick = { MonthlyReportPrinter.shareCsv(context, monthly) }, modifier = Modifier.fillMaxWidth().heightIn(min=50.dp)) { Text("تصدير كشف Excel (CSV)") }
                    Text("ملاحظة: إجمالي المقبوضات يشمل كل الإيصالات السارية ويستبعد الملغاة. تحصيل الاشتراكات مؤشر منفصل. صافي الحركة النقدية = إجمالي المقبوضات ناقص المصروفات المدفوعة.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } }
            }
            item { SectionTitle("مراجعة دورة الأموال") }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text(
                            when { !cashAudit.isLoaded -> "جارٍ مراجعة سجلات دورة الأموال…"; cashAudit.isConsistent -> "لم تُكتشف فروق في السجلات التي تمت مراجعتها"; else -> "توجد نقاط تحتاج مراجعة قبل اعتماد المطابقة" },
                            style = MaterialTheme.typography.titleSmall,
                            color = if (!cashAudit.isLoaded) MaterialTheme.colorScheme.onSurfaceVariant else if (cashAudit.isConsistent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatCard("أرصدة الاسترداد", Money.format(cashAudit.refundCreditsTotal), Modifier.weight(1f))
                            StatCard("حركات رد فعلية", Money.format(cashAudit.refundTransactionsTotal), Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatCard("صافي المرتبات", Money.format(cashAudit.payrollNetTotal), Modifier.weight(1f))
                            StatCard("المدفوع", Money.format(cashAudit.payrollPaidTotal), Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatCard("عكس مرتبات", Money.format(cashAudit.payrollReversedTotal), Modifier.weight(1f))
                            StatCard("المسترد من الموظفين", Money.format(cashAudit.payrollRecoveredTotal), Modifier.weight(1f))
                        }
                        StatCard("مديونية مرتبات متبقية", Money.format(cashAudit.payrollReceivableTotal), Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatCard("سلف مصروفة", Money.format(cashAudit.loanIssuedTotal), Modifier.weight(1f))
                            StatCard("متبقي السلف", Money.format(cashAudit.loanRemainingTotal), Modifier.weight(1f))
                        }
                        Text("عدد ملاحظات المراجعة: ${cashAudit.issues.size}", style = MaterialTheme.typography.bodyMedium)
                        cashAudit.issues.forEach { issue ->
                            HorizontalDivider()
                            Text("${issue.category} • ${issue.reference}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.error)
                            Text(issue.message, style = MaterialTheme.typography.bodySmall)
                        }
                        Text(
                            "المراجعة لا تعدّل أي رصيد. التطابق المحتمل بين سجل الاسترداد وتسوية الانسحاب يظهر كتنبيه للمراجعة ولا يُحذف تلقائيًا.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            item { SectionTitle("ضبط الحساب والجرد الفعلي") }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        CashAccountDropdown(accounts = cashAccounts, selectedId = selectedCashAccountId, onSelected = vm::selectCashAccount, label = "الحساب الجاري")
                        if (cashControl.unassignedSinceOpening > 0) Text("تنبيه: توجد ${cashControl.unassignedSinceOpening} حركة تاريخية بعد تاريخ الرصيد الافتتاحي لم تُحدد وسيلة دفعها؛ لذلك لا تدخل في رصيد هذا الحساب.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        Text("الرصيد الافتتاحي المعتمد", style = MaterialTheme.typography.titleMedium)
                        // Capture the nullable Room/UI state once so Kotlin can safely smart-cast it.
                        val openingBalance = cashControl.opening
                        if (openingBalance == null) {
                            Text("لم يتم تسجيل رصيد افتتاحي لهذا الحساب بعد؛ لذلك لا يمكن اعتماد رصيده الحالي.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        } else {
                            Text("${Money.format(openingBalance.amountPiasters)} • اعتبارًا من ${TimeUtil.fmt(openingBalance.effectiveAt)}", style = MaterialTheme.typography.bodyMedium)
                            if (openingBalance.note.isNotBlank()) Text(openingBalance.note, style = MaterialTheme.typography.bodySmall)
                        }
                        OutlinedTextField(openingAmount, { openingAmount = it; cashInputError = "" }, label = { Text("الرصيد الافتتاحي بالجنيه") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(openingDate, { openingDate = it; cashInputError = "" }, label = { Text("تاريخ سريان الرصيد YYYY-MM-DD") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(openingNote, { openingNote = it }, label = { Text("مصدر الرصيد / ملاحظة اعتماد") }, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            val amount = Money.parseNonNegative(openingAmount)
                            val date = runCatching { LocalDate.parse(openingDate) }.getOrNull()
                            if (amount == null || date == null || openingNote.isBlank()) cashInputError = "أدخل مبلغًا صحيحًا وتاريخًا ومصدرًا واضحًا للرصيد."
                            else {
                                vm.saveCashOpening(amount, date.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli(), openingNote)
                                openingAmount = ""; openingNote = ""; cashInputError = ""
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text(if (cashControl.opening == null) "اعتماد الرصيد الافتتاحي" else "اعتماد رصيد افتتاحي جديد") }
                        Text("كل اعتماد جديد يُضاف كسجل تاريخي ولا يمحو الاعتماد السابق.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        cashControl.openingHistory.drop(1).take(4).forEach { oldOpening ->
                            Text("اعتماد سابق: ${Money.format(oldOpening.amountPiasters)} • ${TimeUtil.fmt(oldOpening.effectiveAt)} • ${oldOpening.note}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        HorizontalDivider()
                        Text("تسجيل الجرد الفعلي", style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(countAmount, { countAmount = it; cashInputError = "" }, label = { Text("المبلغ الموجود فعليًا بالجنيه") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(countDate, { countDate = it; cashInputError = "" }, label = { Text("تاريخ الجرد YYYY-MM-DD") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(countNote, { countNote = it }, label = { Text("ملاحظات الجرد") }, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            val amount = Money.parseNonNegative(countAmount)
                            val date = runCatching { LocalDate.parse(countDate) }.getOrNull()
                            if (amount == null || date == null) cashInputError = "أدخل مبلغ الجرد وتاريخًا صحيحًا."
                            else {
                                vm.recordCashCount(amount, date.atTime(23, 59, 59).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(), countNote)
                                countAmount = ""; countNote = ""; cashInputError = ""
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("حفظ نتيجة الجرد") }
                        if (cashInputError.isNotBlank()) Text(cashInputError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        HorizontalDivider()
                        Text("الرصيد الدفتري التقديري حتى الآن", style = MaterialTheme.typography.labelLarge)
                        Text(cashControl.expectedNow?.let(Money::format) ?: "غير متاح — يلزم اعتماد رصيد افتتاحي", style = MaterialTheme.typography.titleLarge)
                        cashControl.latestDifference?.let { difference ->
                            Text("فرق آخر جرد: ${if (difference > 0) "+" else ""}${Money.format(difference)}", color = if (difference == 0L) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error, style = MaterialTheme.typography.titleMedium)
                            Text("الرصيد الدفتري التقديري وقت الجرد: ${Money.format(cashControl.latestExpected ?: 0L)} • الفعلي: ${Money.format(cashControl.counts.first().actualAmountPiasters)}", style = MaterialTheme.typography.bodySmall)
                        }
                        cashControl.counts.take(5).forEach { count ->
                            Text("جرد ${TimeUtil.fmt(count.countedAt)}: ${Money.format(count.actualAmountPiasters)}${if (count.note.isBlank()) "" else " • ${count.note}"}", style = MaterialTheme.typography.bodySmall)
                        }
                        Text("كل عملية جرد تُحفظ كسجل مستقل. فرق الجرد لا يُرحّل تلقائيًا إلى الخزينة ولا يعدّل الحركات الأصلية. بعض تواريخ المدفوعات القديمة تقديرية وليست تواريخ صرف مؤكدة.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            item { SectionTitle("دفتر حركة الحساب") }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text(cashAccounts.firstOrNull { it.id == selectedCashAccountId }?.name ?: "الحساب المحدد", style = MaterialTheme.typography.titleSmall)
                                Text("${cashLedger.movements.size} حركة في ${cashLedger.month}", style = MaterialTheme.typography.bodySmall)
                            }
                            Text("${cashLedger.excludedCount} للمراجعة\n${cashLedger.unassignedCount} قديمة بلا حساب", style = MaterialTheme.typography.labelMedium, color = if (cashLedger.excludedCount + cashLedger.unassignedCount > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatCard("وارد الحساب", Money.format(cashLedger.inflowsPiasters), Modifier.weight(1f))
                            StatCard("صادر الحساب", Money.format(cashLedger.outflowsPiasters), Modifier.weight(1f))
                        }
                        StatCard("صافي حركة الفترة", Money.format(cashLedger.netMovementPiasters), Modifier.fillMaxWidth())
                        Text(if (cashControl.opening == null) "هذا دفتر مشتق للقراءة والمراجعة؛ لا يوجد رصيد افتتاحي معتمد لهذا الحساب، لذلك لا يمكن تحديد رصيده." else "الرصيد المحسوب خاص بالحساب المختار فقط. الحركات القديمة التي لا نعرف وسيلة دفعها لا تُنسب تلقائيًا إلى النقدية أو البنك، والتحويلات بين الحسابات تظهر كحركة واردة وصادرة وليست إيرادًا أو مصروفًا.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            if (cashLedger.movements.isEmpty()) item { Text("لا توجد حركات مسجلة لهذا الحساب في هذا الشهر.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            if (unassignedCashMovements.isNotEmpty()) {
                item {
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("حركات تاريخية غير مصنفة (${unassignedCashMovements.size})", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onErrorContainer)
                            Text("لم يتم تحديد حساب هذه الحركات في البيانات القديمة. لا تدخل في رصيد أي حساب حتى مراجعة المستندات وتحديد الحساب الصحيح. يُعرض أول 20 سجلًا هنا.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                            unassignedCashMovements.take(20).forEach { old ->
                                HorizontalDivider()
                                Text("${old.category} • ${old.description} • ${Money.format(old.amountPiasters)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                            }
                        }
                    }
                }
            }
            items(cashLedger.movements, key = { "cash-${it.id}" }) { movement ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(movement.category, style = MaterialTheme.typography.labelLarge)
                            Text(
                                (if (movement.direction == com.tahseel.students.data.CashDirection.INFLOW) "+" else "−") + Money.format(movement.amountPiasters),
                                style = MaterialTheme.typography.titleSmall,
                                color = if (!movement.includedInTotals) MaterialTheme.colorScheme.error else if (movement.direction == com.tahseel.students.data.CashDirection.INFLOW) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(movement.description, style = MaterialTheme.typography.bodyMedium)
                        Text("${TimeUtil.fmt(movement.timestamp)} • ${movement.sourceReference}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (movement.note.isNotBlank()) Text(movement.note, style = MaterialTheme.typography.bodySmall, color = if (movement.includedInTotals) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error)
                        if (!movement.includedInTotals) Text("مستبعد من الإجمالي لحين المراجعة", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                    }
                }
            }
            item { SectionTitle("تفاصيل التحصيل") }
            item { Text("عدد العمليات: ${monthly.payments.size} • ${Money.format(monthly.collected)}", style = MaterialTheme.typography.bodyMedium) }
            items(monthly.payments, key = { "mp${it.id}" }) { p -> PaymentRow(p, null, onClick = { onOpen(p.id) }, onStudentClick = p.studentId?.let { id -> { onStudentProfile(id) } }) }
            item { SectionTitle("تفاصيل المصروفات") }
            if (monthly.expenses.isEmpty()) item { Text("لا توجد مصروفات مسجلة لهذا الشهر") }
            items(monthly.expenses, key = { "me${it.id}" }) { e ->
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                    Text(e.title, style = MaterialTheme.typography.titleMedium)
                    Text("القيمة: ${Money.format(e.amountPiasters)} • المدفوع: ${Money.format(e.paidAmountPiasters)}")
                    Text("المتبقي: ${Money.format((e.amountPiasters-e.paidAmountPiasters).coerceAtLeast(0))}")
                } }
            }
            item { SectionTitle("ملخص التحصيل اليومي") }
            item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { StatCard("إجمالي اليوم", Money.format(sum.today), Modifier.weight(1f)); StatCard("إجمالي الشهر الحالي", Money.format(sum.month), Modifier.weight(1f)) } }
            item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { StatCard("الإجمالي الكلي", Money.format(sum.total), Modifier.weight(1f)); StatCard("عدد الإيصالات", sum.count.toString(), Modifier.weight(1f)) } }
            item { SectionTitle("كشف عمليات طالب") }
            item { OutlinedTextField(value = sq, onValueChange = { vm.studentQuery.value = it }, singleLine = true, label = { Text("اسم الطالب") }, modifier = Modifier.fillMaxWidth()) }
            if (sq.isNotBlank()) {
                item { StatCard(if (sres.isEmpty()) "لا توجد عمليات" else "${sres.size} عملية • إجمالي المدفوع", Money.format(sres.sumOf { it.amountPiasters }), Modifier.fillMaxWidth()) }
                items(sres, key = { "s${it.id}" }) { p -> PaymentRow(p, null, onClick = { onOpen(p.id) }, onStudentClick = p.studentId?.let { id -> { onStudentProfile(id) } }) }
            }
            item { SectionTitle("تقرير فترة زمنية") }
            item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { pick = 1 }, modifier = Modifier.weight(1f).heightIn(min = 56.dp)) { Text("من: ${TimeUtil.fmtDate(range.first)}") }
                OutlinedButton(onClick = { pick = 2 }, modifier = Modifier.weight(1f).heightIn(min = 56.dp)) { Text("إلى: ${TimeUtil.fmtDate(range.second)}") }
            } }
            if (range.second.isBefore(range.first)) item { Text("تاريخ النهاية قبل تاريخ البداية", color = MaterialTheme.colorScheme.error) }
            else {
                item { StatCard("${rres.size} عملية • إجمالي الفترة", Money.format(rres.sumOf { it.amountPiasters }), Modifier.fillMaxWidth()) }
                items(rres, key = { "r${it.id}" }) { p -> PaymentRow(p, null, onClick = { onOpen(p.id) }, onStudentClick = p.studentId?.let { id -> { onStudentProfile(id) } }) }
            }
        }
    }
    if (pick == 1) DatePickerDialogSimple(range.first, onPick = vm::setFrom, onDismiss = { pick = 0 })
    if (pick == 2) DatePickerDialogSimple(range.second, onPick = vm::setTo, onDismiss = { pick = 0 })
}
