package com.tahseel.students.data

import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/** One explicitly approved opening balance; absence means the cash balance is not established. */
@Entity(tableName = "cash_opening_balance")
data class CashOpeningBalance(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amountPiasters: Long,
    val effectiveAt: Long,
    val note: String,
    val updatedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "'cash'") val accountId: String = "cash"
)

/** Immutable physical cash count history. */
@Entity(tableName = "cash_counts", indices = [Index("countedAt")])
data class CashCount(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val countedAt: Long,
    val actualAmountPiasters: Long,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "'cash'") val accountId: String = "cash"
)

@Dao
interface CashControlDao {
    @Query("SELECT * FROM cash_opening_balance WHERE accountId=:accountId ORDER BY id DESC LIMIT 1")
    fun observeOpeningBalance(accountId: String): Flow<CashOpeningBalance?>

    @Query("SELECT * FROM cash_opening_balance WHERE accountId=:accountId ORDER BY id DESC")
    fun observeOpeningHistory(accountId: String): Flow<List<CashOpeningBalance>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun saveOpeningBalance(item: CashOpeningBalance)

    @Query("SELECT * FROM cash_counts WHERE accountId=:accountId ORDER BY countedAt DESC, id DESC")
    fun observeCounts(accountId: String): Flow<List<CashCount>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertCount(item: CashCount): Long
}
