package com.tahseel.students

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.tahseel.students.ui.AppNav
import com.tahseel.students.ui.TahseelTheme
import com.tahseel.students.util.AcademyProfileStore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as App
        AcademyProfileStore.refresh(this)
        setContent { TahseelTheme { AppNav(app) } }
    }
}
