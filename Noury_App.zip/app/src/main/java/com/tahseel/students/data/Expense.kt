package com.tahseel.students.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow
import androidx.room.Transaction

@Entity(tableName = "expenses", indices = [Index("spentAt"), Index("category"), Index("monthKey")])
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String,
    val amountPiasters: Long,
    val spentAt: Long,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "0") val paidAmountPiasters: Long = amountPiasters,
    @ColumnInfo(defaultValue = "0") val dueAt: Long = spentAt,
    @ColumnInfo(defaultValue = "''") val monthKey: String = "",
    @ColumnInfo(defaultValue = "NULL") val deletedAt: Long? = null
)

@Entity(tableName = "expense_payments", indices = [Index("expenseId"), Index("paidAt")], foreignKeys = [ForeignKey(entity = Expense::class, parentColumns = ["id"], childColumns = ["expenseId"], onDelete = ForeignKey.CASCADE)])
data class ExpensePayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val expenseId: Long,
    val amountPiasters: Long,
    val paidAt: Long,
    val paymentMethod: String,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val accountId: String? = "cash"
)

@Entity(tableName = "expense_month_locks")
data class ExpenseMonthLock(
    @PrimaryKey val monthKey: String,
    val closedAt: Long,
    val closedBy: String = "authorized_user",
    val note: String = ""
)

@Dao
interface ExpenseDao {
    @Insert suspend fun insert(item: Expense): Long
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertPayment(item: ExpensePayment): Long
    @Query("SELECT * FROM expense_payments ORDER BY paidAt DESC, id DESC") fun observeAllPayments(): Flow<List<ExpensePayment>>
    @Query("SELECT * FROM expense_payments WHERE expenseId = :expenseId ORDER BY paidAt DESC, id DESC") fun observePayments(expenseId: Long): Flow<List<ExpensePayment>>
    @Query("SELECT * FROM expenses WHERE id = :id LIMIT 1") suspend fun findById(id: Long): Expense?
    @Query("SELECT EXISTS(SELECT 1 FROM expense_month_locks WHERE monthKey = :monthKey)") suspend fun isMonthLocked(monthKey: String): Boolean
    @Query("SELECT * FROM expense_month_locks ORDER BY monthKey DESC") fun observeMonthLocks(): Flow<List<ExpenseMonthLock>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putMonthLock(lock: ExpenseMonthLock)
    @Query("DELETE FROM expense_month_locks WHERE monthKey = :monthKey") suspend fun removeMonthLock(monthKey: String): Int
    @Insert suspend fun insertExpenseAudit(log: AuditLog): Long
    @Query("SELECT * FROM audit_logs WHERE entityType IN ('expense','expense_month') ORDER BY createdAt DESC LIMIT 30") fun observeExpenseAudit(): Flow<List<AuditLog>>
    @Query("SELECT isActive FROM cash_accounts WHERE id = :accountId LIMIT 1") suspend fun cashAccountIsActive(accountId: String): Boolean?
    @Transaction
    suspend fun recordPayment(expenseId: Long, amountPiasters: Long, paidAt: Long, paymentMethod: String, note: String, accountId: String = "cash"): Long {
        require(amountPiasters > 0L) { "قيمة الدفعة يجب أن تكون أكبر من صفر" }
        require(paymentMethod.isNotBlank()) { "طريقة الدفع مطلوبة" }
        require(cashAccountIsActive(accountId) == true) { "حساب الصرف غير موجود أو غير نشط" }
        val expense = findById(expenseId) ?: error("بند المصروف غير موجود")
        require(expense.deletedAt == null) { "لا يمكن السداد لبند محذوف" }
        require(!isMonthLocked(expense.monthKey)) { "الشهر مغلق؛ أعد فتحه أولًا" }
        require(!expense.note.startsWith("HR_SYNC:") && expense.category != "المرتبات") { "لا يمكن تسجيل دفعة يدوية لبند المرتبات المُدار من شؤون العاملين" }
        val paid = observePaidPaymentsTotal(expenseId)
        val legacyPaid = (expense.paidAmountPiasters - paid).coerceAtLeast(0L)
        require(legacyPaid + paid + amountPiasters <= expense.amountPiasters.coerceAtLeast(0L)) { "قيمة الدفعة تتجاوز المتبقي من المصروف" }
        val id = insertPayment(ExpensePayment(expenseId = expenseId, amountPiasters = amountPiasters, paidAt = paidAt, paymentMethod = paymentMethod.trim(), note = note.trim(), accountId = accountId))
        val now = System.currentTimeMillis()
        update(expense.copy(paidAmountPiasters = expense.paidAmountPiasters + amountPiasters, updatedAt = now))
        insertExpenseAudit(AuditLog(entityType = "expense", entityId = expenseId, action = "payment_recorded", details = "actor=authorized_user;paymentId=$id;amount=$amountPiasters;method=${paymentMethod.trim()};account=$accountId;paidAt=$paidAt;month=${expense.monthKey}", createdAt = now))
        return id
    }
    @Query("SELECT COALESCE(SUM(amountPiasters), 0) FROM expense_payments WHERE expenseId = :expenseId")
    suspend fun observePaidPaymentsTotal(expenseId: Long): Long
    @Query("SELECT COUNT(*) FROM expense_payments WHERE expenseId = :expenseId")
    suspend fun countPayments(expenseId: Long): Int
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertIfMissing(item: Expense): Long
    @Update suspend fun update(item: Expense)

    @Transaction
    suspend fun saveEditable(item: Expense): Long {
        val now = System.currentTimeMillis()
        require(item.title.isNotBlank()) { "اسم المصروف مطلوب" }
        require(item.amountPiasters >= 0L) { "قيمة المصروف غير صحيحة" }
        require(!isMonthLocked(item.monthKey)) { "الشهر مغلق؛ أعد فتحه أولًا" }
        val old = if (item.id > 0L) findById(item.id) else null
        if (item.id > 0L) require(old != null && old.deletedAt == null) { "المصروف غير موجود أو محذوف" }
        if (old != null) {
            require(!old.note.startsWith("HR_SYNC:") && old.category != "المرتبات") { "هذا البند مُدار من شؤون العاملين" }
            require(item.amountPiasters >= old.paidAmountPiasters) { "لا يمكن خفض قيمة المصروف عن إجمالي المدفوع" }
            val updated = item.copy(createdAt = old.createdAt, paidAmountPiasters = old.paidAmountPiasters, updatedAt = now, deletedAt = null)
            update(updated)
            insertExpenseAudit(AuditLog(entityType = "expense", entityId = old.id, action = "updated", details = "actor=authorized_user;oldTitle=${old.title};newTitle=${updated.title};oldAmount=${old.amountPiasters};newAmount=${updated.amountPiasters};oldCategory=${old.category};newCategory=${updated.category};oldDueAt=${old.dueAt};newDueAt=${updated.dueAt};oldNote=${old.note};newNote=${updated.note};month=${old.monthKey}", createdAt = now))
            return old.id
        }
        val id = insert(item.copy(createdAt = now, updatedAt = now, paidAmountPiasters = 0L, deletedAt = null))
        insertExpenseAudit(AuditLog(entityType = "expense", entityId = id, action = "created", details = "actor=authorized_user;title=${item.title};amount=${item.amountPiasters};category=${item.category};month=${item.monthKey}", createdAt = now))
        return id
    }

    @Transaction
    suspend fun softDeleteExpense(id: Long): Boolean {
        val old = findById(id) ?: return false
        require(old.deletedAt == null) { "المصروف محذوف بالفعل" }
        require(!old.note.startsWith("HR_SYNC:") && old.category != "المرتبات") { "هذا البند مُدار من شؤون العاملين" }
        require(!isMonthLocked(old.monthKey)) { "الشهر مغلق؛ أعد فتحه أولًا" }
        val now = System.currentTimeMillis()
        update(old.copy(deletedAt = now, updatedAt = now))
        insertExpenseAudit(AuditLog(entityType = "expense", entityId = id, action = "soft_deleted", details = "actor=authorized_user;title=${old.title};amount=${old.amountPiasters};paid=${old.paidAmountPiasters};month=${old.monthKey};cash_history_preserved=true", createdAt = now))
        return true
    }

    @Transaction
    suspend fun closeMonth(monthKey: String, note: String = "") {
        require(monthKey.matches(Regex("\\d{4}-\\d{2}"))) { "صيغة الشهر غير صحيحة" }
        if (isMonthLocked(monthKey)) return
        val now = System.currentTimeMillis()
        putMonthLock(ExpenseMonthLock(monthKey, now, note = note.trim()))
        insertExpenseAudit(AuditLog(entityType = "expense_month", entityId = monthKey.replace("-", "").toLong(), action = "closed", details = "actor=authorized_user;month=$monthKey;note=${note.trim()}", createdAt = now))
    }

    @Transaction
    suspend fun reopenMonth(monthKey: String) {
        if (!isMonthLocked(monthKey)) return
        removeMonthLock(monthKey)
        insertExpenseAudit(AuditLog(entityType = "expense_month", entityId = monthKey.replace("-", "").toLong(), action = "reopened", details = "actor=authorized_user;month=$monthKey", createdAt = System.currentTimeMillis()))
    }
    @Query("SELECT * FROM expenses ORDER BY spentAt DESC, id DESC") fun observeAll(): Flow<List<Expense>>
    @Query("SELECT * FROM expenses WHERE (monthKey = :month OR (monthKey = '' AND spentAt >= :from AND spentAt < :until)) AND (title LIKE '%' || :title || '%' OR category = :category) ORDER BY CASE WHEN note LIKE 'HR_SYNC:%' THEN 0 ELSE 1 END, id ASC") suspend fun findMonthlyAll(month: String, title: String, category: String, from: Long, until: Long): List<Expense>
    @Query("SELECT * FROM expenses WHERE (monthKey = :month OR (monthKey = '' AND spentAt >= :from AND spentAt < :until)) AND title = :title AND category = :category LIMIT 1") suspend fun findMonthly(month: String, title: String, category: String, from: Long, until: Long): Expense?
    @Query("SELECT COALESCE(SUM(paidAmountPiasters), 0) FROM expenses WHERE spentAt >= :from AND spentAt < :until") fun observePaidTotal(from: Long, until: Long): Flow<Long>
    @Query("SELECT COALESCE(SUM(amountPiasters), 0) FROM expenses WHERE spentAt >= :from AND spentAt < :until") fun observeTotal(from: Long, until: Long): Flow<Long>
    @Query("SELECT COALESCE(SUM(amountPiasters - paidAmountPiasters), 0) FROM expenses WHERE spentAt >= :from AND spentAt < :until") fun observeOutstanding(from: Long, until: Long): Flow<Long>
    @Query("SELECT COALESCE(SUM(amountPiasters), 0) FROM expenses") fun observeGrandTotal(): Flow<Long>
}
