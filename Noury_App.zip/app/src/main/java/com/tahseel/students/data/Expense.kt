package com.tahseel.students.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow
import androidx.room.Transaction

@Entity(tableName = "expenses", indices = [Index("spentAt"), Index("category"), Index("monthKey")])
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String,
    val amountPiasters: Long,
    val spentAt: Long,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "0") val paidAmountPiasters: Long = amountPiasters,
    @ColumnInfo(defaultValue = "0") val dueAt: Long = spentAt,
    @ColumnInfo(defaultValue = "''") val monthKey: String = ""
)

@Entity(tableName = "expense_payments", indices = [Index("expenseId"), Index("paidAt")], foreignKeys = [ForeignKey(entity = Expense::class, parentColumns = ["id"], childColumns = ["expenseId"], onDelete = ForeignKey.CASCADE)])
data class ExpensePayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val expenseId: Long,
    val amountPiasters: Long,
    val paidAt: Long,
    val paymentMethod: String,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val accountId: String? = "cash"
)

@Dao
interface ExpenseDao {
    @Insert suspend fun insert(item: Expense): Long
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertPayment(item: ExpensePayment): Long
    @Query("SELECT * FROM expense_payments ORDER BY paidAt DESC, id DESC") fun observeAllPayments(): Flow<List<ExpensePayment>>
    @Query("SELECT * FROM expense_payments WHERE expenseId = :expenseId ORDER BY paidAt DESC, id DESC") fun observePayments(expenseId: Long): Flow<List<ExpensePayment>>
    @Query("SELECT * FROM expenses WHERE id = :id LIMIT 1") suspend fun findById(id: Long): Expense?
    @Query("SELECT isActive FROM cash_accounts WHERE id = :accountId LIMIT 1") suspend fun cashAccountIsActive(accountId: String): Boolean?
    @Transaction
    suspend fun recordPayment(expenseId: Long, amountPiasters: Long, paidAt: Long, paymentMethod: String, note: String, accountId: String = "cash"): Long {
        require(amountPiasters > 0L) { "قيمة الدفعة يجب أن تكون أكبر من صفر" }
        require(paymentMethod.isNotBlank()) { "طريقة الدفع مطلوبة" }
        require(cashAccountIsActive(accountId) == true) { "حساب الصرف غير موجود أو غير نشط" }
        val expense = findById(expenseId) ?: error("بند المصروف غير موجود")
        require(!expense.note.startsWith("HR_SYNC:") && expense.category != "المرتبات") { "لا يمكن تسجيل دفعة يدوية لبند المرتبات المُدار من شؤون العاملين" }
        val paid = observePaidPaymentsTotal(expenseId)
        val legacyPaid = (expense.paidAmountPiasters - paid).coerceAtLeast(0L)
        require(legacyPaid + paid + amountPiasters <= expense.amountPiasters.coerceAtLeast(0L)) { "قيمة الدفعة تتجاوز المتبقي من المصروف" }
        val id = insertPayment(ExpensePayment(expenseId = expenseId, amountPiasters = amountPiasters, paidAt = paidAt, paymentMethod = paymentMethod.trim(), note = note.trim(), accountId = accountId))
        update(expense.copy(paidAmountPiasters = expense.paidAmountPiasters + amountPiasters, updatedAt = System.currentTimeMillis()))
        return id
    }
    @Query("SELECT COALESCE(SUM(amountPiasters), 0) FROM expense_payments WHERE expenseId = :expenseId")
    suspend fun observePaidPaymentsTotal(expenseId: Long): Long
    @Query("SELECT COUNT(*) FROM expense_payments WHERE expenseId = :expenseId")
    suspend fun countPayments(expenseId: Long): Int
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertIfMissing(item: Expense): Long
    @Update suspend fun update(item: Expense)
    @Query("DELETE FROM expenses WHERE id = :id AND NOT EXISTS (SELECT 1 FROM expense_payments WHERE expenseId = :id)") suspend fun delete(id: Long): Int
    @Query("SELECT * FROM expenses ORDER BY spentAt DESC, id DESC") fun observeAll(): Flow<List<Expense>>
    @Query("SELECT * FROM expenses WHERE (monthKey = :month OR (monthKey = '' AND spentAt >= :from AND spentAt < :until)) AND (title LIKE '%' || :title || '%' OR category = :category) ORDER BY CASE WHEN note LIKE 'HR_SYNC:%' THEN 0 ELSE 1 END, id ASC") suspend fun findMonthlyAll(month: String, title: String, category: String, from: Long, until: Long): List<Expense>
    @Query("SELECT * FROM expenses WHERE (monthKey = :month OR (monthKey = '' AND spentAt >= :from AND spentAt < :until)) AND title = :title AND category = :category LIMIT 1") suspend fun findMonthly(month: String, title: String, category: String, from: Long, until: Long): Expense?
    @Query("SELECT COALESCE(SUM(paidAmountPiasters), 0) FROM expenses WHERE spentAt >= :from AND spentAt < :until") fun observePaidTotal(from: Long, until: Long): Flow<Long>
    @Query("SELECT COALESCE(SUM(amountPiasters), 0) FROM expenses WHERE spentAt >= :from AND spentAt < :until") fun observeTotal(from: Long, until: Long): Flow<Long>
    @Query("SELECT COALESCE(SUM(amountPiasters - paidAmountPiasters), 0) FROM expenses WHERE spentAt >= :from AND spentAt < :until") fun observeOutstanding(from: Long, until: Long): Flow<Long>
    @Query("SELECT COALESCE(SUM(amountPiasters), 0) FROM expenses") fun observeGrandTotal(): Flow<Long>
}
