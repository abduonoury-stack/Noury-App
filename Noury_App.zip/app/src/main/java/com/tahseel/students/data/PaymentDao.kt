package com.tahseel.students.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(p: Payment): Long

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertAll(list: List<Payment>)

    @Update(onConflict = OnConflictStrategy.ABORT)
    suspend fun update(p: Payment): Int

    @Query("UPDATE payments SET isCancelled = 1, cancelledAt = :cancelledAt, cancellationReason = :reason WHERE id = :id AND isCancelled = 0")
    suspend fun markCancelled(id: Long, cancelledAt: Long, reason: String): Int

    @Query("DELETE FROM payments")
    suspend fun deleteAll()

    @Query("SELECT * FROM payments ORDER BY createdAt DESC, id DESC")
    fun observeAll(): Flow<List<Payment>>

    @Query("SELECT * FROM payments ORDER BY createdAt ASC, id ASC")
    suspend fun getAllAsc(): List<Payment>

    @Query("SELECT * FROM payments WHERE id = :id")
    suspend fun getById(id: Long): Payment?

    @Query("SELECT * FROM payments WHERE id = :id")
    fun observeById(id: Long): Flow<Payment?>

    @Query("SELECT * FROM payments WHERE (studentId = :studentId OR (studentId IS NULL AND studentName = :studentName)) ORDER BY createdAt DESC, id DESC")
    fun observeForStudent(studentId: Long, studentName: String): Flow<List<Payment>>

    @Query("SELECT COALESCE(SUM(amountPiasters), 0) FROM payments WHERE isCancelled = 0")
    fun observeTotal(): Flow<Long>

    @Query("SELECT COUNT(*) FROM payments WHERE isCancelled = 0 AND amountPiasters > 0")
    fun observeCount(): Flow<Int>

    @Query("SELECT COALESCE(SUM(amountPiasters), 0) FROM payments WHERE isCancelled = 0 AND createdAt >= :from AND createdAt < :to")
    fun observeSumBetween(from: Long, to: Long): Flow<Long>

    @Query("SELECT * FROM payments WHERE isCancelled = 0 AND createdAt >= :from AND createdAt < :to ORDER BY createdAt DESC, id DESC")
    fun observeBetween(from: Long, to: Long): Flow<List<Payment>>

    @Query("SELECT * FROM payments WHERE isCancelled = 0 AND amountPiasters > 0 ORDER BY createdAt DESC, id DESC LIMIT 1")
    fun observeLast(): Flow<Payment?>
}
