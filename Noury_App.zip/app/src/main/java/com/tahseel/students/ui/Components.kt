package com.tahseel.students.ui

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.runtime.produceState
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tahseel.students.util.AcademyProfileStore
import com.tahseel.students.data.Payment
import com.tahseel.students.util.Money
import com.tahseel.students.util.TimeUtil
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScaffold(
    title: String,
    onBack: (() -> Unit)?,
    snackbarHost: @Composable () -> Unit = {},
    bottomBar: @Composable () -> Unit = {},
    showTopBar: Boolean = true,
    content: @Composable (PaddingValues) -> Unit
) {
    val academyName by AcademyProfileStore.name.collectAsState()
    Scaffold(
        topBar = { if (showTopBar) {
            Surface(color = Color(0xFFFBF8FF), shadowElevation = 3.dp, tonalElevation = 1.dp) {
            TopAppBar(
                title = {
                    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                        Text(title, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("Noury App  •  $academyName", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary.copy(alpha = 0.76f), letterSpacing = 0.2.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                },
                navigationIcon = {
                    if (onBack != null) IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    } else {
                        Image(painterResource(com.tahseel.students.R.drawable.canaria_logo), contentDescription = academyName, modifier = Modifier.padding(start = 12.dp).size(42.dp))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFFFBF8FF),
                    titleContentColor = MaterialTheme.colorScheme.primary,
                    navigationIconContentColor = MaterialTheme.colorScheme.primary
                ),
                modifier = Modifier.heightIn(min = 72.dp),
                windowInsets = TopAppBarDefaults.windowInsets
            )
            }
        } },
        snackbarHost = snackbarHost,
        bottomBar = bottomBar,
        containerColor = MaterialTheme.colorScheme.background,
        content = { innerPadding ->
            // One shared content width keeps every screen aligned on phones and tablets.
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                Box(Modifier.fillMaxHeight().widthIn(max = 760.dp).fillMaxWidth()) {
                    content(innerPadding)
                }
            }
        }
    )
}

@Composable
fun BigButton(text: String, icon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier, primary: Boolean = true, enabled: Boolean = true) {
    val shape = RoundedCornerShape(19.dp)
    val colors = if (primary) ButtonDefaults.buttonColors(
        containerColor = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.onPrimary
    ) else ButtonDefaults.filledTonalButtonColors(
        containerColor = MaterialTheme.colorScheme.primaryContainer,
        contentColor = MaterialTheme.colorScheme.primary
    )
    Button(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().heightIn(min = 60.dp),
        shape = shape,
        enabled = enabled,
        colors = colors,
        elevation = ButtonDefaults.buttonElevation(defaultElevation = if (primary) 3.dp else 1.dp, pressedElevation = 1.dp),
        border = if (primary) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = if (primary) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.14f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = if (primary) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(7.dp).size(21.dp)
            )
        }
        Spacer(Modifier.width(11.dp))
        Text(text, style = MaterialTheme.typography.labelLarge, maxLines = 2, textAlign = TextAlign.Center)
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier, big: Boolean = false) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.62f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 15.dp), horizontalAlignment = Alignment.Start, verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
            Text(
                value,
                style = if (big) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Row(Modifier.fillMaxWidth().padding(top = 13.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(color = MaterialTheme.colorScheme.secondary, shape = RoundedCornerShape(4.dp), modifier = Modifier.width(4.dp).height(25.dp)) {}
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
    }
}

/** Icon treatment shared across screens: a soft colored tile with a strong foreground glyph. */
@Composable
fun DuotoneIcon(
    icon: ImageVector,
    modifier: Modifier = Modifier,
    tint: Color = MaterialTheme.colorScheme.primary,
    containerColor: Color = MaterialTheme.colorScheme.primaryContainer,
    iconSize: androidx.compose.ui.unit.Dp = 23.dp,
    tileSize: androidx.compose.ui.unit.Dp = 44.dp
) {
    Surface(
        modifier = modifier.size(tileSize),
        shape = RoundedCornerShape(14.dp),
        color = containerColor
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(iconSize))
        }
    }
}

/** Reusable card shell for form groups, summaries and section content. */
@Composable
fun PremiumCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.62f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), content = content)
    }
}

@Composable
fun PaymentRow(p: Payment, serial: Int?, onClick: () -> Unit, onStudentClick: (() -> Unit)? = null) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.62f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            if (serial != null) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(44.dp)) {
                    Box(contentAlignment = Alignment.Center) { Text(serial.toString(), fontWeight = FontWeight.Bold) }
                }
                Spacer(Modifier.width(12.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(p.studentName, style = MaterialTheme.typography.titleMedium, color = if (onStudentClick != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface, modifier = if (onStudentClick != null) Modifier.clickable { onStudentClick() } else Modifier)
                Text("إيصال: ${p.receiptNo}", style = MaterialTheme.typography.bodyMedium)
                if (p.isCancelled) Text("ملغاة • لا تُحتسب ضمن الإيرادات", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.error)
                Text(TimeUtil.fmt(p.createdAt), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
            }
            Spacer(Modifier.width(8.dp))
            Text(Money.format(p.amountPiasters), style = MaterialTheme.typography.titleMedium, color = if (p.isCancelled) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
        }
    }
}

/** DatePicker يعمل بتواريخ UTC داخليًا؛ نحوّلها إلى LocalDate بدون انزياح. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DatePickerDialogSimple(initial: LocalDate, onPick: (LocalDate) -> Unit, onDismiss: () -> Unit) {
    val st = rememberDatePickerState(initialSelectedDateMillis = initial.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                st.selectedDateMillis?.let { onPick(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate()) }
                onDismiss()
            }) { Text("تأكيد") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    ) { DatePicker(state = st) }
}


/** صورة موحدة للطالب؛ عند غياب الصورة نعرض شخصية مرحة ثابتة مرتبطة بمعرّف الطالب. */
@Composable
fun StudentAvatar(photoUri: String?, size: androidx.compose.ui.unit.Dp, studentId: Long = 0L) {
    val context = LocalContext.current
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, photoUri) {
        value = withContext(Dispatchers.IO) {
            runCatching { photoUri?.takeIf { it.isNotBlank() }?.let { saved ->
                context.contentResolver.openInputStream(Uri.parse(saved))?.use { BitmapFactory.decodeStream(it) }
            } }.getOrNull()
        }
    }
    val mascots = listOf("👾", "🦖", "👽", "🐲", "👹", "🦄", "🐸", "🤖", "🐙", "🦊", "🐻", "🐵")
    val colors = listOf(0xFFFFE3A3, 0xFFB8F0EC, 0xFFD8E8FF, 0xFFE5F5B2, 0xFFF7D6EF, 0xFFFFE9B8)
    val index = ((studentId % mascots.size).toInt() + mascots.size) % mascots.size
    Surface(modifier = Modifier.size(size), shape = CircleShape, color = androidx.compose.ui.graphics.Color(colors[index % colors.size])) {
        if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription = "صورة الطالب", modifier = Modifier.fillMaxSize().clip(CircleShape), contentScale = ContentScale.Crop)
        else Box(contentAlignment = Alignment.Center) { Text(mascots[index], fontSize = (size.value * 0.62f).sp) }
    }
}
