package com.tahseel.students.util

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** One source of truth for the academy name shown throughout the app and on generated documents. */
object AcademyProfileStore {
    const val DEFAULT_NAME = "Little Dreams Academy"
    private const val PREFS_NAME = "receipt_profile"

    private val mutableName = MutableStateFlow(DEFAULT_NAME)
    val name: StateFlow<String> = mutableName.asStateFlow()

    private fun preferences(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** Load persisted profile at app start or after a backup restore. */
    fun refresh(context: Context): String {
        val saved = preferences(context).getString("name", DEFAULT_NAME)
            ?.trim().orEmpty().ifBlank { DEFAULT_NAME }
        mutableName.value = saved
        return saved
    }

    /** Read the latest persisted name when generating an external action/message. */
    fun getName(context: Context): String = refresh(context)

    /** Save profile data and publish name changes immediately to every observing screen. */
    fun save(context: Context, name: String, address: String, phone: String): String {
        val normalizedName = name.trim().ifBlank { DEFAULT_NAME }
        preferences(context).edit()
            .putString("name", normalizedName)
            .putString("address", address.trim())
            .putString("phone", phone.trim())
            .apply()
        mutableName.value = normalizedName
        return normalizedName
    }
}
