package com.tahseel.students.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tahseel.students.data.Payment
import com.tahseel.students.data.PaymentRepository
import com.tahseel.students.util.TextUtil
import com.tahseel.students.util.TimeUtil
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import java.time.LocalDate
import java.time.YearMonth

enum class Period { ALL, DAY, MONTH }

data class LedgerFilter(
    val query: String = "",
    val period: Period = Period.ALL,
    val day: LocalDate = LocalDate.now(),
    val month: YearMonth = YearMonth.now()
)

data class LedgerRow(val payment: Payment, val serial: Int)

data class LedgerState(
    val rows: List<LedgerRow> = emptyList(),
    val total: Long = 0,
    val allCount: Int = 0
)

class LedgerViewModel(repo: PaymentRepository) : ViewModel() {
    private val _filter = MutableStateFlow(LedgerFilter())
    val filter: StateFlow<LedgerFilter> = _filter

    val state: StateFlow<LedgerState> = combine(repo.dao.observeAll(), _filter) { all, f ->
        // all مرتبة من الأحدث للأقدم، فالمسلسل = عدد العمليات - الفهرس
        val n = all.size
        val numbered = all.mapIndexed { i, p -> LedgerRow(p, n - i) }
        val q = TextUtil.normalize(f.query)
        val (from, to) = when (f.period) {
            Period.ALL -> 0L to Long.MAX_VALUE
            Period.DAY -> TimeUtil.startOf(f.day) to TimeUtil.startOf(f.day.plusDays(1))
            Period.MONTH -> TimeUtil.startOfMonth(f.month) to TimeUtil.startOfNextMonth(f.month)
        }
        val rows = numbered.filter { r ->
            r.payment.createdAt in from until to &&
                (q.isEmpty() ||
                    TextUtil.normalize(r.payment.studentName).contains(q) ||
                    r.payment.receiptNo.lowercase().contains(q))
        }
        LedgerState(rows, rows.filterNot { it.payment.isCancelled }.sumOf { it.payment.amountPiasters }, n)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), LedgerState())

    fun setQuery(q: String) = _filter.update { it.copy(query = q) }
    fun setPeriod(p: Period) = _filter.update { it.copy(period = p) }
    fun setDay(d: LocalDate) = _filter.update { it.copy(day = d) }
    fun shiftDay(delta: Long) = _filter.update { it.copy(day = it.day.plusDays(delta)) }
    fun shiftMonth(delta: Long) = _filter.update { it.copy(month = it.month.plusMonths(delta)) }
}
