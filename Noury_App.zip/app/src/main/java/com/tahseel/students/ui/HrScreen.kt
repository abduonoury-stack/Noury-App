package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tahseel.students.data.*
import com.tahseel.students.util.Money
import com.tahseel.students.vm.HrViewModel
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

private val hrRoles = listOf("مديرة", "مدرسة", "مشرفة", "ناني", "عاملة نظافة", "سائق", "محاسبة", "إدارية", "أخرى")
private val leaveTypes = listOf("سنوية", "عارضة", "مرضية", "بدون مرتب", "أمومة", "أخرى")
private val arDate: String get() = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HrScreen(vm: HrViewModel, onBack: () -> Unit) {
    val cashAccounts by vm.cashAccounts.collectAsState(); val workdays by vm.workdays.collectAsState(); val employees by vm.employees.collectAsState(); val attendance by vm.attendance.collectAsState(); val selectedDate by vm.selectedDate.collectAsState(); val monthlyAttendance by vm.monthlyAttendance.collectAsState(); val leaves by vm.leaves.collectAsState(); val loans by vm.loans.collectAsState(); val payroll by vm.payroll.collectAsState(); val payrollPayments by vm.payrollPayments.collectAsState(); val payrollReversals by vm.payrollReversals.collectAsState(); val payrollRecoveries by vm.payrollRecoveries.collectAsState(); val payrollMessage by vm.payrollMessage.collectAsState(); val adjustments by vm.adjustments.collectAsState(); val absenceCount by vm.absenceCount.collectAsState(); val month by vm.month.collectAsState()
    LaunchedEffect(Unit) { vm.refreshWorkdays() }
    var section by remember { mutableStateOf("العاملين") }
    var editEmployee by remember { mutableStateOf<Employee?>(null) }; var showEmployee by remember { mutableStateOf(false) }
    var showLeave by remember { mutableStateOf(false) }; var showLoan by remember { mutableStateOf(false) }; var showAdjustment by remember { mutableStateOf(false) }
    var selectedEmployee by remember { mutableStateOf<Long?>(null) }
    var employeeToArchive by remember { mutableStateOf<Employee?>(null) }
    AppScaffold("شؤون العاملين HR", onBack) { pad ->
        Column(
            Modifier.padding(pad).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Card(shape = MaterialTheme.shapes.large, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("إدارة الموارد البشرية", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("ملفات الموظفين • الرواتب • الحضور • الإجازات • السلف", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatCard("إجمالي العاملين", employees.count { it.status != "deleted" }.toString(), Modifier.weight(1f))
                        StatCard("على رأس العمل", employees.count { it.status == "active" }.toString(), Modifier.weight(1f))
                    }
                }
            }
            // تبويبات قابلة للتمرير أفقيًا حتى لا تختفي الأقسام على الشاشات الصغيرة.
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("العاملين", "الحضور", "الإجازات", "المرتبات", "السلف والجزاءات", "التقارير").forEach { label ->
                    FilterChip(selected = section == label, onClick = { section = label }, label = { Text(label, maxLines = 1) })
                }
            }
            when (section) {
                "العاملين" -> {
                    HrEmployeesSection(
                        employees = employees,
                        onAdd = { editEmployee = null; showEmployee = true },
                        onEdit = { employee -> editEmployee = employee; showEmployee = true },
                        onLeave = { employeeId -> selectedEmployee = employeeId; showLeave = true },
                        onLoan = { employeeId -> selectedEmployee = employeeId; showLoan = true },
                        onArchive = { employeeToArchive = it },
                        onToggleStatus = vm::toggleEmployeeStatus
                    )
                }
                "الحضور" -> {
                    HrAttendanceSection(
                        employees = employees,
                        attendance = attendance,
                        monthlyAttendance = monthlyAttendance,
                        selectedDate = selectedDate,
                        month = month,
                        workdays = workdays,
                        onMonthChange = vm::changeMonth,
                        onSelectDate = vm::selectDate,
                        onSetAttendance = { employee, status, date -> vm.setAttendance(employee, status, date) },
                        onSetTimes = { employee, checkIn, checkOut, late, date -> vm.setAttendanceTimes(employee, checkIn, checkOut, late, date) }
                    )
                }
                "الإجازات" -> {
                    HrLeavesSection(
                        employees = employees,
                        leaves = leaves,
                        onNewLeave = { selectedEmployee = null; showLeave = true },
                        onDecision = vm::decideLeave
                    )
                }
                "المرتبات" -> {
                    MonthSelector(month, vm::changeMonth)
                    HrPayrollSection(
                        employees = employees,
                        payroll = payroll,
                        payments = payrollPayments,
                        reversals = payrollReversals,
                        recoveries = payrollRecoveries,
                        monthlyAttendance = monthlyAttendance,
                        workdays = workdays,
                        message = payrollMessage,
                        cashAccounts = cashAccounts,
                        onGenerate = vm::generatePayroll,
                        onRecordPayment = vm::recordPayrollPayment,
                        onVoidOrCorrect = vm::voidOrCorrectPayrollPayment,
                        onReversePaid = { payment, returned, account, reason, note -> vm.reversePaidPayrollPayment(payment, returned, account, reason, note) },
                        onRecordRecovery = vm::recordPayrollRecovery
                    )
                }
                "السلف والجزاءات" -> {
                    MonthSelector(month, vm::changeMonth)
                    HrLoansAdjustmentsSection(
                        employees = employees,
                        loans = loans,
                        adjustments = adjustments,
                        onAddLoan = { selectedEmployee = null; showLoan = true },
                        onAddAdjustment = { selectedEmployee = null; showAdjustment = true }
                    )
                }
                else -> {
                    HrReportsSection(
                        month = month,
                        employees = employees,
                        absenceCount = monthlyAttendance.count { it.status == "absent" && runCatching { LocalDate.parse(it.workDate).dayOfWeek in workdays }.getOrDefault(false) },
                        leaves = leaves,
                        payroll = payroll,
                        payrollPayments = payrollPayments,
                        loans = loans,
                        onMonthChange = vm::changeMonth
                    )
                }
            }
        }
    }
    if (employeeToArchive != null) AlertDialog(
        onDismissRequest = { employeeToArchive = null },
        title = { Text("أرشفة ملف الموظف؟") },
        text = { Text("سيختفي ${employeeToArchive?.fullName} من قائمة العاملين النشطين، لكن ستظل سجلات الحضور والمرتبات والسلف محفوظة في التقارير. لا يتم حذف البيانات المالية نهائيًا.") },
        confirmButton = { TextButton(onClick = { employeeToArchive?.let(vm::archiveEmployee); employeeToArchive = null }) { Text("تأكيد الأرشفة") } },
        dismissButton = { TextButton(onClick = { employeeToArchive = null }) { Text("إلغاء") } }
    )
    if (showEmployee) EmployeeDialog(editEmployee, { showEmployee = false }) { v -> vm.saveEmployee(editEmployee, v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8], v[9], v[10], v[11], v[12], v[13], v[14].toLongOrNull() ?: 0, v[15], v[16], v[17]); showEmployee = false }
    if (showLeave) LeaveDialog(employees, selectedEmployee, { showLeave = false }) { id, type, from, until, days, reason -> vm.saveLeave(id, type, from, until, days, reason); showLeave = false }
    if (showLoan) LoanDialog(employees, selectedEmployee, month.toString(), cashAccounts, { showLoan = false }) { id, amount, installment, m, note, accountId, issuedAt -> vm.addLoan(id, amount, installment, m, note, accountId, issuedAt); showLoan = false }
    if (showAdjustment) AdjustmentDialog(employees, selectedEmployee, { showAdjustment = false }) { id, type, amount, reason -> vm.addAdjustment(id, type, amount, reason); showAdjustment = false }
}

@Composable internal fun MonthSelector(month: YearMonth, onChange: (YearMonth) -> Unit) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) { TextButton(onClick = { onChange(month.minusMonths(1)) }) { Text("‹ السابق") }; Text(month.format(DateTimeFormatter.ofPattern("yyyy / MM")), style = MaterialTheme.typography.titleMedium); TextButton(onClick = { onChange(month.plusMonths(1)) }) { Text("التالي ›") } } }
@Composable private fun EmptyHr(text: String) { Card { Text(text, Modifier.padding(18.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) } }

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun EmployeeDialog(old: Employee?, close: () -> Unit, save: (List<String>) -> Unit) {
    var name by remember { mutableStateOf(old?.fullName ?: "") }; var role by remember { mutableStateOf(old?.jobTitle ?: hrRoles.first()) }; var phone by remember { mutableStateOf(old?.phone ?: "") }; var whatsapp by remember { mutableStateOf(old?.whatsapp ?: "") }; var address by remember { mutableStateOf(old?.address ?: "") }; var nid by remember { mutableStateOf(old?.nationalId ?: "") }; var birth by remember { mutableStateOf(old?.birthDate ?: "") }; var hire by remember { mutableStateOf(old?.hireDate ?: arDate) }; var contract by remember { mutableStateOf(old?.contractType ?: "دائم") }; var end by remember { mutableStateOf(old?.contractEndDate ?: "") }; var dept by remember { mutableStateOf(old?.department ?: "") }; var start by remember { mutableStateOf(old?.workStart ?: "08:00") }; var finish by remember { mutableStateOf(old?.workEnd ?: "16:00") }; var days by remember { mutableStateOf(old?.weeklyDays ?: "السبت-الخميس") }; var salary by remember { mutableStateOf(old?.baseSalaryPiasters?.let { String.format(Locale.US, "%.2f", it / 100.0) } ?: "") }; var emergency by remember { mutableStateOf(old?.emergencyName ?: "") }; var emergencyPhone by remember { mutableStateOf(old?.emergencyPhone ?: "") }; var notes by remember { mutableStateOf(old?.notes ?: "") }
    AlertDialog(onDismissRequest = close, title = { Text(if (old == null) "ملف موظف جديد" else "تعديل ملف الموظف") }, text = { Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        HrField(name, { name = it }, "الاسم رباعي *"); Text("المسمى الوظيفي"); var expanded by remember { mutableStateOf(false) }; ExposedDropdownMenuBox(expanded, { expanded = !expanded }) { OutlinedTextField(role, {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text("المسمى الوظيفي") }); ExposedDropdownMenu(expanded, { expanded = false }) { hrRoles.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { role = it; expanded = false }) } } }
        HrField(phone, { phone = it }, "رقم الموبايل *"); HrField(whatsapp, { whatsapp = it }, "رقم واتساب (اختياري)"); HrField(address, { address = it }, "العنوان"); HrField(nid, { nid = it }, "الرقم القومي"); HrField(birth, { birth = it }, "تاريخ الميلاد YYYY-MM-DD"); HrField(hire, { hire = it }, "تاريخ التعيين YYYY-MM-DD *"); HrField(contract, { contract = it }, "نوع التعاقد"); HrField(end, { end = it }, "نهاية العقد إن وجدت"); HrField(dept, { dept = it }, "القسم / مكان العمل"); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { HrField(start, { start = it }, "بداية الدوام", Modifier.weight(1f)); HrField(finish, { finish = it }, "نهاية الدوام", Modifier.weight(1f)) }; Text("أيام العمل موحدة لجميع العاملين حسب إعدادات الأكاديمية.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary); HrField(salary, { salary = it }, "المرتب الأساسي بالجنيه *"); HrField(emergency, { emergency = it }, "اسم شخص للطوارئ"); HrField(emergencyPhone, { emergencyPhone = it }, "هاتف الطوارئ"); HrField(notes, { notes = it }, "ملاحظات")
    } }, confirmButton = { TextButton(enabled = name.isNotBlank() && phone.isNotBlank() && hire.isNotBlank() && Money.parse(salary) != null, onClick = { save(listOf(name, role, phone, whatsapp, address, nid, birth, hire, contract, end, dept, start, finish, days, (Money.parse(salary) ?: 0L).toString(), emergency, emergencyPhone, notes)) }) { Text("حفظ الملف") } }, dismissButton = { TextButton(onClick = close) { Text("إلغاء") } })
}

@Composable private fun HrField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier) { OutlinedTextField(value, onChange, modifier = modifier.fillMaxWidth(), label = { Text(label) }, singleLine = true) }

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun LeaveDialog(employees: List<Employee>, preset: Long?, close: () -> Unit, save: (Long, String, String, String, Double, String) -> Unit) {
    var id by remember { mutableStateOf(preset ?: employees.firstOrNull()?.id ?: 0L) }; var type by remember { mutableStateOf(leaveTypes.first()) }; var from by remember { mutableStateOf(arDate) }; var until by remember { mutableStateOf(arDate) }; var days by remember { mutableStateOf("1") }; var reason by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = close, title = { Text("تسجيل طلب إجازة") }, text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) { EmployeePicker(employees, id) { id = it }; HrField(type, { type = it }, "نوع الإجازة"); HrField(from, { from = it }, "من تاريخ YYYY-MM-DD"); HrField(until, { until = it }, "إلى تاريخ YYYY-MM-DD"); HrField(days, { days = it }, "عدد الأيام"); HrField(reason, { reason = it }, "سبب الإجازة") } }, confirmButton = { TextButton(enabled = id > 0 && days.toDoubleOrNull() != null, onClick = { save(id, type, from, until, days.toDoubleOrNull() ?: 1.0, reason) }) { Text("حفظ الطلب") } }, dismissButton = { TextButton(onClick = close) { Text("إلغاء") } })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun LoanDialog(employees: List<Employee>, preset: Long?, month: String, cashAccounts: List<CashAccount>, close: () -> Unit, save: (Long, Long, Long, String, String, String, Long) -> Unit) {
    var id by remember { mutableStateOf(preset ?: employees.firstOrNull()?.id ?: 0L) }; var amount by remember { mutableStateOf("") }; var installment by remember { mutableStateOf("") }; var start by remember { mutableStateOf(month) }; var note by remember { mutableStateOf("") }; var accountId by remember { mutableStateOf("cash") }; var issueDate by remember { mutableStateOf(arDate) }
    AlertDialog(onDismissRequest = close, title = { Text("تسجيل سلفة موظف") }, text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) { EmployeePicker(employees, id) { id = it }; HrField(amount, { amount = it }, "قيمة السلفة بالجنيه"); HrField(installment, { installment = it }, "قيمة القسط الشهري بالجنيه"); HrField(issueDate, { issueDate = it }, "تاريخ صرف السلفة YYYY-MM-DD"); HrField(start, { start = it }, "بداية الخصم YYYY-MM"); CashAccountDropdown(accounts = cashAccounts, selectedId = accountId, onSelected = { accountId = it }, label = "حساب صرف السلفة"); HrField(note, { note = it }, "ملاحظات") } }, confirmButton = { TextButton(enabled = id > 0 && Money.parse(amount) != null && Money.parse(installment) != null && (Money.parse(installment) ?: 0L) <= (Money.parse(amount) ?: 0L) && runCatching { YearMonth.parse(start) }.isSuccess && runCatching { LocalDate.parse(issueDate) }.isSuccess, onClick = { val issuedAt = LocalDate.parse(issueDate).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli(); save(id, Money.parse(amount) ?: 0L, Money.parse(installment) ?: 0L, start, note, accountId, issuedAt) }) { Text("حفظ السلفة") } }, dismissButton = { TextButton(onClick = close) { Text("إلغاء") } })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun AdjustmentDialog(employees: List<Employee>, preset: Long?, close: () -> Unit, save: (Long, String, Long, String) -> Unit) {
    var id by remember { mutableStateOf(preset ?: employees.firstOrNull()?.id ?: 0L) }; var type by remember { mutableStateOf("bonus") }; var amount by remember { mutableStateOf("") }; var reason by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = close, title = { Text("مكافأة أو جزاء") }, text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) { EmployeePicker(employees, id) { id = it }; Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { FilterChip(type == "bonus", { type = "bonus" }, label = { Text("مكافأة") }); FilterChip(type == "allowance", { type = "allowance" }, label = { Text("بدل") }); FilterChip(type == "penalty", { type = "penalty" }, label = { Text("جزاء / خصم") }) }; HrField(amount, { amount = it }, "القيمة بالجنيه"); HrField(reason, { reason = it }, "السبب *") } }, confirmButton = { TextButton(enabled = id > 0 && reason.isNotBlank() && Money.parse(amount) != null, onClick = { save(id, type, Money.parse(amount) ?: 0L, reason) }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = close) { Text("إلغاء") } })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun EmployeePicker(employees: List<Employee>, selected: Long, onSelect: (Long) -> Unit) { var expanded by remember { mutableStateOf(false) }; val current = employees.firstOrNull { it.id == selected }; ExposedDropdownMenuBox(expanded, { expanded = !expanded }) { OutlinedTextField(current?.fullName ?: "اختر الموظف", {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text("الموظف") }); ExposedDropdownMenu(expanded, { expanded = false }) { employees.filter { it.status != "deleted" }.forEach { DropdownMenuItem(text = { Text(it.fullName) }, onClick = { onSelect(it.id); expanded = false }) } } } }
