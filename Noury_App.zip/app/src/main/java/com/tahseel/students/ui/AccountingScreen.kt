package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tahseel.students.data.AccountingDao
import com.tahseel.students.util.Money
import kotlinx.coroutines.flow.flatMapLatest

@Composable
fun AccountingScreen(dao: AccountingDao, onBack: () -> Unit, onPayroll: () -> Unit) {
    val accounts by dao.observeAccounts().collectAsState(initial = emptyList())
    val expenses by dao.observeExpenses().collectAsState(initial = emptyList())
    val journal by dao.observeJournal().collectAsState(initial = emptyList())
    val vendors by dao.observeVendors().collectAsState(initial = emptyList())
    var section by remember { mutableStateOf("overview") }
    var seeded by remember { mutableStateOf(false) }
    LaunchedEffect(accounts) {
        if (accounts.isEmpty() && !seeded) {
            seeded = true
            AccountingDao.DEFAULT_CHART.forEach { account -> runCatching { dao.insertAccount(account) } }
        }
    }
    AppScaffold(title = "الإدارة المالية والمحاسبة", onBack = onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("نظام محاسبي بالقيد المزدوج", style = MaterialTheme.typography.titleMedium)
            Text("النسخة التأسيسية — كل المبالغ بالجنيه المصري، والتسجيل المحاسبي يعتمد على المدين والدائن.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = section == "overview", onClick = { section = "overview" }, label = { Text("الرئيسية") })
                FilterChip(selected = section == "accounts", onClick = { section = "accounts" }, label = { Text("دليل الحسابات") })
                FilterChip(selected = section == "journal", onClick = { section = "journal" }, label = { Text("اليومية") })
                FilterChip(selected = section == "expenses", onClick = { section = "expenses" }, label = { Text("المصروفات") })
            }
            when (section) {
                "overview" -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SummaryTile("الحسابات", accounts.size.toString(), Icons.Default.AccountBalance, Modifier.weight(1f))
                        SummaryTile("القيود", journal.size.toString(), Icons.Default.ReceiptLong, Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SummaryTile("فواتير المصروفات", expenses.size.toString(), Icons.Default.Payments, Modifier.weight(1f))
                        SummaryTile("الموردون", vendors.size.toString(), Icons.Default.Assessment, Modifier.weight(1f))
                    }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("مراحل التفعيل", style = MaterialTheme.typography.titleSmall)
                            Text("• تم إنشاء دليل الحسابات الأساسي.")
                            Text("• تم إنشاء جداول اليومية والسطور المدينة والدائنة.")
                            Text("• تم تجهيز الفواتير والدفعات والموردين.")
                            Text("• ترحيل الأرصدة الافتتاحية وربط مصادر التحصيل والمرتبات يأتي بعد اعتماد سياسة الحسابات وتاريخ القطع.")
                        }
                    }
                }
                "accounts" -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(accounts, key = { it.id }) { a ->
                        ListItem(headlineContent = { Text("${a.code} — ${a.name}") }, supportingContent = { Text("${accountTypeLabel(a.type)} • ${if (a.isPosting) "حساب حركة" else "حساب رئيسي"}") }, trailingContent = { if (!a.isActive) Text("موقوف", color = MaterialTheme.colorScheme.error) })
                        HorizontalDivider()
                    }
                }
                "journal" -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (journal.isEmpty()) item { Text("لا توجد قيود مرحّلة حتى الآن. لن ننشئ قيودًا تاريخية تلقائيًا.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    items(journal, key = { it.id }) { e ->
                        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                            Text("${e.entryNo} • ${e.description}", style = MaterialTheme.typography.titleSmall)
                            Text("${e.periodKey} • ${e.sourceType} • ${e.status}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } }
                    }
                }
                "expenses" -> {
                    Text("إدارة المصروفات الجديدة قيد البناء. لن يتم تسجيل فاتورة إلا بعد تفعيل دورة القيد والاستحقاق والسداد.")
                    Text("عدد الفواتير الجديدة: ${expenses.size}")
                }
            }
        }
    }
}

@Composable
private fun SummaryTile(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Text(value, style = MaterialTheme.typography.headlineSmall)
        Text(title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    } }
}

private fun accountTypeLabel(type: String) = when (type) {
    "asset" -> "أصول"; "liability" -> "التزامات"; "equity" -> "حقوق ملكية"; "revenue" -> "إيرادات"; "expense" -> "مصروفات"; else -> type
}

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
@Composable
fun FinancePayrollScreen(hrDao: com.tahseel.students.data.HrDao, onBack: () -> Unit) {
    val month = remember { kotlinx.coroutines.flow.MutableStateFlow(java.time.YearMonth.now()) }
    val selected by month.collectAsState()
    val payroll by month.flatMapLatest { hrDao.observePayroll(it.toString()) }.collectAsState(initial = emptyList())
    val employees by hrDao.observeEmployees().collectAsState(initial = emptyList())
    val payments by month.flatMapLatest { hrDao.observePayrollPayments(it.toString()) }.collectAsState(initial = emptyList())
    val names = employees.associate { it.id to it.fullName }
    val total = payroll.sumOf { it.netPiasters }
    val paid = payroll.sumOf { row -> payments.filter { it.payrollId == row.id && it.status == "active" }.sumOf { it.amountPiasters } }
    AppScaffold(title = "المرتبات — الإدارة المالية", onBack = onBack) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { month.value = selected.minusMonths(1) }) { Text("‹ السابق") }
                    Text(selected.toString(), style = MaterialTheme.typography.titleLarge)
                    TextButton(onClick = { month.value = selected.plusMonths(1) }) { Text("التالي ›") }
                }
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("إجمالي صافي المرتبات: ${Money.format(total)}")
                    Text("المدفوع فعليًا: ${Money.format(paid)}")
                    Text("المتبقي: ${Money.format((total - paid).coerceAtLeast(0L))}")
                    Text("مصدر بيانات الرواتب: شؤون العاملين — لا يتم إنشاء كشف راتب مكرر هنا.", style = MaterialTheme.typography.bodySmall)
                } }
            }
            items(payroll, key = { it.id }) { row ->
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(names[row.employeeId] ?: "موظف #${row.employeeId}", style = MaterialTheme.typography.titleSmall)
                    Text("الصافي: ${Money.format(row.netPiasters)} • المدفوع: ${Money.format(payments.filter { it.payrollId == row.id && it.status == "active" }.sumOf { it.amountPiasters })}")
                    Text("المتبقي: ${Money.format((row.netPiasters - payments.filter { it.payrollId == row.id && it.status == "active" }.sumOf { it.amountPiasters }).coerceAtLeast(0L))}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } }
            }
        }
    }
}
