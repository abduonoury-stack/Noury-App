package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tahseel.students.data.AccountingDao
import com.tahseel.students.data.AccountingVendor
import com.tahseel.students.data.AccountingExpense
import com.tahseel.students.util.Money
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.launch

@Composable
fun AccountingScreen(dao: AccountingDao, onBack: () -> Unit, onPayroll: () -> Unit) {
    val accounts by dao.observeAccounts().collectAsState(initial = emptyList())
    val expenses by dao.observeExpenses().collectAsState(initial = emptyList())
    val journal by dao.observeJournal().collectAsState(initial = emptyList())
    val vendors by dao.observeVendors().collectAsState(initial = emptyList())
    val trialBalance by dao.observeTrialBalance().collectAsState(initial = emptyList())
    val periods by dao.observePeriods().collectAsState(initial = emptyList())
    var ledgerAccountId by remember { mutableLongStateOf(0L) }
    val ledgerRows by remember(ledgerAccountId) { dao.observeAccountLedger(ledgerAccountId) }.collectAsState(initial = emptyList())
    val cashAccounts by dao.observeActiveCashAccounts().collectAsState(initial = emptyList())
    val screenScope = rememberCoroutineScope()
    var section by remember { mutableStateOf("overview") }
    LaunchedEffect(Unit) {
        val now = java.time.YearMonth.now()
        val start = now.atDay(1).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        val end = now.atEndOfMonth().atTime(23, 59, 59).atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        dao.ensurePeriod(now.toString(), start, end)
    }
    AppScaffold(title = "الإدارة المالية والمحاسبة", onBack = onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("نظام محاسبي بالقيد المزدوج", style = MaterialTheme.typography.titleMedium)
            Text("النسخة التأسيسية — كل المبالغ بالجنيه المصري، والتسجيل المحاسبي يعتمد على المدين والدائن.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = section == "overview", onClick = { section = "overview" }, label = { Text("الرئيسية") })
                FilterChip(selected = section == "accounts", onClick = { section = "accounts" }, label = { Text("دليل الحسابات") })
                FilterChip(selected = section == "journal", onClick = { section = "journal" }, label = { Text("اليومية") })
                FilterChip(selected = section == "expenses", onClick = { section = "expenses" }, label = { Text("المصروفات") })
                FilterChip(selected = section == "trial", onClick = { section = "trial" }, label = { Text("ميزان المراجعة") })
                FilterChip(selected = section == "income", onClick = { section = "income" }, label = { Text("قائمة الدخل") })
                FilterChip(selected = section == "position", onClick = { section = "position" }, label = { Text("المركز المالي") })
                FilterChip(selected = section == "payroll", onClick = onPayroll, label = { Text("المرتبات") })
                FilterChip(selected = section == "ledger", onClick = { section = "ledger" }, label = { Text("دفتر الأستاذ") })
                FilterChip(selected = section == "vendors", onClick = { section = "vendors" }, label = { Text("الموردون") })
                FilterChip(selected = section == "periods", onClick = { section = "periods" }, label = { Text("الفترات والافتتاحي") })
            }
            when (section) {
                "overview" -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SummaryTile("الحسابات", accounts.size.toString(), Icons.Default.AccountBalance, Modifier.weight(1f))
                        SummaryTile("القيود", journal.size.toString(), Icons.Default.ReceiptLong, Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SummaryTile("فواتير المصروفات", expenses.size.toString(), Icons.Default.Payments, Modifier.weight(1f))
                        SummaryTile("الموردون", vendors.size.toString(), Icons.Default.Assessment, Modifier.weight(1f))
                    }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("مراحل التفعيل", style = MaterialTheme.typography.titleSmall)
                            Text("• تم إنشاء دليل الحسابات الأساسي.")
                            Text("• تم إنشاء جداول اليومية والسطور المدينة والدائنة.")
                            Text("• تم تجهيز الفواتير والدفعات والموردين.")
                            Text("• ربط صرف السلف واستحقاق وصرف المرتبات بالقيود المحاسبية.")
                            Text("• إضافة كشف الأستاذ وإدارة الموردين وإغلاق الفترات وترحيل الأرصدة الافتتاحية من هذه الشاشة.")
                            Text("• المطابقة البنكية والتدفقات النقدية الشاملة وربط عكس الدفعات ما زالت ضمن الأعمال المتبقية.")
                        }
                    }
                }
                "accounts" -> {
                    accounts.forEach { a ->
                        ListItem(headlineContent = { Text("${a.code} — ${a.name}", maxLines = 2) }, supportingContent = { Text("${accountTypeLabel(a.type)} • ${if (a.isPosting) "حساب حركة" else "حساب رئيسي"}") }, trailingContent = { if (!a.isActive) Text("موقوف", color = MaterialTheme.colorScheme.error) })
                        HorizontalDivider()
                    }
                }
                "journal" -> {
                    if (journal.isEmpty()) Text("لا توجد قيود مرحّلة حتى الآن. لن ننشئ قيودًا تاريخية تلقائيًا.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    journal.forEach { e ->
                        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                            Text("${e.entryNo} • ${e.description}", style = MaterialTheme.typography.titleSmall)
                            Text("${e.periodKey} • ${e.sourceType} • ${e.status}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } }
                    }
                }
                "expenses" -> {
                    var title by remember { mutableStateOf("") }
                    var amount by remember { mutableStateOf("") }
                    var dueDays by remember { mutableStateOf("0") }
                    var vendorName by remember { mutableStateOf("") }
                    var selectedExpenseAccount by remember { mutableLongStateOf(0L) }
                    var selectedCash by remember { mutableStateOf("cash") }
                    var paymentAmounts by remember { mutableStateOf(mapOf<Long, String>()) }
                    var message by remember { mutableStateOf("") }
                    val expenseAccounts = accounts.filter { it.isActive && it.isPosting && it.type == "expense" }
                    val currentMonth = java.time.YearMonth.now()
                    val now = System.currentTimeMillis()
                    val dateNow = java.time.Instant.ofEpochMilli(now).atZone(java.time.ZoneId.systemDefault()).toLocalDate()
                    val periodKey = currentMonth.toString()
                    LaunchedEffect(expenseAccounts) { if (selectedExpenseAccount == 0L) selectedExpenseAccount = expenseAccounts.firstOrNull()?.id ?: 0L }
                    LaunchedEffect(cashAccounts) { if (cashAccounts.none { it.id == selectedCash }) selectedCash = cashAccounts.firstOrNull()?.id ?: "cash" }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("تسجيل فاتورة مصروف جديدة", style = MaterialTheme.typography.titleMedium)
                            OutlinedTextField(title, { title = it }, label = { Text("بيان المصروف / الفاتورة") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(amount, { amount = it }, label = { Text("قيمة الفاتورة بالجنيه") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                            var accountMenu by remember { mutableStateOf(false) }
                            Box {
                                OutlinedButton(onClick = { accountMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(expenseAccounts.firstOrNull { it.id == selectedExpenseAccount }?.let { "${it.code} — ${it.name}" } ?: "اختر حساب المصروف") }
                                DropdownMenu(expanded = accountMenu, onDismissRequest = { accountMenu = false }) { expenseAccounts.forEach { a -> DropdownMenuItem(text = { Text("${a.code} — ${a.name}") }, onClick = { selectedExpenseAccount = a.id; accountMenu = false }) } }
                            }
                            OutlinedTextField(vendorName, { vendorName = it }, label = { Text("اسم المورد (اختياري)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            Button(onClick = {
                                val cents = amount.trim().replace(',', '.').toBigDecimalOrNull()?.movePointRight(2)?.setScale(0, java.math.RoundingMode.HALF_UP)?.longValueExact()
                                if (title.isBlank() || cents == null || cents <= 0 || selectedExpenseAccount == 0L) { message = "أدخل البيان والقيمة واختر حساب المصروف" }
                                else {
                                    screenScope.launch {
                                        runCatching {
                                            val vendorId = if (vendorName.isBlank()) null else dao.insertVendor(AccountingVendor(name = vendorName.trim()))
                                            dao.recordAccruedExpense(AccountingExpense(title=title.trim(), categoryAccountId=selectedExpenseAccount, vendorId=vendorId, documentDate=now, dueDate=now, amountPiasters=cents, periodKey=periodKey))
                                        }.onSuccess { title = ""; amount = ""; vendorName = ""; message = "تم تسجيل الفاتورة وإثبات الاستحقاق محاسبيًا" }.onFailure { message = it.message ?: "تعذر التسجيل" }
                                    }
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text("حفظ الفاتورة وترحيل الاستحقاق") }
                            if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
                            Text("ملاحظة: الفاتورة تثبت كاستحقاق أولًا، ولا تخصم من الخزينة إلا عند تسجيل دفعة فعلية.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Text("الفواتير المسجلة (${expenses.size})", style = MaterialTheme.typography.titleMedium)
                    expenses.forEach { expense ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(expense.title, style = MaterialTheme.typography.titleSmall)
                                Text("الإجمالي: ${Money.format(expense.amountPiasters)} • المدفوع: ${Money.format(expense.paidPiasters)} • المتبقي: ${Money.format(expense.amountPiasters-expense.paidPiasters)}")
                                Text("الحالة: ${when(expense.status){"paid"->"مدفوعة";"partial"->"مدفوعة جزئيًا";else->"مستحقة"}} • ${expense.periodKey}", style = MaterialTheme.typography.bodySmall)
                                if (expense.status == "unpaid" || expense.status == "partial") {
                                    OutlinedTextField(paymentAmounts[expense.id] ?: "", { paymentAmounts = paymentAmounts + (expense.id to it) }, label = { Text("قيمة الدفعة بالجنيه") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                                    var cashMenu by remember(expense.id) { mutableStateOf(false) }
                                    Box {
                                        OutlinedButton(onClick = { cashMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(cashAccounts.firstOrNull { it.id == selectedCash }?.name ?: "اختر حساب الصرف") }
                                        DropdownMenu(expanded = cashMenu, onDismissRequest = { cashMenu = false }) { cashAccounts.forEach { c -> DropdownMenuItem(text = { Text(c.name) }, onClick = { selectedCash = c.id; cashMenu = false }) } }
                                    }
                                    Button(onClick = {
                                        val piasters = (paymentAmounts[expense.id] ?: "").trim().replace(',', '.').toBigDecimalOrNull()?.movePointRight(2)?.setScale(0, java.math.RoundingMode.HALF_UP)?.toLong()
                                        if (piasters == null || piasters <= 0) message = "أدخل قيمة دفعة صحيحة" else screenScope.launch {
                                            runCatching { dao.recordExpensePayment(expense.id, piasters, selectedCash, "cash") }
                                                .onSuccess { paymentAmounts = paymentAmounts - expense.id; message = "تم تسجيل السداد وترحيل قيده" }
                                                .onFailure { message = it.message ?: "تعذر تسجيل السداد" }
                                        }
                                    }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل دفعة وترحيلها") }
                                }
                            }
                        }
                    }
                }
                "income" -> {
                    val revenue = trialBalance.filter { it.type == "revenue" }.sumOf { (it.creditPiasters - it.debitPiasters).coerceAtLeast(0L) }
                    val expensesTotal = trialBalance.filter { it.type == "expense" }.sumOf { (it.debitPiasters - it.creditPiasters).coerceAtLeast(0L) }
                    val net = revenue - expensesTotal
                    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("قائمة الدخل — منذ بداية السجلات المرحلة", style = MaterialTheme.typography.titleMedium)
                        Text("الإيرادات: ${Money.format(revenue)}")
                        Text("المصروفات: ${Money.format(expensesTotal)}")
                        HorizontalDivider()
                        Text("${if (net >= 0) "صافي الربح" else "صافي الخسارة"}: ${Money.format(kotlin.math.abs(net))}", style = MaterialTheme.typography.titleLarge, color = if (net >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                        Text("تعرض القائمة القيود المرحلة فقط، ولا تعتبر نهائية قبل استكمال ترحيل جميع مصادر الإيراد والمرتبات والأرصدة الافتتاحية.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } }
                }
                "position" -> {
                    val assets = trialBalance.filter { it.type == "asset" }.sumOf { (it.debitPiasters - it.creditPiasters).coerceAtLeast(0L) }
                    val liabilities = trialBalance.filter { it.type == "liability" }.sumOf { (it.creditPiasters - it.debitPiasters).coerceAtLeast(0L) }
                    val equity = trialBalance.filter { it.type == "equity" }.sumOf { (it.creditPiasters - it.debitPiasters).coerceAtLeast(0L) }
                    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("المركز المالي — أرصدة القيود المرحلة", style = MaterialTheme.typography.titleMedium)
                        Text("الأصول: ${Money.format(assets)}")
                        Text("الالتزامات: ${Money.format(liabilities)}")
                        Text("حقوق الملكية: ${Money.format(equity)}")
                        Text("فرق المعادلة: ${Money.format(assets - liabilities - equity)}", color = if (assets == liabilities + equity) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                        Text("تقرير مبدئي؛ لا يعتمد كميزانية معتمدة قبل إدخال الأرصدة الافتتاحية واستكمال الترحيل وإقفال الفترة.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } }
                }
                "trial" -> {
                    val debit = trialBalance.sumOf { it.debitPiasters }
                    val credit = trialBalance.sumOf { it.creditPiasters }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("إجمالي المدين: ${Money.format(debit)}")
                            Text("إجمالي الدائن: ${Money.format(credit)}")
                            Text(if (debit == credit) "الميزان متوازن" else "يوجد فرق يحتاج إلى مراجعة", color = if (debit == credit) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                        }
                    }
                    trialBalance.forEach { row ->
                        ListItem(
                            headlineContent = { Text("${row.code} — ${row.name}", maxLines = 2) },
                            supportingContent = { Text(accountTypeLabel(row.type)) },
                            trailingContent = { Text("${Money.format(row.debitPiasters)} / ${Money.format(row.creditPiasters)}") }
                        )
                        HorizontalDivider()
                    }
                }
                "ledger" -> {
                    val posting = accounts.filter { it.isActive && it.isPosting }
                    var accountMenu by remember { mutableStateOf(false) }
                    LaunchedEffect(posting) { if (posting.none { it.id == ledgerAccountId }) ledgerAccountId = posting.firstOrNull()?.id ?: 0L }
                    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("كشف حساب تفصيلي", style = MaterialTheme.typography.titleMedium)
                        Box {
                            OutlinedButton(onClick = { accountMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(posting.firstOrNull { it.id == ledgerAccountId }?.let { "${it.code} — ${it.name}" } ?: "اختر الحساب") }
                            DropdownMenu(expanded = accountMenu, onDismissRequest = { accountMenu = false }) { posting.forEach { a -> DropdownMenuItem(text = { Text("${a.code} — ${a.name}") }, onClick = { ledgerAccountId = a.id; accountMenu = false }) } }
                        }
                        val selected = posting.firstOrNull { it.id == ledgerAccountId }
                        val debit = ledgerRows.sumOf { it.debitPiasters }
                        val credit = ledgerRows.sumOf { it.creditPiasters }
                        val balance = if (selected?.type in listOf("asset", "expense")) debit - credit else credit - debit
                        Text("إجمالي المدين: ${Money.format(debit)} • إجمالي الدائن: ${Money.format(credit)}")
                        Text("الرصيد الصافي: ${Money.format(kotlin.math.abs(balance))} ${if (balance >= 0) if (selected?.type in listOf("asset", "expense")) "مدين" else "دائن" else if (selected?.type in listOf("asset", "expense")) "دائن" else "مدين"}", style = MaterialTheme.typography.titleSmall)
                    } }
                    if (ledgerRows.isEmpty()) Text("لا توجد حركات مرحلة على هذا الحساب.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    ledgerRows.forEach { row ->
                        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("${row.entryNo} • ${row.description}", style = MaterialTheme.typography.titleSmall)
                            Text(java.time.Instant.ofEpochMilli(row.entryDate).atZone(java.time.ZoneId.systemDefault()).toLocalDate().toString(), style = MaterialTheme.typography.bodySmall)
                            Text(row.memo)
                            Text("مدين ${Money.format(row.debitPiasters)} • دائن ${Money.format(row.creditPiasters)}")
                        } }
                    }
                }
                "vendors" -> {
                    var name by remember { mutableStateOf("") }
                    var phone by remember { mutableStateOf("") }
                    var tax by remember { mutableStateOf("") }
                    var address by remember { mutableStateOf("") }
                    var note by remember { mutableStateOf("") }
                    var vendorMessage by remember { mutableStateOf("") }
                    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("إضافة مورد", style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(name, { name = it }, label = { Text("اسم المورد") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(phone, { phone = it }, label = { Text("الهاتف") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(tax, { tax = it }, label = { Text("الرقم الضريبي") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(address, { address = it }, label = { Text("العنوان") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(note, { note = it }, label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth())
                        Button(onClick = { if (name.isBlank()) vendorMessage = "اسم المورد مطلوب" else screenScope.launch { runCatching { dao.insertVendor(AccountingVendor(name = name.trim(), phone = phone.trim(), taxNumber = tax.trim(), address = address.trim(), notes = note.trim())) }.onSuccess { name = ""; phone = ""; tax = ""; address = ""; note = ""; vendorMessage = "تم حفظ المورد" }.onFailure { vendorMessage = it.message ?: "تعذر حفظ المورد" } } }, modifier = Modifier.fillMaxWidth()) { Text("حفظ المورد") }
                        if (vendorMessage.isNotBlank()) Text(vendorMessage, color = MaterialTheme.colorScheme.primary)
                    } }
                    Text("الموردون النشطون (${vendors.size})", style = MaterialTheme.typography.titleMedium)
                    vendors.forEach { vendor ->
                        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                            Text(vendor.name, style = MaterialTheme.typography.titleSmall)
                            Text(listOf(vendor.phone, vendor.taxNumber, vendor.address).filter { it.isNotBlank() }.joinToString(" • "))
                            if (vendor.notes.isNotBlank()) Text(vendor.notes, style = MaterialTheme.typography.bodySmall)
                            TextButton(onClick = { screenScope.launch { dao.updateVendor(vendor.copy(isActive = false)) } }) { Text("أرشفة المورد") }
                        } }
                    }
                }
                "periods" -> {
                    var periodNote by remember { mutableStateOf("") }
                    var cutoff by remember { mutableStateOf(java.time.LocalDate.now().toString()) }
                    var approval by remember { mutableStateOf("") }
                    var openingValues by remember { mutableStateOf(mapOf<Long, String>()) }
                    var openingDebit by remember { mutableStateOf(mapOf<Long, Boolean>()) }
                    var periodMessage by remember { mutableStateOf("") }
                    Text("إدارة الفترات المحاسبية", style = MaterialTheme.typography.titleMedium)
                    periods.forEach { period ->
                        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(period.periodKey, style = MaterialTheme.typography.titleSmall)
                            Text(if (period.status == "open") "مفتوحة" else "مغلقة")
                            if (period.note.isNotBlank()) Text("ملاحظة: ${period.note}", style = MaterialTheme.typography.bodySmall)
                            OutlinedTextField(periodNote, { periodNote = it }, label = { Text("سبب الإغلاق / إعادة الفتح") }, modifier = Modifier.fillMaxWidth())
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (period.status == "open") Button(onClick = { screenScope.launch { runCatching { dao.closePeriod(period.periodKey, periodNote) }.onSuccess { periodNote = ""; periodMessage = "تم إغلاق ${period.periodKey}" }.onFailure { periodMessage = it.message ?: "تعذر الإغلاق" } } }) { Text("إغلاق الفترة") }
                                else Button(onClick = { screenScope.launch { runCatching { dao.reopenPeriod(period.periodKey, periodNote) }.onSuccess { periodNote = ""; periodMessage = "تمت إعادة فتح ${period.periodKey}" }.onFailure { periodMessage = it.message ?: "تعذر إعادة الفتح" } } }) { Text("إعادة فتح") }
                            }
                        } }
                    }
                    if (periodMessage.isNotBlank()) Text(periodMessage, color = MaterialTheme.colorScheme.primary)
                    HorizontalDivider()
                    Text("ترحيل الأرصدة الافتتاحية", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(cutoff, { cutoff = it }, label = { Text("تاريخ القطع YYYY-MM-DD") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(approval, { approval = it }, label = { Text("مصدر الأرصدة / مرجع الاعتماد") }, modifier = Modifier.fillMaxWidth())
                    accounts.filter { it.isActive && it.isPosting }.forEach { account ->
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("${account.code} — ${account.name}", style = MaterialTheme.typography.bodyMedium)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(openingValues[account.id] ?: "", { openingValues = openingValues + (account.id to it) }, label = { Text("الرصيد بالجنيه") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                                FilterChip(selected = openingDebit[account.id] != false, onClick = { openingDebit = openingDebit + (account.id to true) }, label = { Text("مدين") })
                                FilterChip(selected = openingDebit[account.id] == false, onClick = { openingDebit = openingDebit + (account.id to false) }, label = { Text("دائن") })
                            }
                        }
                    }
                    Button(onClick = { screenScope.launch {
                        runCatching {
                            val date = java.time.LocalDate.parse(cutoff).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
                            val ym = java.time.YearMonth.from(java.time.Instant.ofEpochMilli(date).atZone(java.time.ZoneId.systemDefault()).toLocalDate())
                            val start = ym.atDay(1).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
                            val end = ym.atEndOfMonth().plusDays(1).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli() - 1L
                            dao.ensurePeriod(ym.toString(), start, end)
                            val drafts = accounts.filter { it.isActive && it.isPosting }.mapNotNull { account ->
                                val amount = (openingValues[account.id] ?: "").trim().replace(',', '.').toBigDecimalOrNull()?.movePointRight(2)?.setScale(0, java.math.RoundingMode.HALF_UP)?.longValueExact() ?: 0L
                                if (amount <= 0L) null else if (openingDebit[account.id] != false) com.tahseel.students.data.JournalLineDraft(account.id, debitPiasters = amount, memo = "رصيد افتتاحي") else com.tahseel.students.data.JournalLineDraft(account.id, creditPiasters = amount, memo = "رصيد افتتاحي")
                            }
                            dao.postOpeningBalances(date, drafts, approval)
                        }.onSuccess { openingValues = emptyMap(); approval = ""; periodMessage = "تم ترحيل قيد الأرصدة الافتتاحية" }.onFailure { periodMessage = it.message ?: "تعذر ترحيل الأرصدة" }
                    } }, modifier = Modifier.fillMaxWidth()) { Text("اعتماد وترحيل الأرصدة الافتتاحية") }
                    Text("يجب إدخال الأرصدة الفعلية فقط. النظام لن ينشئ حساب موازنة أو يختلق فرقًا لإجبار القيد على التوازن.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun SummaryTile(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Text(value, style = MaterialTheme.typography.headlineSmall)
        Text(title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    } }
}

private fun accountTypeLabel(type: String) = when (type) {
    "asset" -> "أصول"; "liability" -> "التزامات"; "equity" -> "حقوق ملكية"; "revenue" -> "إيرادات"; "expense" -> "مصروفات"; else -> type
}

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
@Composable
fun FinancePayrollScreen(hrDao: com.tahseel.students.data.HrDao, onBack: () -> Unit) {
    val month = remember { kotlinx.coroutines.flow.MutableStateFlow(java.time.YearMonth.now()) }
    val selected by month.collectAsState()
    val payroll by month.flatMapLatest { hrDao.observePayroll(it.toString()) }.collectAsState(initial = emptyList())
    val employees by hrDao.observeEmployees().collectAsState(initial = emptyList())
    val payments by month.flatMapLatest { hrDao.observePayrollPayments(it.toString()) }.collectAsState(initial = emptyList())
    val names = employees.associate { it.id to it.fullName }
    val total = payroll.sumOf { it.netPiasters }
    val paid = payroll.sumOf { row -> payments.filter { it.payrollId == row.id && it.status == "active" }.sumOf { it.amountPiasters } }
    AppScaffold(title = "المرتبات — الإدارة المالية", onBack = onBack) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { month.value = selected.minusMonths(1) }) { Text("‹ السابق") }
                    Text(selected.toString(), style = MaterialTheme.typography.titleLarge)
                    TextButton(onClick = { month.value = selected.plusMonths(1) }) { Text("التالي ›") }
                }
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("إجمالي صافي المرتبات: ${Money.format(total)}")
                    Text("المدفوع فعليًا: ${Money.format(paid)}")
                    Text("المتبقي: ${Money.format((total - paid).coerceAtLeast(0L))}")
                    Text("مصدر بيانات الرواتب: شؤون العاملين — لا يتم إنشاء كشف راتب مكرر هنا.", style = MaterialTheme.typography.bodySmall)
                } }
            }
            items(payroll, key = { it.id }) { row ->
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(names[row.employeeId] ?: "موظف #${row.employeeId}", style = MaterialTheme.typography.titleSmall)
                    Text("الصافي: ${Money.format(row.netPiasters)} • المدفوع: ${Money.format(payments.filter { it.payrollId == row.id && it.status == "active" }.sumOf { it.amountPiasters })}")
                    Text("المتبقي: ${Money.format((row.netPiasters - payments.filter { it.payrollId == row.id && it.status == "active" }.sumOf { it.amountPiasters }).coerceAtLeast(0L))}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } }
            }
        }
    }
}
