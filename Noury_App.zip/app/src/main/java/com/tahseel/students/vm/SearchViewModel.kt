package com.tahseel.students.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tahseel.students.data.Student
import com.tahseel.students.data.StudentDao
import com.tahseel.students.util.TextUtil
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

class SearchViewModel(studentsDao: StudentDao) : ViewModel() {
    val query = MutableStateFlow("")
    val results: StateFlow<List<Student>> = combine(studentsDao.observeAll(), query) { students, q ->
        val name = TextUtil.normalize(q)
        val phone = normalizeDigits(q)
        if (q.isBlank()) emptyList() else students.filter { student ->
            (name.isNotEmpty() && TextUtil.normalize(student.fullName).contains(name)) ||
                (phone.isNotEmpty() && normalizeDigits(student.motherWhatsapp).contains(phone))
        }.sortedBy { TextUtil.normalize(it.fullName) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private fun normalizeDigits(value: String): String = value.map { ch -> when (ch) {
        in '٠'..'٩' -> ('0'.code + (ch - '٠')).toChar()
        in '۰'..'۹' -> ('0'.code + (ch - '۰')).toChar()
        else -> ch
    } }.filter { it.isDigit() }.joinToString("")
}
