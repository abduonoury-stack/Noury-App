package com.tahseel.students.data

/** Cash collected from valid receipts in a period; cancelled receipts never affect cash totals. */
fun sumValidReceiptAmounts(payments: List<Payment>): Long =
    payments.asSequence()
        .filterNot { it.isCancelled }
        .sumOf { it.amountPiasters.coerceAtLeast(0L) }

/** Net cash movement is based on all valid receipts, not subscription-only collections. */
fun netCashMovement(validReceiptCollections: Long, expensesPaid: Long): Long =
    validReceiptCollections.coerceAtLeast(0L) - expensesPaid.coerceAtLeast(0L)
