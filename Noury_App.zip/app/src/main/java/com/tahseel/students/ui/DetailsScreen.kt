package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.util.Money
import com.tahseel.students.util.TimeUtil
import com.tahseel.students.vm.DetailsViewModel
import com.tahseel.students.vm.FormEvent
import kotlinx.coroutines.launch

@Composable
fun DetailsScreen(vm: DetailsViewModel, onBack: () -> Unit, onEdit: (Long) -> Unit, onStudentProfile: (Long) -> Unit) {
    val p by vm.payment.collectAsStateWithLifecycle()
    var confirm by remember { mutableStateOf(false) }
    var cancellationReason by remember { mutableStateOf("") }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        vm.events.collect { e ->
            when (e) {
                FormEvent.Done -> onBack()
                is FormEvent.Message -> scope.launch { snack.showSnackbar(e.text) }
            }
        }
    }

    AppScaffold("تفاصيل العملية", onBack, snackbarHost = { SnackbarHost(snack) }) { pad ->
        val cur = p
        if (cur == null) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.fillMaxWidth().clickable(enabled = cur.studentId != null) { cur.studentId?.let(onStudentProfile) }) { StatCard("اسم الطالب", cur.studentName, Modifier.fillMaxWidth()); if (cur.studentId != null) Text("اضغط لفتح ملف الطالب", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall) }
                StatCard("رقم الإيصال", cur.receiptNo, Modifier.fillMaxWidth())
                StatCard("المبلغ", Money.format(cur.amountPiasters), Modifier.fillMaxWidth(), big = true)
                StatCard("التاريخ والوقت", TimeUtil.fmt(cur.createdAt), Modifier.fillMaxWidth())
                if (cur.isCancelled) {
                    Text("هذه العملية ملغاة ولا تدخل ضمن إجماليات الإيرادات.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.titleMedium)
                    if (cur.cancellationReason.isNotBlank()) Text("سبب الإلغاء: ${cur.cancellationReason}")
                    cur.cancelledAt?.let { Text("تاريخ الإلغاء: ${TimeUtil.fmt(it)}") }
                } else {
                    Spacer(Modifier.height(4.dp))
                    BigButton("تعديل العملية", Icons.Default.Edit, { onEdit(cur.id) })
                    BigButton("إلغاء العملية", Icons.Default.Delete, { confirm = true }, primary = false)
                }
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("تأكيد إلغاء العملية") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("سيتم استبعاد المبلغ من إجماليات الإيرادات، مع الاحتفاظ بالعملية والإيصال وسجل الإلغاء. لا يمكن التراجع عن الإلغاء من هذه الشاشة.")
                    OutlinedTextField(
                        value = cancellationReason,
                        onValueChange = { cancellationReason = it },
                        label = { Text("سبب الإلغاء (اختياري)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = { TextButton(onClick = { confirm = false; vm.cancel(cancellationReason) }) { Text("تأكيد الإلغاء", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("إلغاء") } }
        )
    }
}
