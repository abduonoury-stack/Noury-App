package com.tahseel.students.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tahseel.students.data.CashAccount
import com.tahseel.students.data.CashAccountDao
import com.tahseel.students.data.CashTransferDao
import com.tahseel.students.data.CashTransfer
import com.tahseel.students.util.Money
import java.time.LocalDate
import java.time.ZoneId
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
fun CashAccountsScreen(dao: CashAccountDao, transferDao: CashTransferDao, onBack: () -> Unit) {
    val accounts by dao.observeAll().collectAsStateWithLifecycle(emptyList())
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("bank") }
    var fromId by remember { mutableStateOf("cash") }
    var toId by remember { mutableStateOf("") }
    var transferAmount by remember { mutableStateOf("") }
    var transferDate by remember { mutableStateOf(LocalDate.now().toString()) }
    var transferNote by remember { mutableStateOf("") }
    var transferMessage by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    AppScaffold("حسابات النقدية والبنوك", onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("كل حساب له رصيد مستقل. التحصيل أو الصرف يُسجل على الحساب المختار فقط، والتحويل بين الحسابات لا يُعد إيرادًا أو مصروفًا.", style = MaterialTheme.typography.bodyMedium)
            Card { Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("إضافة حساب", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(name, { name = it.take(60) }, label = { Text("اسم الحساب") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = type == "bank", onClick = { type = "bank" }, label = { Text("بنك") })
                    FilterChip(selected = type == "wallet", onClick = { type = "wallet" }, label = { Text("محفظة") })
                    FilterChip(selected = type == "electronic", onClick = { type = "electronic" }, label = { Text("إلكتروني") })
                }
                Button(onClick = {
                    val clean = name.trim()
                    if (clean.isNotBlank()) scope.launch {
                        dao.insert(CashAccount(id = "${type}_${UUID.randomUUID()}", name = clean, type = type))
                        name = ""
                    }
                }, enabled = name.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("إضافة الحساب") }
            } }
            Card { Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("تحويل بين الحسابات", style = MaterialTheme.typography.titleMedium)
                CashAccountDropdown(accounts = accounts.filter { it.isActive }, selectedId = fromId, onSelected = { fromId = it }, label = "من حساب")
                CashAccountDropdown(accounts = accounts.filter { it.isActive }, selectedId = toId, onSelected = { toId = it }, label = "إلى حساب")
                OutlinedTextField(transferAmount, { transferAmount = it }, label = { Text("المبلغ بالجنيه") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(transferDate, { transferDate = it }, label = { Text("تاريخ التحويل YYYY-MM-DD") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(transferNote, { transferNote = it }, label = { Text("رقم مرجعي / ملاحظات") }, modifier = Modifier.fillMaxWidth())
                if (transferMessage.isNotBlank()) Text(transferMessage, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Button(onClick = {
                    val amount = Money.parse(transferAmount)
                    val date = runCatching { LocalDate.parse(transferDate) }.getOrNull()
                    val from = accounts.firstOrNull { it.id == fromId && it.isActive }
                    val to = accounts.firstOrNull { it.id == toId && it.isActive }
                    when {
                        from == null || to == null -> transferMessage = "اختر حسابين نشطين"
                        fromId == toId -> transferMessage = "لا يمكن التحويل إلى الحساب نفسه"
                        amount == null || amount <= 0L -> transferMessage = "أدخل مبلغًا صحيحًا أكبر من صفر"
                        date == null -> transferMessage = "تاريخ التحويل غير صحيح"
                        else -> scope.launch {
                            runCatching { transferDao.record(CashTransfer(fromAccountId = fromId, toAccountId = toId, amountPiasters = amount, transferredAt = date.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli(), note = transferNote.trim())) }
                                .onSuccess { transferAmount = ""; transferNote = ""; transferMessage = "" }
                                .onFailure { transferMessage = it.message ?: "تعذر تسجيل التحويل" }
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل التحويل") }
                Text("التحويل يسجل خصمًا من الحساب الأول وإضافة للحساب الثاني بالقيمة نفسها، ولا يدخل ضمن الإيرادات أو المصروفات التشغيلية.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } }
            Text("الحسابات المسجلة", style = MaterialTheme.typography.titleMedium)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(accounts, key = { it.id }) { account ->
                    Card { Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(account.name, style = MaterialTheme.typography.titleSmall)
                            Text(when (account.type) { "cash" -> "نقدية"; "bank" -> "حساب بنكي"; "wallet" -> "محفظة إلكترونية"; else -> "وسيلة إلكترونية" }, style = MaterialTheme.typography.bodySmall)
                        }
                        if (account.id != "cash") {
                            TextButton(onClick = { scope.launch { dao.setActive(account.id, !account.isActive) } }) { Text(if (account.isActive) "تعطيل" else "تفعيل") }
                        } else Text("أساسي", color = MaterialTheme.colorScheme.primary)
                    } }
                }
            }
        }
    }
}
