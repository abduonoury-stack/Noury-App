# تحديث 2.2.65 — إصلاح فشل ترجمة أيقونة الإدارة المالية

## سبب الفشل
كان `DashboardScreen.kt` يستخدم `Icons.Default.AccountBalance` في بطاقة الإدارة المالية دون استيراد `androidx.compose.material.icons.filled.AccountBalance`، ففشل Kotlin عند `compileDebugKotlin` برسالة `Unresolved reference: AccountBalance`.

## الإصلاح
- إضافة الاستيراد الناقص إلى `DashboardScreen.kt`.
- لا تغيير في منطق الشاشة أو قاعدة البيانات أو بيانات المستخدم.
- رفع versionCode إلى 84 وversionName إلى 2.2.65.

## حالة التحقق
تم فحص أن الأيقونة مستخدمة ومستوردَة في `AccountingScreen.kt` ضمن المشروع نفسه. لم يتم تشغيل بناء Gradle محليًا في هذه البيئة؛ يجب إعادة تشغيل GitHub Actions للتحقق من نجاح `compileDebugKotlin` وباقي الاختبارات.
